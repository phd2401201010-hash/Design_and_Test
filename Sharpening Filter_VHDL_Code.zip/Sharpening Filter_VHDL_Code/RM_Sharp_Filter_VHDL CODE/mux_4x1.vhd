library ieee;
use ieee.std_logic_1164.all;

entity mux_4x1 is
Port(I0, I1, I2, I3 : in std_logic_vector(15 downto 0);
	S : in std_logic_vector(1 downto 0);
	Yout : out std_logic_vector(15 downto 0));
end mux_4x1;

architecture behavioral of mux_4x1 is
begin
process(I0, I1, I2, I3, S)
begin
	if(S= "00") then
		Yout <= I0;
	elsif(S="01") then
		Yout <= I1;
	elsif(S="10") then
	   Yout <= I2;
	else 
		Yout <= I3;
	end if;
end process;
end behavioral;
		