Library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;

entity sharpening_filter is
Port(V1,V2,V3,V4,V5,V6,V7,V8,V9,V10,V11,V12,V13,V14,V15,V16,V17,V18,V19,V20,V21,V22 : in std_logic_vector(15 downto 0); --primary inputs
	 RMS,RDS,IMS,IDS,LIMS,LIDS,BMS,BDS,MMS,MDS,AMS,ADS,CMS,CDS,NMS,NDS,GLMS,GLDS : std_logic; --selection lines of 2x1/1x2 mux/demux of red, khaki, indigo, lime, blue, maroon, Aqua, Crimson, Navy, gold
	 WMS,WDS: STD_logic_vector(1 downto 0); --selection line of 4X1/1x4 mux/demux of wheat
	 RR,KR,IR,LIR,BR,PR,MR,AR,CR,NR,GLR,WR,ORR,GYR,TR,OLR,GR,LR,SR,YR,SALR,TAR: in std_logic; --register enable pin for all registers
	 KMS,KDS,PMS,PDS: in std_logic_vector(2 downto 0); -- selection lines of 8x1/1x8 mux/demux of khaki, purple
	 KTMS,KTDS: in std_logic; -- selection lines for trojan path 2x1/1x2 mux/demux of khaki
	 RTMS,RTDS,PTMS,PTDS: in std_logic_vector(2 downto 0); --selection lines for trojan path 8x1/1x8 mux/demux of red,purple
	 ITMS,ITDS,LITMS,LITDS: in std_logic_vector(1 downto 0); --selection lines for trojan path 4x1/1x4 mux/demux of indigo, lime
	 TTS: in std_logic; --selection line for trojan triggered 2x1/1x2 mux/demux
	 L1,L2,L3,L4,L5,L6,L7,L8,L9,L10,L11,L12,L13,L14,L15,L16,L17,L18: in std_logic;--latch enable pin
	 A1S1,A1S2,A1S3,A2S1,A2S2,A2S3 : in std_logic_vector(2 downto 0);--selection line(adders) for 8x1/1x8 mux/demux of A1,A2 adders
	 A3S1,A3S2,A3S3,A4S1,A4S2,A4S3 : in std_logic_vector(1 downto 0);--selection line(adders) for 4x1/1x4 mux/demux of A3,A4 adders
	 ML1S1,ML1S2,ML1S3,ML2S1,ML2S2,ML2S3 : in std_logic ; -- selection line(multiplier) for 2x1/1x2 mux/demux of M1,M2 multiplier 
	 OP1_1,OP1_2,OP2_1,OP2_2 : out std_logic_vector(15 downto 0));--final output
end sharpening_filter;

architecture structural of sharpening_filter is

component adder is
Port(A,B : in std_logic_vector(15 downto 0);
	O : out std_logic_vector(15 downto 0));
end component;

component multiplier is
Port(A,B : in std_logic_vector(15 downto 0);
	O : out std_logic_vector(15 downto 0));
end component;

component mux_2x1 is
Port(I0,I1 : in std_logic_vector(15 downto 0);
	S : in std_logic;
	Yout : out std_logic_vector(15 downto 0));
end component;

component mux_4x1 is
Port(I0,I1,I2,I3 : in std_logic_vector(15 downto 0);
	S : in std_logic_vector(1 downto 0);
	Yout : out std_logic_vector(15 downto 0)); 
end component;

component mux_8x1 is
Port(I0,I1,I2,I3,I4,I5,I6,I7 : in std_logic_vector(15 downto 0);
	S : in std_logic_vector(2 downto 0);
	Yout : out std_logic_vector(15 downto 0)); 
end component;

component demux_1x2 is
Port(Yin: in std_logic_vector(15 downto 0);
	S : in std_logic;
	I0,I1 : out std_logic_vector(15 downto 0)); 
end component;

component demux_1x4 is
Port(Yin: in std_logic_vector(15 downto 0);
	S : in std_logic_vector(1 downto 0);
	I0,I1,I2,I3 : out std_logic_vector(15 downto 0)); 
end component;

component demux_1x8 is
Port(Yin: in std_logic_vector(15 downto 0);
	S : in std_logic_vector(2 downto 0);
	I0,I1,I2,I3,I4,I5,I6,I7 : out std_logic_vector(15 downto 0)); 
end component;

component reg is
Port(Rin : in std_logic_vector(15 downto 0);
	Ren : in std_logic;
	Ro : out std_logic_vector(15 downto 0));
end component;

component latch is
Port(Lin : in std_logic_vector(15 downto 0);
	Len : in std_logic;
	Lo : out std_logic_vector(15 downto 0));
end component;

Signal S1,S2,S3,S4,S5,S6,S7,S8,S9,S10,S11,S12,S13,S14,S15,S16,S17,S18,S19,S20  : std_logic_vector(15 downto 0);
Signal S21,S22,S23,S24,S25,S26,S27,S28,S29,S30,S31,S32,S33,S34,S35,S36,S37,S38,S39,S40  : std_logic_vector(15 downto 0);
Signal S41,S42,S43,S44,S45,S46,S47,S48,S49,S50,S51,S52,S53,S54,S55,S56,S57,S58,S59,S60,S61 : std_logic_vector(15 downto 0);
Signal S1_1,S1_2,S2_1,S2_2,S3_1,S3_2,S4_1,S4_2,S5_1,S5_2,S6_1,S6_2,S7_1,S7_2,S8_1,S8_2,S9_1,S9_2,S10_1,S10_2,S11_1,S11_2,S12_1,S12_2,S13_1,S13_2,S14_1,S14_2,S15_1,S15_2,S16_1,S16_2,S17_1,S17_2  : std_logic_vector(15 downto 0);

Signal F1,F2,F3,F4,F5,F6,F7,F8,F9,F10,F11,F12,F13,F14,F15,F16,F17,F18,F19,F20 : std_logic_vector(15 downto 0);--free signal pins
Signal F21,F22,F23,F24,F25,F26,F27,F28,F29,F30,F31,F32,F33,F34,F35,F36,F37,F38,F39,F40 : std_logic_vector(15 downto 0);--free signal pins
Signal F41,F42,F43,F44,F45,F46,F47,F48,F49,F50,F51,F52,F53,F54,F55,F56 ,F57,F58, F59: std_logic_vector(15 downto 0);--free signal pins

Signal M1,M2,M3,M4,M5,M6,M7,M8,M9,M10,M11,M12,M13,M14,M15,M16,M17,M18,M19,M20  : std_logic_vector(15 downto 0);
Signal M21,M22,M23,M24,M25,M26,M27,M28,M29,M30 : std_logic_vector(15 downto 0);
Signal M31,M32,M33,M34,M35,M36,M37,M38,M39,M40,M41,M42,M43,M44,M45,M46,M47,M48,M49,M50,M51  : std_logic_vector(15 downto 0);

Signal R1,R2,R3,R4,R5,R6,R7,R8,R9,R10,R11 : std_logic_vector(15 downto 0);

Signal L1out,L2out,L3out,L4out,L5out,L6out,L7out,L8out,L9out,L10out,L11out,L12out,L13out,L14out,L15out,L16out,L17out,L18out: std_logic_vector(15 downto 0);--latch enable pin

Signal A1,A2,A3,A4,ML1,ML2: std_logic_vector(15 downto 0);


begin

S1 <= S1_1 OR S1_2;
S2 <= S2_1 OR S2_2;
S3 <= S3_1 OR S3_2;
S4 <= S4_1 OR S4_2;
S5 <= S5_1 OR S5_2;
S6 <= S6_1 OR S6_2;
S7 <= S7_1 OR S7_2;
S8 <= S8_1 OR S8_2;
S9 <= S9_1 OR S9_2;
S10 <= S10_1 OR S10_2;
S11 <= S11_1 OR S11_2;
S12 <= S12_1 OR M24;
S13 <= S13_1 OR S13_2;
S14 <= S14_1 OR S14_2;
S15 <= S15_1 OR S15_2;
S16 <= S16_1 OR S16_2;
S17 <= S17_1 OR S17_2;






 
----------Red Register----------
L_1:mux_2x1 port map(I0=>V1,I1=>S57,S=>RMS,Yout=>M1);
TL_2:mux_8x1 port map(I0=>V1,I1=>S43,I2=>S44,I3=>S57,I4=>S45,I5=>F1,I6=>F2, I7=>F59, S=>RTMS,Yout=>M2); -- Trojan path mux/demux
TL_3:mux_2x1 port map(I0=>M1,I1=>M2,S=>TTS,Yout=>M3);
L_4:reg port map(Rin=>M3,Ren=>RR,Ro=>R1);
TL_5:demux_1x2 port map(Yin=>R1,S=>TTS,I0=>M4,I1=>M5);
L_6:demux_1x2 port map(Yin=>M4,S=>RDS,I0=>S1_1,I1=>S2_1);
TL_7:demux_1x8 port map(Yin=>M5, S=>RTDS,I0=>S1_2,I1=>S3_1,I2=>S4_1,I3=>S5_1,I4=>S2_2,I5=>OP2_1,I6=>F4,I7=>F5); -- Trojan path mux/demux
-----------Khaki Register-----------
L_8:mux_8x1 port map(I0=>V2,I1=>S41,I2=>S43,I3=>S44,I4=>S45,I5=>F6,I6=>F7,I7=>F8,S=>KMS,Yout=>M6); 
TL_9:mux_2x1 port map(I0=>V2,I1=>S41,S=>KTMS,Yout=>M7);-- Trojan path mux/demux
TL_10:mux_2x1 port map(I0=>M6,I1=>M7,S=>TTS,Yout=>M8);
L_11:reg port map(Rin=>M8,Ren=>KR,Ro=>R2);
TL_12:demux_1x2 port map(Yin=>R2,S=>TTS,I0=>M9,I1=>M10);
L_13:demux_1x8 port map(Yin=>M9, S=>KDS,I0=>S6_1,I1=>S3_2,I2=>S4_2,I3=>S5_2,I4=>OP1_1,I5=>F10,I6=>F11,I7=>F12); -- Trojan path mux/demux
TL_14:demux_1x2 port map(Yin=>M10,S=>KTDS,I0=>S6_2,I1=>F13); -- Trojan path mux/demux
-----------Indigo Register-----------
L_15:mux_2x1 port map(I0=>V3,I1=>S46,S=>IMS,Yout=>M11);
TL_16:mux_4x1 port map(I0=>V3,I1=>S46,I2=>S60,I3=>F15,S=>ITMS,Yout=>M12); -- Trojan path mux/demux
TL_17:mux_2x1 port map(I0=>M11,I1=>M12,S=>TTS,Yout=>M13);
L_18:reg port map(Rin=>M13,Ren=>IR,Ro=>R3);
TL_19:demux_1x2 port map(Yin=>R3,S=>TTS,I0=>M14,I1=>M15);
L_20:demux_1x2 port map(Yin=>M14,S=>IDS,I0=>S7_1,I1=>S8_1);
TL_21:demux_1x4 port map(Yin=>M15, S=>ITDS,I0=>S7_2,I1=>S8_2,I2=>OP2_2,I3=>F17); -- Trojan path mux/demux
-----------Lime Register-----------
L_22:mux_2x1 port map(I0=>V5,I1=>S48,S=>LIMS,Yout=>M16);
TL_23:mux_4x1 port map(I0=>V5,I1=>S50,I2=>S48,I3=>F18,S=>LITMS,Yout=>M17); -- Trojan path mux/demux
TL_24:mux_2x1 port map(I0=>M16,I1=>M17,S=>TTS,Yout=>M18);
L_25:reg port map(Rin=>M18,Ren=>LIR,Ro=>R4);
TL_26:demux_1x2 port map(Yin=>R4,S=>TTS,I0=>M19,I1=>M20);
L_27:demux_1x2 port map(Yin=>M19,S=>LIDS,I0=>S9_1,I1=>S10_1);
TL_28:demux_1x4 port map(Yin=>M20, S=>LITDS,I0=>S9_2,I1=>S11_1,I2=>OP2_2,I3=>F19); -- Trojan path mux/demux
-----------BLUE Register-----------
L_29:mux_2x1 port map(I0=>V6,I1=>S50,S=>BMS,Yout=>M21);
TL_30:mux_2x1 port map(I0=>M21,I1=>V6,S=>TTS,Yout=>M22);
L_31:reg port map(Rin=>M22,Ren=>BR,Ro=>R5);
TL_32:demux_1x2 port map(Yin=>R5,S=>TTS,I0=>M23,I1=>M24);
L_33:demux_1x2 port map(Yin=>M23,S=>BDS,I0=>S12_1,I1=>S11_1);
--L_34:--M24; -- Trojan path mux/demux
-----------PURPLE Register-----------
L_35:mux_8x1 port map(I0=>V12,I1=>S42,I2=>S52,I3=>S49,I4=>S59,I5=>S60,I6=>F20,I7=>F21,S=>PMS,Yout=>M25); 
TL_36:mux_8x1 port map(I0=>V12,I1=>S42,I2=>S52,I3=>S49,I4=>S59,I5=>F22,I6=>F23,I7=>F24,S=>PMS,Yout=>M26); 
TL_37:mux_2x1 port map(I0=>M25,I1=>M26,S=>TTS,Yout=>M27);
L_38:reg port map(Rin=>M27,Ren=>PR,Ro=>R6);
TL_39:demux_1x2 port map(Yin=>R6,S=>TTS,I0=>M28,I1=>M29);
L_40:demux_1x8 port map(Yin=>M28, S=>PDS,I0=>S13_1,I1=>S14_1,I2=>S15_1,I3=>S16_1,I4=>S17_1,I5=>OP1_2,I6=>F26,I7=>F27); -- Trojan path mux/demux
TL_41:demux_1x8 port map(Yin=>M29, S=>PDS,I0=>S13_2,I1=>S14_2,I2=>S15_2,I3=>S16_2,I4=>S17_2,I5=>F28,I6=>F29,I7=>F30); -- Trojan path mux/demux
-----------MAROON Register-----------
L_42:mux_2x1 port map(I0=>V7,I1=>S53,S=>MMS,Yout=>M30);
L_43:reg port map(Rin=>M30,Ren=>MR,Ro=>R7);
L_44:demux_1x2 port map(Yin=>R7,S=>MDS,I0=>S18,I1=>S19);
-----------AQUA Register-----------
L_45:mux_2x1 port map(I0=>V10,I1=>S56,S=>AMS,Yout=>M31);
L_46:reg port map(Rin=>M31,Ren=>AR,Ro=>R8);
L_47:demux_1x2 port map(Yin=>R8,S=>ADS,I0=>S20,I1=>S21);
-----------CRIMSON Register-----------
L_48:mux_2x1 port map(I0=>V14,I1=>S47,S=>CMS,Yout=>M32);
L_49:reg port map(Rin=>M32,Ren=>CR,Ro=>R9);
L_50:demux_1x2 port map(Yin=>R9,S=>CDS,I0=>S22,I1=>S23);
-----------NAVY Register-----------
L_51:mux_2x1 port map(I0=>V18,I1=>S54,S=>NMS,Yout=>M33);
L_52:reg port map(Rin=>M33,Ren=>NR,Ro=>R10);
L_53:demux_1x2 port map(Yin=>R10,S=>NDS,I0=>S24,I1=>S25);
-----------GOLD Register-----------
L_54:mux_2x1 port map(I0=>V21,I1=>S58,S=>GLMS,Yout=>M34);
L_55:reg port map(Rin=>M34,Ren=>GLR,Ro=>R11);
L_56:demux_1x2 port map(Yin=>R11,S=>GLDS,I0=>S26,I1=>S27);
-----------WHEAT Register-----------
L_57:mux_4x1 port map(I0=>V16,I1=>S51,I2=>S55,I3=>F31,S=>WMS,Yout=>M35); -- Trojan path mux/demux
L_58:reg port map(Rin=>M35,Ren=>WR,Ro=>R11);
L_59:demux_1x4 port map(Yin=>R11,S=>WDS,I0=>S28,I1=>S29,I2=>S30,I3=>F32);
-----------ORANGE Register-----------
L_60:reg port map(Rin=>V4,Ren=>ORR,Ro=>S31);
-----------GREY Register-----------
L_61:reg port map(Rin=>V8,Ren=>GYR,Ro=>S32);
-----------TEAL Register-----------
L_62:reg port map(Rin=>V8,Ren=>TR,Ro=>S33);
-----------OLIVE Register-----------
L_63:reg port map(Rin=>V11,Ren=>OLR,Ro=>S34);
-----------GREEN Register-----------
L_64:reg port map(Rin=>V13,Ren=>GR,Ro=>S35);
-----------LAVENDER Register-----------
L_65:reg port map(Rin=>V15,Ren=>LR,Ro=>S36);
-----------SLIVER Register-----------
L_66:reg port map(Rin=>V17,Ren=>SR,Ro=>S37);
-----------Yellow Register-----------
L_67:reg port map(Rin=>V19,Ren=>YR,Ro=>S38);
-----------SALMON Register-----------
L_68:reg port map(Rin=>V20,Ren=>SALR,Ro=>S39);
-----------TAN Register-----------
L_69:reg port map(Rin=>V22,Ren=>TAR,Ro=>S40);
----------Adder(A1)----------
L_70:mux_8x1 port map(I0=>S1,I1=>S13,I2=>S3,I3=>S4,I4=>S2,I5=>F33,I6=>F34,I7=>F35,S=>A1S1,Yout=>M36);
L_71:latch Port map(Lin=>M36,Len=>L1,Lo=>L1out);
L_72:mux_8x1 port map(I0=>S6,I1=>S35,I2=>S8,I3=>S10,I4=>S21,I5=>F36,I6=>F37,I7=>F38,S=>A1S2,Yout=>M37); 
L_73:latch Port map(Lin=>M37,Len=>L2,Lo=>L2out);
L_74:adder Port map(A=>L1out, B=>L2out,O=>A1);
L_75:latch Port map(Lin=>A1,Len=>L3,Lo=>L3out);
L_76:demux_1x8 port map(Yin=>L3out, S=>a1s3,I0=>S41,I1=>S42,I2=>S43,I3=>S44,I4=>S45,I5=>F39,I6=>F40,I7=>F41); -- Trojan path mux/demux
----------Adder(A2)----------
L_77:mux_8x1 port map(I0=>S7,I1=>S22,I2=>S11,I3=>S15,I4=>S17,I5=>F42,I6=>F43,I7=>F44,S=>A2S1,Yout=>M38);
L_78:latch Port map(Lin=>M38,Len=>L4,Lo=>L4out);
L_79:mux_8x1 port map(I0=>S31,I1=>S36,I2=>S19,I3=>S30,I4=>S27,I5=>F45,I6=>F46,I7=>F47,S=>A2S2,Yout=>M39); 
L_80:latch Port map(Lin=>M39,Len=>L5,Lo=>L5out);
L_81:adder Port map(A=>L4out, B=>L5out,O=>A2);
L_82:latch Port map(Lin=>A2,Len=>L6,Lo=>L6out);
L_83:demux_1x8 port map(Yin=>L6out, S=>a1s3,I0=>S46,I1=>S47,I2=>S48,I3=>S49,I4=>S60,I5=>F49,I6=>F50,I7=>F51); -- Trojan path mux/demux
----------Adder(A3)----------
L_84:mux_4x1 port map(I0=>S9,I1=>S29,I2=>S14,I3=>F52,S=>A3S1,Yout=>M40); 
L_85:latch Port map(Lin=>M40,Len=>L7,Lo=>L7out);
L_86:mux_4x1 port map(I0=>S12,I1=>S37,I2=>S23,I3=>F53,S=>A3S2,Yout=>M41);
L_87:latch Port map(Lin=>M41,Len=>L8,Lo=>L8out);
L_88:adder Port map(A=>L7out, B=>L8out,O=>A3);
L_89:latch Port map(Lin=>A3,Len=>L9,Lo=>L9out);
L_90:demux_1x4 port map(Yin=>L9out, S=>A3S3,I0=>S50,I1=>S51,I2=>S52,I3=>F54); -- Trojan path mux/demux
----------Adder(A4)----------
L_91:mux_4x1 port map(I0=>S18,I1=>S24,I2=>S28,I3=>F55,S=>A4S1,Yout=>M42); 
L_92:latch Port map(Lin=>M42,Len=>L10,Lo=>L10out);
L_93:mux_4x1 port map(I0=>S32,I1=>S38,I2=>S25,I3=>F56,S=>A4S2,Yout=>M43);
L_94:latch Port map(Lin=>M43,Len=>L11,Lo=>L11out);
L_95:adder Port map(A=>L10out, B=>L11out,O=>A4);
L_96:latch Port map(Lin=>A2,Len=>L12,Lo=>L12out);
L_97:demux_1x4 port map(Yin=>L12out, S=>A4S3,I0=>S53,I1=>S54,I2=>S55,I3=>F57); -- Trojan path mux/demux
-------------Multiplier(M1)-------------
L_98:mux_2x1 Port Map(I0=>S20,I1=>S5,S=>ML1S1,Yout=>M48);	
L_99:latch Port Map(Lin=>M48,Len=>L13,Lo=>L13out); 
L_100:mux_2x1 Port Map(I0=>S34,I1=>S33,S=>ML1S2,Yout=>M49);
L_101:latch Port Map(Lin=>M49,Len=>L14,Lo=>L14out); 
L_102:multiplier Port Map(A=>L13out,B=>L14out,O=>ML1);	
L_103:latch Port Map(Lin=>ML1,Len=>L15,Lo=>L15out); 
L_104:demux_1x2 Port Map(Yin=>L15out,S=>ML1S3,I0=>S56,I1=>S57);	
-------------Multiplier(M2)-------------
L_105:mux_2x1 Port Map(I0=>S26,I1=>S16,S=>ML2S1,Yout=>M50);	
L_106:latch Port Map(Lin=>M50,Len=>L16,Lo=>L16out); 
L_107:mux_2x1 Port Map(I0=>S40,I1=>S39,S=>ML2S2,Yout=>M51);
L_109:latch Port Map(Lin=>M51,Len=>L17,Lo=>L17out); 
L_110:multiplier Port Map(A=>L16out,B=>L17out,O=>ML2);	
L_111:latch Port Map(Lin=>ML2,Len=>L18,Lo=>L18out); 
L_112:demux_1x2 Port Map(Yin=>L18out,S=>ML2S3,I0=>S58,I1=>S59);
end structural;