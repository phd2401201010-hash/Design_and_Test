library ieee;
use ieee.std_logic_1164.all;

entity mux_1x8 is
Port(I0,I1,I2,I3,I4,I5,I6,I7 : in std_logic_vector(15 downto 0);
	S : in std_logic_vector(2 downto 0);
	Yout : out std_logic_vector(15 downto 0));
end mux_1x8;

architecture behavioral of mux_1x8 is
begin
process(I0,I1,I2,I3,I4,I5,I6,I7, S)
begin
		if(s = "000") then
			Yout <= I0;
		elsif(s = "001") then
			Yout <= I1;
		elsif(S= "010") then
			Yout <= I2;
		elsif(S= "011") then
			Yout <= I3;
		elsif(S= "100") then 
			Yout <= I4;
		elsif(S = "101") then
			Yout <= I5;
		elsif(S= "110") then
			Yout <= I6;
		else
			Yout <= I7;
		end if;
end process;
end behavioral;