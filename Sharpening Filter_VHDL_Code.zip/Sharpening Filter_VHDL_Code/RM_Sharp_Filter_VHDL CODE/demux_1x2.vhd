library ieee;
use ieee.std_logic_1164.all;

entity demux_1x2 is
Port(Yin : in std_logic_vector(15 downto 0);
	S : in std_logic;
	I0, I1 : out std_logic_vector(15 downto 0));
end demux_1x2;

architecture behavioral of demux_1x2 is
begin
process(Yin,S)
begin
	if(S = '0') then
		I0 <= Yin;
	else
		I1 <= Yin;
	end if;
end process;
end behavioral;