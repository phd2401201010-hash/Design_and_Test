library ieee;
use ieee.std_logic_1164.all;

entity demux_1x4 is
Port(Yin : in std_logic_vector(15 downto 0);
	S : in STD_LOGIC_vector(1 downto 0);
	I0,I1,I2,I3 : OUT STD_logic_vector(15 downto 0));
end demux_1x4;

architecture behavioral of demux_1x4 is
begin 
process(Yin, S)
begin
	if(S = "00") then
		I0 <= Yin;
	elsif(S = "01") then
		I1 <= Yin;
	elsif(S = "10") then
		I2 <= Yin;
	else
		I3 <= Yin;
	end if;
end process;
end behavioral;