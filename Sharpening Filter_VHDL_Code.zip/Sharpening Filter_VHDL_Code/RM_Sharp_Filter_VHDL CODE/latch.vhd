library ieee;
use ieee.std_logic_1164.all;

entity latch1 is
Port(Lin : in std_logic_vector(15 downto 0);
	Len : in std_logic;
	Lo : out std_logic_vector(15 downto 0));
end latch1;

architecture behavioral of latch1 is
begin
process(Lin, Len)
begin
	if(Len = '0') then
			Lo<=Lin;
	end if;
end process;
end behavioral;