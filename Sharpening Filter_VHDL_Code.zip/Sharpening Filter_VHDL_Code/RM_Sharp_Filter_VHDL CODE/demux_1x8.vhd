library ieee;
use ieee.std_logic_1164.all;

entity demux_1X8 is
port(Yin : in std_logic_vector(15 downto 0);
	S : in std_logic_vector(2 downto 0);
	I0, I1, I2, I3, I4, I5, I6, I7 : out std_logic_vector(15 downto 0));
end demux_1X8;

architecture behavioral of demux_1X8 is
begin
process(Yin, S)
begin
	if(S = "000") then
		I0<=Yin;
	elsif(S = "001") then
		I1<=Yin;
	elsif(S = "010") then
		I2<=Yin;
	elsif(S= "011") then
		I3<=Yin;
	elsif(S="100") then
		I4<=Yin;
	elsif(S = "101") then
		I5 <=Yin;
	elsif(S = "110") then
		I6 <= Yin;
	else
		I7 <= Yin;
	end if;
end process;
end behavioral;