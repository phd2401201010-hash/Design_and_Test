library ieee;
use ieee.std_logic_1164.all;

entity reg is
Port(Rin : in std_logic_vector(15 downto 0);
	Ren : in std_logic;
	Ro : out std_logic_vector(15 downto 0));
end reg;

architecture behavioral of reg is
begin
process(Rin, Ren)
begin
	if(Ren = '0') then
			Ro<=Rin;
	end if;
end process;
end behavioral;