library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;

entity adder is
port(A : in STD_logic_vector(15 downto 0);
	B : in STD_logic_vector(15 downto 0);
	O : out STD_logic_vector(15 downto 0));
end adder;

architecture dataflow of adder is
begin
O <= A + B;
END dataflow; 