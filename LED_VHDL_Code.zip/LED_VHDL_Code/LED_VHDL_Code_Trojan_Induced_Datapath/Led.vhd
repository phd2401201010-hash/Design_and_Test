Library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;

entity Led is
Port (R0,R1,R2,R3,R4,R5,R6,R7,R8,R9,R10,R11,R12,R13 : in std_logic_vector(15 downto 0);--primary inputs
		ORMS,ORDS,OLMS,OLDS,TMS,TDS : in std_logic;--selection lines for 2x1/1x2 mux/demux of orange,olive,tan registers
		RMS,RDS,PMS,PDS,AMS,ADS,KMS,KDS : in std_logic_vector(1 downto 0);--selection lines for 4x1/1x4 mux/demux of red,purple,aqua,khaki registers
      RR,PR,IR,ORR,MR,AR,OLR,KR,GR,BR,CR,SR,NR,TR : in std_logic;--register enable pin for all registers
		RTMS,RTDS,ATMS,ATDS : in std_logic_vector(2 downto 0);--selection line for trojan path 8x1/1x8 mux/demux of red and aqua registers
		PTMS,PTDS,ITMS,ITDS,NTMS,NTDS : std_logic;--selection line for trojan path 2x1/1x2 mux/demux of purple,indigo,navy registers
		TTS : in std_logic;--selection line for trojan triggered 2x1/1x2 mux/demux
		L1,L2,L3,L4,L5,L6,L7,L8,L9,L10,L11,L12 : in std_logic;--latch enable pin
		A1S1,A1S2,A1S3,A2S1,A2S2,A2S3 : in std_logic_vector(1 downto 0);--selection line(muLiplexer) for 4x1/1x4 mux/demux of A1,A2 adders
		M1S1,M1S2,M1S3,M2S1,M2S2,M2S3 : in std_logic;--selection line(multiplexer) for 2x1/1x2 mux/demux of M1,M2 multipliers		
		OP1_1,OP1_2,OP2 : out std_logic_vector(15 downto 0));--final output
end Led;

architecture Structural of Led is

component adder_df is
Port (A,B : in std_logic_vector(15 downto 0);
		O : out std_logic_vector (15 downto 0));
end component;

component multiplier_bh is
Port (A,B : in std_logic_vector(15 downto 0);
		O : out std_logic_vector (15 downto 0));
end component;

component mux_2x1_bh is
Port (I0,I1 : in std_logic_vector(15 downto 0);
	   S : in std_logic;
		Yout : out std_logic_vector(15 downto 0));
end component;

component mux_4x1_bh is
Port(I0,I1,I2,I3 : in std_logic_vector(15 downto 0);
	  S : in std_logic_vector(1 downto 0);
	  Yout : out std_logic_vector(15 downto 0));
end component;

component mux_8x1_bh is
Port(I0,I1,I2,I3,I4,I5,I6,I7 : in std_logic_vector(15 downto 0);
	  S : in std_logic_vector(2 downto 0);
	  Yout : out std_logic_vector(15 downto 0));
end component;

component demux_1x2_bh is
Port(Yin : in std_logic_vector(15 downto 0);
	  S : in std_logic;
	  I0,I1: out std_logic_vector(15 downto 0));
end component;

component demux_1x4_bh is
Port (Yin: in std_logic_vector(15 downto 0);
		S : in std_logic_vector(1 downto 0);
		I0,I1,I2,I3 : out std_logic_vector(15 downto 0));
end component;

component demux_1x8_bh is
Port (Yin : in std_logic_vector(15 downto 0);
		S : in std_logic_vector(2 downto 0);
		I0,I1,I2,I3,I4,I5,I6,I7 : out std_logic_vector(15 downto 0));
end component;

component reg_bh is
port (Rin : in std_logic_vector(15 downto 0);
		Ren : in std_logic;
		Ro : out std_logic_vector(15 downto 0));
end component;

component latch_bh is
port (Lin : in std_logic_vector(15 downto 0);
		Len : in std_logic;
		Lo : out std_logic_vector(15 downto 0));
end component;

Signal s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12,s13,s14,s15,s16,s17,s18,s19,s20  : std_logic_vector(15 downto 0);
Signal s21,s22,s23,s24,s25,s26,s27,s28,s29,s30,s31,s32,s33,s34,s35,s36,s37,s38,s39,s40 : std_logic_vector(15 downto 0);
Signal s41,s42,s43,s44,s45,s46,s47,s48,s49,s50,s51,s52,s53,s54,s55,s56,s57,s58,s59,s60  : std_logic_vector(15 downto 0);
Signal s61,s62,s63,s64,s65,s66,s67,s68,s69,s70,s71,s72,s73,s74,s75,s76,s77,s78,s79,s80 : std_logic_vector(15 downto 0);
Signal s81,s82,s83,s84,s85,s86,s87,s88,s89,s90,s91,s92,s93,s94,s95,s96,s97,s98,s99,s100  : std_logic_vector(15 downto 0);
Signal s101,s102,s103,s104,s105,s106,s107,s108,s109,s110,s111,s112,s113,s114 : std_logic_vector(15 downto 0);
Signal s13_1,s13_2,s14_1,s14_2,s16_1,s16_2,s25_1,s25_2,s26_1,s26_2,s31_1,s31_2,s38_1,s38_2,s52_1,s52_2,s54_1,s54_2,s55_1,s55_2,s67_1,s67_2,s77_1,s77_2,s84_1,s84_2 : std_logic_vector(15 downto 0);
Signal f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13,f14,f15,f16,f17,f18,f19 : std_logic_vector(15 downto 0);--free signal pins

begin

s13 <= s13_1 or s13_2;
s14 <= s14_1 or s14_2;
s25 <= s25_1 or s25_2;
s26 <= s26_1 or s26_2;
s31 <= s31_1 or s31_2;
s38 <= s38_1 or s38_2;
s52 <= s52_1 or s52_2;
s54 <= s54_1 or s54_2;
s55 <= s55_1 or s55_2;
s67 <= s67_1 or s67_2;
s77 <= s77_1 or s77_2;
s84 <= s84_1 or s84_2;
-------------Red register-------------
L_1:mux_4x1_bh port map(I0=>R0,I1=>s1,I2=>s2,I3=>f1,S=>RMS,Yout=>s3);
L_2:mux_8x1_bh port map(I0=>R0,I1=>s4,I2=>s1,I3=>s5,I4=>s2,I5=>f2,I6=>f3,I7=>f4,S=>RTMS,Yout=>s8);--Trojan path mux/demux
L_3:mux_2x1_bh port map(I0=>s3,I1=>s8,S=>TTS,Yout=>s9);--Trojan path mux/demux
L_4:reg_bh port map(Rin=>s9,Ren=>RR,Ro=>s10);
L_5:demux_1x2_bh port map(Yin=>s10,S=>TTS,I0=>s11,I1=>s12);--Trojan path mux/demux
L_6:demux_1x4_bh port map(Yin=>s11,S=>RDS,I0=>s13_1,I1=>s14_1,I2=>OP1_1,I3=>f5);
L_7:demux_1x8_bh port map(Yin=>s12,S=>RTDS,I0=>s13_2,I1=>s15,I2=>s14_2,I3=>s16_1,I4=>OP1_2,I5=>f6,I6=>f7,I7=>f8);--Trojan path mux/demux
-------------Purple register-------------
L_8:mux_4x1_bh port map(I0=>R1,I1=>s17,I2=>s5,I3=>f9,S=>PMS,Yout=>s19);
L_9:mux_2x1_bh port map(I0=>R1,I1=>s17,S=>PTMS,Yout=>s20);--Trojan path mux/demux
L_10:mux_2x1_bh port map(I0=>s19,I1=>s20,S=>TTS,Yout=>s21);--Trojan path mux/demux
L_11:reg_bh port map(Rin=>s21,Ren=>PR,Ro=>s22);
L_12:demux_1x2_bh port map(Yin=>s22,S=>TTS,I0=>s23,I1=>s24);--Trojan path mux/demux
L_13:demux_1x4_bh port map(Yin=>s23,S=>PDS,I0=>s25_1,I1=>s26_1,I2=>s16_2,I3=>f10);
L_14:demux_1x2_bh port map(Yin=>s24,S=>PTDS,I0=>s25_2,I1=>s26_2);--Trojan path mux/demux
-------------Indigo register-------------
L_15:mux_2x1_bh port map(I0=>R2,I1=>s27,S=>ITMS,Yout=>s28);--Trojan path mux/demux
L_16:mux_2x1_bh port map(I0=>R2,I1=>s28,S=>TTS,Yout=>s29);--Trojan path mux/demux
L_17:reg_bh port map(Rin=>s29,Ren=>PR,Ro=>s30);
L_18:demux_1x2_bh port map(Yin=>s30,S=>TTS,I0=>s31_1,I1=>s32);--Trojan path mux/demux
L_19:demux_1x2_bh port map(Yin=>s32,S=>ITDS,I0=>s31_2,I1=>s33);--Trojan path mux/demux
-------------Orange register-------------
L_20:mux_2x1_bh port map(I0=>R3,I1=>s4,S=>ORMS,Yout=>s34);
L_21:mux_2x1_bh port map(I0=>s34,I1=>R3,S=>TTS,Yout=>s35);--Trojan path mux/demux
L_22:reg_bh port map(Rin=>s35,Ren=>ORR,Ro=>s36);
L_23:demux_1x2_bh port map(Yin=>s36,S=>TTS,I0=>s37,I1=>s38_1);--Trojan path mux/demux
L_24:demux_1x2_bh port map(Yin=>s37,S=>ORDS,I0=>s38_2,I1=>s39);
-------------Maroon register-------------
L_25:reg_bh port map(Rin=>R4,Ren=>MR,Ro=>s40);
-------------Aqua register-------------
L_26:mux_4x1_bh port map(I0=>R5,I1=>s41,I2=>s42,I3=>s43,S=>AMS,Yout=>s44);
L_27:mux_8x1_bh port map(I0=>R5,I1=>s42,I2=>s45,I3=>s43,I4=>s46,I5=>f11,I6=>f12,I7=>f13,S=>ATMS,Yout=>s47);--Trojan path mux/demux
L_28:mux_2x1_bh port map(I0=>s44,I1=>s47,S=>TTS,Yout=>s48);--Trojan path mux/demux
L_29:reg_bh port map(Rin=>s48,Ren=>AR,Ro=>s49);
L_30:demux_1x2_bh port map(Yin=>s49,S=>TTS,I0=>s50,I1=>s51);--Trojan path mux/demux
L_31:demux_1x4_bh port map(Yin=>s50,S=>ADS,I0=>s52_1,I1=>s53,I2=>s54_1,I3=>s55_1);
L_32:demux_1x8_bh port map(Yin=>s51,S=>ATDS,I0=>s52_2,I1=>s54_2,I2=>s56,I3=>s55_2,I4=>s57,I5=>f14,I6=>f15,I7=>f16);--Trojan path mux/demux
-------------Olive register-------------
L_33:mux_2x1_bh port map(I0=>R6,I1=>s58,S=>OLMS,Yout=>s59);
L_34:reg_bh port map(Rin=>s59,Ren=>OLR,Ro=>s60);
L_35:demux_1x2_bh port map(Yin=>s60,S=>OLDS,I0=>s61,I1=>s62);
-------------Khaki register-------------
L_36:mux_4x1_bh port map(I0=>R7,I1=>s45,I2=>s46,I3=>f17,S=>KMS,Yout=>s63);
L_37:mux_2x1_bh port map(I0=>s63,I1=>R7,S=>TTS,Yout=>s64);--Trojan path mux/demux
L_38:reg_bh port map(Rin=>s64,Ren=>KR,Ro=>s65);
L_39:demux_1x2_bh port map(Yin=>s65,S=>TTS,I0=>s66,I1=>s67_2);--Trojan path mux/demux
L_40:demux_1x4_bh port map(Yin=>s66,S=>KDS,I0=>s67_1,I1=>s68,I2=>s69,I3=>f18);
-------------Green register-------------
L_41:reg_bh port map(Rin=>R8,Ren=>GR,Ro=>s70);
-------------Black register-------------
L_42:reg_bh port map(Rin=>R9,Ren=>BR,Ro=>s71);
-------------Crimson register-------------
L_43:reg_bh port map(Rin=>R10,Ren=>CR,Ro=>s72);
-------------Salmon register-------------
L_44:reg_bh port map(Rin=>R11,Ren=>SR,Ro=>s73);
-------------Navy register-------------
L_45:mux_2x1_bh port map(I0=>R12,I1=>s41,S=>NTMS,Yout=>s74);--Trojan path mux/demux
L_46:mux_2x1_bh port map(I0=>R12,I1=>s74,S=>TTS,Yout=>s75);--Trojan path mux/demux
L_47:reg_bh port map(Rin=>s75,Ren=>NR,Ro=>s76);
L_48:demux_1x2_bh port map(Yin=>s76,S=>TTS,I0=>s77_1,I1=>s78);--Trojan path mux/demux
L_49:demux_1x2_bh port map(Yin=>s78,S=>NTDS,I0=>s77_2,I1=>s79);--Trojan path mux/demux
-------------Tan register-------------
L_50:mux_2x1_bh port map(I0=>R13,I1=>s27,S=>TMS,Yout=>s80);
L_51:mux_2x1_bh port map(I0=>s80,I1=>R13,S=>TTS,Yout=>s81);--Trojan path mux/demux
L_52:reg_bh port map(Rin=>s81,Ren=>TR,Ro=>s82);
L_53:demux_1x2_bh port map(Yin=>s82,S=>TTS,I0=>s83,I1=>s84_1);--Trojan path mux/demux
L_54:demux_1x2_bh port map(Yin=>s83,S=>TDS,I0=>s84_2,I1=>s85);
-------------Lower Level Trojan Mux-------------
L_55:mux_2x1_bh port map(I0=>s16_2,I1=>s16_1,S=>TTS,Yout=>s86);--Trojan path mux/demux
L_56:mux_2x1_bh port map(I0=>s39,I1=>s15,S=>TTS,Yout=>s87);--Trojan path mux/demux
L_57:mux_2x1_bh port map(I0=>s68,I1=>s56,S=>TTS,Yout=>s88);--Trojan path mux/demux
L_58:mux_2x1_bh port map(I0=>s69,I1=>s57,S=>TTS,Yout=>OP2);--Trojan path mux/demux
L_59:mux_2x1_bh port map(I0=>s53,I1=>s79,S=>TTS,Yout=>s89);--Trojan path mux/demux
L_60:mux_2x1_bh port map(I0=>s85,I1=>s33,S=>TTS,Yout=>s90);--Trojan path mux/demux
-------------Adder(A1)-------------
L_61:mux_4x1_bh Port Map(I0=>s13,I1=>s67,I2=>s87,I3=>s86,S=>A1S1,Yout=>s91);	
L_62:latch_bh Port Map(Lin=>s91,Len=>L1,Lo=>s92); 
L_63:mux_4x1_bh Port Map(I0=>s25,I1=>s70,I2=>s26,I3=>s90,S=>A1S2,Yout=>s93);
L_64:latch_bh Port Map(Lin=>s93,Len=>L2,Lo=>s94); 
L_65:adder_df Port Map(A=>s92,B=>s94,O=>s95);	
L_66:latch_bh Port Map(Lin=>s95,Len=>L3,Lo=>s96); 
L_67:demux_1x4_bh Port Map(Yin=>s96,S=>A1S3,I0=>s4,I1=>s42,I2=>s1,I3=>s2);
-------------Multiplier(M1)-------------
L_68:mux_2x1_bh Port Map(I0=>s52,I1=>s14,S=>M1S1,Yout=>s97);	
L_69:latch_bh Port Map(Lin=>s97,Len=>L4,Lo=>s98); 
L_70:mux_2x1_bh Port Map(I0=>s61,I1=>s40,S=>M1S2,Yout=>s99);
L_71:latch_bh Port Map(Lin=>s99,Len=>L5,Lo=>s100); 
L_72:multiplier_bh Port Map(A=>s98,B=>s100,O=>s101);	
L_73:latch_bh Port Map(Lin=>s101,Len=>L6,Lo=>s102); 
L_74:demux_1x2_bh Port Map(Yin=>s102,S=>M1S3,I0=>s27,I1=>s5);
-------------Adder(A2)-------------
L_75:mux_4x1_bh Port Map(I0=>s31,I1=>s71,I2=>s54,I3=>s55,S=>A2S1,Yout=>s103);	
L_76:latch_bh Port Map(Lin=>s103,Len=>L7,Lo=>s104); 
L_77:mux_4x1_bh Port Map(I0=>s38,I1=>s72,I2=>s62,I3=>s89,S=>A2S2,Yout=>s105);
L_78:latch_bh Port Map(Lin=>s105,Len=>L8,Lo=>s106); 
L_79:adder_df Port Map(A=>s104,B=>s106,O=>s107);	
L_80:latch_bh Port Map(Lin=>s107,Len=>L9,Lo=>s108); 
L_81:demux_1x4_bh Port Map(Yin=>s108,S=>A2S3,I0=>s17,I1=>s58,I2=>s45,I3=>s46);
-------------Multiplier(M1)-------------
L_82:mux_2x1_bh Port Map(I0=>s77,I1=>s88,S=>M2S1,Yout=>s109);	
L_83:latch_bh Port Map(Lin=>s109,Len=>L10,Lo=>s110); 
L_84:mux_2x1_bh Port Map(I0=>s84,I1=>s73,S=>M2S2,Yout=>s111);
L_85:latch_bh Port Map(Lin=>s111,Len=>L11,Lo=>s112); 
L_86:multiplier_bh Port Map(A=>s110,B=>s112,O=>s113);	
L_87:latch_bh Port Map(Lin=>s113,Len=>L12,Lo=>s114); 
L_88:demux_1x2_bh Port Map(Yin=>s114,S=>M2S3,I0=>s41,I1=>s43);	
end Structural;