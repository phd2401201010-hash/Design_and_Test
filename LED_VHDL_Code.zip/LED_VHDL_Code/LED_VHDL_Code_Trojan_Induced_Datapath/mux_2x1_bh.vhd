library ieee;
use ieee.std_logic_1164.all;

entity mux_2x1_bh is
Port (I0,I1 : in std_logic_vector(15 downto 0);
		S : in std_logic;
		Yout : out std_logic_vector(15 downto 0));
end mux_2x1_bh;

architecture behavioral of mux_2x1_bh is
begin
process(I0,I1,S)
begin
	if(S = '0') then
		Yout <= I0;
	else
		Yout <= I1;
	end if;
end process;
end behavioral;