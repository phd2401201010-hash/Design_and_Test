library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;

entity adder_df is
Port (A : in STD_LOGIC_VECTOR(15 downto 0);
		B : in STD_LOGIC_VECTOR(15 downto 0);
		O : out STD_LOGIC_VECTOR(15 downto 0));
end adder_df;

architecture dataflow of adder_df is
begin
O <= A + B;
end dataflow;
