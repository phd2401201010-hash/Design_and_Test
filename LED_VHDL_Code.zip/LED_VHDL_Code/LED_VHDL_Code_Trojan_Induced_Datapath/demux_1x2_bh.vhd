library ieee;
use ieee.std_logic_1164.all;

entity demux_1x2_bh is
Port (Yin : in std_logic_vector(15 downto 0);
		S : in std_logic;
		I0,I1 : out std_logic_vector(15 downto 0));
end demux_1x2_bh;

architecture behavioral of demux_1x2_bh is
begin
process(Yin,S)
begin
	if(S = '0')then
		I0 <= Yin;
	else
		I1 <= Yin;
	end if;
end process;
end behavioral;