library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;

entity adder is
Port (a : in STD_LOGIC_VECTOR(15 downto 0);
		b : in STD_LOGIC_VECTOR(15 downto 0);
		c : out STD_LOGIC_VECTOR(15 downto 0));
end adder;

architecture dataflow of adder is
begin
c <= a + b;
end dataflow;
