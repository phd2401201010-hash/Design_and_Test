library ieee;
use ieee.std_logic_1164.all;

entity DEMUX_1x4 is
port(Yin : in std_logic_vector(15 downto 0);
      S: in std_logic_vector(1 downto 0);
      I0,I1,I2,I3 : out std_logic_vector(15 downto 0));
end DEMUX_1x4;

architecture behv of DEMUX_1x4 is
begin
process(Yin,S)is
begin
if(S="00")then
I3<=Yin;
elsif(S="01")then
I2<=Yin;
elsif(S="10")then
I1<=Yin;
else
I0<=Yin;
end if;
end process;
end behv;
