library ieee;
use ieee.std_logic_1164.all;

entity MUX_8x1 is
port (I0,I1,I2,I3,I4,I5,I6,I7: in std_logic_vector (15 downto 0);
		S: in std_logic_vector (2 downto 0);
		Yout: out std_logic_vector(15 downto 0));
end MUX_8x1;

architecture behv of MUX_8x1 is
begin
with S select
Yout <= I0 when "000",
I1 when "001",
I2 when "010",
I3 when "011",
I4 when "100",
I5 when "101",
I6 when "110",
I7 when "111";
end behv;
