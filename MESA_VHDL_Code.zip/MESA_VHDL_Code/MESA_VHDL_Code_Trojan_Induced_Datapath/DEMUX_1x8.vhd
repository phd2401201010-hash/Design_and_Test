library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;

entity DEMUX_1x8 is
port(Yin:in std_logic_vector(15 downto 0);
     S: in std_logic_vector (2 downto 0); 
     I0,I1,I2,I3,I4,I5,I6,I7: out std_logic_vector(15 downto 0)
);
end DEMUX_1x8;
architecture behv of DEMUX_1x8 is
begin
	I0<=Yin when S="000" else "0000000000000000";
	I1<=Yin when S="001" else "0000000000000000";
	I2<=Yin when S="010" else "0000000000000000";
	I3<=Yin when S="011" else "0000000000000000";
	I4<=Yin when S="100" else "0000000000000000";
	I5<=Yin when S="101" else "0000000000000000";
	I6<=Yin when S="110" else "0000000000000000";
	I7<=Yin when S="111" else "0000000000000000";
end behv;
