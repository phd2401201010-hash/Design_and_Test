library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity mesa is
Port(v0,v1,v2,v3 : in STD_LOGIC_VECTOR(15 downto 0);--primary inputs
		BMS1,BDS2,YMS1,YDS2,GMS1,GDS2 : in STD_LOGIC_VECTOR(1 downto 0);--selection line for 4x1/1x4 MUX/DEMUX for Reg B,Y,G
		RMS1,RDS2 : in STD_LOGIC_VECTOR(2 downto 0);--selection line for 8x1/1x8 MUX/DEMUX for Reg R
		TTS : in STD_LOGIC;--selection line for trojan triggered 2x1/1x2 MUX/DEMUX
		BTPM_S1,BTPD_S2 : in STD_LOGIC;-- selection line for trojan path 2x1/1x2 MUX/DEMUX for Reg B
		YTPM_S1,YTPD_S2 : in STD_LOGIC_VECTOR(2 downto 0);-- selection line for trojan path 8x1/1x8 MUX/DEMUX for Reg B
		M1S1,M1S2,M1S3,M2S1,M2S2,M2S3,M3S1,M3S2,M3S3,M4S1,M4S2,M4S3,A1S1,A1S2,A1S3,A2S1,A2S2,A2S3,A3S1,A3S2,A3S3 : in STD_LOGIC;--selection line for 2x1/1x2 MUX/DEMUX for 4-Multipliers and 3-Adders
		Op1,Op2_1,Op2_2 : out STD_LOGIC_VECTOR(15 downto 0));--final outputs
end mesa;
		
architecture Structural of mesa is

component MUX_2x1 is
Port(I0,I1 : in STD_LOGIC_VECTOR(15 downto 0);
		S : in STD_LOGIC;
		Yout : out STD_LOGIC_VECTOR(15 downto 0));
end component;

component MUX_4x1 is
Port(I0,I1,I2,I3 : in STD_LOGIC_VECTOR(15 downto 0);
		S : in STD_LOGIC_VECTOR(1 downto 0);
		Yout : out STD_LOGIC_VECTOR(15 downto 0));
end component;

component MUX_8x1 is
Port(I0,I1,I2,I3,I4,I5,I6,I7 : in STD_LOGIC_VECTOR(15 downto 0);
		S : in STD_LOGIC_VECTOR(2 downto 0);
		Yout : out STD_LOGIC_VECTOR(15 downto 0));
end component;

component DEMUX_1x2 is
Port(Yin : in STD_LOGIC_VECTOR(15 downto 0);
		S : in STD_LOGIC;
		I0,I1 : out STD_LOGIC_VECTOR(15 downto 0));
end component;

component DEMUX_1x4 is
Port(Yin : in STD_LOGIC_VECTOR(15 downto 0);
		S : in STD_LOGIC_VECTOR(1 downto 0);
		I0,I1,I2,I3 : out STD_LOGIC_VECTOR(15 downto 0));
end component;

component DEMUX_1x8 is
Port(Yin : in STD_LOGIC_VECTOR(15 downto 0);
		S : in STD_LOGIC_VECTOR(2 downto 0);
		I0,I1,I2,I3,I4,I5,I6,I7 : out STD_LOGIC_VECTOR(15 downto 0));
end component;

--Same name 'S' selection line for all MUX/DEMUX doesn't mean that they are using same selection line but,
 --they are local to each component declaration

component Multiplier is
Port(A,B : in STD_LOGIC_VECTOR(15 downto 0);
		O : out STD_LOGIC_VECTOR(15 downto 0));
end component;

component Adder is
Port(A,B : in STD_LOGIC_VECTOR(15 downto 0);
		O : out STD_LOGIC_VECTOR(15 downto 0));
end component;

component Reg is
Port(Ri : in STD_LOGIC_VECTOR(15 downto 0);
		Ren : in STD_LOGIC;
		Ro : out STD_LOGIC_VECTOR(15 downto 0));
end component;

component Latc is
Port(Li : in STD_LOGIC_VECTOR(15 downto 0);
		Len : in STD_LOGIC;
		Lo : out STD_LOGIC_VECTOR(15 downto 0));
end component;

Signal s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12,s13,s14,s15,s16,s17,s18,s19,s20,s21,s22,s23,s24,s25,s26,s27,s28,s29,s30 : STD_LOGIC_VECTOR(15 downto 0);
Signal s31,s32,s33,s34,s35,s36,s37,s38,s39,s40,s41,s42,s43,s44,s45,s46,s47,s48,s49,s50,s51,s52,s53,s54,s55,s56,s57,s58,s59,s60 : STD_LOGIC_VECTOR(15 downto 0);
Signal s61,s62,s63,s64,s65,s66,s67,s68,s69,s70,s71,s72,s73,s74,s75,s76,s77,s78,s79,s80,s81,s82,s83 : STD_LOGIC_VECTOR(15 downto 0);
Signal f1,f2,f3,f4,f5,f6,f7,f8,f9,f10 : STD_LOGIC_VECTOR(15 downto 0);--free input ports of MUX of registers
Signal Br,Yr,Rr,Gr,l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,l14,l15,l16,l17,l18,l19,l20 : STD_LOGIC;--register/latch enable pin
Signal s3_1,s3_2,s4_1,s4_2,s4_3,s5_1,s5_2,s7_1,s10_1,s11_1,s11_2,s12_1,s12_2,s13_1,s13_2,s14_1,s15_1,s15_2,s17_1,s18_1,s19_1,s20_1,s21_1,s22_1,s22_2,s23_1,s24_1,s25_1,s26_1 : STD_LOGIC_VECTOR(15 downto 0);

begin
s5 <= s5_1 or s5_2;
s13 <= s13_1 or s13_2;
s15 <= s15_1 or s15_2;

------------------Blue Register-------------------------
L_1:MUX_4x1 Port Map(I0=>v2,I1=>s1,I2=>s2,I3=>f1,S=>BMS1,Yout=>s3);
L_2:Reg Port Map(Ri=>s3_2,Ren=>Br,Ro=>s4);
L_3:DEMUX_1x4 Port Map(Yin=>s4_1,S=>BDS2,I0=>s5_1,I1=>s6,I2=>s7,I3=>f2);
------------------Yellow Register-------------------------
L_4:MUX_4x1 Port Map(I0=>v3,I1=>s8,I2=>s9,I3=>s10,S=>YMS1,Yout=>s11);
L_5:Reg Port Map(Ri=>s11_1,Ren=>Yr,Ro=>s11_2);
L_6:DEMUX_1x4 Port Map(Yin=>s12_1,S=>YDS2,I0=>s13_1,I1=>s14,I2=>s15_1,I3=>Op2_1);
------------------Red Register-------------------------
L_7:MUX_8x1 Port Map(I0=>v0,I1=>s16,I2=>s17,I3=>s18,I4=>s19,I5=>s20,I6=>s21,I7=>f9,S=>RMS1,Yout=>s22);	
L_8:Reg Port Map(Ri=>s22,Ren=>Rr,Ro=>s23);
L_9:DEMUX_1x8 Port Map(Yin=>s23,S=>RDS2,I0=>s24,I1=>s25,I2=>s26,I3=>s27,I4=>s28,I5=>s29,I6=>Op1,I7=>f10);
------------------Green Register-------------------------
L_10:MUX_4x1 Port Map(I0=>v1,I1=>s30,I2=>s31,I3=>s32,S=>GMS1,Yout=>s33);
L_11:Reg Port Map(Ri=>s34,Ren=>Gr,Ro=>s34);
L_12:DEMUX_1x4 Port Map(Yin=>s33,S=>GDS2,I0=>s35,I1=>s36,I2=>s37,I3=>s38);
----------------------------------------Muliplier(M1)----------------------------
L_13:MUX_2x1 Port Map(I0=>s24,I1=>s26,S=>M1S1,Yout=>s39);	
L_14:Latc Port Map(Li=>s39,Len=>l1,Lo=>s40);
L_15:MUX_2x1 Port Map(I0=>s24,I1=>s26,S=>M1S2,Yout=>s41);
L_16:Latc Port Map(Li=>s41,Len=>l2,Lo=>s42);
L_17:Multiplier Port Map(A=>s40,B=>s42,O=>s43);	
L_18:Latc Port Map(Li=>s43,Len=>l3,Lo=>s44); 
L_19:DEMUX_1x2 Port Map(Yin=>s44,S=>M1S3,I0=>s16,I1=>s18);	
----------------------------------------Muliplier(M2)----------------------------
L_20:MUX_2x1 Port Map(I0=>s35,I1=>s37,S=>M2S1,Yout=>s45);	
L_21:Latc Port Map(Li=>s45,Len=>l4,Lo=>s46); 
L_22:MUX_2x1 Port Map(I0=>s35,I1=>s17_1,S=>M2S2,Yout=>s47);
L_23:Latc Port Map(Li=>s47,Len=>l5,Lo=>s48); 
L_24:Multiplier Port Map(A=>s46,B=>s48,O=>s49);	
L_25:Latc Port Map(Li=>s49,Len=>l6,Lo=>s50); 
L_26:DEMUX_1x2 Port Map(Yin=>s50,S=>M2S3,I0=>s30,I1=>s32);	
----------------------------------------Muliplier(M3)----------------------------
L_27:MUX_2x1 Port Map(I0=>s5,I1=>s7,S=>M3S1,Yout=>s51);	
L_28:Latc Port Map(Li=>s51,Len=>l7,Lo=>s52); 
L_29:MUX_2x1 Port Map(I0=>s5,I1=>s7,S=>M3S2,Yout=>s53);
L_30:Latc Port Map(Li=>s53,Len=>l8,Lo=>s54); 
L_31:Multiplier Port Map(A=>s52,B=>s54,O=>s55);	
L_32:Latc Port Map(Li=>s55,Len=>l9,Lo=>s56); 
L_33:DEMUX_1x2 Port Map(Yin=>s56,S=>M3S3,I0=>s8,I1=>s9);	
----------------------------------------Muliplier(M4)----------------------------
L_34:MUX_2x1 Port Map(I0=>s13,I1=>s28,S=>M4S1,Yout=>s57);	
L_35:Latc Port Map(Li=>s57,Len=>l10,Lo=>s58); 
L_36:MUX_2x1 Port Map(I0=>s13,I1=>s28,S=>M4S2,Yout=>s59);
L_37:Latc Port Map(Li=>s59,Len=>l11,Lo=>s60); 
L_38:Multiplier Port Map(A=>s58,B=>s60,O=>s61);	
L_39:Latc Port Map(Li=>s61,Len=>l12,Lo=>s62); 
L_40:DEMUX_1x2 Port Map(Yin=>s62,S=>M4S3,I0=>s1,I1=>s20);	
----------------------------------------Adder(A1)------------
L_41:MUX_2x1 Port Map(I0=>s25,I1=>s27,S=>A1S1,Yout=>s63);	
L_42:Latc Port Map(Li=>s63,Len=>l13,Lo=>s64); 
L_43:MUX_2x1 Port Map(I0=>s25,I1=>s27,S=>A1S2,Yout=>s65);
L_44:Latc Port Map(Li=>s65,Len=>l14,Lo=>s66); 
L_45:Adder Port Map(A=>s64,B=>s66,O=>s67);	
L_46:Latc Port Map(Li=>s67,Len=>l15,Lo=>s68); 
L_47:DEMUX_1x2 Port Map(Yin=>s68,S=>A1S3,I0=>s17,I1=>s19);	
----------------------------------------Adder(A2)------------
L_48:MUX_2x1 Port Map(I0=>s36,I1=>s15,S=>A2S1,Yout=>s69);	
L_49:Latc Port Map(Li=>s69,Len=>l16,Lo=>s70); 
L_50:MUX_2x1 Port Map(I0=>s36,I1=>s15,S=>A2S2,Yout=>s71);
L_51:Latc Port Map(Li=>s71,Len=>l17,Lo=>s72); 
L_52:Adder Port Map(A=>s70,B=>s72,O=>s73);		
L_53:Latc Port Map(Li=>s73,Len=>l17,Lo=>s74); 
L_54:DEMUX_1x2 Port Map(Yin=>s74,S=>A2S3,I0=>s31,I1=>s10);	
----------------------------------------Adder(A3)------------
L_55:MUX_2x1 Port Map(I0=>s18_1,I1=>s29,S=>A3S1,Yout=>s75);	
L_56:Latc Port Map(Li=>s75,Len=>l18,Lo=>s76); 
L_57:MUX_2x1 Port Map(I0=>s18_1,I1=>s38,S=>A3S2,Yout=>s77);
L_58:Latc Port Map(Li=>s77,Len=>l19,Lo=>s78); 
L_59:Adder Port Map(A=>s76,B=>s78,O=>s79);	
L_60:Latc Port Map(Li=>s79,Len=>l20,Lo=>s80); 
L_61:DEMUX_1x2 Port Map(Yin=>s80,S=>A3S3,I0=>s2,I1=>s21);
-----------------------Trojan  Multiplexer------------------
TM1:MUX_2x1 Port Map (I0=>v2,I1=>s8,S=>BTPM_S1,Yout=>s3_1);
TM2:MUX_2x1 Port Map (I0=>s3,I1=>s3_1,S=>TTS,Yout=>s3_2);
TM3:DEMUX_1x2 Port Map(Yin=>s4,S=>TTS,I0=>s4_1,I1=>s4_2);
TM4:DEMUX_1x2 Port Map(Yin=>s4_2,S=>BTPD_S2,I0=>s5_2,I1=>s4_3);
TM5:MUX_8x1 Port Map(I0=>v3,I1=>s1,I2=>s2,I3=>s9,I4=>s10,I5=>f3,I6=>f4,I7=>f5,S=>YTPM_S1,Yout=>s10_1);	
TM6:MUX_2x1 Port Map(I0=>s11,I1=>s10_1,S=>TTS,Yout=>S11_1);
TM7:DEMUX_1x2 Port Map(Yin=>s11_2,S=>TTS,I0=>s12_1,I1=>s12_2);
TM8:DEMUX_1x8 Port Map(Yin=>s12_2,S=>YTPD_S2,I0=>s13_2,I1=>s14_1,I2=>s7_1,I3=>s15_2,I4=>Op2_2,I5=>f6,I6=>f7,I7=>f8);
TM9:MUX_2x1 Port Map(I0=>s14,I1=>s4_3,S=>TTS,Yout=>s17_1);
TM10:MUX_2x1 Port Map(I0=>s6,I1=>s14_1,S=>TTS,Yout=>s18_1);
TM11:MUX_2x1 Port Map(I0=>s7,I1=>s7_1,S=>TTS,Yout=>s19_1);
end Structural;
