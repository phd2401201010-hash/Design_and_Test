library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;
entity Adder is
port(A:in std_logic_vector(15 downto 0);
     B:in std_logic_vector(15 downto 0);
	  O:out std_logic_vector(15 downto 0));
end Adder;
architecture behv of Adder is
begin
process(A,B)is
begin
O<=A+B;
end process;
end behv;
