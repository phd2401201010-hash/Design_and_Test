library ieee;
use ieee.std_logic_1164.all;

entity MUX_2x1 is
port(I0,I1 : in std_logic_vector(15 downto 0);
		S : in std_logic;
		Yout :out std_logic_vector(15 downto 0));
end MUX_2x1;

architecture behv of MUX_2x1 is
begin
process(I0,I1,S)is
begin
if(S='0')then
Yout<=I1;
else
Yout<=I0;
end if;
end process;
end behv;
