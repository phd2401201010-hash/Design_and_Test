library ieee;
use ieee.std_logic_1164.all;
entity MUX_4x1 is
port(I0,I1,I2,I3:in std_logic_vector(15 downto 0);
		S: in std_logic_vector(1 downto 0);
		Yout:out std_logic_vector(15 downto 0));
end MUX_4x1;

architecture behv of MUX_4x1 is
begin
process(I0,I1,I2,I3,S) is
begin
if(S="00")then
Yout<=I3;
elsif(S="01")then
Yout<=I2;
elsif(S="10")then
Yout<=I1;
else
Yout<=I0;
end if;
end process;
end behv;
