library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;
entity Multiplier is
port(A:in std_logic_vector(15 downto 0);
     B:in std_logic_vector(15 downto 0);
	  O: out std_logic_vector(15 downto 0)
);

end Multiplier;
architecture behv of Multiplier is
--temporary signal declaration.
signal R1,R2 : std_logic_vector(15 downto 0) := (others => '0');
signal R3 : std_logic_vector(31 downto 0);      

begin
R1 <= A;
R2 <= B;
process(A,B)is
begin
R3 <= R1 * R2;  --Multiplication
O<= R3(15 downto 0);
end process;
end behv;