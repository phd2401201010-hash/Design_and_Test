library ieee;
use ieee.std_logic_1164.all;
entity Reg is
port(Ri:in std_logic_vector(15 downto 0);
		Ren: in std_logic;
     Ro: out std_logic_vector(15 downto 0)
	
);
end Reg;
architecture behv of Reg is
begin
process(Ri,Ren)is
begin
	if (Ren='0')then
		Ro<=Ri;
end if;
end process;
end behv;
