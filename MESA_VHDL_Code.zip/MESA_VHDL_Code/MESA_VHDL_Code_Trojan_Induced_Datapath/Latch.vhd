library ieee;
use ieee.std_logic_1164.all;

entity Latc is
port(Li:in std_logic_vector(15 downto 0);
    Len:in std_logic;
	  Lo: out std_logic_vector(15 downto 0));
end Latc;

architecture behv of Latc is
begin
process(Li,Len)is
begin
if (Len='0')then
Lo<=Li;
end if;
end process;
end behv;
