library ieee;
use ieee.std_logic_1164.all;
entity DEMUX_1x2 is
port(Yin:in std_logic_vector(15 downto 0);
		S: in std_logic;
		I0,I1:out std_logic_vector(15 downto 0));
end DEMUX_1x2;
architecture behv of DEMUX_1x2 is
begin
process(Yin,S)is
begin
if(S='0')then
I1<=Yin;
else
I0<=Yin;
end if;
end process;
end behv;
