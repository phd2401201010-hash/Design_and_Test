-- Copyright (C) 1991-2013 Altera Corporation
-- Your use of Altera Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Altera Program License 
-- Subscription Agreement, Altera MegaCore Function License 
-- Agreement, or other applicable license agreement, including, 
-- without limitation, that your use is for the sole purpose of 
-- programming logic devices manufactured by Altera and sold by 
-- Altera or its authorized distributors.  Please refer to the 
-- applicable agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus II 64-Bit"
-- VERSION "Version 13.0.1 Build 232 06/12/2013 Service Pack 1 SJ Web Edition"

-- DATE "03/19/2026 18:20:24"

-- 
-- Device: Altera EP4CGX150DF31I7AD Package FBGA896
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY CYCLONEIV;
LIBRARY IEEE;
USE CYCLONEIV.CYCLONEIV_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	mesa IS
    PORT (
	v0 : IN std_logic_vector(15 DOWNTO 0);
	v1 : IN std_logic_vector(15 DOWNTO 0);
	v2 : IN std_logic_vector(15 DOWNTO 0);
	v3 : IN std_logic_vector(15 DOWNTO 0);
	BMS1 : IN std_logic_vector(1 DOWNTO 0);
	BDS2 : IN std_logic_vector(1 DOWNTO 0);
	YMS1 : IN std_logic_vector(1 DOWNTO 0);
	YDS2 : IN std_logic_vector(1 DOWNTO 0);
	GMS1 : IN std_logic_vector(1 DOWNTO 0);
	GDS2 : IN std_logic_vector(1 DOWNTO 0);
	RMS1 : IN std_logic_vector(2 DOWNTO 0);
	RDS2 : IN std_logic_vector(2 DOWNTO 0);
	TTS : IN std_logic;
	BTPM_S1 : IN std_logic;
	BTPD_S2 : IN std_logic;
	YTPM_S1 : IN std_logic_vector(2 DOWNTO 0);
	YTPD_S2 : IN std_logic_vector(2 DOWNTO 0);
	M1S1 : IN std_logic;
	M1S2 : IN std_logic;
	M1S3 : IN std_logic;
	M2S1 : IN std_logic;
	M2S2 : IN std_logic;
	M2S3 : IN std_logic;
	M3S1 : IN std_logic;
	M3S2 : IN std_logic;
	M3S3 : IN std_logic;
	M4S1 : IN std_logic;
	M4S2 : IN std_logic;
	M4S3 : IN std_logic;
	A1S1 : IN std_logic;
	A1S2 : IN std_logic;
	A1S3 : IN std_logic;
	A2S1 : IN std_logic;
	A2S2 : IN std_logic;
	A2S3 : IN std_logic;
	A3S1 : IN std_logic;
	A3S2 : IN std_logic;
	A3S3 : IN std_logic;
	Op1 : OUT std_logic_vector(15 DOWNTO 0);
	Op2_1 : OUT std_logic_vector(15 DOWNTO 0);
	Op2_2 : OUT std_logic_vector(15 DOWNTO 0)
	);
END mesa;

-- Design Ports Information
-- Op1[0]	=>  Location: PIN_AG26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op1[1]	=>  Location: PIN_AA28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op1[2]	=>  Location: PIN_AD27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op1[3]	=>  Location: PIN_AB29,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op1[4]	=>  Location: PIN_AC28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op1[5]	=>  Location: PIN_Y30,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op1[6]	=>  Location: PIN_AC27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op1[7]	=>  Location: PIN_AE25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op1[8]	=>  Location: PIN_AB27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op1[9]	=>  Location: PIN_AD30,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op1[10]	=>  Location: PIN_Y22,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op1[11]	=>  Location: PIN_AD28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op1[12]	=>  Location: PIN_AC30,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op1[13]	=>  Location: PIN_AA22,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op1[14]	=>  Location: PIN_AD29,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op1[15]	=>  Location: PIN_AB26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op2_1[0]	=>  Location: PIN_AJ15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op2_1[1]	=>  Location: PIN_AA20,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op2_1[2]	=>  Location: PIN_AF24,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op2_1[3]	=>  Location: PIN_AF27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op2_1[4]	=>  Location: PIN_AF16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op2_1[5]	=>  Location: PIN_AF28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op2_1[6]	=>  Location: PIN_AC25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op2_1[7]	=>  Location: PIN_AE23,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op2_1[8]	=>  Location: PIN_AB25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op2_1[9]	=>  Location: PIN_AE21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op2_1[10]	=>  Location: PIN_AK13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op2_1[11]	=>  Location: PIN_AH14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op2_1[12]	=>  Location: PIN_AA21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op2_1[13]	=>  Location: PIN_AH24,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op2_1[14]	=>  Location: PIN_U21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op2_1[15]	=>  Location: PIN_AG24,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op2_2[0]	=>  Location: PIN_AK17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op2_2[1]	=>  Location: PIN_AH21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op2_2[2]	=>  Location: PIN_AF15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op2_2[3]	=>  Location: PIN_AE16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op2_2[4]	=>  Location: PIN_AG23,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op2_2[5]	=>  Location: PIN_AK15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op2_2[6]	=>  Location: PIN_AE15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op2_2[7]	=>  Location: PIN_AJ7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op2_2[8]	=>  Location: PIN_Y28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op2_2[9]	=>  Location: PIN_AG25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op2_2[10]	=>  Location: PIN_AE14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op2_2[11]	=>  Location: PIN_AD16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op2_2[12]	=>  Location: PIN_AK7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op2_2[13]	=>  Location: PIN_AK9,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op2_2[14]	=>  Location: PIN_AA26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Op2_2[15]	=>  Location: PIN_AJ27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RDS2[1]	=>  Location: PIN_AA27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RDS2[2]	=>  Location: PIN_AJ21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RMS1[2]	=>  Location: PIN_AB28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RMS1[0]	=>  Location: PIN_AG20,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RMS1[1]	=>  Location: PIN_AE19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v0[0]	=>  Location: PIN_AH16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RDS2[0]	=>  Location: PIN_AF30,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v0[1]	=>  Location: PIN_AJ12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v0[2]	=>  Location: PIN_Y27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v0[3]	=>  Location: PIN_AK10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v0[4]	=>  Location: PIN_AG30,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v0[5]	=>  Location: PIN_AK24,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v0[6]	=>  Location: PIN_AK25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v0[7]	=>  Location: PIN_AH26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v0[8]	=>  Location: PIN_AB30,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v0[9]	=>  Location: PIN_AK8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v0[10]	=>  Location: PIN_AE27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v0[11]	=>  Location: PIN_AH29,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v0[12]	=>  Location: PIN_AB14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v0[13]	=>  Location: PIN_AK28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v0[14]	=>  Location: PIN_AB17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v0[15]	=>  Location: PIN_AE29,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- YTPD_S2[2]	=>  Location: PIN_AF18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- YTPD_S2[0]	=>  Location: PIN_AE17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- YTPD_S2[1]	=>  Location: PIN_AK18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- M4S3	=>  Location: PIN_A15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- A1S2	=>  Location: PIN_AK29,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- A1S1	=>  Location: PIN_AA29,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- A1S3	=>  Location: PIN_V15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- M1S3	=>  Location: PIN_V30,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- A3S1	=>  Location: PIN_AK22,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- TTS	=>  Location: PIN_W15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- A3S2	=>  Location: PIN_AK21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- A3S3	=>  Location: PIN_AJ16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- YDS2[0]	=>  Location: PIN_AE5,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- YDS2[1]	=>  Location: PIN_AE8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- YTPM_S1[1]	=>  Location: PIN_Y18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- YTPM_S1[0]	=>  Location: PIN_AA18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v3[0]	=>  Location: PIN_AA17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- YTPM_S1[2]	=>  Location: PIN_AG19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v3[1]	=>  Location: PIN_AF22,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v3[2]	=>  Location: PIN_AA25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v3[3]	=>  Location: PIN_AK23,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v3[4]	=>  Location: PIN_AA15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v3[5]	=>  Location: PIN_AD22,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v3[6]	=>  Location: PIN_AJ9,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v3[7]	=>  Location: PIN_AE22,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v3[8]	=>  Location: PIN_AG29,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v3[9]	=>  Location: PIN_AH25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v3[10]	=>  Location: PIN_AJ13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v3[11]	=>  Location: PIN_AD24,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v3[12]	=>  Location: PIN_AJ30,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v3[13]	=>  Location: PIN_AB21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v3[14]	=>  Location: PIN_AH22,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v3[15]	=>  Location: PIN_AH23,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- BDS2[1]	=>  Location: PIN_D16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- BDS2[0]	=>  Location: PIN_B16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- GMS1[0]	=>  Location: PIN_AH17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- GMS1[1]	=>  Location: PIN_AK19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v1[0]	=>  Location: PIN_AH18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- GDS2[0]	=>  Location: PIN_A4,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- GDS2[1]	=>  Location: PIN_G7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v1[1]	=>  Location: PIN_Y20,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v1[2]	=>  Location: PIN_AK26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v1[3]	=>  Location: PIN_AG28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v1[4]	=>  Location: PIN_AJ25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v1[5]	=>  Location: PIN_AD25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v1[6]	=>  Location: PIN_AG17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v1[7]	=>  Location: PIN_AH27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v1[8]	=>  Location: PIN_AG15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v1[9]	=>  Location: PIN_AD23,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v1[10]	=>  Location: PIN_AJ28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v1[11]	=>  Location: PIN_Y25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v1[12]	=>  Location: PIN_AC16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v1[13]	=>  Location: PIN_AD26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v1[14]	=>  Location: PIN_AK11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v1[15]	=>  Location: PIN_Y21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- YMS1[1]	=>  Location: PIN_AG18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- YMS1[0]	=>  Location: PIN_AH19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- A2S1	=>  Location: PIN_AH20,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- A2S2	=>  Location: PIN_B15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- A2S3	=>  Location: PIN_AK16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- M3S3	=>  Location: PIN_T30,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- M4S1	=>  Location: PIN_AE30,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- M4S2	=>  Location: PIN_AF19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- M1S1	=>  Location: PIN_AB22,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- M1S2	=>  Location: PIN_T21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v2[0]	=>  Location: PIN_AE26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- BMS1[1]	=>  Location: PIN_AJ22,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- BMS1[0]	=>  Location: PIN_AJ19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- M2S3	=>  Location: PIN_T29,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v2[1]	=>  Location: PIN_AH15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v2[2]	=>  Location: PIN_AK14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v2[3]	=>  Location: PIN_AK12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v2[4]	=>  Location: PIN_AJ24,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v2[5]	=>  Location: PIN_AH30,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v2[6]	=>  Location: PIN_AG16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v2[7]	=>  Location: PIN_AE20,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v2[8]	=>  Location: PIN_AH28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v2[9]	=>  Location: PIN_V21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v2[10]	=>  Location: PIN_AE28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v2[11]	=>  Location: PIN_Y17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v2[12]	=>  Location: PIN_AG27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v2[13]	=>  Location: PIN_AG22,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v2[14]	=>  Location: PIN_AK27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- v2[15]	=>  Location: PIN_AF21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- M3S1	=>  Location: PIN_Y19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- M3S2	=>  Location: PIN_AJ18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- M2S1	=>  Location: PIN_AG21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- M2S2	=>  Location: PIN_AE18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- BTPD_S2	=>  Location: PIN_V29,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- BTPM_S1	=>  Location: PIN_AK20,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF mesa IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_v0 : std_logic_vector(15 DOWNTO 0);
SIGNAL ww_v1 : std_logic_vector(15 DOWNTO 0);
SIGNAL ww_v2 : std_logic_vector(15 DOWNTO 0);
SIGNAL ww_v3 : std_logic_vector(15 DOWNTO 0);
SIGNAL ww_BMS1 : std_logic_vector(1 DOWNTO 0);
SIGNAL ww_BDS2 : std_logic_vector(1 DOWNTO 0);
SIGNAL ww_YMS1 : std_logic_vector(1 DOWNTO 0);
SIGNAL ww_YDS2 : std_logic_vector(1 DOWNTO 0);
SIGNAL ww_GMS1 : std_logic_vector(1 DOWNTO 0);
SIGNAL ww_GDS2 : std_logic_vector(1 DOWNTO 0);
SIGNAL ww_RMS1 : std_logic_vector(2 DOWNTO 0);
SIGNAL ww_RDS2 : std_logic_vector(2 DOWNTO 0);
SIGNAL ww_TTS : std_logic;
SIGNAL ww_BTPM_S1 : std_logic;
SIGNAL ww_BTPD_S2 : std_logic;
SIGNAL ww_YTPM_S1 : std_logic_vector(2 DOWNTO 0);
SIGNAL ww_YTPD_S2 : std_logic_vector(2 DOWNTO 0);
SIGNAL ww_M1S1 : std_logic;
SIGNAL ww_M1S2 : std_logic;
SIGNAL ww_M1S3 : std_logic;
SIGNAL ww_M2S1 : std_logic;
SIGNAL ww_M2S2 : std_logic;
SIGNAL ww_M2S3 : std_logic;
SIGNAL ww_M3S1 : std_logic;
SIGNAL ww_M3S2 : std_logic;
SIGNAL ww_M3S3 : std_logic;
SIGNAL ww_M4S1 : std_logic;
SIGNAL ww_M4S2 : std_logic;
SIGNAL ww_M4S3 : std_logic;
SIGNAL ww_A1S1 : std_logic;
SIGNAL ww_A1S2 : std_logic;
SIGNAL ww_A1S3 : std_logic;
SIGNAL ww_A2S1 : std_logic;
SIGNAL ww_A2S2 : std_logic;
SIGNAL ww_A2S3 : std_logic;
SIGNAL ww_A3S1 : std_logic;
SIGNAL ww_A3S2 : std_logic;
SIGNAL ww_A3S3 : std_logic;
SIGNAL ww_Op1 : std_logic_vector(15 DOWNTO 0);
SIGNAL ww_Op2_1 : std_logic_vector(15 DOWNTO 0);
SIGNAL ww_Op2_2 : std_logic_vector(15 DOWNTO 0);
SIGNAL \L_38|Mult0|auto_generated|mac_out2_DATAA_bus\ : std_logic_vector(35 DOWNTO 0);
SIGNAL \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\ : std_logic_vector(35 DOWNTO 0);
SIGNAL \L_17|Mult0|auto_generated|mac_out2_DATAA_bus\ : std_logic_vector(35 DOWNTO 0);
SIGNAL \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\ : std_logic_vector(35 DOWNTO 0);
SIGNAL \L_38|Mult0|auto_generated|mac_mult1_DATAA_bus\ : std_logic_vector(17 DOWNTO 0);
SIGNAL \L_38|Mult0|auto_generated|mac_mult1_DATAB_bus\ : std_logic_vector(17 DOWNTO 0);
SIGNAL \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\ : std_logic_vector(35 DOWNTO 0);
SIGNAL \L_17|Mult0|auto_generated|mac_mult1_DATAA_bus\ : std_logic_vector(17 DOWNTO 0);
SIGNAL \L_17|Mult0|auto_generated|mac_mult1_DATAB_bus\ : std_logic_vector(17 DOWNTO 0);
SIGNAL \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\ : std_logic_vector(35 DOWNTO 0);
SIGNAL \L_31|Mult0|auto_generated|mac_out2_DATAA_bus\ : std_logic_vector(35 DOWNTO 0);
SIGNAL \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\ : std_logic_vector(35 DOWNTO 0);
SIGNAL \L_24|Mult0|auto_generated|mac_out2_DATAA_bus\ : std_logic_vector(35 DOWNTO 0);
SIGNAL \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\ : std_logic_vector(35 DOWNTO 0);
SIGNAL \L_31|Mult0|auto_generated|mac_mult1_DATAA_bus\ : std_logic_vector(17 DOWNTO 0);
SIGNAL \L_31|Mult0|auto_generated|mac_mult1_DATAB_bus\ : std_logic_vector(17 DOWNTO 0);
SIGNAL \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\ : std_logic_vector(35 DOWNTO 0);
SIGNAL \L_24|Mult0|auto_generated|mac_mult1_DATAA_bus\ : std_logic_vector(17 DOWNTO 0);
SIGNAL \L_24|Mult0|auto_generated|mac_mult1_DATAB_bus\ : std_logic_vector(17 DOWNTO 0);
SIGNAL \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\ : std_logic_vector(35 DOWNTO 0);
SIGNAL \L_6|Equal0~1clkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \L_3|I0[15]~0clkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \L_6|Equal0~2clkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \L_6|Equal0~0clkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \L_6|I0[15]~0clkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \L_3|Equal0~0clkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \L_12|Equal0~0clkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \L_12|Equal0~2clkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \L_12|Equal0~1clkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \L_12|I0[15]~0clkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \L_3|Equal0~1clkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \TTS~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \A2S3~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \A1S3~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \A3S3~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \M4S3~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \BTPD_S2~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \M2S3~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \M1S3~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \M3S3~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \L_38|Mult0|auto_generated|mac_out2~DATAOUT16\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_out2~DATAOUT17\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_out2~DATAOUT18\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_out2~DATAOUT19\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_out2~DATAOUT20\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_out2~DATAOUT21\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_out2~DATAOUT22\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_out2~DATAOUT23\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_out2~DATAOUT24\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_out2~DATAOUT25\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_out2~DATAOUT26\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_out2~DATAOUT27\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_out2~DATAOUT28\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_out2~DATAOUT29\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_out2~DATAOUT30\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_out2~DATAOUT31\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_out2~0\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_out2~1\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_out2~2\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_out2~3\ : std_logic;
SIGNAL \L_45|O[0]~0_combout\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_out2~DATAOUT7\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_out2~DATAOUT9\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_out2~DATAOUT16\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_out2~DATAOUT17\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_out2~DATAOUT18\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_out2~DATAOUT19\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_out2~DATAOUT20\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_out2~DATAOUT21\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_out2~DATAOUT22\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_out2~DATAOUT23\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_out2~DATAOUT24\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_out2~DATAOUT25\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_out2~DATAOUT26\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_out2~DATAOUT27\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_out2~DATAOUT28\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_out2~DATAOUT29\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_out2~DATAOUT30\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_out2~DATAOUT31\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_out2~0\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_out2~1\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_out2~2\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_out2~3\ : std_logic;
SIGNAL \L_59|O[2]~4_combout\ : std_logic;
SIGNAL \L_45|O[4]~8_combout\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_out2~DATAOUT16\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_out2~DATAOUT17\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_out2~DATAOUT18\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_out2~DATAOUT19\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_out2~DATAOUT20\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_out2~DATAOUT21\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_out2~DATAOUT22\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_out2~DATAOUT23\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_out2~DATAOUT24\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_out2~DATAOUT25\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_out2~DATAOUT26\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_out2~DATAOUT27\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_out2~DATAOUT28\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_out2~DATAOUT29\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_out2~DATAOUT30\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_out2~DATAOUT31\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_out2~0\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_out2~1\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_out2~2\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_out2~3\ : std_logic;
SIGNAL \L_52|O[1]~2_combout\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_out2~DATAOUT3\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_out2~DATAOUT8\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_out2~DATAOUT16\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_out2~DATAOUT17\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_out2~DATAOUT18\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_out2~DATAOUT19\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_out2~DATAOUT20\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_out2~DATAOUT21\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_out2~DATAOUT22\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_out2~DATAOUT23\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_out2~DATAOUT24\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_out2~DATAOUT25\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_out2~DATAOUT26\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_out2~DATAOUT27\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_out2~DATAOUT28\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_out2~DATAOUT29\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_out2~DATAOUT30\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_out2~DATAOUT31\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_out2~0\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_out2~1\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_out2~2\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_out2~3\ : std_logic;
SIGNAL \L_7|Mux8~0_combout\ : std_logic;
SIGNAL \L_7|Mux8~1_combout\ : std_logic;
SIGNAL \L_7|Mux6~0_combout\ : std_logic;
SIGNAL \L_7|Mux6~1_combout\ : std_logic;
SIGNAL \L_43|Yout[0]~1_combout\ : std_logic;
SIGNAL \L_55|Yout[0]~2_combout\ : std_logic;
SIGNAL \L_43|Yout[1]~2_combout\ : std_logic;
SIGNAL \L_57|Yout[1]~3_combout\ : std_logic;
SIGNAL \L_41|Yout[2]~3_combout\ : std_logic;
SIGNAL \L_55|Yout[2]~4_combout\ : std_logic;
SIGNAL \L_43|Yout[3]~4_combout\ : std_logic;
SIGNAL \L_57|Yout[3]~7_combout\ : std_logic;
SIGNAL \L_41|Yout[4]~5_combout\ : std_logic;
SIGNAL \L_55|Yout[4]~6_combout\ : std_logic;
SIGNAL \L_41|Yout[5]~6_combout\ : std_logic;
SIGNAL \L_55|Yout[5]~7_combout\ : std_logic;
SIGNAL \L_41|Yout[6]~7_combout\ : std_logic;
SIGNAL \L_55|Yout[6]~8_combout\ : std_logic;
SIGNAL \L_43|Yout[7]~8_combout\ : std_logic;
SIGNAL \L_57|Yout[7]~14_combout\ : std_logic;
SIGNAL \L_55|Yout[7]~9_combout\ : std_logic;
SIGNAL \L_43|Yout[8]~9_combout\ : std_logic;
SIGNAL \L_55|Yout[8]~10_combout\ : std_logic;
SIGNAL \L_41|Yout[9]~10_combout\ : std_logic;
SIGNAL \L_55|Yout[9]~11_combout\ : std_logic;
SIGNAL \L_41|Yout[10]~11_combout\ : std_logic;
SIGNAL \L_57|Yout[10]~21_combout\ : std_logic;
SIGNAL \L_43|Yout[11]~12_combout\ : std_logic;
SIGNAL \L_57|Yout[11]~23_combout\ : std_logic;
SIGNAL \L_43|Yout[12]~13_combout\ : std_logic;
SIGNAL \L_55|Yout[12]~14_combout\ : std_logic;
SIGNAL \L_43|Yout[13]~14_combout\ : std_logic;
SIGNAL \L_57|Yout[13]~27_combout\ : std_logic;
SIGNAL \L_43|Yout[14]~15_combout\ : std_logic;
SIGNAL \L_57|Yout[14]~29_combout\ : std_logic;
SIGNAL \L_50|Yout[0]~1_combout\ : std_logic;
SIGNAL \L_50|Yout[1]~3_combout\ : std_logic;
SIGNAL \L_50|Yout[2]~5_combout\ : std_logic;
SIGNAL \L_48|Yout[3]~3_combout\ : std_logic;
SIGNAL \L_50|Yout[4]~9_combout\ : std_logic;
SIGNAL \L_50|Yout[5]~11_combout\ : std_logic;
SIGNAL \L_48|Yout[6]~6_combout\ : std_logic;
SIGNAL \L_48|Yout[7]~7_combout\ : std_logic;
SIGNAL \L_50|Yout[8]~17_combout\ : std_logic;
SIGNAL \L_50|Yout[9]~19_combout\ : std_logic;
SIGNAL \L_48|Yout[10]~10_combout\ : std_logic;
SIGNAL \L_50|Yout[11]~23_combout\ : std_logic;
SIGNAL \L_48|Yout[12]~12_combout\ : std_logic;
SIGNAL \L_50|Yout[13]~27_combout\ : std_logic;
SIGNAL \L_48|Yout[14]~14_combout\ : std_logic;
SIGNAL \TM2|Yout[5]~11_combout\ : std_logic;
SIGNAL \TM2|Yout[7]~15_combout\ : std_logic;
SIGNAL \TM2|Yout[7]~16_combout\ : std_logic;
SIGNAL \TM2|Yout[9]~19_combout\ : std_logic;
SIGNAL \TM2|Yout[11]~23_combout\ : std_logic;
SIGNAL \TM2|Yout[13]~27_combout\ : std_logic;
SIGNAL \TM2|Yout[1]~34_combout\ : std_logic;
SIGNAL \TM2|Yout[15]~48_combout\ : std_logic;
SIGNAL \v0[0]~input_o\ : std_logic;
SIGNAL \v0[1]~input_o\ : std_logic;
SIGNAL \v0[2]~input_o\ : std_logic;
SIGNAL \v0[3]~input_o\ : std_logic;
SIGNAL \v0[4]~input_o\ : std_logic;
SIGNAL \v0[5]~input_o\ : std_logic;
SIGNAL \v0[6]~input_o\ : std_logic;
SIGNAL \v0[7]~input_o\ : std_logic;
SIGNAL \v0[8]~input_o\ : std_logic;
SIGNAL \v0[9]~input_o\ : std_logic;
SIGNAL \v0[10]~input_o\ : std_logic;
SIGNAL \v0[11]~input_o\ : std_logic;
SIGNAL \v0[12]~input_o\ : std_logic;
SIGNAL \v0[15]~input_o\ : std_logic;
SIGNAL \A1S2~input_o\ : std_logic;
SIGNAL \A1S1~input_o\ : std_logic;
SIGNAL \v3[0]~input_o\ : std_logic;
SIGNAL \v3[3]~input_o\ : std_logic;
SIGNAL \v3[6]~input_o\ : std_logic;
SIGNAL \v3[7]~input_o\ : std_logic;
SIGNAL \v3[9]~input_o\ : std_logic;
SIGNAL \v3[11]~input_o\ : std_logic;
SIGNAL \v3[12]~input_o\ : std_logic;
SIGNAL \v3[14]~input_o\ : std_logic;
SIGNAL \v1[1]~input_o\ : std_logic;
SIGNAL \v1[4]~input_o\ : std_logic;
SIGNAL \v1[9]~input_o\ : std_logic;
SIGNAL \v1[10]~input_o\ : std_logic;
SIGNAL \M1S2~input_o\ : std_logic;
SIGNAL \v2[1]~input_o\ : std_logic;
SIGNAL \v2[7]~input_o\ : std_logic;
SIGNAL \v2[8]~input_o\ : std_logic;
SIGNAL \v2[13]~input_o\ : std_logic;
SIGNAL \Op1[0]~output_o\ : std_logic;
SIGNAL \Op1[1]~output_o\ : std_logic;
SIGNAL \Op1[2]~output_o\ : std_logic;
SIGNAL \Op1[3]~output_o\ : std_logic;
SIGNAL \Op1[4]~output_o\ : std_logic;
SIGNAL \Op1[5]~output_o\ : std_logic;
SIGNAL \Op1[6]~output_o\ : std_logic;
SIGNAL \Op1[7]~output_o\ : std_logic;
SIGNAL \Op1[8]~output_o\ : std_logic;
SIGNAL \Op1[9]~output_o\ : std_logic;
SIGNAL \Op1[10]~output_o\ : std_logic;
SIGNAL \Op1[11]~output_o\ : std_logic;
SIGNAL \Op1[12]~output_o\ : std_logic;
SIGNAL \Op1[13]~output_o\ : std_logic;
SIGNAL \Op1[14]~output_o\ : std_logic;
SIGNAL \Op1[15]~output_o\ : std_logic;
SIGNAL \Op2_1[0]~output_o\ : std_logic;
SIGNAL \Op2_1[1]~output_o\ : std_logic;
SIGNAL \Op2_1[2]~output_o\ : std_logic;
SIGNAL \Op2_1[3]~output_o\ : std_logic;
SIGNAL \Op2_1[4]~output_o\ : std_logic;
SIGNAL \Op2_1[5]~output_o\ : std_logic;
SIGNAL \Op2_1[6]~output_o\ : std_logic;
SIGNAL \Op2_1[7]~output_o\ : std_logic;
SIGNAL \Op2_1[8]~output_o\ : std_logic;
SIGNAL \Op2_1[9]~output_o\ : std_logic;
SIGNAL \Op2_1[10]~output_o\ : std_logic;
SIGNAL \Op2_1[11]~output_o\ : std_logic;
SIGNAL \Op2_1[12]~output_o\ : std_logic;
SIGNAL \Op2_1[13]~output_o\ : std_logic;
SIGNAL \Op2_1[14]~output_o\ : std_logic;
SIGNAL \Op2_1[15]~output_o\ : std_logic;
SIGNAL \Op2_2[0]~output_o\ : std_logic;
SIGNAL \Op2_2[1]~output_o\ : std_logic;
SIGNAL \Op2_2[2]~output_o\ : std_logic;
SIGNAL \Op2_2[3]~output_o\ : std_logic;
SIGNAL \Op2_2[4]~output_o\ : std_logic;
SIGNAL \Op2_2[5]~output_o\ : std_logic;
SIGNAL \Op2_2[6]~output_o\ : std_logic;
SIGNAL \Op2_2[7]~output_o\ : std_logic;
SIGNAL \Op2_2[8]~output_o\ : std_logic;
SIGNAL \Op2_2[9]~output_o\ : std_logic;
SIGNAL \Op2_2[10]~output_o\ : std_logic;
SIGNAL \Op2_2[11]~output_o\ : std_logic;
SIGNAL \Op2_2[12]~output_o\ : std_logic;
SIGNAL \Op2_2[13]~output_o\ : std_logic;
SIGNAL \Op2_2[14]~output_o\ : std_logic;
SIGNAL \Op2_2[15]~output_o\ : std_logic;
SIGNAL \RMS1[1]~input_o\ : std_logic;
SIGNAL \RMS1[2]~input_o\ : std_logic;
SIGNAL \RMS1[0]~input_o\ : std_logic;
SIGNAL \L_7|Mux15~0_combout\ : std_logic;
SIGNAL \A3S3~input_o\ : std_logic;
SIGNAL \A3S3~inputclkctrl_outclk\ : std_logic;
SIGNAL \L_7|Mux15~3_combout\ : std_logic;
SIGNAL \A1S3~input_o\ : std_logic;
SIGNAL \A1S3~inputclkctrl_outclk\ : std_logic;
SIGNAL \M1S3~input_o\ : std_logic;
SIGNAL \M1S3~inputclkctrl_outclk\ : std_logic;
SIGNAL \RDS2[1]~input_o\ : std_logic;
SIGNAL \M1S1~input_o\ : std_logic;
SIGNAL \RDS2[0]~input_o\ : std_logic;
SIGNAL \L_13|Yout[15]~0_combout\ : std_logic;
SIGNAL \L_13|Yout[0]~1_combout\ : std_logic;
SIGNAL \A3S1~input_o\ : std_logic;
SIGNAL \TTS~input_o\ : std_logic;
SIGNAL \YTPD_S2[0]~input_o\ : std_logic;
SIGNAL \YTPD_S2[2]~input_o\ : std_logic;
SIGNAL \L_55|Yout[0]~0_combout\ : std_logic;
SIGNAL \TTS~inputclkctrl_outclk\ : std_logic;
SIGNAL \YTPM_S1[2]~input_o\ : std_logic;
SIGNAL \YTPM_S1[1]~input_o\ : std_logic;
SIGNAL \BTPD_S2~input_o\ : std_logic;
SIGNAL \BTPD_S2~inputclkctrl_outclk\ : std_logic;
SIGNAL \M3S3~input_o\ : std_logic;
SIGNAL \M3S3~inputclkctrl_outclk\ : std_logic;
SIGNAL \BDS2[1]~input_o\ : std_logic;
SIGNAL \BDS2[0]~input_o\ : std_logic;
SIGNAL \L_3|I0[15]~0_combout\ : std_logic;
SIGNAL \L_3|I0[15]~0clkctrl_outclk\ : std_logic;
SIGNAL \BMS1[0]~input_o\ : std_logic;
SIGNAL \BMS1[1]~input_o\ : std_logic;
SIGNAL \TM2|Yout[1]~3_combout\ : std_logic;
SIGNAL \M4S3~input_o\ : std_logic;
SIGNAL \M4S3~inputclkctrl_outclk\ : std_logic;
SIGNAL \M4S1~input_o\ : std_logic;
SIGNAL \L_34|Yout[0]~0_combout\ : std_logic;
SIGNAL \YTPD_S2[1]~input_o\ : std_logic;
SIGNAL \TM8|Equal0~0_combout\ : std_logic;
SIGNAL \YDS2[1]~input_o\ : std_logic;
SIGNAL \YDS2[0]~input_o\ : std_logic;
SIGNAL \L_6|I0[15]~0_combout\ : std_logic;
SIGNAL \L_6|I0[15]~0clkctrl_outclk\ : std_logic;
SIGNAL \A2S3~input_o\ : std_logic;
SIGNAL \A2S3~inputclkctrl_outclk\ : std_logic;
SIGNAL \GMS1[0]~input_o\ : std_logic;
SIGNAL \M2S1~input_o\ : std_logic;
SIGNAL \GDS2[1]~input_o\ : std_logic;
SIGNAL \GDS2[0]~input_o\ : std_logic;
SIGNAL \L_12|I0[15]~0_combout\ : std_logic;
SIGNAL \L_12|I0[15]~0clkctrl_outclk\ : std_logic;
SIGNAL \L_12|Equal0~2_combout\ : std_logic;
SIGNAL \L_12|Equal0~2clkctrl_outclk\ : std_logic;
SIGNAL \L_20|Yout[0]~0_combout\ : std_logic;
SIGNAL \M2S3~input_o\ : std_logic;
SIGNAL \M2S3~inputclkctrl_outclk\ : std_logic;
SIGNAL \v1[2]~input_o\ : std_logic;
SIGNAL \A2S1~input_o\ : std_logic;
SIGNAL \L_12|Equal0~1_combout\ : std_logic;
SIGNAL \L_12|Equal0~1clkctrl_outclk\ : std_logic;
SIGNAL \v3[2]~input_o\ : std_logic;
SIGNAL \L_3|Equal0~1_combout\ : std_logic;
SIGNAL \L_3|Equal0~1clkctrl_outclk\ : std_logic;
SIGNAL \BTPM_S1~input_o\ : std_logic;
SIGNAL \v2[2]~input_o\ : std_logic;
SIGNAL \TM2|Yout[2]~35_combout\ : std_logic;
SIGNAL \L_27|Yout[2]~2_combout\ : std_logic;
SIGNAL \v2[3]~input_o\ : std_logic;
SIGNAL \M3S1~input_o\ : std_logic;
SIGNAL \v2[4]~input_o\ : std_logic;
SIGNAL \v3[1]~input_o\ : std_logic;
SIGNAL \YMS1[0]~input_o\ : std_logic;
SIGNAL \TM6|Yout[1]~68_combout\ : std_logic;
SIGNAL \TM6|Yout[1]~69_combout\ : std_logic;
SIGNAL \L_36|Yout[1]~1_combout\ : std_logic;
SIGNAL \L_34|Yout[1]~2_combout\ : std_logic;
SIGNAL \YTPM_S1[0]~input_o\ : std_logic;
SIGNAL \TM6|Yout[0]~0_combout\ : std_logic;
SIGNAL \RDS2[2]~input_o\ : std_logic;
SIGNAL \L_43|Yout[15]~0_combout\ : std_logic;
SIGNAL \L_43|Yout[2]~3_combout\ : std_logic;
SIGNAL \L_41|Yout[15]~0_combout\ : std_logic;
SIGNAL \L_41|Yout[1]~2_combout\ : std_logic;
SIGNAL \L_41|Yout[0]~1_combout\ : std_logic;
SIGNAL \L_45|O[0]~1\ : std_logic;
SIGNAL \L_45|O[1]~3\ : std_logic;
SIGNAL \L_45|O[2]~4_combout\ : std_logic;
SIGNAL \L_13|Yout[3]~4_combout\ : std_logic;
SIGNAL \A3S2~input_o\ : std_logic;
SIGNAL \TM8|Equal3~0_combout\ : std_logic;
SIGNAL \v3[4]~input_o\ : std_logic;
SIGNAL \TM2|Yout[9]~2_combout\ : std_logic;
SIGNAL \L_3|Equal0~0_combout\ : std_logic;
SIGNAL \L_3|Equal0~0clkctrl_outclk\ : std_logic;
SIGNAL \L_36|Yout[4]~4_combout\ : std_logic;
SIGNAL \L_34|Yout[4]~5_combout\ : std_logic;
SIGNAL \L_36|Yout[5]~5_combout\ : std_logic;
SIGNAL \L_43|Yout[5]~6_combout\ : std_logic;
SIGNAL \L_43|Yout[4]~5_combout\ : std_logic;
SIGNAL \L_41|Yout[3]~4_combout\ : std_logic;
SIGNAL \L_45|O[2]~5\ : std_logic;
SIGNAL \L_45|O[3]~7\ : std_logic;
SIGNAL \L_45|O[4]~9\ : std_logic;
SIGNAL \L_45|O[5]~10_combout\ : std_logic;
SIGNAL \YMS1[1]~input_o\ : std_logic;
SIGNAL \L_57|Yout[6]~12_combout\ : std_logic;
SIGNAL \L_12|Equal0~0_combout\ : std_logic;
SIGNAL \L_12|Equal0~0clkctrl_outclk\ : std_logic;
SIGNAL \L_57|Yout[6]~13_combout\ : std_logic;
SIGNAL \L_55|Yout[15]~1_combout\ : std_logic;
SIGNAL \GMS1[1]~input_o\ : std_logic;
SIGNAL \L_10|Yout[3]~6_combout\ : std_logic;
SIGNAL \v1[3]~input_o\ : std_logic;
SIGNAL \L_10|Yout[3]~7_combout\ : std_logic;
SIGNAL \TM6|Yout[3]~72_combout\ : std_logic;
SIGNAL \TM6|Yout[3]~73_combout\ : std_logic;
SIGNAL \L_6|Equal0~1_combout\ : std_logic;
SIGNAL \L_6|Equal0~1clkctrl_outclk\ : std_logic;
SIGNAL \L_50|Yout[3]~6_combout\ : std_logic;
SIGNAL \L_50|Yout[3]~7_combout\ : std_logic;
SIGNAL \L_50|Yout[1]~2_combout\ : std_logic;
SIGNAL \L_48|Yout[1]~1_combout\ : std_logic;
SIGNAL \L_52|O[0]~1\ : std_logic;
SIGNAL \L_52|O[1]~3\ : std_logic;
SIGNAL \L_52|O[2]~5\ : std_logic;
SIGNAL \L_52|O[3]~6_combout\ : std_logic;
SIGNAL \TM6|Yout[0]~5_combout\ : std_logic;
SIGNAL \v1[7]~input_o\ : std_logic;
SIGNAL \L_20|Yout[3]~3_combout\ : std_logic;
SIGNAL \v1[6]~input_o\ : std_logic;
SIGNAL \L_20|Yout[7]~7_combout\ : std_logic;
SIGNAL \v1[8]~input_o\ : std_logic;
SIGNAL \L_10|Yout[8]~16_combout\ : std_logic;
SIGNAL \L_10|Yout[8]~17_combout\ : std_logic;
SIGNAL \L_20|Yout[8]~8_combout\ : std_logic;
SIGNAL \v3[10]~input_o\ : std_logic;
SIGNAL \v2[9]~input_o\ : std_logic;
SIGNAL \v2[10]~input_o\ : std_logic;
SIGNAL \TM2|Yout[10]~43_combout\ : std_logic;
SIGNAL \v3[8]~input_o\ : std_logic;
SIGNAL \v2[11]~input_o\ : std_logic;
SIGNAL \L_13|Yout[5]~6_combout\ : std_logic;
SIGNAL \TM6|Yout[9]~84_combout\ : std_logic;
SIGNAL \TM6|Yout[9]~85_combout\ : std_logic;
SIGNAL \L_50|Yout[9]~18_combout\ : std_logic;
SIGNAL \L_48|Yout[9]~9_combout\ : std_logic;
SIGNAL \L_52|O[3]~7\ : std_logic;
SIGNAL \L_52|O[4]~9\ : std_logic;
SIGNAL \L_52|O[5]~11\ : std_logic;
SIGNAL \L_52|O[6]~13\ : std_logic;
SIGNAL \L_52|O[7]~14_combout\ : std_logic;
SIGNAL \TM6|Yout[10]~42_combout\ : std_logic;
SIGNAL \TM6|Yout[10]~43_combout\ : std_logic;
SIGNAL \TM6|Yout[10]~44_combout\ : std_logic;
SIGNAL \TM6|Yout[10]~45_combout\ : std_logic;
SIGNAL \L_57|Yout[10]~20_combout\ : std_logic;
SIGNAL \L_55|Yout[10]~12_combout\ : std_logic;
SIGNAL \L_57|Yout[8]~16_combout\ : std_logic;
SIGNAL \L_57|Yout[8]~17_combout\ : std_logic;
SIGNAL \L_59|O[6]~13\ : std_logic;
SIGNAL \L_59|O[7]~15\ : std_logic;
SIGNAL \L_59|O[8]~17\ : std_logic;
SIGNAL \L_59|O[9]~19\ : std_logic;
SIGNAL \L_59|O[10]~20_combout\ : std_logic;
SIGNAL \L_13|Yout[7]~8_combout\ : std_logic;
SIGNAL \L_41|Yout[8]~9_combout\ : std_logic;
SIGNAL \L_41|Yout[7]~8_combout\ : std_logic;
SIGNAL \L_43|Yout[6]~7_combout\ : std_logic;
SIGNAL \L_45|O[5]~11\ : std_logic;
SIGNAL \L_45|O[6]~13\ : std_logic;
SIGNAL \L_45|O[7]~15\ : std_logic;
SIGNAL \L_45|O[8]~16_combout\ : std_logic;
SIGNAL \L_13|Yout[9]~10_combout\ : std_logic;
SIGNAL \L_13|Yout[10]~11_combout\ : std_logic;
SIGNAL \L_41|Yout[11]~12_combout\ : std_logic;
SIGNAL \L_43|Yout[10]~11_combout\ : std_logic;
SIGNAL \L_43|Yout[9]~10_combout\ : std_logic;
SIGNAL \L_45|O[8]~17\ : std_logic;
SIGNAL \L_45|O[9]~19\ : std_logic;
SIGNAL \L_45|O[10]~21\ : std_logic;
SIGNAL \L_45|O[11]~22_combout\ : std_logic;
SIGNAL \L_7|Mux4~0_combout\ : std_logic;
SIGNAL \L_13|Yout[13]~14_combout\ : std_logic;
SIGNAL \L_50|Yout[11]~22_combout\ : std_logic;
SIGNAL \L_48|Yout[11]~11_combout\ : std_logic;
SIGNAL \L_52|O[9]~19\ : std_logic;
SIGNAL \L_52|O[10]~21\ : std_logic;
SIGNAL \L_52|O[11]~22_combout\ : std_logic;
SIGNAL \A2S2~input_o\ : std_logic;
SIGNAL \L_57|Yout[12]~24_combout\ : std_logic;
SIGNAL \v1[12]~input_o\ : std_logic;
SIGNAL \L_20|Yout[12]~12_combout\ : std_logic;
SIGNAL \L_27|Yout[15]~15_combout\ : std_logic;
SIGNAL \v2[0]~input_o\ : std_logic;
SIGNAL \v3[13]~input_o\ : std_logic;
SIGNAL \TM6|Yout[13]~92_combout\ : std_logic;
SIGNAL \TM6|Yout[13]~93_combout\ : std_logic;
SIGNAL \L_36|Yout[13]~13_combout\ : std_logic;
SIGNAL \L_34|Yout[13]~14_combout\ : std_logic;
SIGNAL \L_36|Yout[14]~14_combout\ : std_logic;
SIGNAL \L_34|Yout[14]~15_combout\ : std_logic;
SIGNAL \v3[15]~input_o\ : std_logic;
SIGNAL \L_29|Yout[1]~1_combout\ : std_logic;
SIGNAL \M3S2~input_o\ : std_logic;
SIGNAL \L_29|Yout[2]~2_combout\ : std_logic;
SIGNAL \L_29|Yout[3]~3_combout\ : std_logic;
SIGNAL \L_29|Yout[4]~4_combout\ : std_logic;
SIGNAL \v2[5]~input_o\ : std_logic;
SIGNAL \TM2|Yout[5]~38_combout\ : std_logic;
SIGNAL \L_29|Yout[5]~5_combout\ : std_logic;
SIGNAL \v2[6]~input_o\ : std_logic;
SIGNAL \TM2|Yout[6]~13_combout\ : std_logic;
SIGNAL \TM2|Yout[6]~14_combout\ : std_logic;
SIGNAL \L_29|Yout[6]~6_combout\ : std_logic;
SIGNAL \L_29|Yout[7]~7_combout\ : std_logic;
SIGNAL \TM2|Yout[8]~41_combout\ : std_logic;
SIGNAL \L_29|Yout[8]~8_combout\ : std_logic;
SIGNAL \M4S2~input_o\ : std_logic;
SIGNAL \L_36|Yout[0]~16_combout\ : std_logic;
SIGNAL \L_36|Yout[0]~17_combout\ : std_logic;
SIGNAL \L_36|Yout[1]~18_combout\ : std_logic;
SIGNAL \L_36|Yout[2]~19_combout\ : std_logic;
SIGNAL \L_36|Yout[3]~3_combout\ : std_logic;
SIGNAL \L_36|Yout[3]~20_combout\ : std_logic;
SIGNAL \L_36|Yout[4]~21_combout\ : std_logic;
SIGNAL \L_36|Yout[5]~22_combout\ : std_logic;
SIGNAL \L_36|Yout[6]~23_combout\ : std_logic;
SIGNAL \L_36|Yout[7]~7_combout\ : std_logic;
SIGNAL \L_36|Yout[7]~24_combout\ : std_logic;
SIGNAL \L_36|Yout[8]~25_combout\ : std_logic;
SIGNAL \L_36|Yout[9]~9_combout\ : std_logic;
SIGNAL \L_36|Yout[9]~26_combout\ : std_logic;
SIGNAL \L_36|Yout[10]~10_combout\ : std_logic;
SIGNAL \L_36|Yout[10]~27_combout\ : std_logic;
SIGNAL \L_36|Yout[11]~28_combout\ : std_logic;
SIGNAL \L_36|Yout[12]~29_combout\ : std_logic;
SIGNAL \L_36|Yout[13]~30_combout\ : std_logic;
SIGNAL \L_36|Yout[14]~31_combout\ : std_logic;
SIGNAL \L_13|Yout[15]~16_combout\ : std_logic;
SIGNAL \L_15|Yout[15]~0_combout\ : std_logic;
SIGNAL \L_15|Yout[0]~1_combout\ : std_logic;
SIGNAL \L_15|Yout[1]~2_combout\ : std_logic;
SIGNAL \L_15|Yout[2]~3_combout\ : std_logic;
SIGNAL \L_15|Yout[3]~4_combout\ : std_logic;
SIGNAL \L_15|Yout[4]~5_combout\ : std_logic;
SIGNAL \L_15|Yout[5]~6_combout\ : std_logic;
SIGNAL \L_15|Yout[6]~7_combout\ : std_logic;
SIGNAL \L_15|Yout[7]~8_combout\ : std_logic;
SIGNAL \L_15|Yout[8]~9_combout\ : std_logic;
SIGNAL \L_15|Yout[9]~10_combout\ : std_logic;
SIGNAL \L_15|Yout[10]~11_combout\ : std_logic;
SIGNAL \L_15|Yout[11]~12_combout\ : std_logic;
SIGNAL \L_15|Yout[12]~13_combout\ : std_logic;
SIGNAL \L_15|Yout[13]~14_combout\ : std_logic;
SIGNAL \L_15|Yout[14]~15_combout\ : std_logic;
SIGNAL \L_15|Yout[15]~16_combout\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_mult1~DATAOUT8\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_mult1~DATAOUT9\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_mult1~DATAOUT10\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_mult1~DATAOUT11\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_mult1~DATAOUT12\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_mult1~DATAOUT13\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_mult1~DATAOUT14\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_mult1~DATAOUT15\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_mult1~DATAOUT16\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_mult1~DATAOUT17\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_mult1~DATAOUT18\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_mult1~DATAOUT19\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_mult1~DATAOUT20\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_mult1~DATAOUT21\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_mult1~DATAOUT22\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_mult1~DATAOUT23\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_mult1~DATAOUT24\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_mult1~DATAOUT25\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_mult1~DATAOUT26\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_mult1~DATAOUT27\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_mult1~DATAOUT28\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_mult1~DATAOUT29\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_mult1~DATAOUT30\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_mult1~DATAOUT31\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_mult1~0\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_mult1~1\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_mult1~2\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_mult1~3\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_out2~DATAOUT15\ : std_logic;
SIGNAL \L_41|Yout[15]~16_combout\ : std_logic;
SIGNAL \L_43|Yout[15]~16_combout\ : std_logic;
SIGNAL \L_41|Yout[14]~15_combout\ : std_logic;
SIGNAL \L_41|Yout[13]~14_combout\ : std_logic;
SIGNAL \L_41|Yout[12]~13_combout\ : std_logic;
SIGNAL \L_45|O[11]~23\ : std_logic;
SIGNAL \L_45|O[12]~25\ : std_logic;
SIGNAL \L_45|O[13]~27\ : std_logic;
SIGNAL \L_45|O[14]~29\ : std_logic;
SIGNAL \L_45|O[15]~30_combout\ : std_logic;
SIGNAL \L_7|Mux0~0_combout\ : std_logic;
SIGNAL \L_7|Mux0~1_combout\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_mult1~DATAOUT13\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_mult1~DATAOUT14\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_mult1~DATAOUT15\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_mult1~DATAOUT16\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_mult1~DATAOUT17\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_mult1~DATAOUT18\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_mult1~DATAOUT19\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_mult1~DATAOUT20\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_mult1~DATAOUT21\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_mult1~DATAOUT22\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_mult1~DATAOUT23\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_mult1~DATAOUT24\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_mult1~DATAOUT25\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_mult1~DATAOUT26\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_mult1~DATAOUT27\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_mult1~DATAOUT28\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_mult1~DATAOUT29\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_mult1~DATAOUT30\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_mult1~DATAOUT31\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_mult1~0\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_mult1~1\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_mult1~2\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_mult1~3\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_out2~DATAOUT15\ : std_logic;
SIGNAL \L_7|Mux0~2_combout\ : std_logic;
SIGNAL \L_7|Mux0~3_combout\ : std_logic;
SIGNAL \L_36|Yout[15]~32_combout\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_mult1~DATAOUT12\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_out2~DATAOUT9\ : std_logic;
SIGNAL \TM2|Yout[9]~20_combout\ : std_logic;
SIGNAL \L_29|Yout[9]~9_combout\ : std_logic;
SIGNAL \L_29|Yout[10]~10_combout\ : std_logic;
SIGNAL \L_29|Yout[11]~11_combout\ : std_logic;
SIGNAL \v2[12]~input_o\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_out2~DATAOUT12\ : std_logic;
SIGNAL \TM2|Yout[12]~25_combout\ : std_logic;
SIGNAL \TM2|Yout[12]~26_combout\ : std_logic;
SIGNAL \L_29|Yout[12]~12_combout\ : std_logic;
SIGNAL \TM2|Yout[13]~46_combout\ : std_logic;
SIGNAL \L_29|Yout[13]~13_combout\ : std_logic;
SIGNAL \v2[14]~input_o\ : std_logic;
SIGNAL \TM2|Yout[14]~47_combout\ : std_logic;
SIGNAL \L_29|Yout[14]~14_combout\ : std_logic;
SIGNAL \L_29|Yout[15]~15_combout\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_mult1~DATAOUT15\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_mult1~DATAOUT16\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_mult1~DATAOUT17\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_mult1~DATAOUT18\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_mult1~DATAOUT19\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_mult1~DATAOUT20\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_mult1~DATAOUT21\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_mult1~DATAOUT22\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_mult1~DATAOUT23\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_mult1~DATAOUT24\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_mult1~DATAOUT25\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_mult1~DATAOUT26\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_mult1~DATAOUT27\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_mult1~DATAOUT28\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_mult1~DATAOUT29\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_mult1~DATAOUT30\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_mult1~DATAOUT31\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_mult1~0\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_mult1~1\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_mult1~2\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_mult1~3\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_out2~DATAOUT15\ : std_logic;
SIGNAL \v1[15]~input_o\ : std_logic;
SIGNAL \v1[14]~input_o\ : std_logic;
SIGNAL \L_20|Yout[15]~15_combout\ : std_logic;
SIGNAL \M2S2~input_o\ : std_logic;
SIGNAL \TM6|Yout[0]~66_combout\ : std_logic;
SIGNAL \TM6|Yout[0]~67_combout\ : std_logic;
SIGNAL \L_6|Equal0~2_combout\ : std_logic;
SIGNAL \L_6|Equal0~2clkctrl_outclk\ : std_logic;
SIGNAL \L_22|Yout[0]~0_combout\ : std_logic;
SIGNAL \L_22|Yout[0]~1_combout\ : std_logic;
SIGNAL \L_22|Yout[1]~2_combout\ : std_logic;
SIGNAL \L_22|Yout[1]~3_combout\ : std_logic;
SIGNAL \L_22|Yout[2]~4_combout\ : std_logic;
SIGNAL \L_22|Yout[2]~5_combout\ : std_logic;
SIGNAL \L_22|Yout[3]~6_combout\ : std_logic;
SIGNAL \L_22|Yout[3]~7_combout\ : std_logic;
SIGNAL \TM2|Yout[4]~37_combout\ : std_logic;
SIGNAL \L_22|Yout[4]~8_combout\ : std_logic;
SIGNAL \L_22|Yout[4]~9_combout\ : std_logic;
SIGNAL \L_22|Yout[5]~10_combout\ : std_logic;
SIGNAL \L_22|Yout[5]~11_combout\ : std_logic;
SIGNAL \L_22|Yout[6]~12_combout\ : std_logic;
SIGNAL \L_22|Yout[6]~13_combout\ : std_logic;
SIGNAL \L_22|Yout[7]~14_combout\ : std_logic;
SIGNAL \L_22|Yout[7]~15_combout\ : std_logic;
SIGNAL \L_22|Yout[8]~16_combout\ : std_logic;
SIGNAL \L_22|Yout[8]~17_combout\ : std_logic;
SIGNAL \L_22|Yout[9]~18_combout\ : std_logic;
SIGNAL \L_22|Yout[9]~19_combout\ : std_logic;
SIGNAL \L_22|Yout[10]~20_combout\ : std_logic;
SIGNAL \L_22|Yout[10]~21_combout\ : std_logic;
SIGNAL \TM6|Yout[11]~88_combout\ : std_logic;
SIGNAL \TM6|Yout[11]~89_combout\ : std_logic;
SIGNAL \L_22|Yout[11]~22_combout\ : std_logic;
SIGNAL \L_22|Yout[11]~23_combout\ : std_logic;
SIGNAL \L_22|Yout[12]~24_combout\ : std_logic;
SIGNAL \L_22|Yout[12]~25_combout\ : std_logic;
SIGNAL \L_22|Yout[13]~26_combout\ : std_logic;
SIGNAL \L_22|Yout[13]~27_combout\ : std_logic;
SIGNAL \L_22|Yout[14]~28_combout\ : std_logic;
SIGNAL \L_22|Yout[14]~29_combout\ : std_logic;
SIGNAL \L_22|Yout[15]~30_combout\ : std_logic;
SIGNAL \L_22|Yout[15]~31_combout\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_mult1~DATAOUT10\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_mult1~DATAOUT11\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_mult1~DATAOUT12\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_mult1~DATAOUT13\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_mult1~DATAOUT14\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_mult1~DATAOUT15\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_mult1~DATAOUT16\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_mult1~DATAOUT17\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_mult1~DATAOUT18\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_mult1~DATAOUT19\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_mult1~DATAOUT20\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_mult1~DATAOUT21\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_mult1~DATAOUT22\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_mult1~DATAOUT23\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_mult1~DATAOUT24\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_mult1~DATAOUT25\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_mult1~DATAOUT26\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_mult1~DATAOUT27\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_mult1~DATAOUT28\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_mult1~DATAOUT29\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_mult1~DATAOUT30\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_mult1~DATAOUT31\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_mult1~0\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_mult1~1\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_mult1~2\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_mult1~3\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_out2~DATAOUT14\ : std_logic;
SIGNAL \L_10|Yout[14]~28_combout\ : std_logic;
SIGNAL \L_10|Yout[14]~29_combout\ : std_logic;
SIGNAL \L_20|Yout[14]~14_combout\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_mult1~DATAOUT9\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_out2~DATAOUT15\ : std_logic;
SIGNAL \L_10|Yout[15]~30_combout\ : std_logic;
SIGNAL \L_10|Yout[15]~31_combout\ : std_logic;
SIGNAL \v2[15]~input_o\ : std_logic;
SIGNAL \TM2|Yout[15]~31_combout\ : std_logic;
SIGNAL \TM2|Yout[15]~32_combout\ : std_logic;
SIGNAL \L_57|Yout[15]~30_combout\ : std_logic;
SIGNAL \L_57|Yout[15]~31_combout\ : std_logic;
SIGNAL \L_55|Yout[15]~17_combout\ : std_logic;
SIGNAL \L_59|O[10]~21\ : std_logic;
SIGNAL \L_59|O[11]~23\ : std_logic;
SIGNAL \L_59|O[12]~25\ : std_logic;
SIGNAL \L_59|O[13]~27\ : std_logic;
SIGNAL \L_59|O[14]~29\ : std_logic;
SIGNAL \L_59|O[15]~30_combout\ : std_logic;
SIGNAL \TM6|Yout[15]~62_combout\ : std_logic;
SIGNAL \TM6|Yout[15]~63_combout\ : std_logic;
SIGNAL \TM6|Yout[15]~64_combout\ : std_logic;
SIGNAL \TM6|Yout[15]~65_combout\ : std_logic;
SIGNAL \L_50|Yout[15]~30_combout\ : std_logic;
SIGNAL \L_50|Yout[15]~31_combout\ : std_logic;
SIGNAL \L_48|Yout[15]~15_combout\ : std_logic;
SIGNAL \L_52|O[11]~23\ : std_logic;
SIGNAL \L_52|O[12]~25\ : std_logic;
SIGNAL \L_52|O[13]~27\ : std_logic;
SIGNAL \L_52|O[14]~29\ : std_logic;
SIGNAL \L_52|O[15]~30_combout\ : std_logic;
SIGNAL \TM6|Yout[15]~96_combout\ : std_logic;
SIGNAL \TM6|Yout[15]~97_combout\ : std_logic;
SIGNAL \L_36|Yout[15]~15_combout\ : std_logic;
SIGNAL \L_34|Yout[15]~16_combout\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_mult1~DATAOUT11\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_out2~dataout\ : std_logic;
SIGNAL \L_57|Yout[0]~0_combout\ : std_logic;
SIGNAL \L_57|Yout[0]~1_combout\ : std_logic;
SIGNAL \L_59|O[0]~0_combout\ : std_logic;
SIGNAL \TM2|Yout[0]~0_combout\ : std_logic;
SIGNAL \TM2|Yout[0]~1_combout\ : std_logic;
SIGNAL \L_29|Yout[0]~0_combout\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_mult1~DATAOUT14\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_out2~DATAOUT14\ : std_logic;
SIGNAL \TM6|Yout[14]~94_combout\ : std_logic;
SIGNAL \TM6|Yout[14]~95_combout\ : std_logic;
SIGNAL \L_50|Yout[14]~28_combout\ : std_logic;
SIGNAL \L_50|Yout[14]~29_combout\ : std_logic;
SIGNAL \L_52|O[14]~28_combout\ : std_logic;
SIGNAL \TM6|Yout[14]~58_combout\ : std_logic;
SIGNAL \TM6|Yout[14]~59_combout\ : std_logic;
SIGNAL \TM6|Yout[14]~60_combout\ : std_logic;
SIGNAL \TM6|Yout[14]~61_combout\ : std_logic;
SIGNAL \L_57|Yout[14]~28_combout\ : std_logic;
SIGNAL \L_55|Yout[14]~16_combout\ : std_logic;
SIGNAL \L_59|O[14]~28_combout\ : std_logic;
SIGNAL \TM2|Yout[14]~29_combout\ : std_logic;
SIGNAL \TM2|Yout[14]~30_combout\ : std_logic;
SIGNAL \L_27|Yout[14]~14_combout\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_mult1~DATAOUT13\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_out2~DATAOUT13\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_out2~DATAOUT13\ : std_logic;
SIGNAL \TM6|Yout[13]~54_combout\ : std_logic;
SIGNAL \TM6|Yout[13]~55_combout\ : std_logic;
SIGNAL \TM6|Yout[13]~56_combout\ : std_logic;
SIGNAL \TM6|Yout[13]~57_combout\ : std_logic;
SIGNAL \L_50|Yout[13]~26_combout\ : std_logic;
SIGNAL \L_48|Yout[13]~13_combout\ : std_logic;
SIGNAL \L_52|O[13]~26_combout\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_out2~DATAOUT13\ : std_logic;
SIGNAL \L_10|Yout[13]~26_combout\ : std_logic;
SIGNAL \v1[13]~input_o\ : std_logic;
SIGNAL \L_10|Yout[13]~27_combout\ : std_logic;
SIGNAL \L_20|Yout[13]~13_combout\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_mult1~DATAOUT8\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_out2~DATAOUT11\ : std_logic;
SIGNAL \L_10|Yout[11]~22_combout\ : std_logic;
SIGNAL \v1[11]~input_o\ : std_logic;
SIGNAL \L_10|Yout[11]~23_combout\ : std_logic;
SIGNAL \L_20|Yout[11]~11_combout\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_mult1~DATAOUT7\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_out2~DATAOUT12\ : std_logic;
SIGNAL \L_10|Yout[12]~24_combout\ : std_logic;
SIGNAL \L_10|Yout[12]~25_combout\ : std_logic;
SIGNAL \L_57|Yout[12]~25_combout\ : std_logic;
SIGNAL \L_59|O[12]~24_combout\ : std_logic;
SIGNAL \TM6|Yout[12]~50_combout\ : std_logic;
SIGNAL \TM6|Yout[12]~51_combout\ : std_logic;
SIGNAL \TM6|Yout[12]~52_combout\ : std_logic;
SIGNAL \TM6|Yout[12]~53_combout\ : std_logic;
SIGNAL \L_50|Yout[12]~24_combout\ : std_logic;
SIGNAL \L_50|Yout[12]~25_combout\ : std_logic;
SIGNAL \L_52|O[12]~24_combout\ : std_logic;
SIGNAL \TM6|Yout[12]~90_combout\ : std_logic;
SIGNAL \TM6|Yout[12]~91_combout\ : std_logic;
SIGNAL \L_36|Yout[12]~12_combout\ : std_logic;
SIGNAL \L_34|Yout[12]~13_combout\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_mult1~DATAOUT10\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_out2~DATAOUT11\ : std_logic;
SIGNAL \TM2|Yout[11]~24_combout\ : std_logic;
SIGNAL \L_57|Yout[11]~22_combout\ : std_logic;
SIGNAL \L_55|Yout[11]~13_combout\ : std_logic;
SIGNAL \L_59|O[11]~22_combout\ : std_logic;
SIGNAL \TM6|Yout[11]~46_combout\ : std_logic;
SIGNAL \TM6|Yout[11]~47_combout\ : std_logic;
SIGNAL \TM6|Yout[11]~48_combout\ : std_logic;
SIGNAL \TM6|Yout[11]~49_combout\ : std_logic;
SIGNAL \L_36|Yout[11]~11_combout\ : std_logic;
SIGNAL \L_34|Yout[11]~12_combout\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_mult1~DATAOUT9\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_out2~DATAOUT14\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_out2~DATAOUT14\ : std_logic;
SIGNAL \L_45|O[14]~28_combout\ : std_logic;
SIGNAL \v0[14]~input_o\ : std_logic;
SIGNAL \L_7|Mux1~0_combout\ : std_logic;
SIGNAL \L_7|Mux1~1_combout\ : std_logic;
SIGNAL \L_7|Mux1~2_combout\ : std_logic;
SIGNAL \L_7|Mux1~3_combout\ : std_logic;
SIGNAL \L_13|Yout[14]~15_combout\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_mult1~DATAOUT7\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_out2~DATAOUT12\ : std_logic;
SIGNAL \L_7|Mux3~0_combout\ : std_logic;
SIGNAL \L_45|O[12]~24_combout\ : std_logic;
SIGNAL \L_7|Mux3~1_combout\ : std_logic;
SIGNAL \L_7|Mux3~2_combout\ : std_logic;
SIGNAL \L_7|Mux3~3_combout\ : std_logic;
SIGNAL \L_13|Yout[12]~13_combout\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_mult1~DATAOUT6\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_out2~DATAOUT11\ : std_logic;
SIGNAL \L_7|Mux4~1_combout\ : std_logic;
SIGNAL \L_7|Mux4~2_combout\ : std_logic;
SIGNAL \L_7|Mux4~3_combout\ : std_logic;
SIGNAL \L_13|Yout[11]~12_combout\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_mult1~DATAOUT5\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_out2~DATAOUT8\ : std_logic;
SIGNAL \L_7|Mux7~0_combout\ : std_logic;
SIGNAL \L_7|Mux7~1_combout\ : std_logic;
SIGNAL \L_7|Mux7~2_combout\ : std_logic;
SIGNAL \L_7|Mux7~3_combout\ : std_logic;
SIGNAL \L_13|Yout[8]~9_combout\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_mult1~DATAOUT4\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_out2~DATAOUT10\ : std_logic;
SIGNAL \L_7|Mux5~0_combout\ : std_logic;
SIGNAL \L_45|O[10]~20_combout\ : std_logic;
SIGNAL \L_7|Mux5~1_combout\ : std_logic;
SIGNAL \L_7|Mux5~2_combout\ : std_logic;
SIGNAL \L_7|Mux5~3_combout\ : std_logic;
SIGNAL \L_34|Yout[10]~11_combout\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_mult1~DATAOUT8\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_out2~DATAOUT7\ : std_logic;
SIGNAL \TM6|Yout[7]~30_combout\ : std_logic;
SIGNAL \TM6|Yout[7]~31_combout\ : std_logic;
SIGNAL \TM6|Yout[7]~32_combout\ : std_logic;
SIGNAL \TM6|Yout[7]~33_combout\ : std_logic;
SIGNAL \L_50|Yout[7]~14_combout\ : std_logic;
SIGNAL \L_50|Yout[7]~15_combout\ : std_logic;
SIGNAL \L_52|O[7]~15\ : std_logic;
SIGNAL \L_52|O[8]~16_combout\ : std_logic;
SIGNAL \L_59|O[8]~16_combout\ : std_logic;
SIGNAL \TM6|Yout[8]~34_combout\ : std_logic;
SIGNAL \TM6|Yout[8]~35_combout\ : std_logic;
SIGNAL \TM6|Yout[8]~36_combout\ : std_logic;
SIGNAL \TM6|Yout[8]~37_combout\ : std_logic;
SIGNAL \L_50|Yout[8]~16_combout\ : std_logic;
SIGNAL \L_48|Yout[8]~8_combout\ : std_logic;
SIGNAL \L_52|O[8]~17\ : std_logic;
SIGNAL \L_52|O[9]~18_combout\ : std_logic;
SIGNAL \TM6|Yout[9]~38_combout\ : std_logic;
SIGNAL \TM6|Yout[9]~39_combout\ : std_logic;
SIGNAL \TM6|Yout[9]~40_combout\ : std_logic;
SIGNAL \TM6|Yout[9]~41_combout\ : std_logic;
SIGNAL \L_57|Yout[9]~18_combout\ : std_logic;
SIGNAL \L_57|Yout[9]~19_combout\ : std_logic;
SIGNAL \L_59|O[9]~18_combout\ : std_logic;
SIGNAL \L_45|O[9]~18_combout\ : std_logic;
SIGNAL \L_7|Mux6~2_combout\ : std_logic;
SIGNAL \L_7|Mux6~3_combout\ : std_logic;
SIGNAL \L_34|Yout[9]~10_combout\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_mult1~DATAOUT7\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_out2~DATAOUT6\ : std_logic;
SIGNAL \L_45|O[6]~12_combout\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_out2~DATAOUT6\ : std_logic;
SIGNAL \L_7|Mux9~0_combout\ : std_logic;
SIGNAL \L_7|Mux9~1_combout\ : std_logic;
SIGNAL \L_7|Mux9~2_combout\ : std_logic;
SIGNAL \L_7|Mux9~3_combout\ : std_logic;
SIGNAL \L_13|Yout[6]~7_combout\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_mult1~DATAOUT3\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_out2~DATAOUT13\ : std_logic;
SIGNAL \v0[13]~input_o\ : std_logic;
SIGNAL \L_45|O[13]~26_combout\ : std_logic;
SIGNAL \L_7|Mux2~0_combout\ : std_logic;
SIGNAL \L_7|Mux2~1_combout\ : std_logic;
SIGNAL \L_7|Mux2~2_combout\ : std_logic;
SIGNAL \L_7|Mux2~3_combout\ : std_logic;
SIGNAL \L_57|Yout[13]~26_combout\ : std_logic;
SIGNAL \L_55|Yout[13]~15_combout\ : std_logic;
SIGNAL \L_59|O[13]~26_combout\ : std_logic;
SIGNAL \TM2|Yout[13]~28_combout\ : std_logic;
SIGNAL \L_27|Yout[13]~13_combout\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_mult1~DATAOUT12\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_out2~DATAOUT12\ : std_logic;
SIGNAL \TM2|Yout[12]~45_combout\ : std_logic;
SIGNAL \L_27|Yout[12]~12_combout\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_mult1~DATAOUT11\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_out2~DATAOUT11\ : std_logic;
SIGNAL \TM2|Yout[11]~44_combout\ : std_logic;
SIGNAL \L_27|Yout[11]~11_combout\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_mult1~DATAOUT10\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_out2~DATAOUT8\ : std_logic;
SIGNAL \TM6|Yout[8]~82_combout\ : std_logic;
SIGNAL \TM6|Yout[8]~83_combout\ : std_logic;
SIGNAL \L_36|Yout[8]~8_combout\ : std_logic;
SIGNAL \L_34|Yout[8]~9_combout\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_mult1~DATAOUT6\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_out2~DATAOUT10\ : std_logic;
SIGNAL \TM2|Yout[10]~21_combout\ : std_logic;
SIGNAL \TM2|Yout[10]~22_combout\ : std_logic;
SIGNAL \L_27|Yout[10]~10_combout\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_mult1~DATAOUT9\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_out2~DATAOUT9\ : std_logic;
SIGNAL \TM2|Yout[9]~42_combout\ : std_logic;
SIGNAL \L_27|Yout[9]~9_combout\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_mult1~DATAOUT8\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_out2~DATAOUT10\ : std_logic;
SIGNAL \TM6|Yout[10]~86_combout\ : std_logic;
SIGNAL \TM6|Yout[10]~87_combout\ : std_logic;
SIGNAL \L_50|Yout[10]~20_combout\ : std_logic;
SIGNAL \L_50|Yout[10]~21_combout\ : std_logic;
SIGNAL \L_52|O[10]~20_combout\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_out2~DATAOUT10\ : std_logic;
SIGNAL \L_10|Yout[10]~20_combout\ : std_logic;
SIGNAL \L_10|Yout[10]~21_combout\ : std_logic;
SIGNAL \L_20|Yout[10]~10_combout\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_mult1~DATAOUT6\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_out2~DATAOUT9\ : std_logic;
SIGNAL \L_10|Yout[9]~18_combout\ : std_logic;
SIGNAL \L_10|Yout[9]~19_combout\ : std_logic;
SIGNAL \L_20|Yout[9]~9_combout\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_mult1~DATAOUT5\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_out2~DATAOUT6\ : std_logic;
SIGNAL \L_10|Yout[6]~12_combout\ : std_logic;
SIGNAL \L_10|Yout[6]~13_combout\ : std_logic;
SIGNAL \L_20|Yout[6]~6_combout\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_mult1~DATAOUT4\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_out2~DATAOUT5\ : std_logic;
SIGNAL \v1[5]~input_o\ : std_logic;
SIGNAL \L_10|Yout[5]~10_combout\ : std_logic;
SIGNAL \L_10|Yout[5]~11_combout\ : std_logic;
SIGNAL \L_20|Yout[5]~5_combout\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_mult1~DATAOUT3\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_out2~DATAOUT4\ : std_logic;
SIGNAL \L_10|Yout[4]~8_combout\ : std_logic;
SIGNAL \L_10|Yout[4]~9_combout\ : std_logic;
SIGNAL \L_20|Yout[4]~4_combout\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_mult1~DATAOUT2\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_out2~DATAOUT7\ : std_logic;
SIGNAL \L_10|Yout[7]~14_combout\ : std_logic;
SIGNAL \L_10|Yout[7]~15_combout\ : std_logic;
SIGNAL \L_57|Yout[7]~15_combout\ : std_logic;
SIGNAL \L_59|O[7]~14_combout\ : std_logic;
SIGNAL \L_45|O[7]~14_combout\ : std_logic;
SIGNAL \L_7|Mux8~2_combout\ : std_logic;
SIGNAL \L_7|Mux8~3_combout\ : std_logic;
SIGNAL \L_34|Yout[7]~8_combout\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_mult1~DATAOUT5\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_out2~DATAOUT3\ : std_logic;
SIGNAL \TM2|Yout[2]~5_combout\ : std_logic;
SIGNAL \TM2|Yout[2]~6_combout\ : std_logic;
SIGNAL \L_57|Yout[2]~4_combout\ : std_logic;
SIGNAL \L_57|Yout[2]~5_combout\ : std_logic;
SIGNAL \L_59|O[0]~1\ : std_logic;
SIGNAL \L_59|O[1]~3\ : std_logic;
SIGNAL \L_59|O[2]~5\ : std_logic;
SIGNAL \L_59|O[3]~6_combout\ : std_logic;
SIGNAL \TM6|Yout[3]~14_combout\ : std_logic;
SIGNAL \TM6|Yout[3]~15_combout\ : std_logic;
SIGNAL \TM6|Yout[3]~16_combout\ : std_logic;
SIGNAL \TM6|Yout[3]~17_combout\ : std_logic;
SIGNAL \TM2|Yout[3]~7_combout\ : std_logic;
SIGNAL \TM2|Yout[3]~8_combout\ : std_logic;
SIGNAL \L_57|Yout[3]~6_combout\ : std_logic;
SIGNAL \L_55|Yout[3]~5_combout\ : std_logic;
SIGNAL \L_59|O[3]~7\ : std_logic;
SIGNAL \L_59|O[4]~9\ : std_logic;
SIGNAL \L_59|O[5]~11\ : std_logic;
SIGNAL \L_59|O[6]~12_combout\ : std_logic;
SIGNAL \TM6|Yout[6]~26_combout\ : std_logic;
SIGNAL \TM6|Yout[6]~27_combout\ : std_logic;
SIGNAL \TM6|Yout[6]~28_combout\ : std_logic;
SIGNAL \TM6|Yout[6]~29_combout\ : std_logic;
SIGNAL \L_50|Yout[6]~12_combout\ : std_logic;
SIGNAL \L_50|Yout[6]~13_combout\ : std_logic;
SIGNAL \L_52|O[6]~12_combout\ : std_logic;
SIGNAL \TM6|Yout[6]~78_combout\ : std_logic;
SIGNAL \TM6|Yout[6]~79_combout\ : std_logic;
SIGNAL \L_36|Yout[6]~6_combout\ : std_logic;
SIGNAL \L_34|Yout[6]~7_combout\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_mult1~DATAOUT4\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_out2~DATAOUT5\ : std_logic;
SIGNAL \L_7|Mux10~2_combout\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_out2~DATAOUT5\ : std_logic;
SIGNAL \L_7|Mux10~0_combout\ : std_logic;
SIGNAL \L_7|Mux10~1_combout\ : std_logic;
SIGNAL \L_7|Mux10~3_combout\ : std_logic;
SIGNAL \L_34|Yout[5]~6_combout\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_mult1~DATAOUT3\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_out2~DATAOUT8\ : std_logic;
SIGNAL \TM2|Yout[8]~17_combout\ : std_logic;
SIGNAL \TM2|Yout[8]~18_combout\ : std_logic;
SIGNAL \L_27|Yout[8]~8_combout\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_mult1~DATAOUT7\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_out2~DATAOUT7\ : std_logic;
SIGNAL \TM2|Yout[7]~40_combout\ : std_logic;
SIGNAL \L_27|Yout[7]~7_combout\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_mult1~DATAOUT6\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_out2~DATAOUT6\ : std_logic;
SIGNAL \TM2|Yout[6]~39_combout\ : std_logic;
SIGNAL \L_27|Yout[6]~6_combout\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_mult1~DATAOUT5\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_out2~DATAOUT5\ : std_logic;
SIGNAL \v3[5]~input_o\ : std_logic;
SIGNAL \TM6|Yout[5]~76_combout\ : std_logic;
SIGNAL \TM6|Yout[5]~77_combout\ : std_logic;
SIGNAL \L_50|Yout[5]~10_combout\ : std_logic;
SIGNAL \L_48|Yout[5]~5_combout\ : std_logic;
SIGNAL \L_52|O[5]~10_combout\ : std_logic;
SIGNAL \TM6|Yout[5]~22_combout\ : std_logic;
SIGNAL \TM6|Yout[5]~23_combout\ : std_logic;
SIGNAL \TM6|Yout[5]~24_combout\ : std_logic;
SIGNAL \TM6|Yout[5]~25_combout\ : std_logic;
SIGNAL \L_57|Yout[5]~10_combout\ : std_logic;
SIGNAL \L_57|Yout[5]~11_combout\ : std_logic;
SIGNAL \L_59|O[5]~10_combout\ : std_logic;
SIGNAL \TM2|Yout[5]~12_combout\ : std_logic;
SIGNAL \L_27|Yout[5]~5_combout\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_mult1~DATAOUT4\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_out2~DATAOUT4\ : std_logic;
SIGNAL \TM6|Yout[4]~74_combout\ : std_logic;
SIGNAL \TM6|Yout[4]~75_combout\ : std_logic;
SIGNAL \L_50|Yout[4]~8_combout\ : std_logic;
SIGNAL \L_48|Yout[4]~4_combout\ : std_logic;
SIGNAL \L_52|O[4]~8_combout\ : std_logic;
SIGNAL \TM6|Yout[4]~18_combout\ : std_logic;
SIGNAL \TM6|Yout[4]~19_combout\ : std_logic;
SIGNAL \TM6|Yout[4]~20_combout\ : std_logic;
SIGNAL \TM6|Yout[4]~21_combout\ : std_logic;
SIGNAL \L_57|Yout[4]~8_combout\ : std_logic;
SIGNAL \L_57|Yout[4]~9_combout\ : std_logic;
SIGNAL \L_59|O[4]~8_combout\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_out2~DATAOUT4\ : std_logic;
SIGNAL \L_7|Mux11~0_combout\ : std_logic;
SIGNAL \L_7|Mux11~1_combout\ : std_logic;
SIGNAL \L_7|Mux11~2_combout\ : std_logic;
SIGNAL \L_7|Mux11~3_combout\ : std_logic;
SIGNAL \L_13|Yout[4]~5_combout\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_mult1~DATAOUT2\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_out2~DATAOUT2\ : std_logic;
SIGNAL \L_7|Mux13~0_combout\ : std_logic;
SIGNAL \L_7|Mux13~1_combout\ : std_logic;
SIGNAL \L_7|Mux13~2_combout\ : std_logic;
SIGNAL \L_7|Mux13~3_combout\ : std_logic;
SIGNAL \L_13|Yout[2]~3_combout\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_mult1~DATAOUT1\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_out2~DATAOUT3\ : std_logic;
SIGNAL \L_45|O[3]~6_combout\ : std_logic;
SIGNAL \L_7|Mux12~0_combout\ : std_logic;
SIGNAL \L_7|Mux12~1_combout\ : std_logic;
SIGNAL \L_7|Mux12~2_combout\ : std_logic;
SIGNAL \L_7|Mux12~3_combout\ : std_logic;
SIGNAL \L_34|Yout[3]~4_combout\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_mult1~DATAOUT2\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_out2~DATAOUT2\ : std_logic;
SIGNAL \TM6|Yout[2]~10_combout\ : std_logic;
SIGNAL \TM6|Yout[2]~11_combout\ : std_logic;
SIGNAL \TM6|Yout[2]~12_combout\ : std_logic;
SIGNAL \TM6|Yout[2]~13_combout\ : std_logic;
SIGNAL \L_36|Yout[2]~2_combout\ : std_logic;
SIGNAL \L_34|Yout[2]~3_combout\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_mult1~DATAOUT1\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_out2~DATAOUT4\ : std_logic;
SIGNAL \TM2|Yout[4]~9_combout\ : std_logic;
SIGNAL \TM2|Yout[4]~10_combout\ : std_logic;
SIGNAL \L_27|Yout[4]~4_combout\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_mult1~DATAOUT3\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_out2~DATAOUT3\ : std_logic;
SIGNAL \TM2|Yout[3]~36_combout\ : std_logic;
SIGNAL \L_27|Yout[3]~3_combout\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_mult1~DATAOUT2\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_out2~DATAOUT2\ : std_logic;
SIGNAL \TM6|Yout[2]~70_combout\ : std_logic;
SIGNAL \TM6|Yout[2]~71_combout\ : std_logic;
SIGNAL \L_50|Yout[2]~4_combout\ : std_logic;
SIGNAL \L_48|Yout[2]~2_combout\ : std_logic;
SIGNAL \L_52|O[2]~4_combout\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_out2~DATAOUT2\ : std_logic;
SIGNAL \L_10|Yout[2]~4_combout\ : std_logic;
SIGNAL \L_10|Yout[2]~5_combout\ : std_logic;
SIGNAL \L_20|Yout[2]~2_combout\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_mult1~DATAOUT1\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_out2~DATAOUT1\ : std_logic;
SIGNAL \L_10|Yout[1]~2_combout\ : std_logic;
SIGNAL \L_10|Yout[1]~3_combout\ : std_logic;
SIGNAL \L_20|Yout[1]~1_combout\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_mult1~dataout\ : std_logic;
SIGNAL \L_24|Mult0|auto_generated|mac_out2~dataout\ : std_logic;
SIGNAL \L_10|Yout[0]~0_combout\ : std_logic;
SIGNAL \v1[0]~input_o\ : std_logic;
SIGNAL \L_10|Yout[0]~1_combout\ : std_logic;
SIGNAL \L_50|Yout[0]~0_combout\ : std_logic;
SIGNAL \L_48|Yout[0]~0_combout\ : std_logic;
SIGNAL \L_52|O[0]~0_combout\ : std_logic;
SIGNAL \TM6|Yout[0]~1_combout\ : std_logic;
SIGNAL \TM6|Yout[0]~2_combout\ : std_logic;
SIGNAL \TM6|Yout[0]~3_combout\ : std_logic;
SIGNAL \TM6|Yout[0]~4_combout\ : std_logic;
SIGNAL \L_36|Yout[0]~0_combout\ : std_logic;
SIGNAL \L_34|Yout[0]~1_combout\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_mult1~dataout\ : std_logic;
SIGNAL \L_38|Mult0|auto_generated|mac_out2~DATAOUT1\ : std_logic;
SIGNAL \TM2|Yout[1]~4_combout\ : std_logic;
SIGNAL \L_27|Yout[1]~1_combout\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_mult1~DATAOUT1\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_out2~dataout\ : std_logic;
SIGNAL \TM2|Yout[0]~33_combout\ : std_logic;
SIGNAL \L_27|Yout[0]~0_combout\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_mult1~dataout\ : std_logic;
SIGNAL \L_31|Mult0|auto_generated|mac_out2~DATAOUT1\ : std_logic;
SIGNAL \TM6|Yout[1]~6_combout\ : std_logic;
SIGNAL \TM6|Yout[1]~7_combout\ : std_logic;
SIGNAL \TM6|Yout[1]~8_combout\ : std_logic;
SIGNAL \TM6|Yout[1]~9_combout\ : std_logic;
SIGNAL \L_57|Yout[1]~2_combout\ : std_logic;
SIGNAL \L_55|Yout[1]~3_combout\ : std_logic;
SIGNAL \L_59|O[1]~2_combout\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_out2~DATAOUT1\ : std_logic;
SIGNAL \L_45|O[1]~2_combout\ : std_logic;
SIGNAL \L_7|Mux14~0_combout\ : std_logic;
SIGNAL \L_7|Mux14~1_combout\ : std_logic;
SIGNAL \L_7|Mux14~2_combout\ : std_logic;
SIGNAL \L_7|Mux14~3_combout\ : std_logic;
SIGNAL \L_13|Yout[1]~2_combout\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_mult1~dataout\ : std_logic;
SIGNAL \L_17|Mult0|auto_generated|mac_out2~dataout\ : std_logic;
SIGNAL \L_7|Mux15~1_combout\ : std_logic;
SIGNAL \L_7|Mux15~2_combout\ : std_logic;
SIGNAL \L_7|Mux15~4_combout\ : std_logic;
SIGNAL \L_7|Mux15~5_combout\ : std_logic;
SIGNAL \L_9|I6[0]~0_combout\ : std_logic;
SIGNAL \L_9|I6[1]~1_combout\ : std_logic;
SIGNAL \L_9|I6[2]~2_combout\ : std_logic;
SIGNAL \L_9|I6[3]~3_combout\ : std_logic;
SIGNAL \L_9|I6[4]~4_combout\ : std_logic;
SIGNAL \L_9|I6[5]~5_combout\ : std_logic;
SIGNAL \L_9|I6[6]~6_combout\ : std_logic;
SIGNAL \L_9|I6[7]~7_combout\ : std_logic;
SIGNAL \L_9|I6[8]~8_combout\ : std_logic;
SIGNAL \L_9|I6[9]~9_combout\ : std_logic;
SIGNAL \L_9|I6[10]~10_combout\ : std_logic;
SIGNAL \L_9|I6[11]~11_combout\ : std_logic;
SIGNAL \L_9|I6[12]~12_combout\ : std_logic;
SIGNAL \L_9|I6[13]~13_combout\ : std_logic;
SIGNAL \L_9|I6[14]~14_combout\ : std_logic;
SIGNAL \L_9|I6[15]~15_combout\ : std_logic;
SIGNAL \L_6|Equal0~0_combout\ : std_logic;
SIGNAL \L_6|Equal0~0clkctrl_outclk\ : std_logic;
SIGNAL \TM6|Yout[7]~80_combout\ : std_logic;
SIGNAL \TM6|Yout[7]~81_combout\ : std_logic;
SIGNAL \TM8|I4[0]~0_combout\ : std_logic;
SIGNAL \TM8|I4[1]~1_combout\ : std_logic;
SIGNAL \TM8|I4[2]~2_combout\ : std_logic;
SIGNAL \TM8|I4[3]~3_combout\ : std_logic;
SIGNAL \TM8|I4[4]~4_combout\ : std_logic;
SIGNAL \TM8|I4[5]~5_combout\ : std_logic;
SIGNAL \TM8|I4[6]~6_combout\ : std_logic;
SIGNAL \TM8|I4[7]~7_combout\ : std_logic;
SIGNAL \TM8|I4[8]~8_combout\ : std_logic;
SIGNAL \TM8|I4[9]~9_combout\ : std_logic;
SIGNAL \TM8|I4[10]~10_combout\ : std_logic;
SIGNAL \TM8|I4[11]~11_combout\ : std_logic;
SIGNAL \TM8|I4[12]~12_combout\ : std_logic;
SIGNAL \TM8|I4[13]~13_combout\ : std_logic;
SIGNAL \TM8|I4[14]~14_combout\ : std_logic;
SIGNAL \TM8|I4[15]~15_combout\ : std_logic;
SIGNAL \TM3|I0\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \TM4|I0\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \L_19|I1\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \L_3|I0\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \TM7|I0\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \TM7|I1\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \TM4|I1\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \L_3|I1\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \L_3|I2\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \L_19|I0\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \L_6|I3\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \L_6|I2\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \L_6|I1\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \L_6|I0\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \L_12|I3\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \L_12|I2\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \L_12|I1\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \L_12|I0\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \L_26|I1\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \L_26|I0\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \L_33|I1\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \L_33|I0\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \L_40|I1\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \L_40|I0\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \L_47|I1\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \L_47|I0\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \L_54|I1\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \L_54|I0\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \L_61|I1\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \L_61|I0\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \TM3|I1\ : std_logic_vector(15 DOWNTO 0);

BEGIN

ww_v0 <= v0;
ww_v1 <= v1;
ww_v2 <= v2;
ww_v3 <= v3;
ww_BMS1 <= BMS1;
ww_BDS2 <= BDS2;
ww_YMS1 <= YMS1;
ww_YDS2 <= YDS2;
ww_GMS1 <= GMS1;
ww_GDS2 <= GDS2;
ww_RMS1 <= RMS1;
ww_RDS2 <= RDS2;
ww_TTS <= TTS;
ww_BTPM_S1 <= BTPM_S1;
ww_BTPD_S2 <= BTPD_S2;
ww_YTPM_S1 <= YTPM_S1;
ww_YTPD_S2 <= YTPD_S2;
ww_M1S1 <= M1S1;
ww_M1S2 <= M1S2;
ww_M1S3 <= M1S3;
ww_M2S1 <= M2S1;
ww_M2S2 <= M2S2;
ww_M2S3 <= M2S3;
ww_M3S1 <= M3S1;
ww_M3S2 <= M3S2;
ww_M3S3 <= M3S3;
ww_M4S1 <= M4S1;
ww_M4S2 <= M4S2;
ww_M4S3 <= M4S3;
ww_A1S1 <= A1S1;
ww_A1S2 <= A1S2;
ww_A1S3 <= A1S3;
ww_A2S1 <= A2S1;
ww_A2S2 <= A2S2;
ww_A2S3 <= A2S3;
ww_A3S1 <= A3S1;
ww_A3S2 <= A3S2;
ww_A3S3 <= A3S3;
Op1 <= ww_Op1;
Op2_1 <= ww_Op2_1;
Op2_2 <= ww_Op2_2;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\L_38|Mult0|auto_generated|mac_out2_DATAA_bus\ <= (\L_38|Mult0|auto_generated|mac_mult1~DATAOUT31\ & \L_38|Mult0|auto_generated|mac_mult1~DATAOUT30\ & \L_38|Mult0|auto_generated|mac_mult1~DATAOUT29\ & \L_38|Mult0|auto_generated|mac_mult1~DATAOUT28\ & 
\L_38|Mult0|auto_generated|mac_mult1~DATAOUT27\ & \L_38|Mult0|auto_generated|mac_mult1~DATAOUT26\ & \L_38|Mult0|auto_generated|mac_mult1~DATAOUT25\ & \L_38|Mult0|auto_generated|mac_mult1~DATAOUT24\ & \L_38|Mult0|auto_generated|mac_mult1~DATAOUT23\ & 
\L_38|Mult0|auto_generated|mac_mult1~DATAOUT22\ & \L_38|Mult0|auto_generated|mac_mult1~DATAOUT21\ & \L_38|Mult0|auto_generated|mac_mult1~DATAOUT20\ & \L_38|Mult0|auto_generated|mac_mult1~DATAOUT19\ & \L_38|Mult0|auto_generated|mac_mult1~DATAOUT18\ & 
\L_38|Mult0|auto_generated|mac_mult1~DATAOUT17\ & \L_38|Mult0|auto_generated|mac_mult1~DATAOUT16\ & \L_38|Mult0|auto_generated|mac_mult1~DATAOUT15\ & \L_38|Mult0|auto_generated|mac_mult1~DATAOUT14\ & \L_38|Mult0|auto_generated|mac_mult1~DATAOUT13\ & 
\L_38|Mult0|auto_generated|mac_mult1~DATAOUT12\ & \L_38|Mult0|auto_generated|mac_mult1~DATAOUT11\ & \L_38|Mult0|auto_generated|mac_mult1~DATAOUT10\ & \L_38|Mult0|auto_generated|mac_mult1~DATAOUT9\ & \L_38|Mult0|auto_generated|mac_mult1~DATAOUT8\ & 
\L_38|Mult0|auto_generated|mac_mult1~DATAOUT7\ & \L_38|Mult0|auto_generated|mac_mult1~DATAOUT6\ & \L_38|Mult0|auto_generated|mac_mult1~DATAOUT5\ & \L_38|Mult0|auto_generated|mac_mult1~DATAOUT4\ & \L_38|Mult0|auto_generated|mac_mult1~DATAOUT3\ & 
\L_38|Mult0|auto_generated|mac_mult1~DATAOUT2\ & \L_38|Mult0|auto_generated|mac_mult1~DATAOUT1\ & \L_38|Mult0|auto_generated|mac_mult1~dataout\ & \L_38|Mult0|auto_generated|mac_mult1~3\ & \L_38|Mult0|auto_generated|mac_mult1~2\ & 
\L_38|Mult0|auto_generated|mac_mult1~1\ & \L_38|Mult0|auto_generated|mac_mult1~0\);

\L_38|Mult0|auto_generated|mac_out2~0\ <= \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\(0);
\L_38|Mult0|auto_generated|mac_out2~1\ <= \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\(1);
\L_38|Mult0|auto_generated|mac_out2~2\ <= \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\(2);
\L_38|Mult0|auto_generated|mac_out2~3\ <= \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\(3);
\L_38|Mult0|auto_generated|mac_out2~dataout\ <= \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\(4);
\L_38|Mult0|auto_generated|mac_out2~DATAOUT1\ <= \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\(5);
\L_38|Mult0|auto_generated|mac_out2~DATAOUT2\ <= \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\(6);
\L_38|Mult0|auto_generated|mac_out2~DATAOUT3\ <= \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\(7);
\L_38|Mult0|auto_generated|mac_out2~DATAOUT4\ <= \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\(8);
\L_38|Mult0|auto_generated|mac_out2~DATAOUT5\ <= \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\(9);
\L_38|Mult0|auto_generated|mac_out2~DATAOUT6\ <= \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\(10);
\L_38|Mult0|auto_generated|mac_out2~DATAOUT7\ <= \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\(11);
\L_38|Mult0|auto_generated|mac_out2~DATAOUT8\ <= \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\(12);
\L_38|Mult0|auto_generated|mac_out2~DATAOUT9\ <= \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\(13);
\L_38|Mult0|auto_generated|mac_out2~DATAOUT10\ <= \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\(14);
\L_38|Mult0|auto_generated|mac_out2~DATAOUT11\ <= \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\(15);
\L_38|Mult0|auto_generated|mac_out2~DATAOUT12\ <= \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\(16);
\L_38|Mult0|auto_generated|mac_out2~DATAOUT13\ <= \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\(17);
\L_38|Mult0|auto_generated|mac_out2~DATAOUT14\ <= \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\(18);
\L_38|Mult0|auto_generated|mac_out2~DATAOUT15\ <= \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\(19);
\L_38|Mult0|auto_generated|mac_out2~DATAOUT16\ <= \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\(20);
\L_38|Mult0|auto_generated|mac_out2~DATAOUT17\ <= \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\(21);
\L_38|Mult0|auto_generated|mac_out2~DATAOUT18\ <= \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\(22);
\L_38|Mult0|auto_generated|mac_out2~DATAOUT19\ <= \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\(23);
\L_38|Mult0|auto_generated|mac_out2~DATAOUT20\ <= \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\(24);
\L_38|Mult0|auto_generated|mac_out2~DATAOUT21\ <= \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\(25);
\L_38|Mult0|auto_generated|mac_out2~DATAOUT22\ <= \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\(26);
\L_38|Mult0|auto_generated|mac_out2~DATAOUT23\ <= \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\(27);
\L_38|Mult0|auto_generated|mac_out2~DATAOUT24\ <= \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\(28);
\L_38|Mult0|auto_generated|mac_out2~DATAOUT25\ <= \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\(29);
\L_38|Mult0|auto_generated|mac_out2~DATAOUT26\ <= \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\(30);
\L_38|Mult0|auto_generated|mac_out2~DATAOUT27\ <= \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\(31);
\L_38|Mult0|auto_generated|mac_out2~DATAOUT28\ <= \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\(32);
\L_38|Mult0|auto_generated|mac_out2~DATAOUT29\ <= \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\(33);
\L_38|Mult0|auto_generated|mac_out2~DATAOUT30\ <= \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\(34);
\L_38|Mult0|auto_generated|mac_out2~DATAOUT31\ <= \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\(35);

\L_17|Mult0|auto_generated|mac_out2_DATAA_bus\ <= (\L_17|Mult0|auto_generated|mac_mult1~DATAOUT31\ & \L_17|Mult0|auto_generated|mac_mult1~DATAOUT30\ & \L_17|Mult0|auto_generated|mac_mult1~DATAOUT29\ & \L_17|Mult0|auto_generated|mac_mult1~DATAOUT28\ & 
\L_17|Mult0|auto_generated|mac_mult1~DATAOUT27\ & \L_17|Mult0|auto_generated|mac_mult1~DATAOUT26\ & \L_17|Mult0|auto_generated|mac_mult1~DATAOUT25\ & \L_17|Mult0|auto_generated|mac_mult1~DATAOUT24\ & \L_17|Mult0|auto_generated|mac_mult1~DATAOUT23\ & 
\L_17|Mult0|auto_generated|mac_mult1~DATAOUT22\ & \L_17|Mult0|auto_generated|mac_mult1~DATAOUT21\ & \L_17|Mult0|auto_generated|mac_mult1~DATAOUT20\ & \L_17|Mult0|auto_generated|mac_mult1~DATAOUT19\ & \L_17|Mult0|auto_generated|mac_mult1~DATAOUT18\ & 
\L_17|Mult0|auto_generated|mac_mult1~DATAOUT17\ & \L_17|Mult0|auto_generated|mac_mult1~DATAOUT16\ & \L_17|Mult0|auto_generated|mac_mult1~DATAOUT15\ & \L_17|Mult0|auto_generated|mac_mult1~DATAOUT14\ & \L_17|Mult0|auto_generated|mac_mult1~DATAOUT13\ & 
\L_17|Mult0|auto_generated|mac_mult1~DATAOUT12\ & \L_17|Mult0|auto_generated|mac_mult1~DATAOUT11\ & \L_17|Mult0|auto_generated|mac_mult1~DATAOUT10\ & \L_17|Mult0|auto_generated|mac_mult1~DATAOUT9\ & \L_17|Mult0|auto_generated|mac_mult1~DATAOUT8\ & 
\L_17|Mult0|auto_generated|mac_mult1~DATAOUT7\ & \L_17|Mult0|auto_generated|mac_mult1~DATAOUT6\ & \L_17|Mult0|auto_generated|mac_mult1~DATAOUT5\ & \L_17|Mult0|auto_generated|mac_mult1~DATAOUT4\ & \L_17|Mult0|auto_generated|mac_mult1~DATAOUT3\ & 
\L_17|Mult0|auto_generated|mac_mult1~DATAOUT2\ & \L_17|Mult0|auto_generated|mac_mult1~DATAOUT1\ & \L_17|Mult0|auto_generated|mac_mult1~dataout\ & \L_17|Mult0|auto_generated|mac_mult1~3\ & \L_17|Mult0|auto_generated|mac_mult1~2\ & 
\L_17|Mult0|auto_generated|mac_mult1~1\ & \L_17|Mult0|auto_generated|mac_mult1~0\);

\L_17|Mult0|auto_generated|mac_out2~0\ <= \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\(0);
\L_17|Mult0|auto_generated|mac_out2~1\ <= \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\(1);
\L_17|Mult0|auto_generated|mac_out2~2\ <= \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\(2);
\L_17|Mult0|auto_generated|mac_out2~3\ <= \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\(3);
\L_17|Mult0|auto_generated|mac_out2~dataout\ <= \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\(4);
\L_17|Mult0|auto_generated|mac_out2~DATAOUT1\ <= \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\(5);
\L_17|Mult0|auto_generated|mac_out2~DATAOUT2\ <= \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\(6);
\L_17|Mult0|auto_generated|mac_out2~DATAOUT3\ <= \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\(7);
\L_17|Mult0|auto_generated|mac_out2~DATAOUT4\ <= \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\(8);
\L_17|Mult0|auto_generated|mac_out2~DATAOUT5\ <= \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\(9);
\L_17|Mult0|auto_generated|mac_out2~DATAOUT6\ <= \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\(10);
\L_17|Mult0|auto_generated|mac_out2~DATAOUT7\ <= \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\(11);
\L_17|Mult0|auto_generated|mac_out2~DATAOUT8\ <= \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\(12);
\L_17|Mult0|auto_generated|mac_out2~DATAOUT9\ <= \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\(13);
\L_17|Mult0|auto_generated|mac_out2~DATAOUT10\ <= \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\(14);
\L_17|Mult0|auto_generated|mac_out2~DATAOUT11\ <= \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\(15);
\L_17|Mult0|auto_generated|mac_out2~DATAOUT12\ <= \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\(16);
\L_17|Mult0|auto_generated|mac_out2~DATAOUT13\ <= \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\(17);
\L_17|Mult0|auto_generated|mac_out2~DATAOUT14\ <= \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\(18);
\L_17|Mult0|auto_generated|mac_out2~DATAOUT15\ <= \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\(19);
\L_17|Mult0|auto_generated|mac_out2~DATAOUT16\ <= \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\(20);
\L_17|Mult0|auto_generated|mac_out2~DATAOUT17\ <= \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\(21);
\L_17|Mult0|auto_generated|mac_out2~DATAOUT18\ <= \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\(22);
\L_17|Mult0|auto_generated|mac_out2~DATAOUT19\ <= \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\(23);
\L_17|Mult0|auto_generated|mac_out2~DATAOUT20\ <= \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\(24);
\L_17|Mult0|auto_generated|mac_out2~DATAOUT21\ <= \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\(25);
\L_17|Mult0|auto_generated|mac_out2~DATAOUT22\ <= \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\(26);
\L_17|Mult0|auto_generated|mac_out2~DATAOUT23\ <= \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\(27);
\L_17|Mult0|auto_generated|mac_out2~DATAOUT24\ <= \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\(28);
\L_17|Mult0|auto_generated|mac_out2~DATAOUT25\ <= \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\(29);
\L_17|Mult0|auto_generated|mac_out2~DATAOUT26\ <= \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\(30);
\L_17|Mult0|auto_generated|mac_out2~DATAOUT27\ <= \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\(31);
\L_17|Mult0|auto_generated|mac_out2~DATAOUT28\ <= \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\(32);
\L_17|Mult0|auto_generated|mac_out2~DATAOUT29\ <= \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\(33);
\L_17|Mult0|auto_generated|mac_out2~DATAOUT30\ <= \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\(34);
\L_17|Mult0|auto_generated|mac_out2~DATAOUT31\ <= \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\(35);

\L_38|Mult0|auto_generated|mac_mult1_DATAA_bus\ <= (\L_34|Yout[15]~16_combout\ & \L_34|Yout[14]~15_combout\ & \L_34|Yout[13]~14_combout\ & \L_34|Yout[12]~13_combout\ & \L_34|Yout[11]~12_combout\ & \L_34|Yout[10]~11_combout\ & \L_34|Yout[9]~10_combout\ & 
\L_34|Yout[8]~9_combout\ & \L_34|Yout[7]~8_combout\ & \L_34|Yout[6]~7_combout\ & \L_34|Yout[5]~6_combout\ & \L_34|Yout[4]~5_combout\ & \L_34|Yout[3]~4_combout\ & \L_34|Yout[2]~3_combout\ & \L_34|Yout[1]~2_combout\ & \L_34|Yout[0]~1_combout\ & gnd & gnd);

\L_38|Mult0|auto_generated|mac_mult1_DATAB_bus\ <= (\L_36|Yout[15]~32_combout\ & \L_36|Yout[14]~31_combout\ & \L_36|Yout[13]~30_combout\ & \L_36|Yout[12]~29_combout\ & \L_36|Yout[11]~28_combout\ & \L_36|Yout[10]~27_combout\ & \L_36|Yout[9]~26_combout\ & 
\L_36|Yout[8]~25_combout\ & \L_36|Yout[7]~24_combout\ & \L_36|Yout[6]~23_combout\ & \L_36|Yout[5]~22_combout\ & \L_36|Yout[4]~21_combout\ & \L_36|Yout[3]~20_combout\ & \L_36|Yout[2]~19_combout\ & \L_36|Yout[1]~18_combout\ & \L_36|Yout[0]~17_combout\ & gnd
& gnd);

\L_38|Mult0|auto_generated|mac_mult1~0\ <= \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(0);
\L_38|Mult0|auto_generated|mac_mult1~1\ <= \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(1);
\L_38|Mult0|auto_generated|mac_mult1~2\ <= \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(2);
\L_38|Mult0|auto_generated|mac_mult1~3\ <= \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(3);
\L_38|Mult0|auto_generated|mac_mult1~dataout\ <= \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(4);
\L_38|Mult0|auto_generated|mac_mult1~DATAOUT1\ <= \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(5);
\L_38|Mult0|auto_generated|mac_mult1~DATAOUT2\ <= \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(6);
\L_38|Mult0|auto_generated|mac_mult1~DATAOUT3\ <= \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(7);
\L_38|Mult0|auto_generated|mac_mult1~DATAOUT4\ <= \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(8);
\L_38|Mult0|auto_generated|mac_mult1~DATAOUT5\ <= \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(9);
\L_38|Mult0|auto_generated|mac_mult1~DATAOUT6\ <= \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(10);
\L_38|Mult0|auto_generated|mac_mult1~DATAOUT7\ <= \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(11);
\L_38|Mult0|auto_generated|mac_mult1~DATAOUT8\ <= \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(12);
\L_38|Mult0|auto_generated|mac_mult1~DATAOUT9\ <= \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(13);
\L_38|Mult0|auto_generated|mac_mult1~DATAOUT10\ <= \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(14);
\L_38|Mult0|auto_generated|mac_mult1~DATAOUT11\ <= \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(15);
\L_38|Mult0|auto_generated|mac_mult1~DATAOUT12\ <= \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(16);
\L_38|Mult0|auto_generated|mac_mult1~DATAOUT13\ <= \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(17);
\L_38|Mult0|auto_generated|mac_mult1~DATAOUT14\ <= \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(18);
\L_38|Mult0|auto_generated|mac_mult1~DATAOUT15\ <= \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(19);
\L_38|Mult0|auto_generated|mac_mult1~DATAOUT16\ <= \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(20);
\L_38|Mult0|auto_generated|mac_mult1~DATAOUT17\ <= \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(21);
\L_38|Mult0|auto_generated|mac_mult1~DATAOUT18\ <= \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(22);
\L_38|Mult0|auto_generated|mac_mult1~DATAOUT19\ <= \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(23);
\L_38|Mult0|auto_generated|mac_mult1~DATAOUT20\ <= \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(24);
\L_38|Mult0|auto_generated|mac_mult1~DATAOUT21\ <= \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(25);
\L_38|Mult0|auto_generated|mac_mult1~DATAOUT22\ <= \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(26);
\L_38|Mult0|auto_generated|mac_mult1~DATAOUT23\ <= \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(27);
\L_38|Mult0|auto_generated|mac_mult1~DATAOUT24\ <= \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(28);
\L_38|Mult0|auto_generated|mac_mult1~DATAOUT25\ <= \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(29);
\L_38|Mult0|auto_generated|mac_mult1~DATAOUT26\ <= \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(30);
\L_38|Mult0|auto_generated|mac_mult1~DATAOUT27\ <= \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(31);
\L_38|Mult0|auto_generated|mac_mult1~DATAOUT28\ <= \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(32);
\L_38|Mult0|auto_generated|mac_mult1~DATAOUT29\ <= \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(33);
\L_38|Mult0|auto_generated|mac_mult1~DATAOUT30\ <= \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(34);
\L_38|Mult0|auto_generated|mac_mult1~DATAOUT31\ <= \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(35);

\L_17|Mult0|auto_generated|mac_mult1_DATAA_bus\ <= (\L_13|Yout[15]~16_combout\ & \L_13|Yout[14]~15_combout\ & \L_13|Yout[13]~14_combout\ & \L_13|Yout[12]~13_combout\ & \L_13|Yout[11]~12_combout\ & \L_13|Yout[10]~11_combout\ & \L_13|Yout[9]~10_combout\ & 
\L_13|Yout[8]~9_combout\ & \L_13|Yout[7]~8_combout\ & \L_13|Yout[6]~7_combout\ & \L_13|Yout[5]~6_combout\ & \L_13|Yout[4]~5_combout\ & \L_13|Yout[3]~4_combout\ & \L_13|Yout[2]~3_combout\ & \L_13|Yout[1]~2_combout\ & \L_13|Yout[0]~1_combout\ & gnd & gnd);

\L_17|Mult0|auto_generated|mac_mult1_DATAB_bus\ <= (\L_15|Yout[15]~16_combout\ & \L_15|Yout[14]~15_combout\ & \L_15|Yout[13]~14_combout\ & \L_15|Yout[12]~13_combout\ & \L_15|Yout[11]~12_combout\ & \L_15|Yout[10]~11_combout\ & \L_15|Yout[9]~10_combout\ & 
\L_15|Yout[8]~9_combout\ & \L_15|Yout[7]~8_combout\ & \L_15|Yout[6]~7_combout\ & \L_15|Yout[5]~6_combout\ & \L_15|Yout[4]~5_combout\ & \L_15|Yout[3]~4_combout\ & \L_15|Yout[2]~3_combout\ & \L_15|Yout[1]~2_combout\ & \L_15|Yout[0]~1_combout\ & gnd & gnd);

\L_17|Mult0|auto_generated|mac_mult1~0\ <= \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(0);
\L_17|Mult0|auto_generated|mac_mult1~1\ <= \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(1);
\L_17|Mult0|auto_generated|mac_mult1~2\ <= \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(2);
\L_17|Mult0|auto_generated|mac_mult1~3\ <= \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(3);
\L_17|Mult0|auto_generated|mac_mult1~dataout\ <= \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(4);
\L_17|Mult0|auto_generated|mac_mult1~DATAOUT1\ <= \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(5);
\L_17|Mult0|auto_generated|mac_mult1~DATAOUT2\ <= \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(6);
\L_17|Mult0|auto_generated|mac_mult1~DATAOUT3\ <= \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(7);
\L_17|Mult0|auto_generated|mac_mult1~DATAOUT4\ <= \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(8);
\L_17|Mult0|auto_generated|mac_mult1~DATAOUT5\ <= \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(9);
\L_17|Mult0|auto_generated|mac_mult1~DATAOUT6\ <= \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(10);
\L_17|Mult0|auto_generated|mac_mult1~DATAOUT7\ <= \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(11);
\L_17|Mult0|auto_generated|mac_mult1~DATAOUT8\ <= \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(12);
\L_17|Mult0|auto_generated|mac_mult1~DATAOUT9\ <= \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(13);
\L_17|Mult0|auto_generated|mac_mult1~DATAOUT10\ <= \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(14);
\L_17|Mult0|auto_generated|mac_mult1~DATAOUT11\ <= \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(15);
\L_17|Mult0|auto_generated|mac_mult1~DATAOUT12\ <= \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(16);
\L_17|Mult0|auto_generated|mac_mult1~DATAOUT13\ <= \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(17);
\L_17|Mult0|auto_generated|mac_mult1~DATAOUT14\ <= \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(18);
\L_17|Mult0|auto_generated|mac_mult1~DATAOUT15\ <= \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(19);
\L_17|Mult0|auto_generated|mac_mult1~DATAOUT16\ <= \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(20);
\L_17|Mult0|auto_generated|mac_mult1~DATAOUT17\ <= \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(21);
\L_17|Mult0|auto_generated|mac_mult1~DATAOUT18\ <= \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(22);
\L_17|Mult0|auto_generated|mac_mult1~DATAOUT19\ <= \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(23);
\L_17|Mult0|auto_generated|mac_mult1~DATAOUT20\ <= \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(24);
\L_17|Mult0|auto_generated|mac_mult1~DATAOUT21\ <= \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(25);
\L_17|Mult0|auto_generated|mac_mult1~DATAOUT22\ <= \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(26);
\L_17|Mult0|auto_generated|mac_mult1~DATAOUT23\ <= \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(27);
\L_17|Mult0|auto_generated|mac_mult1~DATAOUT24\ <= \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(28);
\L_17|Mult0|auto_generated|mac_mult1~DATAOUT25\ <= \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(29);
\L_17|Mult0|auto_generated|mac_mult1~DATAOUT26\ <= \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(30);
\L_17|Mult0|auto_generated|mac_mult1~DATAOUT27\ <= \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(31);
\L_17|Mult0|auto_generated|mac_mult1~DATAOUT28\ <= \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(32);
\L_17|Mult0|auto_generated|mac_mult1~DATAOUT29\ <= \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(33);
\L_17|Mult0|auto_generated|mac_mult1~DATAOUT30\ <= \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(34);
\L_17|Mult0|auto_generated|mac_mult1~DATAOUT31\ <= \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(35);

\L_31|Mult0|auto_generated|mac_out2_DATAA_bus\ <= (\L_31|Mult0|auto_generated|mac_mult1~DATAOUT31\ & \L_31|Mult0|auto_generated|mac_mult1~DATAOUT30\ & \L_31|Mult0|auto_generated|mac_mult1~DATAOUT29\ & \L_31|Mult0|auto_generated|mac_mult1~DATAOUT28\ & 
\L_31|Mult0|auto_generated|mac_mult1~DATAOUT27\ & \L_31|Mult0|auto_generated|mac_mult1~DATAOUT26\ & \L_31|Mult0|auto_generated|mac_mult1~DATAOUT25\ & \L_31|Mult0|auto_generated|mac_mult1~DATAOUT24\ & \L_31|Mult0|auto_generated|mac_mult1~DATAOUT23\ & 
\L_31|Mult0|auto_generated|mac_mult1~DATAOUT22\ & \L_31|Mult0|auto_generated|mac_mult1~DATAOUT21\ & \L_31|Mult0|auto_generated|mac_mult1~DATAOUT20\ & \L_31|Mult0|auto_generated|mac_mult1~DATAOUT19\ & \L_31|Mult0|auto_generated|mac_mult1~DATAOUT18\ & 
\L_31|Mult0|auto_generated|mac_mult1~DATAOUT17\ & \L_31|Mult0|auto_generated|mac_mult1~DATAOUT16\ & \L_31|Mult0|auto_generated|mac_mult1~DATAOUT15\ & \L_31|Mult0|auto_generated|mac_mult1~DATAOUT14\ & \L_31|Mult0|auto_generated|mac_mult1~DATAOUT13\ & 
\L_31|Mult0|auto_generated|mac_mult1~DATAOUT12\ & \L_31|Mult0|auto_generated|mac_mult1~DATAOUT11\ & \L_31|Mult0|auto_generated|mac_mult1~DATAOUT10\ & \L_31|Mult0|auto_generated|mac_mult1~DATAOUT9\ & \L_31|Mult0|auto_generated|mac_mult1~DATAOUT8\ & 
\L_31|Mult0|auto_generated|mac_mult1~DATAOUT7\ & \L_31|Mult0|auto_generated|mac_mult1~DATAOUT6\ & \L_31|Mult0|auto_generated|mac_mult1~DATAOUT5\ & \L_31|Mult0|auto_generated|mac_mult1~DATAOUT4\ & \L_31|Mult0|auto_generated|mac_mult1~DATAOUT3\ & 
\L_31|Mult0|auto_generated|mac_mult1~DATAOUT2\ & \L_31|Mult0|auto_generated|mac_mult1~DATAOUT1\ & \L_31|Mult0|auto_generated|mac_mult1~dataout\ & \L_31|Mult0|auto_generated|mac_mult1~3\ & \L_31|Mult0|auto_generated|mac_mult1~2\ & 
\L_31|Mult0|auto_generated|mac_mult1~1\ & \L_31|Mult0|auto_generated|mac_mult1~0\);

\L_31|Mult0|auto_generated|mac_out2~0\ <= \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\(0);
\L_31|Mult0|auto_generated|mac_out2~1\ <= \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\(1);
\L_31|Mult0|auto_generated|mac_out2~2\ <= \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\(2);
\L_31|Mult0|auto_generated|mac_out2~3\ <= \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\(3);
\L_31|Mult0|auto_generated|mac_out2~dataout\ <= \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\(4);
\L_31|Mult0|auto_generated|mac_out2~DATAOUT1\ <= \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\(5);
\L_31|Mult0|auto_generated|mac_out2~DATAOUT2\ <= \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\(6);
\L_31|Mult0|auto_generated|mac_out2~DATAOUT3\ <= \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\(7);
\L_31|Mult0|auto_generated|mac_out2~DATAOUT4\ <= \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\(8);
\L_31|Mult0|auto_generated|mac_out2~DATAOUT5\ <= \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\(9);
\L_31|Mult0|auto_generated|mac_out2~DATAOUT6\ <= \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\(10);
\L_31|Mult0|auto_generated|mac_out2~DATAOUT7\ <= \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\(11);
\L_31|Mult0|auto_generated|mac_out2~DATAOUT8\ <= \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\(12);
\L_31|Mult0|auto_generated|mac_out2~DATAOUT9\ <= \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\(13);
\L_31|Mult0|auto_generated|mac_out2~DATAOUT10\ <= \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\(14);
\L_31|Mult0|auto_generated|mac_out2~DATAOUT11\ <= \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\(15);
\L_31|Mult0|auto_generated|mac_out2~DATAOUT12\ <= \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\(16);
\L_31|Mult0|auto_generated|mac_out2~DATAOUT13\ <= \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\(17);
\L_31|Mult0|auto_generated|mac_out2~DATAOUT14\ <= \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\(18);
\L_31|Mult0|auto_generated|mac_out2~DATAOUT15\ <= \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\(19);
\L_31|Mult0|auto_generated|mac_out2~DATAOUT16\ <= \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\(20);
\L_31|Mult0|auto_generated|mac_out2~DATAOUT17\ <= \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\(21);
\L_31|Mult0|auto_generated|mac_out2~DATAOUT18\ <= \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\(22);
\L_31|Mult0|auto_generated|mac_out2~DATAOUT19\ <= \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\(23);
\L_31|Mult0|auto_generated|mac_out2~DATAOUT20\ <= \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\(24);
\L_31|Mult0|auto_generated|mac_out2~DATAOUT21\ <= \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\(25);
\L_31|Mult0|auto_generated|mac_out2~DATAOUT22\ <= \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\(26);
\L_31|Mult0|auto_generated|mac_out2~DATAOUT23\ <= \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\(27);
\L_31|Mult0|auto_generated|mac_out2~DATAOUT24\ <= \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\(28);
\L_31|Mult0|auto_generated|mac_out2~DATAOUT25\ <= \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\(29);
\L_31|Mult0|auto_generated|mac_out2~DATAOUT26\ <= \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\(30);
\L_31|Mult0|auto_generated|mac_out2~DATAOUT27\ <= \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\(31);
\L_31|Mult0|auto_generated|mac_out2~DATAOUT28\ <= \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\(32);
\L_31|Mult0|auto_generated|mac_out2~DATAOUT29\ <= \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\(33);
\L_31|Mult0|auto_generated|mac_out2~DATAOUT30\ <= \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\(34);
\L_31|Mult0|auto_generated|mac_out2~DATAOUT31\ <= \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\(35);

\L_24|Mult0|auto_generated|mac_out2_DATAA_bus\ <= (\L_24|Mult0|auto_generated|mac_mult1~DATAOUT31\ & \L_24|Mult0|auto_generated|mac_mult1~DATAOUT30\ & \L_24|Mult0|auto_generated|mac_mult1~DATAOUT29\ & \L_24|Mult0|auto_generated|mac_mult1~DATAOUT28\ & 
\L_24|Mult0|auto_generated|mac_mult1~DATAOUT27\ & \L_24|Mult0|auto_generated|mac_mult1~DATAOUT26\ & \L_24|Mult0|auto_generated|mac_mult1~DATAOUT25\ & \L_24|Mult0|auto_generated|mac_mult1~DATAOUT24\ & \L_24|Mult0|auto_generated|mac_mult1~DATAOUT23\ & 
\L_24|Mult0|auto_generated|mac_mult1~DATAOUT22\ & \L_24|Mult0|auto_generated|mac_mult1~DATAOUT21\ & \L_24|Mult0|auto_generated|mac_mult1~DATAOUT20\ & \L_24|Mult0|auto_generated|mac_mult1~DATAOUT19\ & \L_24|Mult0|auto_generated|mac_mult1~DATAOUT18\ & 
\L_24|Mult0|auto_generated|mac_mult1~DATAOUT17\ & \L_24|Mult0|auto_generated|mac_mult1~DATAOUT16\ & \L_24|Mult0|auto_generated|mac_mult1~DATAOUT15\ & \L_24|Mult0|auto_generated|mac_mult1~DATAOUT14\ & \L_24|Mult0|auto_generated|mac_mult1~DATAOUT13\ & 
\L_24|Mult0|auto_generated|mac_mult1~DATAOUT12\ & \L_24|Mult0|auto_generated|mac_mult1~DATAOUT11\ & \L_24|Mult0|auto_generated|mac_mult1~DATAOUT10\ & \L_24|Mult0|auto_generated|mac_mult1~DATAOUT9\ & \L_24|Mult0|auto_generated|mac_mult1~DATAOUT8\ & 
\L_24|Mult0|auto_generated|mac_mult1~DATAOUT7\ & \L_24|Mult0|auto_generated|mac_mult1~DATAOUT6\ & \L_24|Mult0|auto_generated|mac_mult1~DATAOUT5\ & \L_24|Mult0|auto_generated|mac_mult1~DATAOUT4\ & \L_24|Mult0|auto_generated|mac_mult1~DATAOUT3\ & 
\L_24|Mult0|auto_generated|mac_mult1~DATAOUT2\ & \L_24|Mult0|auto_generated|mac_mult1~DATAOUT1\ & \L_24|Mult0|auto_generated|mac_mult1~dataout\ & \L_24|Mult0|auto_generated|mac_mult1~3\ & \L_24|Mult0|auto_generated|mac_mult1~2\ & 
\L_24|Mult0|auto_generated|mac_mult1~1\ & \L_24|Mult0|auto_generated|mac_mult1~0\);

\L_24|Mult0|auto_generated|mac_out2~0\ <= \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\(0);
\L_24|Mult0|auto_generated|mac_out2~1\ <= \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\(1);
\L_24|Mult0|auto_generated|mac_out2~2\ <= \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\(2);
\L_24|Mult0|auto_generated|mac_out2~3\ <= \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\(3);
\L_24|Mult0|auto_generated|mac_out2~dataout\ <= \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\(4);
\L_24|Mult0|auto_generated|mac_out2~DATAOUT1\ <= \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\(5);
\L_24|Mult0|auto_generated|mac_out2~DATAOUT2\ <= \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\(6);
\L_24|Mult0|auto_generated|mac_out2~DATAOUT3\ <= \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\(7);
\L_24|Mult0|auto_generated|mac_out2~DATAOUT4\ <= \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\(8);
\L_24|Mult0|auto_generated|mac_out2~DATAOUT5\ <= \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\(9);
\L_24|Mult0|auto_generated|mac_out2~DATAOUT6\ <= \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\(10);
\L_24|Mult0|auto_generated|mac_out2~DATAOUT7\ <= \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\(11);
\L_24|Mult0|auto_generated|mac_out2~DATAOUT8\ <= \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\(12);
\L_24|Mult0|auto_generated|mac_out2~DATAOUT9\ <= \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\(13);
\L_24|Mult0|auto_generated|mac_out2~DATAOUT10\ <= \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\(14);
\L_24|Mult0|auto_generated|mac_out2~DATAOUT11\ <= \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\(15);
\L_24|Mult0|auto_generated|mac_out2~DATAOUT12\ <= \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\(16);
\L_24|Mult0|auto_generated|mac_out2~DATAOUT13\ <= \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\(17);
\L_24|Mult0|auto_generated|mac_out2~DATAOUT14\ <= \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\(18);
\L_24|Mult0|auto_generated|mac_out2~DATAOUT15\ <= \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\(19);
\L_24|Mult0|auto_generated|mac_out2~DATAOUT16\ <= \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\(20);
\L_24|Mult0|auto_generated|mac_out2~DATAOUT17\ <= \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\(21);
\L_24|Mult0|auto_generated|mac_out2~DATAOUT18\ <= \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\(22);
\L_24|Mult0|auto_generated|mac_out2~DATAOUT19\ <= \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\(23);
\L_24|Mult0|auto_generated|mac_out2~DATAOUT20\ <= \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\(24);
\L_24|Mult0|auto_generated|mac_out2~DATAOUT21\ <= \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\(25);
\L_24|Mult0|auto_generated|mac_out2~DATAOUT22\ <= \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\(26);
\L_24|Mult0|auto_generated|mac_out2~DATAOUT23\ <= \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\(27);
\L_24|Mult0|auto_generated|mac_out2~DATAOUT24\ <= \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\(28);
\L_24|Mult0|auto_generated|mac_out2~DATAOUT25\ <= \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\(29);
\L_24|Mult0|auto_generated|mac_out2~DATAOUT26\ <= \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\(30);
\L_24|Mult0|auto_generated|mac_out2~DATAOUT27\ <= \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\(31);
\L_24|Mult0|auto_generated|mac_out2~DATAOUT28\ <= \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\(32);
\L_24|Mult0|auto_generated|mac_out2~DATAOUT29\ <= \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\(33);
\L_24|Mult0|auto_generated|mac_out2~DATAOUT30\ <= \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\(34);
\L_24|Mult0|auto_generated|mac_out2~DATAOUT31\ <= \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\(35);

\L_31|Mult0|auto_generated|mac_mult1_DATAA_bus\ <= (\L_27|Yout[15]~15_combout\ & \L_27|Yout[14]~14_combout\ & \L_27|Yout[13]~13_combout\ & \L_27|Yout[12]~12_combout\ & \L_27|Yout[11]~11_combout\ & \L_27|Yout[10]~10_combout\ & \L_27|Yout[9]~9_combout\ & 
\L_27|Yout[8]~8_combout\ & \L_27|Yout[7]~7_combout\ & \L_27|Yout[6]~6_combout\ & \L_27|Yout[5]~5_combout\ & \L_27|Yout[4]~4_combout\ & \L_27|Yout[3]~3_combout\ & \L_27|Yout[2]~2_combout\ & \L_27|Yout[1]~1_combout\ & \L_27|Yout[0]~0_combout\ & gnd & gnd);

\L_31|Mult0|auto_generated|mac_mult1_DATAB_bus\ <= (\L_29|Yout[15]~15_combout\ & \L_29|Yout[14]~14_combout\ & \L_29|Yout[13]~13_combout\ & \L_29|Yout[12]~12_combout\ & \L_29|Yout[11]~11_combout\ & \L_29|Yout[10]~10_combout\ & \L_29|Yout[9]~9_combout\ & 
\L_29|Yout[8]~8_combout\ & \L_29|Yout[7]~7_combout\ & \L_29|Yout[6]~6_combout\ & \L_29|Yout[5]~5_combout\ & \L_29|Yout[4]~4_combout\ & \L_29|Yout[3]~3_combout\ & \L_29|Yout[2]~2_combout\ & \L_29|Yout[1]~1_combout\ & \L_29|Yout[0]~0_combout\ & gnd & gnd);

\L_31|Mult0|auto_generated|mac_mult1~0\ <= \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(0);
\L_31|Mult0|auto_generated|mac_mult1~1\ <= \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(1);
\L_31|Mult0|auto_generated|mac_mult1~2\ <= \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(2);
\L_31|Mult0|auto_generated|mac_mult1~3\ <= \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(3);
\L_31|Mult0|auto_generated|mac_mult1~dataout\ <= \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(4);
\L_31|Mult0|auto_generated|mac_mult1~DATAOUT1\ <= \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(5);
\L_31|Mult0|auto_generated|mac_mult1~DATAOUT2\ <= \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(6);
\L_31|Mult0|auto_generated|mac_mult1~DATAOUT3\ <= \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(7);
\L_31|Mult0|auto_generated|mac_mult1~DATAOUT4\ <= \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(8);
\L_31|Mult0|auto_generated|mac_mult1~DATAOUT5\ <= \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(9);
\L_31|Mult0|auto_generated|mac_mult1~DATAOUT6\ <= \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(10);
\L_31|Mult0|auto_generated|mac_mult1~DATAOUT7\ <= \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(11);
\L_31|Mult0|auto_generated|mac_mult1~DATAOUT8\ <= \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(12);
\L_31|Mult0|auto_generated|mac_mult1~DATAOUT9\ <= \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(13);
\L_31|Mult0|auto_generated|mac_mult1~DATAOUT10\ <= \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(14);
\L_31|Mult0|auto_generated|mac_mult1~DATAOUT11\ <= \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(15);
\L_31|Mult0|auto_generated|mac_mult1~DATAOUT12\ <= \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(16);
\L_31|Mult0|auto_generated|mac_mult1~DATAOUT13\ <= \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(17);
\L_31|Mult0|auto_generated|mac_mult1~DATAOUT14\ <= \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(18);
\L_31|Mult0|auto_generated|mac_mult1~DATAOUT15\ <= \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(19);
\L_31|Mult0|auto_generated|mac_mult1~DATAOUT16\ <= \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(20);
\L_31|Mult0|auto_generated|mac_mult1~DATAOUT17\ <= \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(21);
\L_31|Mult0|auto_generated|mac_mult1~DATAOUT18\ <= \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(22);
\L_31|Mult0|auto_generated|mac_mult1~DATAOUT19\ <= \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(23);
\L_31|Mult0|auto_generated|mac_mult1~DATAOUT20\ <= \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(24);
\L_31|Mult0|auto_generated|mac_mult1~DATAOUT21\ <= \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(25);
\L_31|Mult0|auto_generated|mac_mult1~DATAOUT22\ <= \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(26);
\L_31|Mult0|auto_generated|mac_mult1~DATAOUT23\ <= \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(27);
\L_31|Mult0|auto_generated|mac_mult1~DATAOUT24\ <= \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(28);
\L_31|Mult0|auto_generated|mac_mult1~DATAOUT25\ <= \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(29);
\L_31|Mult0|auto_generated|mac_mult1~DATAOUT26\ <= \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(30);
\L_31|Mult0|auto_generated|mac_mult1~DATAOUT27\ <= \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(31);
\L_31|Mult0|auto_generated|mac_mult1~DATAOUT28\ <= \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(32);
\L_31|Mult0|auto_generated|mac_mult1~DATAOUT29\ <= \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(33);
\L_31|Mult0|auto_generated|mac_mult1~DATAOUT30\ <= \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(34);
\L_31|Mult0|auto_generated|mac_mult1~DATAOUT31\ <= \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(35);

\L_24|Mult0|auto_generated|mac_mult1_DATAA_bus\ <= (\L_20|Yout[15]~15_combout\ & \L_20|Yout[14]~14_combout\ & \L_20|Yout[13]~13_combout\ & \L_20|Yout[12]~12_combout\ & \L_20|Yout[11]~11_combout\ & \L_20|Yout[10]~10_combout\ & \L_20|Yout[9]~9_combout\ & 
\L_20|Yout[8]~8_combout\ & \L_20|Yout[7]~7_combout\ & \L_20|Yout[6]~6_combout\ & \L_20|Yout[5]~5_combout\ & \L_20|Yout[4]~4_combout\ & \L_20|Yout[3]~3_combout\ & \L_20|Yout[2]~2_combout\ & \L_20|Yout[1]~1_combout\ & \L_20|Yout[0]~0_combout\ & gnd & gnd);

\L_24|Mult0|auto_generated|mac_mult1_DATAB_bus\ <= (\L_22|Yout[15]~31_combout\ & \L_22|Yout[14]~29_combout\ & \L_22|Yout[13]~27_combout\ & \L_22|Yout[12]~25_combout\ & \L_22|Yout[11]~23_combout\ & \L_22|Yout[10]~21_combout\ & \L_22|Yout[9]~19_combout\ & 
\L_22|Yout[8]~17_combout\ & \L_22|Yout[7]~15_combout\ & \L_22|Yout[6]~13_combout\ & \L_22|Yout[5]~11_combout\ & \L_22|Yout[4]~9_combout\ & \L_22|Yout[3]~7_combout\ & \L_22|Yout[2]~5_combout\ & \L_22|Yout[1]~3_combout\ & \L_22|Yout[0]~1_combout\ & gnd & 
gnd);

\L_24|Mult0|auto_generated|mac_mult1~0\ <= \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(0);
\L_24|Mult0|auto_generated|mac_mult1~1\ <= \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(1);
\L_24|Mult0|auto_generated|mac_mult1~2\ <= \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(2);
\L_24|Mult0|auto_generated|mac_mult1~3\ <= \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(3);
\L_24|Mult0|auto_generated|mac_mult1~dataout\ <= \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(4);
\L_24|Mult0|auto_generated|mac_mult1~DATAOUT1\ <= \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(5);
\L_24|Mult0|auto_generated|mac_mult1~DATAOUT2\ <= \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(6);
\L_24|Mult0|auto_generated|mac_mult1~DATAOUT3\ <= \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(7);
\L_24|Mult0|auto_generated|mac_mult1~DATAOUT4\ <= \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(8);
\L_24|Mult0|auto_generated|mac_mult1~DATAOUT5\ <= \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(9);
\L_24|Mult0|auto_generated|mac_mult1~DATAOUT6\ <= \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(10);
\L_24|Mult0|auto_generated|mac_mult1~DATAOUT7\ <= \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(11);
\L_24|Mult0|auto_generated|mac_mult1~DATAOUT8\ <= \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(12);
\L_24|Mult0|auto_generated|mac_mult1~DATAOUT9\ <= \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(13);
\L_24|Mult0|auto_generated|mac_mult1~DATAOUT10\ <= \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(14);
\L_24|Mult0|auto_generated|mac_mult1~DATAOUT11\ <= \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(15);
\L_24|Mult0|auto_generated|mac_mult1~DATAOUT12\ <= \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(16);
\L_24|Mult0|auto_generated|mac_mult1~DATAOUT13\ <= \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(17);
\L_24|Mult0|auto_generated|mac_mult1~DATAOUT14\ <= \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(18);
\L_24|Mult0|auto_generated|mac_mult1~DATAOUT15\ <= \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(19);
\L_24|Mult0|auto_generated|mac_mult1~DATAOUT16\ <= \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(20);
\L_24|Mult0|auto_generated|mac_mult1~DATAOUT17\ <= \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(21);
\L_24|Mult0|auto_generated|mac_mult1~DATAOUT18\ <= \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(22);
\L_24|Mult0|auto_generated|mac_mult1~DATAOUT19\ <= \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(23);
\L_24|Mult0|auto_generated|mac_mult1~DATAOUT20\ <= \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(24);
\L_24|Mult0|auto_generated|mac_mult1~DATAOUT21\ <= \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(25);
\L_24|Mult0|auto_generated|mac_mult1~DATAOUT22\ <= \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(26);
\L_24|Mult0|auto_generated|mac_mult1~DATAOUT23\ <= \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(27);
\L_24|Mult0|auto_generated|mac_mult1~DATAOUT24\ <= \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(28);
\L_24|Mult0|auto_generated|mac_mult1~DATAOUT25\ <= \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(29);
\L_24|Mult0|auto_generated|mac_mult1~DATAOUT26\ <= \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(30);
\L_24|Mult0|auto_generated|mac_mult1~DATAOUT27\ <= \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(31);
\L_24|Mult0|auto_generated|mac_mult1~DATAOUT28\ <= \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(32);
\L_24|Mult0|auto_generated|mac_mult1~DATAOUT29\ <= \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(33);
\L_24|Mult0|auto_generated|mac_mult1~DATAOUT30\ <= \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(34);
\L_24|Mult0|auto_generated|mac_mult1~DATAOUT31\ <= \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\(35);

\L_6|Equal0~1clkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \L_6|Equal0~1_combout\);

\L_3|I0[15]~0clkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \L_3|I0[15]~0_combout\);

\L_6|Equal0~2clkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \L_6|Equal0~2_combout\);

\L_6|Equal0~0clkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \L_6|Equal0~0_combout\);

\L_6|I0[15]~0clkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \L_6|I0[15]~0_combout\);

\L_3|Equal0~0clkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \L_3|Equal0~0_combout\);

\L_12|Equal0~0clkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \L_12|Equal0~0_combout\);

\L_12|Equal0~2clkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \L_12|Equal0~2_combout\);

\L_12|Equal0~1clkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \L_12|Equal0~1_combout\);

\L_12|I0[15]~0clkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \L_12|I0[15]~0_combout\);

\L_3|Equal0~1clkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \L_3|Equal0~1_combout\);

\TTS~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \TTS~input_o\);

\A2S3~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \A2S3~input_o\);

\A1S3~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \A1S3~input_o\);

\A3S3~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \A3S3~input_o\);

\M4S3~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \M4S3~input_o\);

\BTPD_S2~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \BTPD_S2~input_o\);

\M2S3~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \M2S3~input_o\);

\M1S3~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \M1S3~input_o\);

\M3S3~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \M3S3~input_o\);

-- Location: LCCOMB_X76_Y17_N0
\L_45|O[0]~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_45|O[0]~0_combout\ = (\L_43|Yout[0]~1_combout\ & (\L_41|Yout[0]~1_combout\ $ (VCC))) # (!\L_43|Yout[0]~1_combout\ & (\L_41|Yout[0]~1_combout\ & VCC))
-- \L_45|O[0]~1\ = CARRY((\L_43|Yout[0]~1_combout\ & \L_41|Yout[0]~1_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110011010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_43|Yout[0]~1_combout\,
	datab => \L_41|Yout[0]~1_combout\,
	datad => VCC,
	combout => \L_45|O[0]~0_combout\,
	cout => \L_45|O[0]~1\);

-- Location: DSPOUT_X74_Y16_N2
\L_17|Mult0|auto_generated|mac_out2\ : cycloneiv_mac_out
-- pragma translate_off
GENERIC MAP (
	dataa_width => 36,
	output_clock => "none")
-- pragma translate_on
PORT MAP (
	dataa => \L_17|Mult0|auto_generated|mac_out2_DATAA_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	dataout => \L_17|Mult0|auto_generated|mac_out2_DATAOUT_bus\);

-- Location: LCCOMB_X76_Y12_N4
\L_59|O[2]~4\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_59|O[2]~4_combout\ = ((\L_55|Yout[2]~4_combout\ $ (\L_57|Yout[2]~5_combout\ $ (!\L_59|O[1]~3\)))) # (GND)
-- \L_59|O[2]~5\ = CARRY((\L_55|Yout[2]~4_combout\ & ((\L_57|Yout[2]~5_combout\) # (!\L_59|O[1]~3\))) # (!\L_55|Yout[2]~4_combout\ & (\L_57|Yout[2]~5_combout\ & !\L_59|O[1]~3\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100110001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_55|Yout[2]~4_combout\,
	datab => \L_57|Yout[2]~5_combout\,
	datad => VCC,
	cin => \L_59|O[1]~3\,
	combout => \L_59|O[2]~4_combout\,
	cout => \L_59|O[2]~5\);

-- Location: LCCOMB_X76_Y17_N8
\L_45|O[4]~8\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_45|O[4]~8_combout\ = ((\L_41|Yout[4]~5_combout\ $ (\L_43|Yout[4]~5_combout\ $ (!\L_45|O[3]~7\)))) # (GND)
-- \L_45|O[4]~9\ = CARRY((\L_41|Yout[4]~5_combout\ & ((\L_43|Yout[4]~5_combout\) # (!\L_45|O[3]~7\))) # (!\L_41|Yout[4]~5_combout\ & (\L_43|Yout[4]~5_combout\ & !\L_45|O[3]~7\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100110001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_41|Yout[4]~5_combout\,
	datab => \L_43|Yout[4]~5_combout\,
	datad => VCC,
	cin => \L_45|O[3]~7\,
	combout => \L_45|O[4]~8_combout\,
	cout => \L_45|O[4]~9\);

-- Location: LCCOMB_X76_Y7_N2
\L_52|O[1]~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_52|O[1]~2_combout\ = (\L_50|Yout[1]~3_combout\ & ((\L_48|Yout[1]~1_combout\ & (\L_52|O[0]~1\ & VCC)) # (!\L_48|Yout[1]~1_combout\ & (!\L_52|O[0]~1\)))) # (!\L_50|Yout[1]~3_combout\ & ((\L_48|Yout[1]~1_combout\ & (!\L_52|O[0]~1\)) # 
-- (!\L_48|Yout[1]~1_combout\ & ((\L_52|O[0]~1\) # (GND)))))
-- \L_52|O[1]~3\ = CARRY((\L_50|Yout[1]~3_combout\ & (!\L_48|Yout[1]~1_combout\ & !\L_52|O[0]~1\)) # (!\L_50|Yout[1]~3_combout\ & ((!\L_52|O[0]~1\) # (!\L_48|Yout[1]~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011000010111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_50|Yout[1]~3_combout\,
	datab => \L_48|Yout[1]~1_combout\,
	datad => VCC,
	cin => \L_52|O[0]~1\,
	combout => \L_52|O[1]~2_combout\,
	cout => \L_52|O[1]~3\);

-- Location: DSPOUT_X74_Y8_N2
\L_24|Mult0|auto_generated|mac_out2\ : cycloneiv_mac_out
-- pragma translate_off
GENERIC MAP (
	dataa_width => 36,
	output_clock => "none")
-- pragma translate_on
PORT MAP (
	dataa => \L_24|Mult0|auto_generated|mac_out2_DATAA_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	dataout => \L_24|Mult0|auto_generated|mac_out2_DATAOUT_bus\);

-- Location: LCCOMB_X77_Y14_N20
\L_7|Mux8~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux8~0_combout\ = (\RMS1[0]~input_o\ & (((\RMS1[1]~input_o\)))) # (!\RMS1[0]~input_o\ & ((\RMS1[1]~input_o\ & ((\L_47|I0\(7)))) # (!\RMS1[1]~input_o\ & (\v0[7]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010010100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \RMS1[0]~input_o\,
	datab => \v0[7]~input_o\,
	datac => \RMS1[1]~input_o\,
	datad => \L_47|I0\(7),
	combout => \L_7|Mux8~0_combout\);

-- Location: LCCOMB_X77_Y14_N6
\L_7|Mux8~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux8~1_combout\ = (\RMS1[0]~input_o\ & ((\L_7|Mux8~0_combout\ & ((\L_19|I1\(7)))) # (!\L_7|Mux8~0_combout\ & (\L_19|I0\(7))))) # (!\RMS1[0]~input_o\ & (((\L_7|Mux8~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_19|I0\(7),
	datab => \RMS1[0]~input_o\,
	datac => \L_19|I1\(7),
	datad => \L_7|Mux8~0_combout\,
	combout => \L_7|Mux8~1_combout\);

-- Location: LCCOMB_X72_Y16_N0
\L_7|Mux6~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux6~0_combout\ = (\RMS1[1]~input_o\ & (((\RMS1[0]~input_o\) # (\L_47|I0\(9))))) # (!\RMS1[1]~input_o\ & (\v0[9]~input_o\ & (!\RMS1[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111011000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v0[9]~input_o\,
	datab => \RMS1[1]~input_o\,
	datac => \RMS1[0]~input_o\,
	datad => \L_47|I0\(9),
	combout => \L_7|Mux6~0_combout\);

-- Location: LCCOMB_X72_Y16_N10
\L_7|Mux6~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux6~1_combout\ = (\RMS1[0]~input_o\ & ((\L_7|Mux6~0_combout\ & (\L_19|I1\(9))) # (!\L_7|Mux6~0_combout\ & ((\L_19|I0\(9)))))) # (!\RMS1[0]~input_o\ & (((\L_7|Mux6~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \RMS1[0]~input_o\,
	datab => \L_19|I1\(9),
	datac => \L_19|I0\(9),
	datad => \L_7|Mux6~0_combout\,
	combout => \L_7|Mux6~1_combout\);

-- Location: LCCOMB_X76_Y16_N10
\L_43|Yout[0]~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_43|Yout[0]~1_combout\ = (\L_43|Yout[15]~0_combout\ & \L_7|Mux15~5_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_43|Yout[15]~0_combout\,
	datad => \L_7|Mux15~5_combout\,
	combout => \L_43|Yout[0]~1_combout\);

-- Location: LCCOMB_X75_Y12_N12
\L_55|Yout[0]~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_55|Yout[0]~2_combout\ = (\L_55|Yout[15]~1_combout\ & ((\L_7|Mux15~5_combout\) # ((\A3S1~input_o\ & \L_57|Yout[0]~0_combout\)))) # (!\L_55|Yout[15]~1_combout\ & (\A3S1~input_o\ & (\L_57|Yout[0]~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_55|Yout[15]~1_combout\,
	datab => \A3S1~input_o\,
	datac => \L_57|Yout[0]~0_combout\,
	datad => \L_7|Mux15~5_combout\,
	combout => \L_55|Yout[0]~2_combout\);

-- Location: LCCOMB_X77_Y17_N20
\L_43|Yout[1]~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_43|Yout[1]~2_combout\ = (\L_43|Yout[15]~0_combout\ & \L_7|Mux14~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \L_43|Yout[15]~0_combout\,
	datad => \L_7|Mux14~3_combout\,
	combout => \L_43|Yout[1]~2_combout\);

-- Location: LCCOMB_X77_Y12_N16
\L_57|Yout[1]~3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_57|Yout[1]~3_combout\ = (\A3S2~input_o\ & (\L_57|Yout[1]~2_combout\)) # (!\A3S2~input_o\ & ((\L_12|I3\(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \A3S2~input_o\,
	datac => \L_57|Yout[1]~2_combout\,
	datad => \L_12|I3\(1),
	combout => \L_57|Yout[1]~3_combout\);

-- Location: LCCOMB_X73_Y13_N22
\L_41|Yout[2]~3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_41|Yout[2]~3_combout\ = (\L_41|Yout[15]~0_combout\ & \L_7|Mux13~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_41|Yout[15]~0_combout\,
	datac => \L_7|Mux13~3_combout\,
	combout => \L_41|Yout[2]~3_combout\);

-- Location: LCCOMB_X77_Y12_N20
\L_55|Yout[2]~4\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_55|Yout[2]~4_combout\ = (\L_55|Yout[15]~1_combout\ & ((\L_7|Mux13~3_combout\) # ((\A3S1~input_o\ & \L_57|Yout[2]~4_combout\)))) # (!\L_55|Yout[15]~1_combout\ & (\A3S1~input_o\ & (\L_57|Yout[2]~4_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_55|Yout[15]~1_combout\,
	datab => \A3S1~input_o\,
	datac => \L_57|Yout[2]~4_combout\,
	datad => \L_7|Mux13~3_combout\,
	combout => \L_55|Yout[2]~4_combout\);

-- Location: LCCOMB_X75_Y17_N16
\L_43|Yout[3]~4\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_43|Yout[3]~4_combout\ = (\L_43|Yout[15]~0_combout\ & \L_7|Mux12~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \L_43|Yout[15]~0_combout\,
	datad => \L_7|Mux12~3_combout\,
	combout => \L_43|Yout[3]~4_combout\);

-- Location: LCCOMB_X76_Y5_N20
\L_57|Yout[3]~7\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_57|Yout[3]~7_combout\ = (\A3S2~input_o\ & (\L_57|Yout[3]~6_combout\)) # (!\A3S2~input_o\ & ((\L_12|I3\(3))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \A3S2~input_o\,
	datac => \L_57|Yout[3]~6_combout\,
	datad => \L_12|I3\(3),
	combout => \L_57|Yout[3]~7_combout\);

-- Location: LCCOMB_X77_Y15_N10
\L_41|Yout[4]~5\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_41|Yout[4]~5_combout\ = (\L_41|Yout[15]~0_combout\ & \L_7|Mux11~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_41|Yout[15]~0_combout\,
	datad => \L_7|Mux11~3_combout\,
	combout => \L_41|Yout[4]~5_combout\);

-- Location: LCCOMB_X75_Y12_N2
\L_55|Yout[4]~6\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_55|Yout[4]~6_combout\ = (\L_55|Yout[15]~1_combout\ & ((\L_7|Mux11~3_combout\) # ((\A3S1~input_o\ & \L_57|Yout[4]~8_combout\)))) # (!\L_55|Yout[15]~1_combout\ & (\A3S1~input_o\ & (\L_57|Yout[4]~8_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_55|Yout[15]~1_combout\,
	datab => \A3S1~input_o\,
	datac => \L_57|Yout[4]~8_combout\,
	datad => \L_7|Mux11~3_combout\,
	combout => \L_55|Yout[4]~6_combout\);

-- Location: LCCOMB_X76_Y14_N28
\L_41|Yout[5]~6\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_41|Yout[5]~6_combout\ = (\L_41|Yout[15]~0_combout\ & \L_7|Mux10~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \L_41|Yout[15]~0_combout\,
	datad => \L_7|Mux10~3_combout\,
	combout => \L_41|Yout[5]~6_combout\);

-- Location: LCCOMB_X76_Y8_N30
\L_55|Yout[5]~7\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_55|Yout[5]~7_combout\ = (\L_55|Yout[15]~1_combout\ & ((\L_7|Mux10~3_combout\) # ((\A3S1~input_o\ & \L_57|Yout[5]~10_combout\)))) # (!\L_55|Yout[15]~1_combout\ & (\A3S1~input_o\ & (\L_57|Yout[5]~10_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_55|Yout[15]~1_combout\,
	datab => \A3S1~input_o\,
	datac => \L_57|Yout[5]~10_combout\,
	datad => \L_7|Mux10~3_combout\,
	combout => \L_55|Yout[5]~7_combout\);

-- Location: LCCOMB_X75_Y14_N2
\L_41|Yout[6]~7\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_41|Yout[6]~7_combout\ = (\L_41|Yout[15]~0_combout\ & \L_7|Mux9~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \L_41|Yout[15]~0_combout\,
	datad => \L_7|Mux9~3_combout\,
	combout => \L_41|Yout[6]~7_combout\);

-- Location: LCCOMB_X76_Y8_N12
\L_55|Yout[6]~8\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_55|Yout[6]~8_combout\ = (\L_55|Yout[15]~1_combout\ & ((\L_7|Mux9~3_combout\) # ((\A3S1~input_o\ & \L_57|Yout[6]~12_combout\)))) # (!\L_55|Yout[15]~1_combout\ & (\A3S1~input_o\ & (\L_57|Yout[6]~12_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_55|Yout[15]~1_combout\,
	datab => \A3S1~input_o\,
	datac => \L_57|Yout[6]~12_combout\,
	datad => \L_7|Mux9~3_combout\,
	combout => \L_55|Yout[6]~8_combout\);

-- Location: LCCOMB_X77_Y14_N2
\L_43|Yout[7]~8\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_43|Yout[7]~8_combout\ = (\L_43|Yout[15]~0_combout\ & \L_7|Mux8~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_43|Yout[15]~0_combout\,
	datac => \L_7|Mux8~3_combout\,
	combout => \L_43|Yout[7]~8_combout\);

-- Location: LCCOMB_X79_Y12_N12
\L_57|Yout[7]~14\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_57|Yout[7]~14_combout\ = (\TM7|I1\(7) & ((\L_55|Yout[0]~0_combout\) # ((\L_3|I1\(7) & \TTS~input_o\)))) # (!\TM7|I1\(7) & (\L_3|I1\(7) & ((\TTS~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM7|I1\(7),
	datab => \L_3|I1\(7),
	datac => \L_55|Yout[0]~0_combout\,
	datad => \TTS~input_o\,
	combout => \L_57|Yout[7]~14_combout\);

-- Location: LCCOMB_X79_Y12_N30
\L_55|Yout[7]~9\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_55|Yout[7]~9_combout\ = (\L_57|Yout[7]~14_combout\ & ((\A3S1~input_o\) # ((\L_55|Yout[15]~1_combout\ & \L_7|Mux8~3_combout\)))) # (!\L_57|Yout[7]~14_combout\ & (\L_55|Yout[15]~1_combout\ & ((\L_7|Mux8~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_57|Yout[7]~14_combout\,
	datab => \L_55|Yout[15]~1_combout\,
	datac => \A3S1~input_o\,
	datad => \L_7|Mux8~3_combout\,
	combout => \L_55|Yout[7]~9_combout\);

-- Location: LCCOMB_X77_Y15_N16
\L_43|Yout[8]~9\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_43|Yout[8]~9_combout\ = (\L_43|Yout[15]~0_combout\ & \L_7|Mux7~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_43|Yout[15]~0_combout\,
	datad => \L_7|Mux7~3_combout\,
	combout => \L_43|Yout[8]~9_combout\);

-- Location: LCCOMB_X77_Y8_N30
\L_55|Yout[8]~10\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_55|Yout[8]~10_combout\ = (\L_55|Yout[15]~1_combout\ & ((\L_7|Mux7~3_combout\) # ((\A3S1~input_o\ & \L_57|Yout[8]~16_combout\)))) # (!\L_55|Yout[15]~1_combout\ & (\A3S1~input_o\ & (\L_57|Yout[8]~16_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_55|Yout[15]~1_combout\,
	datab => \A3S1~input_o\,
	datac => \L_57|Yout[8]~16_combout\,
	datad => \L_7|Mux7~3_combout\,
	combout => \L_55|Yout[8]~10_combout\);

-- Location: LCCOMB_X75_Y17_N14
\L_41|Yout[9]~10\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_41|Yout[9]~10_combout\ = (\L_41|Yout[15]~0_combout\ & \L_7|Mux6~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_41|Yout[15]~0_combout\,
	datad => \L_7|Mux6~3_combout\,
	combout => \L_41|Yout[9]~10_combout\);

-- Location: LCCOMB_X76_Y8_N6
\L_55|Yout[9]~11\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_55|Yout[9]~11_combout\ = (\L_55|Yout[15]~1_combout\ & ((\L_7|Mux6~3_combout\) # ((\A3S1~input_o\ & \L_57|Yout[9]~18_combout\)))) # (!\L_55|Yout[15]~1_combout\ & (\A3S1~input_o\ & (\L_57|Yout[9]~18_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_55|Yout[15]~1_combout\,
	datab => \A3S1~input_o\,
	datac => \L_57|Yout[9]~18_combout\,
	datad => \L_7|Mux6~3_combout\,
	combout => \L_55|Yout[9]~11_combout\);

-- Location: LCCOMB_X75_Y16_N0
\L_41|Yout[10]~11\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_41|Yout[10]~11_combout\ = (\L_41|Yout[15]~0_combout\ & \L_7|Mux5~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_41|Yout[15]~0_combout\,
	datac => \L_7|Mux5~3_combout\,
	combout => \L_41|Yout[10]~11_combout\);

-- Location: LCCOMB_X75_Y16_N6
\L_57|Yout[10]~21\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_57|Yout[10]~21_combout\ = (\A3S2~input_o\ & (\L_57|Yout[10]~20_combout\)) # (!\A3S2~input_o\ & ((\L_12|I3\(10))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \A3S2~input_o\,
	datac => \L_57|Yout[10]~20_combout\,
	datad => \L_12|I3\(10),
	combout => \L_57|Yout[10]~21_combout\);

-- Location: LCCOMB_X76_Y13_N6
\L_43|Yout[11]~12\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_43|Yout[11]~12_combout\ = (\L_43|Yout[15]~0_combout\ & \L_7|Mux4~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_43|Yout[15]~0_combout\,
	datad => \L_7|Mux4~3_combout\,
	combout => \L_43|Yout[11]~12_combout\);

-- Location: LCCOMB_X77_Y8_N2
\L_57|Yout[11]~23\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_57|Yout[11]~23_combout\ = (\A3S2~input_o\ & ((\L_57|Yout[11]~22_combout\))) # (!\A3S2~input_o\ & (\L_12|I3\(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \A3S2~input_o\,
	datac => \L_12|I3\(11),
	datad => \L_57|Yout[11]~22_combout\,
	combout => \L_57|Yout[11]~23_combout\);

-- Location: LCCOMB_X75_Y17_N8
\L_43|Yout[12]~13\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_43|Yout[12]~13_combout\ = (\L_43|Yout[15]~0_combout\ & \L_7|Mux3~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_43|Yout[15]~0_combout\,
	datad => \L_7|Mux3~3_combout\,
	combout => \L_43|Yout[12]~13_combout\);

-- Location: LCCOMB_X76_Y13_N30
\L_55|Yout[12]~14\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_55|Yout[12]~14_combout\ = (\A3S1~input_o\ & ((\L_57|Yout[12]~24_combout\) # ((\L_55|Yout[15]~1_combout\ & \L_7|Mux3~3_combout\)))) # (!\A3S1~input_o\ & (\L_55|Yout[15]~1_combout\ & ((\L_7|Mux3~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \A3S1~input_o\,
	datab => \L_55|Yout[15]~1_combout\,
	datac => \L_57|Yout[12]~24_combout\,
	datad => \L_7|Mux3~3_combout\,
	combout => \L_55|Yout[12]~14_combout\);

-- Location: LCCOMB_X75_Y13_N16
\L_43|Yout[13]~14\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_43|Yout[13]~14_combout\ = (\L_43|Yout[15]~0_combout\ & \L_7|Mux2~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \L_43|Yout[15]~0_combout\,
	datad => \L_7|Mux2~3_combout\,
	combout => \L_43|Yout[13]~14_combout\);

-- Location: LCCOMB_X77_Y5_N8
\L_57|Yout[13]~27\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_57|Yout[13]~27_combout\ = (\A3S2~input_o\ & ((\L_57|Yout[13]~26_combout\))) # (!\A3S2~input_o\ & (\L_12|I3\(13)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \A3S2~input_o\,
	datac => \L_12|I3\(13),
	datad => \L_57|Yout[13]~26_combout\,
	combout => \L_57|Yout[13]~27_combout\);

-- Location: LCCOMB_X77_Y17_N24
\L_43|Yout[14]~15\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_43|Yout[14]~15_combout\ = (\L_43|Yout[15]~0_combout\ & \L_7|Mux1~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \L_43|Yout[15]~0_combout\,
	datad => \L_7|Mux1~3_combout\,
	combout => \L_43|Yout[14]~15_combout\);

-- Location: LCCOMB_X76_Y15_N18
\L_57|Yout[14]~29\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_57|Yout[14]~29_combout\ = (\A3S2~input_o\ & ((\L_57|Yout[14]~28_combout\))) # (!\A3S2~input_o\ & (\L_12|I3\(14)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \A3S2~input_o\,
	datac => \L_12|I3\(14),
	datad => \L_57|Yout[14]~28_combout\,
	combout => \L_57|Yout[14]~29_combout\);

-- Location: LCCOMB_X71_Y7_N26
\L_50|Yout[0]~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_50|Yout[0]~1_combout\ = (\A2S2~input_o\ & (\L_12|I1\(0))) # (!\A2S2~input_o\ & ((\L_50|Yout[0]~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \A2S2~input_o\,
	datac => \L_12|I1\(0),
	datad => \L_50|Yout[0]~0_combout\,
	combout => \L_50|Yout[0]~1_combout\);

-- Location: LCCOMB_X77_Y7_N20
\L_50|Yout[1]~3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_50|Yout[1]~3_combout\ = (\A2S2~input_o\ & (\L_12|I1\(1))) # (!\A2S2~input_o\ & ((\L_50|Yout[1]~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \A2S2~input_o\,
	datac => \L_12|I1\(1),
	datad => \L_50|Yout[1]~2_combout\,
	combout => \L_50|Yout[1]~3_combout\);

-- Location: LCCOMB_X77_Y7_N6
\L_50|Yout[2]~5\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_50|Yout[2]~5_combout\ = (\A2S2~input_o\ & (\L_12|I1\(2))) # (!\A2S2~input_o\ & ((\L_50|Yout[2]~4_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \A2S2~input_o\,
	datac => \L_12|I1\(2),
	datad => \L_50|Yout[2]~4_combout\,
	combout => \L_50|Yout[2]~5_combout\);

-- Location: LCCOMB_X78_Y7_N10
\L_48|Yout[3]~3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_48|Yout[3]~3_combout\ = (\A2S1~input_o\ & (\L_12|I1\(3))) # (!\A2S1~input_o\ & ((\L_50|Yout[3]~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \A2S1~input_o\,
	datac => \L_12|I1\(3),
	datad => \L_50|Yout[3]~6_combout\,
	combout => \L_48|Yout[3]~3_combout\);

-- Location: LCCOMB_X77_Y7_N30
\L_50|Yout[4]~9\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_50|Yout[4]~9_combout\ = (\A2S2~input_o\ & (\L_12|I1\(4))) # (!\A2S2~input_o\ & ((\L_50|Yout[4]~8_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_12|I1\(4),
	datac => \A2S2~input_o\,
	datad => \L_50|Yout[4]~8_combout\,
	combout => \L_50|Yout[4]~9_combout\);

-- Location: LCCOMB_X75_Y7_N16
\L_50|Yout[5]~11\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_50|Yout[5]~11_combout\ = (\A2S2~input_o\ & (\L_12|I1\(5))) # (!\A2S2~input_o\ & ((\L_50|Yout[5]~10_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_12|I1\(5),
	datac => \A2S2~input_o\,
	datad => \L_50|Yout[5]~10_combout\,
	combout => \L_50|Yout[5]~11_combout\);

-- Location: LCCOMB_X72_Y7_N22
\L_48|Yout[6]~6\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_48|Yout[6]~6_combout\ = (\A2S1~input_o\ & (\L_12|I1\(6))) # (!\A2S1~input_o\ & ((\L_50|Yout[6]~12_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \A2S1~input_o\,
	datac => \L_12|I1\(6),
	datad => \L_50|Yout[6]~12_combout\,
	combout => \L_48|Yout[6]~6_combout\);

-- Location: LCCOMB_X78_Y7_N28
\L_48|Yout[7]~7\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_48|Yout[7]~7_combout\ = (\A2S1~input_o\ & ((\L_12|I1\(7)))) # (!\A2S1~input_o\ & (\L_50|Yout[7]~14_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \A2S1~input_o\,
	datac => \L_50|Yout[7]~14_combout\,
	datad => \L_12|I1\(7),
	combout => \L_48|Yout[7]~7_combout\);

-- Location: LCCOMB_X75_Y4_N12
\L_50|Yout[8]~17\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_50|Yout[8]~17_combout\ = (\A2S2~input_o\ & (\L_12|I1\(8))) # (!\A2S2~input_o\ & ((\L_50|Yout[8]~16_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \A2S2~input_o\,
	datac => \L_12|I1\(8),
	datad => \L_50|Yout[8]~16_combout\,
	combout => \L_50|Yout[8]~17_combout\);

-- Location: LCCOMB_X76_Y4_N0
\L_50|Yout[9]~19\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_50|Yout[9]~19_combout\ = (\A2S2~input_o\ & (\L_12|I1\(9))) # (!\A2S2~input_o\ & ((\L_50|Yout[9]~18_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \A2S2~input_o\,
	datac => \L_12|I1\(9),
	datad => \L_50|Yout[9]~18_combout\,
	combout => \L_50|Yout[9]~19_combout\);

-- Location: LCCOMB_X76_Y4_N20
\L_48|Yout[10]~10\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_48|Yout[10]~10_combout\ = (\A2S1~input_o\ & (\L_12|I1\(10))) # (!\A2S1~input_o\ & ((\L_50|Yout[10]~20_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \A2S1~input_o\,
	datac => \L_12|I1\(10),
	datad => \L_50|Yout[10]~20_combout\,
	combout => \L_48|Yout[10]~10_combout\);

-- Location: LCCOMB_X75_Y7_N14
\L_50|Yout[11]~23\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_50|Yout[11]~23_combout\ = (\A2S2~input_o\ & ((\L_12|I1\(11)))) # (!\A2S2~input_o\ & (\L_50|Yout[11]~22_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \A2S2~input_o\,
	datac => \L_50|Yout[11]~22_combout\,
	datad => \L_12|I1\(11),
	combout => \L_50|Yout[11]~23_combout\);

-- Location: LCCOMB_X77_Y7_N0
\L_48|Yout[12]~12\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_48|Yout[12]~12_combout\ = (\A2S1~input_o\ & (\L_12|I1\(12))) # (!\A2S1~input_o\ & ((\L_50|Yout[12]~24_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_12|I1\(12),
	datac => \A2S1~input_o\,
	datad => \L_50|Yout[12]~24_combout\,
	combout => \L_48|Yout[12]~12_combout\);

-- Location: LCCOMB_X75_Y7_N8
\L_50|Yout[13]~27\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_50|Yout[13]~27_combout\ = (\A2S2~input_o\ & ((\L_12|I1\(13)))) # (!\A2S2~input_o\ & (\L_50|Yout[13]~26_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \A2S2~input_o\,
	datac => \L_50|Yout[13]~26_combout\,
	datad => \L_12|I1\(13),
	combout => \L_50|Yout[13]~27_combout\);

-- Location: LCCOMB_X72_Y7_N20
\L_48|Yout[14]~14\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_48|Yout[14]~14_combout\ = (\A2S1~input_o\ & (\L_12|I1\(14))) # (!\A2S1~input_o\ & ((\L_50|Yout[14]~28_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \A2S1~input_o\,
	datac => \L_12|I1\(14),
	datad => \L_50|Yout[14]~28_combout\,
	combout => \L_48|Yout[14]~14_combout\);

-- Location: LCCOMB_X78_Y10_N20
\TM2|Yout[5]~11\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[5]~11_combout\ = (\BMS1[1]~input_o\ & ((\v2[5]~input_o\) # (!\BMS1[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \BMS1[1]~input_o\,
	datac => \BMS1[0]~input_o\,
	datad => \v2[5]~input_o\,
	combout => \TM2|Yout[5]~11_combout\);

-- Location: LCCOMB_X79_Y12_N22
\TM2|Yout[7]~15\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[7]~15_combout\ = (\BMS1[1]~input_o\ & ((\v2[7]~input_o\) # (!\BMS1[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \BMS1[0]~input_o\,
	datac => \v2[7]~input_o\,
	datad => \BMS1[1]~input_o\,
	combout => \TM2|Yout[7]~15_combout\);

-- Location: LCCOMB_X78_Y12_N10
\TM2|Yout[7]~16\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[7]~16_combout\ = (\TM2|Yout[9]~2_combout\ & ((\TM2|Yout[7]~15_combout\ & ((\L_40|I0\(7)))) # (!\TM2|Yout[7]~15_combout\ & (\L_61|I0\(7))))) # (!\TM2|Yout[9]~2_combout\ & (\TM2|Yout[7]~15_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110001100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM2|Yout[9]~2_combout\,
	datab => \TM2|Yout[7]~15_combout\,
	datac => \L_61|I0\(7),
	datad => \L_40|I0\(7),
	combout => \TM2|Yout[7]~16_combout\);

-- Location: LCCOMB_X76_Y18_N22
\TM2|Yout[9]~19\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[9]~19_combout\ = (\BMS1[1]~input_o\ & ((\v2[9]~input_o\) # (!\BMS1[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \BMS1[0]~input_o\,
	datac => \v2[9]~input_o\,
	datad => \BMS1[1]~input_o\,
	combout => \TM2|Yout[9]~19_combout\);

-- Location: LCCOMB_X72_Y12_N30
\TM2|Yout[11]~23\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[11]~23_combout\ = (\BMS1[1]~input_o\ & ((\v2[11]~input_o\) # (!\BMS1[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110001000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \BMS1[0]~input_o\,
	datab => \BMS1[1]~input_o\,
	datad => \v2[11]~input_o\,
	combout => \TM2|Yout[11]~23_combout\);

-- Location: LCCOMB_X76_Y18_N12
\TM2|Yout[13]~27\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[13]~27_combout\ = (\BMS1[1]~input_o\ & ((\v2[13]~input_o\) # (!\BMS1[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \BMS1[1]~input_o\,
	datac => \v2[13]~input_o\,
	datad => \BMS1[0]~input_o\,
	combout => \TM2|Yout[13]~27_combout\);

-- Location: LCCOMB_X78_Y10_N22
\TM2|Yout[1]~34\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[1]~34_combout\ = (\BTPM_S1~input_o\ & ((\v2[1]~input_o\))) # (!\BTPM_S1~input_o\ & (\L_33|I0\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \BTPM_S1~input_o\,
	datac => \L_33|I0\(1),
	datad => \v2[1]~input_o\,
	combout => \TM2|Yout[1]~34_combout\);

-- Location: LCCOMB_X76_Y11_N12
\TM2|Yout[15]~48\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[15]~48_combout\ = (\BTPM_S1~input_o\ & (\v2[15]~input_o\)) # (!\BTPM_S1~input_o\ & ((\L_33|I0\(15))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v2[15]~input_o\,
	datab => \BTPM_S1~input_o\,
	datad => \L_33|I0\(15),
	combout => \TM2|Yout[15]~48_combout\);

-- Location: LCCOMB_X76_Y16_N6
\L_40|I1[0]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_40|I1\(0) = (GLOBAL(\M4S3~inputclkctrl_outclk\) & (\L_40|I1\(0))) # (!GLOBAL(\M4S3~inputclkctrl_outclk\) & ((\L_38|Mult0|auto_generated|mac_out2~dataout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_40|I1\(0),
	datac => \M4S3~inputclkctrl_outclk\,
	datad => \L_38|Mult0|auto_generated|mac_out2~dataout\,
	combout => \L_40|I1\(0));

-- Location: LCCOMB_X78_Y16_N10
\L_19|I0[1]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_19|I0\(1) = (GLOBAL(\M1S3~inputclkctrl_outclk\) & ((\L_17|Mult0|auto_generated|mac_out2~DATAOUT1\))) # (!GLOBAL(\M1S3~inputclkctrl_outclk\) & (\L_19|I0\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_19|I0\(1),
	datac => \M1S3~inputclkctrl_outclk\,
	datad => \L_17|Mult0|auto_generated|mac_out2~DATAOUT1\,
	combout => \L_19|I0\(1));

-- Location: LCCOMB_X73_Y13_N12
\L_61|I1[2]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_61|I1\(2) = (GLOBAL(\A3S3~inputclkctrl_outclk\) & (\L_61|I1\(2))) # (!GLOBAL(\A3S3~inputclkctrl_outclk\) & ((\L_59|O[2]~4_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_61|I1\(2),
	datab => \L_59|O[2]~4_combout\,
	datad => \A3S3~inputclkctrl_outclk\,
	combout => \L_61|I1\(2));

-- Location: LCCOMB_X76_Y16_N18
\L_61|I1[3]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_61|I1\(3) = (GLOBAL(\A3S3~inputclkctrl_outclk\) & (\L_61|I1\(3))) # (!GLOBAL(\A3S3~inputclkctrl_outclk\) & ((\L_59|O[3]~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_61|I1\(3),
	datac => \L_59|O[3]~6_combout\,
	datad => \A3S3~inputclkctrl_outclk\,
	combout => \L_61|I1\(3));

-- Location: LCCOMB_X77_Y15_N12
\L_40|I1[4]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_40|I1\(4) = (GLOBAL(\M4S3~inputclkctrl_outclk\) & (\L_40|I1\(4))) # (!GLOBAL(\M4S3~inputclkctrl_outclk\) & ((\L_38|Mult0|auto_generated|mac_out2~DATAOUT4\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_40|I1\(4),
	datac => \L_38|Mult0|auto_generated|mac_out2~DATAOUT4\,
	datad => \M4S3~inputclkctrl_outclk\,
	combout => \L_40|I1\(4));

-- Location: LCCOMB_X76_Y14_N12
\L_19|I1[5]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_19|I1\(5) = (GLOBAL(\M1S3~inputclkctrl_outclk\) & (\L_19|I1\(5))) # (!GLOBAL(\M1S3~inputclkctrl_outclk\) & ((\L_17|Mult0|auto_generated|mac_out2~DATAOUT5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_19|I1\(5),
	datac => \M1S3~inputclkctrl_outclk\,
	datad => \L_17|Mult0|auto_generated|mac_out2~DATAOUT5\,
	combout => \L_19|I1\(5));

-- Location: LCCOMB_X76_Y14_N6
\L_19|I1[6]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_19|I1\(6) = (GLOBAL(\M1S3~inputclkctrl_outclk\) & (\L_19|I1\(6))) # (!GLOBAL(\M1S3~inputclkctrl_outclk\) & ((\L_17|Mult0|auto_generated|mac_out2~DATAOUT6\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_19|I1\(6),
	datac => \M1S3~inputclkctrl_outclk\,
	datad => \L_17|Mult0|auto_generated|mac_out2~DATAOUT6\,
	combout => \L_19|I1\(6));

-- Location: LCCOMB_X77_Y16_N6
\L_19|I0[7]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_19|I0\(7) = (GLOBAL(\M1S3~inputclkctrl_outclk\) & ((\L_17|Mult0|auto_generated|mac_out2~DATAOUT7\))) # (!GLOBAL(\M1S3~inputclkctrl_outclk\) & (\L_19|I0\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_19|I0\(7),
	datac => \L_17|Mult0|auto_generated|mac_out2~DATAOUT7\,
	datad => \M1S3~inputclkctrl_outclk\,
	combout => \L_19|I0\(7));

-- Location: LCCOMB_X77_Y14_N10
\L_47|I0[7]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_47|I0\(7) = (GLOBAL(\A1S3~inputclkctrl_outclk\) & (\L_45|O[7]~14_combout\)) # (!GLOBAL(\A1S3~inputclkctrl_outclk\) & ((\L_47|I0\(7))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_45|O[7]~14_combout\,
	datac => \A1S3~inputclkctrl_outclk\,
	datad => \L_47|I0\(7),
	combout => \L_47|I0\(7));

-- Location: LCCOMB_X77_Y16_N16
\L_19|I1[7]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_19|I1\(7) = (GLOBAL(\M1S3~inputclkctrl_outclk\) & (\L_19|I1\(7))) # (!GLOBAL(\M1S3~inputclkctrl_outclk\) & ((\L_17|Mult0|auto_generated|mac_out2~DATAOUT7\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_19|I1\(7),
	datac => \L_17|Mult0|auto_generated|mac_out2~DATAOUT7\,
	datad => \M1S3~inputclkctrl_outclk\,
	combout => \L_19|I1\(7));

-- Location: LCCOMB_X73_Y16_N20
\L_19|I0[9]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_19|I0\(9) = (GLOBAL(\M1S3~inputclkctrl_outclk\) & ((\L_17|Mult0|auto_generated|mac_out2~DATAOUT9\))) # (!GLOBAL(\M1S3~inputclkctrl_outclk\) & (\L_19|I0\(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_19|I0\(9),
	datac => \L_17|Mult0|auto_generated|mac_out2~DATAOUT9\,
	datad => \M1S3~inputclkctrl_outclk\,
	combout => \L_19|I0\(9));

-- Location: LCCOMB_X72_Y16_N18
\L_47|I0[9]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_47|I0\(9) = (GLOBAL(\A1S3~inputclkctrl_outclk\) & ((\L_45|O[9]~18_combout\))) # (!GLOBAL(\A1S3~inputclkctrl_outclk\) & (\L_47|I0\(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_47|I0\(9),
	datac => \L_45|O[9]~18_combout\,
	datad => \A1S3~inputclkctrl_outclk\,
	combout => \L_47|I0\(9));

-- Location: LCCOMB_X72_Y16_N24
\L_19|I1[9]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_19|I1\(9) = (GLOBAL(\M1S3~inputclkctrl_outclk\) & (\L_19|I1\(9))) # (!GLOBAL(\M1S3~inputclkctrl_outclk\) & ((\L_17|Mult0|auto_generated|mac_out2~DATAOUT9\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_19|I1\(9),
	datac => \L_17|Mult0|auto_generated|mac_out2~DATAOUT9\,
	datad => \M1S3~inputclkctrl_outclk\,
	combout => \L_19|I1\(9));

-- Location: LCCOMB_X76_Y13_N12
\L_19|I0[11]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_19|I0\(11) = (GLOBAL(\M1S3~inputclkctrl_outclk\) & ((\L_17|Mult0|auto_generated|mac_out2~DATAOUT11\))) # (!GLOBAL(\M1S3~inputclkctrl_outclk\) & (\L_19|I0\(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_19|I0\(11),
	datac => \M1S3~inputclkctrl_outclk\,
	datad => \L_17|Mult0|auto_generated|mac_out2~DATAOUT11\,
	combout => \L_19|I0\(11));

-- Location: LCCOMB_X73_Y18_N30
\L_40|I1[12]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_40|I1\(12) = (GLOBAL(\M4S3~inputclkctrl_outclk\) & (\L_40|I1\(12))) # (!GLOBAL(\M4S3~inputclkctrl_outclk\) & ((\L_38|Mult0|auto_generated|mac_out2~DATAOUT12\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_40|I1\(12),
	datac => \M4S3~inputclkctrl_outclk\,
	datad => \L_38|Mult0|auto_generated|mac_out2~DATAOUT12\,
	combout => \L_40|I1\(12));

-- Location: LCCOMB_X75_Y19_N6
\L_19|I1[15]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_19|I1\(15) = (GLOBAL(\M1S3~inputclkctrl_outclk\) & (\L_19|I1\(15))) # (!GLOBAL(\M1S3~inputclkctrl_outclk\) & ((\L_17|Mult0|auto_generated|mac_out2~DATAOUT15\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_19|I1\(15),
	datac => \L_17|Mult0|auto_generated|mac_out2~DATAOUT15\,
	datad => \M1S3~inputclkctrl_outclk\,
	combout => \L_19|I1\(15));

-- Location: LCCOMB_X75_Y19_N22
\L_61|I1[15]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_61|I1\(15) = (GLOBAL(\A3S3~inputclkctrl_outclk\) & (\L_61|I1\(15))) # (!GLOBAL(\A3S3~inputclkctrl_outclk\) & ((\L_59|O[15]~30_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_61|I1\(15),
	datac => \L_59|O[15]~30_combout\,
	datad => \A3S3~inputclkctrl_outclk\,
	combout => \L_61|I1\(15));

-- Location: LCCOMB_X75_Y12_N6
\L_3|I1[0]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I1\(0) = (GLOBAL(\L_3|Equal0~0clkctrl_outclk\) & ((\TM3|I0\(0)))) # (!GLOBAL(\L_3|Equal0~0clkctrl_outclk\) & (\L_3|I1\(0)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_3|I1\(0),
	datab => \TM3|I0\(0),
	datad => \L_3|Equal0~0clkctrl_outclk\,
	combout => \L_3|I1\(0));

-- Location: LCCOMB_X77_Y12_N30
\L_3|I1[1]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I1\(1) = (GLOBAL(\L_3|Equal0~0clkctrl_outclk\) & (\TM3|I0\(1))) # (!GLOBAL(\L_3|Equal0~0clkctrl_outclk\) & ((\L_3|I1\(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I0\(1),
	datac => \L_3|I1\(1),
	datad => \L_3|Equal0~0clkctrl_outclk\,
	combout => \L_3|I1\(1));

-- Location: LCCOMB_X77_Y12_N0
\L_12|I3[1]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I3\(1) = (GLOBAL(\L_12|Equal0~0clkctrl_outclk\) & (\L_12|I3\(1))) # (!GLOBAL(\L_12|Equal0~0clkctrl_outclk\) & ((\L_10|Yout[1]~3_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_12|I3\(1),
	datac => \L_10|Yout[1]~3_combout\,
	datad => \L_12|Equal0~0clkctrl_outclk\,
	combout => \L_12|I3\(1));

-- Location: LCCOMB_X76_Y5_N26
\L_12|I3[3]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I3\(3) = (GLOBAL(\L_12|Equal0~0clkctrl_outclk\) & (\L_12|I3\(3))) # (!GLOBAL(\L_12|Equal0~0clkctrl_outclk\) & ((\L_10|Yout[3]~7_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_12|I3\(3),
	datac => \L_12|Equal0~0clkctrl_outclk\,
	datad => \L_10|Yout[3]~7_combout\,
	combout => \L_12|I3\(3));

-- Location: LCCOMB_X75_Y12_N10
\L_3|I1[4]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I1\(4) = (GLOBAL(\L_3|Equal0~0clkctrl_outclk\) & ((\TM3|I0\(4)))) # (!GLOBAL(\L_3|Equal0~0clkctrl_outclk\) & (\L_3|I1\(4)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_3|I1\(4),
	datac => \TM3|I0\(4),
	datad => \L_3|Equal0~0clkctrl_outclk\,
	combout => \L_3|I1\(4));

-- Location: LCCOMB_X75_Y9_N12
\L_12|I3[4]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I3\(4) = (GLOBAL(\L_12|Equal0~0clkctrl_outclk\) & ((\L_12|I3\(4)))) # (!GLOBAL(\L_12|Equal0~0clkctrl_outclk\) & (\L_10|Yout[4]~9_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_10|Yout[4]~9_combout\,
	datac => \L_12|I3\(4),
	datad => \L_12|Equal0~0clkctrl_outclk\,
	combout => \L_12|I3\(4));

-- Location: LCCOMB_X76_Y8_N22
\L_3|I1[6]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I1\(6) = (GLOBAL(\L_3|Equal0~0clkctrl_outclk\) & ((\TM3|I0\(6)))) # (!GLOBAL(\L_3|Equal0~0clkctrl_outclk\) & (\L_3|I1\(6)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_3|I1\(6),
	datac => \L_3|Equal0~0clkctrl_outclk\,
	datad => \TM3|I0\(6),
	combout => \L_3|I1\(6));

-- Location: LCCOMB_X79_Y12_N28
\L_3|I1[7]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I1\(7) = (GLOBAL(\L_3|Equal0~0clkctrl_outclk\) & (\TM3|I0\(7))) # (!GLOBAL(\L_3|Equal0~0clkctrl_outclk\) & ((\L_3|I1\(7))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I0\(7),
	datac => \L_3|Equal0~0clkctrl_outclk\,
	datad => \L_3|I1\(7),
	combout => \L_3|I1\(7));

-- Location: LCCOMB_X79_Y12_N10
\L_3|I1[8]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I1\(8) = (GLOBAL(\L_3|Equal0~0clkctrl_outclk\) & ((\TM3|I0\(8)))) # (!GLOBAL(\L_3|Equal0~0clkctrl_outclk\) & (\L_3|I1\(8)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_3|I1\(8),
	datac => \L_3|Equal0~0clkctrl_outclk\,
	datad => \TM3|I0\(8),
	combout => \L_3|I1\(8));

-- Location: LCCOMB_X75_Y5_N14
\L_12|I3[10]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I3\(10) = (GLOBAL(\L_12|Equal0~0clkctrl_outclk\) & ((\L_12|I3\(10)))) # (!GLOBAL(\L_12|Equal0~0clkctrl_outclk\) & (\L_10|Yout[10]~21_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_10|Yout[10]~21_combout\,
	datac => \L_12|Equal0~0clkctrl_outclk\,
	datad => \L_12|I3\(10),
	combout => \L_12|I3\(10));

-- Location: LCCOMB_X77_Y8_N28
\L_12|I3[11]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I3\(11) = (GLOBAL(\L_12|Equal0~0clkctrl_outclk\) & (\L_12|I3\(11))) # (!GLOBAL(\L_12|Equal0~0clkctrl_outclk\) & ((\L_10|Yout[11]~23_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_12|I3\(11),
	datac => \L_10|Yout[11]~23_combout\,
	datad => \L_12|Equal0~0clkctrl_outclk\,
	combout => \L_12|I3\(11));

-- Location: LCCOMB_X76_Y15_N24
\L_3|I1[12]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I1\(12) = (GLOBAL(\L_3|Equal0~0clkctrl_outclk\) & (\TM3|I0\(12))) # (!GLOBAL(\L_3|Equal0~0clkctrl_outclk\) & ((\L_3|I1\(12))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM3|I0\(12),
	datac => \L_3|Equal0~0clkctrl_outclk\,
	datad => \L_3|I1\(12),
	combout => \L_3|I1\(12));

-- Location: LCCOMB_X77_Y5_N14
\L_12|I3[13]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I3\(13) = (GLOBAL(\L_12|Equal0~0clkctrl_outclk\) & ((\L_12|I3\(13)))) # (!GLOBAL(\L_12|Equal0~0clkctrl_outclk\) & (\L_10|Yout[13]~27_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_10|Yout[13]~27_combout\,
	datab => \L_12|I3\(13),
	datac => \L_12|Equal0~0clkctrl_outclk\,
	combout => \L_12|I3\(13));

-- Location: LCCOMB_X76_Y15_N6
\L_3|I1[14]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I1\(14) = (GLOBAL(\L_3|Equal0~0clkctrl_outclk\) & (\TM3|I0\(14))) # (!GLOBAL(\L_3|Equal0~0clkctrl_outclk\) & ((\L_3|I1\(14))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I0\(14),
	datac => \L_3|Equal0~0clkctrl_outclk\,
	datad => \L_3|I1\(14),
	combout => \L_3|I1\(14));

-- Location: LCCOMB_X75_Y9_N10
\L_12|I3[14]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I3\(14) = (GLOBAL(\L_12|Equal0~0clkctrl_outclk\) & ((\L_12|I3\(14)))) # (!GLOBAL(\L_12|Equal0~0clkctrl_outclk\) & (\L_10|Yout[14]~29_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_10|Yout[14]~29_combout\,
	datac => \L_12|I3\(14),
	datad => \L_12|Equal0~0clkctrl_outclk\,
	combout => \L_12|I3\(14));

-- Location: LCCOMB_X72_Y8_N12
\L_26|I1[0]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_26|I1\(0) = (GLOBAL(\M2S3~inputclkctrl_outclk\) & (\L_26|I1\(0))) # (!GLOBAL(\M2S3~inputclkctrl_outclk\) & ((\L_24|Mult0|auto_generated|mac_out2~dataout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_26|I1\(0),
	datac => \L_24|Mult0|auto_generated|mac_out2~dataout\,
	datad => \M2S3~inputclkctrl_outclk\,
	combout => \L_26|I1\(0));

-- Location: LCCOMB_X78_Y8_N30
\L_26|I1[1]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_26|I1\(1) = (GLOBAL(\M2S3~inputclkctrl_outclk\) & (\L_26|I1\(1))) # (!GLOBAL(\M2S3~inputclkctrl_outclk\) & ((\L_24|Mult0|auto_generated|mac_out2~DATAOUT1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_26|I1\(1),
	datac => \M2S3~inputclkctrl_outclk\,
	datad => \L_24|Mult0|auto_generated|mac_out2~DATAOUT1\,
	combout => \L_26|I1\(1));

-- Location: LCCOMB_X79_Y8_N22
\L_26|I0[3]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_26|I0\(3) = (GLOBAL(\M2S3~inputclkctrl_outclk\) & ((\L_24|Mult0|auto_generated|mac_out2~DATAOUT3\))) # (!GLOBAL(\M2S3~inputclkctrl_outclk\) & (\L_26|I0\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_26|I0\(3),
	datac => \M2S3~inputclkctrl_outclk\,
	datad => \L_24|Mult0|auto_generated|mac_out2~DATAOUT3\,
	combout => \L_26|I0\(3));

-- Location: LCCOMB_X79_Y8_N10
\L_26|I1[3]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_26|I1\(3) = (GLOBAL(\M2S3~inputclkctrl_outclk\) & (\L_26|I1\(3))) # (!GLOBAL(\M2S3~inputclkctrl_outclk\) & ((\L_24|Mult0|auto_generated|mac_out2~DATAOUT3\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_26|I1\(3),
	datac => \M2S3~inputclkctrl_outclk\,
	datad => \L_24|Mult0|auto_generated|mac_out2~DATAOUT3\,
	combout => \L_26|I1\(3));

-- Location: LCCOMB_X75_Y9_N30
\L_26|I1[4]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_26|I1\(4) = (GLOBAL(\M2S3~inputclkctrl_outclk\) & (\L_26|I1\(4))) # (!GLOBAL(\M2S3~inputclkctrl_outclk\) & ((\L_24|Mult0|auto_generated|mac_out2~DATAOUT4\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_26|I1\(4),
	datac => \M2S3~inputclkctrl_outclk\,
	datad => \L_24|Mult0|auto_generated|mac_out2~DATAOUT4\,
	combout => \L_26|I1\(4));

-- Location: LCCOMB_X72_Y8_N10
\L_54|I0[6]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_54|I0\(6) = (GLOBAL(\A2S3~inputclkctrl_outclk\) & (\L_52|O[6]~12_combout\)) # (!GLOBAL(\A2S3~inputclkctrl_outclk\) & ((\L_54|I0\(6))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_52|O[6]~12_combout\,
	datac => \A2S3~inputclkctrl_outclk\,
	datad => \L_54|I0\(6),
	combout => \L_54|I0\(6));

-- Location: LCCOMB_X72_Y8_N26
\L_26|I1[6]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_26|I1\(6) = (GLOBAL(\M2S3~inputclkctrl_outclk\) & (\L_26|I1\(6))) # (!GLOBAL(\M2S3~inputclkctrl_outclk\) & ((\L_24|Mult0|auto_generated|mac_out2~DATAOUT6\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_26|I1\(6),
	datac => \L_24|Mult0|auto_generated|mac_out2~DATAOUT6\,
	datad => \M2S3~inputclkctrl_outclk\,
	combout => \L_26|I1\(6));

-- Location: LCCOMB_X78_Y12_N30
\TM3|I0[7]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM3|I0\(7) = (GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM2|Yout[7]~16_combout\))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM3|I0\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I0\(7),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM2|Yout[7]~16_combout\,
	combout => \TM3|I0\(7));

-- Location: LCCOMB_X73_Y8_N2
\L_26|I0[7]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_26|I0\(7) = (GLOBAL(\M2S3~inputclkctrl_outclk\) & ((\L_24|Mult0|auto_generated|mac_out2~DATAOUT7\))) # (!GLOBAL(\M2S3~inputclkctrl_outclk\) & (\L_26|I0\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_26|I0\(7),
	datac => \L_24|Mult0|auto_generated|mac_out2~DATAOUT7\,
	datad => \M2S3~inputclkctrl_outclk\,
	combout => \L_26|I0\(7));

-- Location: LCCOMB_X75_Y8_N26
\L_54|I0[8]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_54|I0\(8) = (GLOBAL(\A2S3~inputclkctrl_outclk\) & (\L_52|O[8]~16_combout\)) # (!GLOBAL(\A2S3~inputclkctrl_outclk\) & ((\L_54|I0\(8))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_52|O[8]~16_combout\,
	datac => \L_54|I0\(8),
	datad => \A2S3~inputclkctrl_outclk\,
	combout => \L_54|I0\(8));

-- Location: LCCOMB_X75_Y8_N30
\L_26|I1[8]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_26|I1\(8) = (GLOBAL(\M2S3~inputclkctrl_outclk\) & ((\L_26|I1\(8)))) # (!GLOBAL(\M2S3~inputclkctrl_outclk\) & (\L_24|Mult0|auto_generated|mac_out2~DATAOUT8\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_24|Mult0|auto_generated|mac_out2~DATAOUT8\,
	datac => \L_26|I1\(8),
	datad => \M2S3~inputclkctrl_outclk\,
	combout => \L_26|I1\(8));

-- Location: LCCOMB_X77_Y5_N10
\L_26|I0[13]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_26|I0\(13) = (GLOBAL(\M2S3~inputclkctrl_outclk\) & ((\L_24|Mult0|auto_generated|mac_out2~DATAOUT13\))) # (!GLOBAL(\M2S3~inputclkctrl_outclk\) & (\L_26|I0\(13)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_26|I0\(13),
	datac => \M2S3~inputclkctrl_outclk\,
	datad => \L_24|Mult0|auto_generated|mac_out2~DATAOUT13\,
	combout => \L_26|I0\(13));

-- Location: LCCOMB_X75_Y9_N20
\L_54|I0[14]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_54|I0\(14) = (GLOBAL(\A2S3~inputclkctrl_outclk\) & ((\L_52|O[14]~28_combout\))) # (!GLOBAL(\A2S3~inputclkctrl_outclk\) & (\L_54|I0\(14)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_54|I0\(14),
	datac => \A2S3~inputclkctrl_outclk\,
	datad => \L_52|O[14]~28_combout\,
	combout => \L_54|I0\(14));

-- Location: LCCOMB_X75_Y8_N22
\L_26|I1[15]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_26|I1\(15) = (GLOBAL(\M2S3~inputclkctrl_outclk\) & ((\L_26|I1\(15)))) # (!GLOBAL(\M2S3~inputclkctrl_outclk\) & (\L_24|Mult0|auto_generated|mac_out2~DATAOUT15\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_24|Mult0|auto_generated|mac_out2~DATAOUT15\,
	datac => \L_26|I1\(15),
	datad => \M2S3~inputclkctrl_outclk\,
	combout => \L_26|I1\(15));

-- Location: LCCOMB_X73_Y15_N30
\L_6|I0[2]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I0\(2) = (GLOBAL(\L_6|I0[15]~0clkctrl_outclk\) & (\L_6|I0\(2))) # (!GLOBAL(\L_6|I0[15]~0clkctrl_outclk\) & ((\TM7|I0\(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_6|I0\(2),
	datac => \TM7|I0\(2),
	datad => \L_6|I0[15]~0clkctrl_outclk\,
	combout => \L_6|I0\(2));

-- Location: LCCOMB_X78_Y15_N10
\L_6|I0[4]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I0\(4) = (GLOBAL(\L_6|I0[15]~0clkctrl_outclk\) & (\L_6|I0\(4))) # (!GLOBAL(\L_6|I0[15]~0clkctrl_outclk\) & ((\TM7|I0\(4))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_6|I0\(4),
	datac => \TM7|I0\(4),
	datad => \L_6|I0[15]~0clkctrl_outclk\,
	combout => \L_6|I0\(4));

-- Location: LCCOMB_X72_Y10_N22
\TM4|I0[4]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM4|I0\(4) = (GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & ((\TM3|I1\(4)))) # (!GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & (\TM4|I0\(4)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM4|I0\(4),
	datac => \BTPD_S2~inputclkctrl_outclk\,
	datad => \TM3|I1\(4),
	combout => \TM4|I0\(4));

-- Location: LCCOMB_X70_Y10_N22
\L_3|I2[7]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I2\(7) = (GLOBAL(\L_3|Equal0~1clkctrl_outclk\) & ((\TM3|I0\(7)))) # (!GLOBAL(\L_3|Equal0~1clkctrl_outclk\) & (\L_3|I2\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_3|I2\(7),
	datac => \TM3|I0\(7),
	datad => \L_3|Equal0~1clkctrl_outclk\,
	combout => \L_3|I2\(7));

-- Location: LCCOMB_X79_Y10_N26
\L_3|I0[12]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I0\(12) = (GLOBAL(\L_3|I0[15]~0clkctrl_outclk\) & ((\L_3|I0\(12)))) # (!GLOBAL(\L_3|I0[15]~0clkctrl_outclk\) & (\TM3|I0\(12)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I0\(12),
	datac => \L_3|I0\(12),
	datad => \L_3|I0[15]~0clkctrl_outclk\,
	combout => \L_3|I0\(12));

-- Location: LCCOMB_X77_Y8_N10
\L_12|I2[15]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I2\(15) = (GLOBAL(\L_12|Equal0~2clkctrl_outclk\) & ((\L_10|Yout[15]~31_combout\))) # (!GLOBAL(\L_12|Equal0~2clkctrl_outclk\) & (\L_12|I2\(15)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_12|I2\(15),
	datab => \L_10|Yout[15]~31_combout\,
	datac => \L_12|Equal0~2clkctrl_outclk\,
	combout => \L_12|I2\(15));

-- Location: LCCOMB_X73_Y10_N30
\TM4|I1[0]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM4|I1\(0) = (GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & (\TM4|I1\(0))) # (!GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & ((\TM3|I1\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM4|I1\(0),
	datac => \BTPD_S2~inputclkctrl_outclk\,
	datad => \TM3|I1\(0),
	combout => \TM4|I1\(0));

-- Location: LCCOMB_X75_Y6_N10
\L_6|I1[2]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I1\(2) = (GLOBAL(\L_6|Equal0~2clkctrl_outclk\) & ((\TM7|I0\(2)))) # (!GLOBAL(\L_6|Equal0~2clkctrl_outclk\) & (\L_6|I1\(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_6|I1\(2),
	datac => \TM7|I0\(2),
	datad => \L_6|Equal0~2clkctrl_outclk\,
	combout => \L_6|I1\(2));

-- Location: LCCOMB_X69_Y10_N26
\TM4|I1[3]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM4|I1\(3) = (GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & (\TM4|I1\(3))) # (!GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & ((\TM3|I1\(3))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM4|I1\(3),
	datab => \TM3|I1\(3),
	datad => \BTPD_S2~inputclkctrl_outclk\,
	combout => \TM4|I1\(3));

-- Location: LCCOMB_X75_Y11_N12
\TM4|I1[8]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM4|I1\(8) = (GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & ((\TM4|I1\(8)))) # (!GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & (\TM3|I1\(8)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I1\(8),
	datac => \TM4|I1\(8),
	datad => \BTPD_S2~inputclkctrl_outclk\,
	combout => \TM4|I1\(8));

-- Location: IOIBUF_X53_Y0_N15
\v0[0]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v0(0),
	o => \v0[0]~input_o\);

-- Location: IOIBUF_X50_Y0_N8
\v0[1]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v0(1),
	o => \v0[1]~input_o\);

-- Location: IOIBUF_X117_Y13_N1
\v0[2]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v0(2),
	o => \v0[2]~input_o\);

-- Location: IOIBUF_X44_Y0_N1
\v0[3]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v0(3),
	o => \v0[3]~input_o\);

-- Location: IOIBUF_X117_Y17_N1
\v0[4]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v0(4),
	o => \v0[4]~input_o\);

-- Location: IOIBUF_X92_Y0_N15
\v0[5]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v0(5),
	o => \v0[5]~input_o\);

-- Location: IOIBUF_X92_Y0_N1
\v0[6]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v0(6),
	o => \v0[6]~input_o\);

-- Location: IOIBUF_X108_Y0_N15
\v0[7]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v0(7),
	o => \v0[7]~input_o\);

-- Location: IOIBUF_X117_Y27_N8
\v0[8]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v0(8),
	o => \v0[8]~input_o\);

-- Location: IOIBUF_X44_Y0_N15
\v0[9]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v0(9),
	o => \v0[9]~input_o\);

-- Location: IOIBUF_X117_Y18_N1
\v0[10]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v0(10),
	o => \v0[10]~input_o\);

-- Location: IOIBUF_X117_Y13_N8
\v0[11]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v0(11),
	o => \v0[11]~input_o\);

-- Location: IOIBUF_X46_Y0_N15
\v0[12]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v0(12),
	o => \v0[12]~input_o\);

-- Location: IOIBUF_X117_Y19_N1
\v0[15]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v0(15),
	o => \v0[15]~input_o\);

-- Location: IOIBUF_X106_Y0_N15
\A1S2~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_A1S2,
	o => \A1S2~input_o\);

-- Location: IOIBUF_X117_Y29_N1
\A1S1~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_A1S1,
	o => \A1S1~input_o\);

-- Location: IOIBUF_X61_Y0_N15
\v3[0]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v3(0),
	o => \v3[0]~input_o\);

-- Location: IOIBUF_X92_Y0_N22
\v3[3]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v3(3),
	o => \v3[3]~input_o\);

-- Location: IOIBUF_X44_Y0_N22
\v3[6]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v3(6),
	o => \v3[6]~input_o\);

-- Location: IOIBUF_X90_Y0_N1
\v3[7]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v3(7),
	o => \v3[7]~input_o\);

-- Location: IOIBUF_X97_Y0_N1
\v3[9]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v3(9),
	o => \v3[9]~input_o\);

-- Location: IOIBUF_X115_Y0_N8
\v3[11]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v3(11),
	o => \v3[11]~input_o\);

-- Location: IOIBUF_X117_Y11_N8
\v3[12]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v3(12),
	o => \v3[12]~input_o\);

-- Location: IOIBUF_X88_Y0_N15
\v3[14]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v3(14),
	o => \v3[14]~input_o\);

-- Location: IOIBUF_X106_Y0_N8
\v1[1]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v1(1),
	o => \v1[1]~input_o\);

-- Location: IOIBUF_X99_Y0_N15
\v1[4]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v1(4),
	o => \v1[4]~input_o\);

-- Location: IOIBUF_X111_Y0_N1
\v1[9]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v1(9),
	o => \v1[9]~input_o\);

-- Location: IOIBUF_X104_Y0_N1
\v1[10]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v1(10),
	o => \v1[10]~input_o\);

-- Location: IOIBUF_X117_Y32_N1
\M1S2~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_M1S2,
	o => \M1S2~input_o\);

-- Location: IOIBUF_X53_Y0_N22
\v2[1]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v2(1),
	o => \v2[1]~input_o\);

-- Location: IOIBUF_X86_Y0_N8
\v2[7]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v2(7),
	o => \v2[7]~input_o\);

-- Location: IOIBUF_X113_Y0_N1
\v2[8]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v2(8),
	o => \v2[8]~input_o\);

-- Location: IOIBUF_X88_Y0_N22
\v2[13]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v2(13),
	o => \v2[13]~input_o\);

-- Location: IOOBUF_X108_Y0_N23
\Op1[0]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \L_9|I6[0]~0_combout\,
	devoe => ww_devoe,
	o => \Op1[0]~output_o\);

-- Location: IOOBUF_X117_Y29_N9
\Op1[1]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \L_9|I6[1]~1_combout\,
	devoe => ww_devoe,
	o => \Op1[1]~output_o\);

-- Location: IOOBUF_X117_Y21_N2
\Op1[2]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \L_9|I6[2]~2_combout\,
	devoe => ww_devoe,
	o => \Op1[2]~output_o\);

-- Location: IOOBUF_X117_Y31_N9
\Op1[3]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \L_9|I6[3]~3_combout\,
	devoe => ww_devoe,
	o => \Op1[3]~output_o\);

-- Location: IOOBUF_X117_Y23_N9
\Op1[4]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \L_9|I6[4]~4_combout\,
	devoe => ww_devoe,
	o => \Op1[4]~output_o\);

-- Location: IOOBUF_X117_Y31_N2
\Op1[5]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \L_9|I6[5]~5_combout\,
	devoe => ww_devoe,
	o => \Op1[5]~output_o\);

-- Location: IOOBUF_X117_Y23_N2
\Op1[6]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \L_9|I6[6]~6_combout\,
	devoe => ww_devoe,
	o => \Op1[6]~output_o\);

-- Location: IOOBUF_X117_Y10_N9
\Op1[7]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \L_9|I6[7]~7_combout\,
	devoe => ww_devoe,
	o => \Op1[7]~output_o\);

-- Location: IOOBUF_X117_Y24_N2
\Op1[8]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \L_9|I6[8]~8_combout\,
	devoe => ww_devoe,
	o => \Op1[8]~output_o\);

-- Location: IOOBUF_X117_Y26_N9
\Op1[9]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \L_9|I6[9]~9_combout\,
	devoe => ww_devoe,
	o => \Op1[9]~output_o\);

-- Location: IOOBUF_X117_Y22_N9
\Op1[10]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \L_9|I6[10]~10_combout\,
	devoe => ww_devoe,
	o => \Op1[10]~output_o\);

-- Location: IOOBUF_X117_Y21_N9
\Op1[11]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \L_9|I6[11]~11_combout\,
	devoe => ww_devoe,
	o => \Op1[11]~output_o\);

-- Location: IOOBUF_X117_Y27_N2
\Op1[12]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \L_9|I6[12]~12_combout\,
	devoe => ww_devoe,
	o => \Op1[12]~output_o\);

-- Location: IOOBUF_X117_Y22_N2
\Op1[13]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \L_9|I6[13]~13_combout\,
	devoe => ww_devoe,
	o => \Op1[13]~output_o\);

-- Location: IOOBUF_X117_Y26_N2
\Op1[14]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \L_9|I6[14]~14_combout\,
	devoe => ww_devoe,
	o => \Op1[14]~output_o\);

-- Location: IOOBUF_X117_Y6_N9
\Op1[15]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \L_9|I6[15]~15_combout\,
	devoe => ww_devoe,
	o => \Op1[15]~output_o\);

-- Location: IOOBUF_X63_Y0_N23
\Op2_1[0]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \L_6|I3\(0),
	devoe => ww_devoe,
	o => \Op2_1[0]~output_o\);

-- Location: IOOBUF_X86_Y0_N16
\Op2_1[1]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \L_6|I3\(1),
	devoe => ww_devoe,
	o => \Op2_1[1]~output_o\);

-- Location: IOOBUF_X115_Y0_N23
\Op2_1[2]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \L_6|I3\(2),
	devoe => ww_devoe,
	o => \Op2_1[2]~output_o\);

-- Location: IOOBUF_X117_Y15_N2
\Op2_1[3]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \L_6|I3\(3),
	devoe => ww_devoe,
	o => \Op2_1[3]~output_o\);

-- Location: IOOBUF_X61_Y0_N9
\Op2_1[4]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \L_6|I3\(4),
	devoe => ww_devoe,
	o => \Op2_1[4]~output_o\);

-- Location: IOOBUF_X117_Y15_N9
\Op2_1[5]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \L_6|I3\(5),
	devoe => ww_devoe,
	o => \Op2_1[5]~output_o\);

-- Location: IOOBUF_X117_Y6_N2
\Op2_1[6]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \L_6|I3\(6),
	devoe => ww_devoe,
	o => \Op2_1[6]~output_o\);

-- Location: IOOBUF_X113_Y0_N23
\Op2_1[7]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \L_6|I3\(7),
	devoe => ww_devoe,
	o => \Op2_1[7]~output_o\);

-- Location: IOOBUF_X117_Y7_N2
\Op2_1[8]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \L_6|I3\(8),
	devoe => ww_devoe,
	o => \Op2_1[8]~output_o\);

-- Location: IOOBUF_X86_Y0_N2
\Op2_1[9]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \L_6|I3\(9),
	devoe => ww_devoe,
	o => \Op2_1[9]~output_o\);

-- Location: IOOBUF_X50_Y0_N2
\Op2_1[10]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \L_6|I3\(10),
	devoe => ww_devoe,
	o => \Op2_1[10]~output_o\);

-- Location: IOOBUF_X41_Y0_N16
\Op2_1[11]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \L_6|I3\(11),
	devoe => ww_devoe,
	o => \Op2_1[11]~output_o\);

-- Location: IOOBUF_X108_Y0_N9
\Op2_1[12]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \L_6|I3\(12),
	devoe => ww_devoe,
	o => \Op2_1[12]~output_o\);

-- Location: IOOBUF_X104_Y0_N16
\Op2_1[13]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \L_6|I3\(13),
	devoe => ww_devoe,
	o => \Op2_1[13]~output_o\);

-- Location: IOOBUF_X117_Y33_N9
\Op2_1[14]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \L_6|I3\(14),
	devoe => ww_devoe,
	o => \Op2_1[14]~output_o\);

-- Location: IOOBUF_X104_Y0_N23
\Op2_1[15]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \L_6|I3\(15),
	devoe => ww_devoe,
	o => \Op2_1[15]~output_o\);

-- Location: IOOBUF_X66_Y0_N2
\Op2_2[0]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \TM8|I4[0]~0_combout\,
	devoe => ww_devoe,
	o => \Op2_2[0]~output_o\);

-- Location: IOOBUF_X84_Y0_N16
\Op2_2[1]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \TM8|I4[1]~1_combout\,
	devoe => ww_devoe,
	o => \Op2_2[1]~output_o\);

-- Location: IOOBUF_X48_Y0_N23
\Op2_2[2]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \TM8|I4[2]~2_combout\,
	devoe => ww_devoe,
	o => \Op2_2[2]~output_o\);

-- Location: IOOBUF_X63_Y0_N2
\Op2_2[3]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \TM8|I4[3]~3_combout\,
	devoe => ww_devoe,
	o => \Op2_2[3]~output_o\);

-- Location: IOOBUF_X95_Y0_N16
\Op2_2[4]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \TM8|I4[4]~4_combout\,
	devoe => ww_devoe,
	o => \Op2_2[4]~output_o\);

-- Location: IOOBUF_X63_Y0_N16
\Op2_2[5]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \TM8|I4[5]~5_combout\,
	devoe => ww_devoe,
	o => \Op2_2[5]~output_o\);

-- Location: IOOBUF_X46_Y0_N2
\Op2_2[6]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \TM8|I4[6]~6_combout\,
	devoe => ww_devoe,
	o => \Op2_2[6]~output_o\);

-- Location: IOOBUF_X41_Y0_N9
\Op2_2[7]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \TM8|I4[7]~7_combout\,
	devoe => ww_devoe,
	o => \Op2_2[7]~output_o\);

-- Location: IOOBUF_X117_Y28_N2
\Op2_2[8]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \TM8|I4[8]~8_combout\,
	devoe => ww_devoe,
	o => \Op2_2[8]~output_o\);

-- Location: IOOBUF_X113_Y0_N16
\Op2_2[9]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \TM8|I4[9]~9_combout\,
	devoe => ww_devoe,
	o => \Op2_2[9]~output_o\);

-- Location: IOOBUF_X46_Y0_N9
\Op2_2[10]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \TM8|I4[10]~10_combout\,
	devoe => ww_devoe,
	o => \Op2_2[10]~output_o\);

-- Location: IOOBUF_X63_Y0_N9
\Op2_2[11]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \TM8|I4[11]~11_combout\,
	devoe => ww_devoe,
	o => \Op2_2[11]~output_o\);

-- Location: IOOBUF_X41_Y0_N2
\Op2_2[12]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \TM8|I4[12]~12_combout\,
	devoe => ww_devoe,
	o => \Op2_2[12]~output_o\);

-- Location: IOOBUF_X44_Y0_N9
\Op2_2[13]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \TM8|I4[13]~13_combout\,
	devoe => ww_devoe,
	o => \Op2_2[13]~output_o\);

-- Location: IOOBUF_X117_Y14_N2
\Op2_2[14]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \TM8|I4[14]~14_combout\,
	devoe => ww_devoe,
	o => \Op2_2[14]~output_o\);

-- Location: IOOBUF_X99_Y0_N9
\Op2_2[15]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \TM8|I4[15]~15_combout\,
	devoe => ww_devoe,
	o => \Op2_2[15]~output_o\);

-- Location: IOIBUF_X75_Y0_N22
\RMS1[1]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_RMS1(1),
	o => \RMS1[1]~input_o\);

-- Location: IOIBUF_X117_Y24_N8
\RMS1[2]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_RMS1(2),
	o => \RMS1[2]~input_o\);

-- Location: IOIBUF_X82_Y0_N1
\RMS1[0]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_RMS1(0),
	o => \RMS1[0]~input_o\);

-- Location: LCCOMB_X77_Y16_N12
\L_7|Mux15~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux15~0_combout\ = (\RMS1[2]~input_o\ & ((\RMS1[1]~input_o\) # (\RMS1[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \RMS1[1]~input_o\,
	datac => \RMS1[2]~input_o\,
	datad => \RMS1[0]~input_o\,
	combout => \L_7|Mux15~0_combout\);

-- Location: IOIBUF_X57_Y0_N8
\A3S3~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_A3S3,
	o => \A3S3~input_o\);

-- Location: CLKCTRL_G25
\A3S3~inputclkctrl\ : cycloneiv_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \A3S3~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \A3S3~inputclkctrl_outclk\);

-- Location: LCCOMB_X76_Y16_N4
\L_61|I1[0]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_61|I1\(0) = (GLOBAL(\A3S3~inputclkctrl_outclk\) & ((\L_61|I1\(0)))) # (!GLOBAL(\A3S3~inputclkctrl_outclk\) & (\L_59|O[0]~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_59|O[0]~0_combout\,
	datac => \L_61|I1\(0),
	datad => \A3S3~inputclkctrl_outclk\,
	combout => \L_61|I1\(0));

-- Location: LCCOMB_X77_Y16_N22
\L_7|Mux15~3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux15~3_combout\ = (\RMS1[1]~input_o\) # (!\RMS1[2]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \RMS1[2]~input_o\,
	datad => \RMS1[1]~input_o\,
	combout => \L_7|Mux15~3_combout\);

-- Location: IOIBUF_X57_Y0_N22
\A1S3~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_A1S3,
	o => \A1S3~input_o\);

-- Location: CLKCTRL_G28
\A1S3~inputclkctrl\ : cycloneiv_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \A1S3~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \A1S3~inputclkctrl_outclk\);

-- Location: LCCOMB_X79_Y16_N14
\L_47|I0[0]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_47|I0\(0) = (GLOBAL(\A1S3~inputclkctrl_outclk\) & (\L_45|O[0]~0_combout\)) # (!GLOBAL(\A1S3~inputclkctrl_outclk\) & ((\L_47|I0\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_45|O[0]~0_combout\,
	datac => \L_47|I0\(0),
	datad => \A1S3~inputclkctrl_outclk\,
	combout => \L_47|I0\(0));

-- Location: IOIBUF_X117_Y46_N22
\M1S3~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_M1S3,
	o => \M1S3~input_o\);

-- Location: CLKCTRL_G16
\M1S3~inputclkctrl\ : cycloneiv_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \M1S3~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \M1S3~inputclkctrl_outclk\);

-- Location: IOIBUF_X117_Y14_N8
\RDS2[1]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_RDS2(1),
	o => \RDS2[1]~input_o\);

-- Location: IOIBUF_X108_Y0_N1
\M1S1~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_M1S1,
	o => \M1S1~input_o\);

-- Location: IOIBUF_X117_Y17_N8
\RDS2[0]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_RDS2(0),
	o => \RDS2[0]~input_o\);

-- Location: LCCOMB_X78_Y16_N6
\L_13|Yout[15]~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_13|Yout[15]~0_combout\ = (!\RDS2[2]~input_o\ & (!\RDS2[0]~input_o\ & (\RDS2[1]~input_o\ $ (\M1S1~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000010100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \RDS2[2]~input_o\,
	datab => \RDS2[1]~input_o\,
	datac => \M1S1~input_o\,
	datad => \RDS2[0]~input_o\,
	combout => \L_13|Yout[15]~0_combout\);

-- Location: LCCOMB_X76_Y16_N26
\L_13|Yout[0]~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_13|Yout[0]~1_combout\ = (\L_13|Yout[15]~0_combout\ & \L_7|Mux15~5_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \L_13|Yout[15]~0_combout\,
	datad => \L_7|Mux15~5_combout\,
	combout => \L_13|Yout[0]~1_combout\);

-- Location: IOIBUF_X82_Y0_N8
\A3S1~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_A3S1,
	o => \A3S1~input_o\);

-- Location: IOIBUF_X57_Y0_N15
\TTS~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_TTS,
	o => \TTS~input_o\);

-- Location: IOIBUF_X66_Y0_N15
\YTPD_S2[0]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_YTPD_S2(0),
	o => \YTPD_S2[0]~input_o\);

-- Location: IOIBUF_X66_Y0_N8
\YTPD_S2[2]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_YTPD_S2(2),
	o => \YTPD_S2[2]~input_o\);

-- Location: LCCOMB_X75_Y12_N8
\L_55|Yout[0]~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_55|Yout[0]~0_combout\ = (!\YTPD_S2[1]~input_o\ & (\YTPD_S2[0]~input_o\ & (!\YTPD_S2[2]~input_o\ & !\TTS~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPD_S2[1]~input_o\,
	datab => \YTPD_S2[0]~input_o\,
	datac => \YTPD_S2[2]~input_o\,
	datad => \TTS~input_o\,
	combout => \L_55|Yout[0]~0_combout\);

-- Location: CLKCTRL_G29
\TTS~inputclkctrl\ : cycloneiv_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \TTS~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \TTS~inputclkctrl_outclk\);

-- Location: IOIBUF_X77_Y0_N22
\YTPM_S1[2]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_YTPM_S1(2),
	o => \YTPM_S1[2]~input_o\);

-- Location: IOIBUF_X77_Y0_N15
\YTPM_S1[1]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_YTPM_S1(1),
	o => \YTPM_S1[1]~input_o\);

-- Location: IOIBUF_X117_Y46_N15
\BTPD_S2~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_BTPD_S2,
	o => \BTPD_S2~input_o\);

-- Location: CLKCTRL_G17
\BTPD_S2~inputclkctrl\ : cycloneiv_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \BTPD_S2~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \BTPD_S2~inputclkctrl_outclk\);

-- Location: IOIBUF_X117_Y46_N8
\M3S3~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_M3S3,
	o => \M3S3~input_o\);

-- Location: CLKCTRL_G13
\M3S3~inputclkctrl\ : cycloneiv_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \M3S3~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \M3S3~inputclkctrl_outclk\);

-- Location: IOIBUF_X53_Y91_N22
\BDS2[1]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_BDS2(1),
	o => \BDS2[1]~input_o\);

-- Location: IOIBUF_X61_Y91_N8
\BDS2[0]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_BDS2(0),
	o => \BDS2[0]~input_o\);

-- Location: LCCOMB_X57_Y90_N6
\L_3|I0[15]~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I0[15]~0_combout\ = (!\BDS2[0]~input_o\) # (!\BDS2[1]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \BDS2[1]~input_o\,
	datad => \BDS2[0]~input_o\,
	combout => \L_3|I0[15]~0_combout\);

-- Location: CLKCTRL_G21
\L_3|I0[15]~0clkctrl\ : cycloneiv_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \L_3|I0[15]~0clkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \L_3|I0[15]~0clkctrl_outclk\);

-- Location: LCCOMB_X71_Y10_N4
\L_3|I0[1]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I0\(1) = (GLOBAL(\L_3|I0[15]~0clkctrl_outclk\) & ((\L_3|I0\(1)))) # (!GLOBAL(\L_3|I0[15]~0clkctrl_outclk\) & (\TM3|I0\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I0\(1),
	datac => \L_3|I0\(1),
	datad => \L_3|I0[15]~0clkctrl_outclk\,
	combout => \L_3|I0\(1));

-- Location: IOIBUF_X70_Y0_N15
\BMS1[0]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_BMS1(0),
	o => \BMS1[0]~input_o\);

-- Location: IOIBUF_X82_Y0_N15
\BMS1[1]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_BMS1(1),
	o => \BMS1[1]~input_o\);

-- Location: LCCOMB_X77_Y11_N6
\TM2|Yout[1]~3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[1]~3_combout\ = (\BMS1[1]~input_o\ & ((\v2[1]~input_o\) # (!\BMS1[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v2[1]~input_o\,
	datab => \BMS1[0]~input_o\,
	datad => \BMS1[1]~input_o\,
	combout => \TM2|Yout[1]~3_combout\);

-- Location: LCCOMB_X77_Y11_N30
\L_61|I0[1]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_61|I0\(1) = (GLOBAL(\A3S3~inputclkctrl_outclk\) & (\L_59|O[1]~2_combout\)) # (!GLOBAL(\A3S3~inputclkctrl_outclk\) & ((\L_61|I0\(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_59|O[1]~2_combout\,
	datac => \L_61|I0\(1),
	datad => \A3S3~inputclkctrl_outclk\,
	combout => \L_61|I0\(1));

-- Location: IOIBUF_X57_Y91_N1
\M4S3~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_M4S3,
	o => \M4S3~input_o\);

-- Location: CLKCTRL_G22
\M4S3~inputclkctrl\ : cycloneiv_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \M4S3~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \M4S3~inputclkctrl_outclk\);

-- Location: IOIBUF_X117_Y19_N8
\M4S1~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_M4S1,
	o => \M4S1~input_o\);

-- Location: LCCOMB_X78_Y16_N14
\L_34|Yout[0]~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_34|Yout[0]~0_combout\ = (\RDS2[2]~input_o\ & (!\RDS2[1]~input_o\ & (!\M4S1~input_o\ & !\RDS2[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \RDS2[2]~input_o\,
	datab => \RDS2[1]~input_o\,
	datac => \M4S1~input_o\,
	datad => \RDS2[0]~input_o\,
	combout => \L_34|Yout[0]~0_combout\);

-- Location: IOIBUF_X68_Y0_N22
\YTPD_S2[1]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_YTPD_S2(1),
	o => \YTPD_S2[1]~input_o\);

-- Location: LCCOMB_X71_Y7_N16
\TM8|Equal0~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM8|Equal0~0_combout\ = (!\YTPD_S2[2]~input_o\ & (!\YTPD_S2[1]~input_o\ & !\YTPD_S2[0]~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \YTPD_S2[2]~input_o\,
	datac => \YTPD_S2[1]~input_o\,
	datad => \YTPD_S2[0]~input_o\,
	combout => \TM8|Equal0~0_combout\);

-- Location: IOIBUF_X1_Y0_N15
\YDS2[1]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_YDS2(1),
	o => \YDS2[1]~input_o\);

-- Location: IOIBUF_X5_Y0_N1
\YDS2[0]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_YDS2(0),
	o => \YDS2[0]~input_o\);

-- Location: LCCOMB_X1_Y46_N14
\L_6|I0[15]~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I0[15]~0_combout\ = (!\YDS2[0]~input_o\) # (!\YDS2[1]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \YDS2[1]~input_o\,
	datad => \YDS2[0]~input_o\,
	combout => \L_6|I0[15]~0_combout\);

-- Location: CLKCTRL_G11
\L_6|I0[15]~0clkctrl\ : cycloneiv_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \L_6|I0[15]~0clkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \L_6|I0[15]~0clkctrl_outclk\);

-- Location: LCCOMB_X76_Y16_N8
\L_6|I0[0]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I0\(0) = (GLOBAL(\L_6|I0[15]~0clkctrl_outclk\) & ((\L_6|I0\(0)))) # (!GLOBAL(\L_6|I0[15]~0clkctrl_outclk\) & (\TM7|I0\(0)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM7|I0\(0),
	datac => \L_6|I0\(0),
	datad => \L_6|I0[15]~0clkctrl_outclk\,
	combout => \L_6|I0\(0));

-- Location: IOIBUF_X57_Y0_N1
\A2S3~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_A2S3,
	o => \A2S3~input_o\);

-- Location: CLKCTRL_G27
\A2S3~inputclkctrl\ : cycloneiv_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \A2S3~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \A2S3~inputclkctrl_outclk\);

-- Location: LCCOMB_X72_Y8_N28
\L_54|I0[0]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_54|I0\(0) = (GLOBAL(\A2S3~inputclkctrl_outclk\) & (\L_52|O[0]~0_combout\)) # (!GLOBAL(\A2S3~inputclkctrl_outclk\) & ((\L_54|I0\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_52|O[0]~0_combout\,
	datac => \A2S3~inputclkctrl_outclk\,
	datad => \L_54|I0\(0),
	combout => \L_54|I0\(0));

-- Location: IOIBUF_X70_Y0_N22
\GMS1[0]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_GMS1(0),
	o => \GMS1[0]~input_o\);

-- Location: IOIBUF_X84_Y0_N1
\M2S1~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_M2S1,
	o => \M2S1~input_o\);

-- Location: IOIBUF_X3_Y91_N1
\GDS2[1]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_GDS2(1),
	o => \GDS2[1]~input_o\);

-- Location: IOIBUF_X3_Y91_N22
\GDS2[0]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_GDS2(0),
	o => \GDS2[0]~input_o\);

-- Location: LCCOMB_X1_Y45_N14
\L_12|I0[15]~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I0[15]~0_combout\ = (!\GDS2[0]~input_o\) # (!\GDS2[1]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \GDS2[1]~input_o\,
	datad => \GDS2[0]~input_o\,
	combout => \L_12|I0[15]~0_combout\);

-- Location: CLKCTRL_G1
\L_12|I0[15]~0clkctrl\ : cycloneiv_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \L_12|I0[15]~0clkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \L_12|I0[15]~0clkctrl_outclk\);

-- Location: LCCOMB_X72_Y8_N20
\L_12|I0[0]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I0\(0) = (GLOBAL(\L_12|I0[15]~0clkctrl_outclk\) & (\L_12|I0\(0))) # (!GLOBAL(\L_12|I0[15]~0clkctrl_outclk\) & ((\L_10|Yout[0]~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_12|I0\(0),
	datac => \L_10|Yout[0]~1_combout\,
	datad => \L_12|I0[15]~0clkctrl_outclk\,
	combout => \L_12|I0\(0));

-- Location: LCCOMB_X1_Y45_N4
\L_12|Equal0~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|Equal0~2_combout\ = (!\GDS2[1]~input_o\ & \GDS2[0]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \GDS2[1]~input_o\,
	datad => \GDS2[0]~input_o\,
	combout => \L_12|Equal0~2_combout\);

-- Location: CLKCTRL_G0
\L_12|Equal0~2clkctrl\ : cycloneiv_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \L_12|Equal0~2clkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \L_12|Equal0~2clkctrl_outclk\);

-- Location: LCCOMB_X73_Y8_N28
\L_12|I2[0]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I2\(0) = (GLOBAL(\L_12|Equal0~2clkctrl_outclk\) & (\L_10|Yout[0]~1_combout\)) # (!GLOBAL(\L_12|Equal0~2clkctrl_outclk\) & ((\L_12|I2\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_10|Yout[0]~1_combout\,
	datac => \L_12|Equal0~2clkctrl_outclk\,
	datad => \L_12|I2\(0),
	combout => \L_12|I2\(0));

-- Location: LCCOMB_X73_Y8_N4
\L_20|Yout[0]~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_20|Yout[0]~0_combout\ = (\M2S1~input_o\ & (\L_12|I0\(0))) # (!\M2S1~input_o\ & ((\L_12|I2\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \M2S1~input_o\,
	datac => \L_12|I0\(0),
	datad => \L_12|I2\(0),
	combout => \L_20|Yout[0]~0_combout\);

-- Location: IOIBUF_X117_Y46_N1
\M2S3~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_M2S3,
	o => \M2S3~input_o\);

-- Location: CLKCTRL_G15
\M2S3~inputclkctrl\ : cycloneiv_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \M2S3~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \M2S3~inputclkctrl_outclk\);

-- Location: IOIBUF_X95_Y0_N1
\v1[2]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v1(2),
	o => \v1[2]~input_o\);

-- Location: IOIBUF_X84_Y0_N22
\A2S1~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_A2S1,
	o => \A2S1~input_o\);

-- Location: LCCOMB_X4_Y90_N20
\L_12|Equal0~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|Equal0~1_combout\ = (\GDS2[1]~input_o\ & !\GDS2[0]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \GDS2[1]~input_o\,
	datad => \GDS2[0]~input_o\,
	combout => \L_12|Equal0~1_combout\);

-- Location: CLKCTRL_G20
\L_12|Equal0~1clkctrl\ : cycloneiv_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \L_12|Equal0~1clkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \L_12|Equal0~1clkctrl_outclk\);

-- Location: LCCOMB_X77_Y7_N8
\L_12|I1[2]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I1\(2) = (GLOBAL(\L_12|Equal0~1clkctrl_outclk\) & (\L_10|Yout[2]~5_combout\)) # (!GLOBAL(\L_12|Equal0~1clkctrl_outclk\) & ((\L_12|I1\(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_10|Yout[2]~5_combout\,
	datac => \L_12|Equal0~1clkctrl_outclk\,
	datad => \L_12|I1\(2),
	combout => \L_12|I1\(2));

-- Location: IOIBUF_X117_Y7_N8
\v3[2]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v3(2),
	o => \v3[2]~input_o\);

-- Location: LCCOMB_X57_Y90_N18
\L_3|Equal0~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|Equal0~1_combout\ = (!\BDS2[1]~input_o\ & \BDS2[0]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \BDS2[1]~input_o\,
	datad => \BDS2[0]~input_o\,
	combout => \L_3|Equal0~1_combout\);

-- Location: CLKCTRL_G18
\L_3|Equal0~1clkctrl\ : cycloneiv_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \L_3|Equal0~1clkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \L_3|Equal0~1clkctrl_outclk\);

-- Location: LCCOMB_X70_Y10_N8
\L_3|I2[2]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I2\(2) = (GLOBAL(\L_3|Equal0~1clkctrl_outclk\) & (\TM3|I0\(2))) # (!GLOBAL(\L_3|Equal0~1clkctrl_outclk\) & ((\L_3|I2\(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I0\(2),
	datab => \L_3|I2\(2),
	datad => \L_3|Equal0~1clkctrl_outclk\,
	combout => \L_3|I2\(2));

-- Location: LCCOMB_X70_Y10_N26
\L_3|I0[2]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I0\(2) = (GLOBAL(\L_3|I0[15]~0clkctrl_outclk\) & ((\L_3|I0\(2)))) # (!GLOBAL(\L_3|I0[15]~0clkctrl_outclk\) & (\TM3|I0\(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I0\(2),
	datac => \L_3|I0[15]~0clkctrl_outclk\,
	datad => \L_3|I0\(2),
	combout => \L_3|I0\(2));

-- Location: IOIBUF_X77_Y0_N1
\BTPM_S1~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_BTPM_S1,
	o => \BTPM_S1~input_o\);

-- Location: IOIBUF_X53_Y0_N1
\v2[2]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v2(2),
	o => \v2[2]~input_o\);

-- Location: LCCOMB_X73_Y11_N28
\TM2|Yout[2]~35\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[2]~35_combout\ = (\BTPM_S1~input_o\ & (\v2[2]~input_o\)) # (!\BTPM_S1~input_o\ & ((\L_33|I0\(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \BTPM_S1~input_o\,
	datac => \v2[2]~input_o\,
	datad => \L_33|I0\(2),
	combout => \TM2|Yout[2]~35_combout\);

-- Location: LCCOMB_X73_Y11_N30
\TM3|I1[2]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM3|I1\(2) = (GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM3|I1\(2))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM2|Yout[2]~35_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I1\(2),
	datab => \TTS~inputclkctrl_outclk\,
	datad => \TM2|Yout[2]~35_combout\,
	combout => \TM3|I1\(2));

-- Location: LCCOMB_X70_Y10_N28
\TM4|I0[2]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM4|I0\(2) = (GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & ((\TM3|I1\(2)))) # (!GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & (\TM4|I0\(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM4|I0\(2),
	datac => \TM3|I1\(2),
	datad => \BTPD_S2~inputclkctrl_outclk\,
	combout => \TM4|I0\(2));

-- Location: LCCOMB_X70_Y10_N20
\L_27|Yout[2]~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_27|Yout[2]~2_combout\ = (\M3S1~input_o\ & (((\L_3|I0\(2)) # (\TM4|I0\(2))))) # (!\M3S1~input_o\ & (\L_3|I2\(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111011100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M3S1~input_o\,
	datab => \L_3|I2\(2),
	datac => \L_3|I0\(2),
	datad => \TM4|I0\(2),
	combout => \L_27|Yout[2]~2_combout\);

-- Location: LCCOMB_X70_Y10_N4
\L_3|I0[3]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I0\(3) = (GLOBAL(\L_3|I0[15]~0clkctrl_outclk\) & ((\L_3|I0\(3)))) # (!GLOBAL(\L_3|I0[15]~0clkctrl_outclk\) & (\TM3|I0\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I0\(3),
	datab => \L_3|I0\(3),
	datac => \L_3|I0[15]~0clkctrl_outclk\,
	combout => \L_3|I0\(3));

-- Location: LCCOMB_X70_Y10_N30
\L_3|I2[3]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I2\(3) = (GLOBAL(\L_3|Equal0~1clkctrl_outclk\) & (\TM3|I0\(3))) # (!GLOBAL(\L_3|Equal0~1clkctrl_outclk\) & ((\L_3|I2\(3))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I0\(3),
	datac => \L_3|Equal0~1clkctrl_outclk\,
	datad => \L_3|I2\(3),
	combout => \L_3|I2\(3));

-- Location: IOIBUF_X50_Y0_N15
\v2[3]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v2(3),
	o => \v2[3]~input_o\);

-- Location: IOIBUF_X86_Y0_N22
\M3S1~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_M3S1,
	o => \M3S1~input_o\);

-- Location: IOIBUF_X92_Y0_N8
\v2[4]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v2(4),
	o => \v2[4]~input_o\);

-- Location: IOIBUF_X88_Y0_N1
\v3[1]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v3(1),
	o => \v3[1]~input_o\);

-- Location: IOIBUF_X75_Y0_N8
\YMS1[0]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_YMS1(0),
	o => \YMS1[0]~input_o\);

-- Location: LCCOMB_X78_Y10_N14
\L_33|I0[1]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_33|I0\(1) = (GLOBAL(\M3S3~inputclkctrl_outclk\) & ((\L_31|Mult0|auto_generated|mac_out2~DATAOUT1\))) # (!GLOBAL(\M3S3~inputclkctrl_outclk\) & (\L_33|I0\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_33|I0\(1),
	datac => \L_31|Mult0|auto_generated|mac_out2~DATAOUT1\,
	datad => \M3S3~inputclkctrl_outclk\,
	combout => \L_33|I0\(1));

-- Location: LCCOMB_X77_Y9_N26
\L_54|I1[1]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_54|I1\(1) = (GLOBAL(\A2S3~inputclkctrl_outclk\) & ((\L_54|I1\(1)))) # (!GLOBAL(\A2S3~inputclkctrl_outclk\) & (\L_52|O[1]~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_52|O[1]~2_combout\,
	datac => \L_54|I1\(1),
	datad => \A2S3~inputclkctrl_outclk\,
	combout => \L_54|I1\(1));

-- Location: LCCOMB_X78_Y10_N12
\TM6|Yout[1]~68\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[1]~68_combout\ = (\YMS1[1]~input_o\ & ((\YMS1[0]~input_o\) # ((\L_33|I0\(1))))) # (!\YMS1[1]~input_o\ & (!\YMS1[0]~input_o\ & ((\L_54|I1\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011100110101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YMS1[1]~input_o\,
	datab => \YMS1[0]~input_o\,
	datac => \L_33|I0\(1),
	datad => \L_54|I1\(1),
	combout => \TM6|Yout[1]~68_combout\);

-- Location: LCCOMB_X78_Y10_N2
\TM6|Yout[1]~69\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[1]~69_combout\ = (\YMS1[0]~input_o\ & ((\TM6|Yout[1]~68_combout\ & ((\v3[1]~input_o\))) # (!\TM6|Yout[1]~68_combout\ & (\L_33|I1\(1))))) # (!\YMS1[0]~input_o\ & (((\TM6|Yout[1]~68_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YMS1[0]~input_o\,
	datab => \L_33|I1\(1),
	datac => \v3[1]~input_o\,
	datad => \TM6|Yout[1]~68_combout\,
	combout => \TM6|Yout[1]~69_combout\);

-- Location: LCCOMB_X78_Y10_N30
\TM7|I0[1]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM7|I0\(1) = (GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM6|Yout[1]~69_combout\))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM7|I0\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM7|I0\(1),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM6|Yout[1]~69_combout\,
	combout => \TM7|I0\(1));

-- Location: LCCOMB_X78_Y15_N8
\L_6|I0[1]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I0\(1) = (GLOBAL(\L_6|I0[15]~0clkctrl_outclk\) & ((\L_6|I0\(1)))) # (!GLOBAL(\L_6|I0[15]~0clkctrl_outclk\) & (\TM7|I0\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM7|I0\(1),
	datac => \L_6|I0\(1),
	datad => \L_6|I0[15]~0clkctrl_outclk\,
	combout => \L_6|I0\(1));

-- Location: LCCOMB_X78_Y15_N16
\L_36|Yout[1]~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_36|Yout[1]~1_combout\ = (\L_6|I0\(1)) # ((\TM8|Equal0~0_combout\ & \TM7|I1\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM8|Equal0~0_combout\,
	datac => \L_6|I0\(1),
	datad => \TM7|I1\(1),
	combout => \L_36|Yout[1]~1_combout\);

-- Location: LCCOMB_X78_Y15_N26
\L_34|Yout[1]~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_34|Yout[1]~2_combout\ = (\L_34|Yout[0]~0_combout\ & ((\L_7|Mux14~3_combout\) # ((\L_36|Yout[1]~1_combout\ & \M4S1~input_o\)))) # (!\L_34|Yout[0]~0_combout\ & (\L_36|Yout[1]~1_combout\ & (\M4S1~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_34|Yout[0]~0_combout\,
	datab => \L_36|Yout[1]~1_combout\,
	datac => \M4S1~input_o\,
	datad => \L_7|Mux14~3_combout\,
	combout => \L_34|Yout[1]~2_combout\);

-- Location: LCCOMB_X72_Y9_N8
\L_54|I1[2]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_54|I1\(2) = (GLOBAL(\A2S3~inputclkctrl_outclk\) & ((\L_54|I1\(2)))) # (!GLOBAL(\A2S3~inputclkctrl_outclk\) & (\L_52|O[2]~4_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_52|O[2]~4_combout\,
	datac => \L_54|I1\(2),
	datad => \A2S3~inputclkctrl_outclk\,
	combout => \L_54|I1\(2));

-- Location: IOIBUF_X77_Y0_N8
\YTPM_S1[0]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_YTPM_S1(0),
	o => \YTPM_S1[0]~input_o\);

-- Location: LCCOMB_X73_Y14_N28
\TM6|Yout[0]~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[0]~0_combout\ = (\YTPM_S1[1]~input_o\) # (!\YTPM_S1[0]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \YTPM_S1[0]~input_o\,
	datad => \YTPM_S1[1]~input_o\,
	combout => \TM6|Yout[0]~0_combout\);

-- Location: LCCOMB_X73_Y15_N20
\L_40|I1[2]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_40|I1\(2) = (GLOBAL(\M4S3~inputclkctrl_outclk\) & (\L_40|I1\(2))) # (!GLOBAL(\M4S3~inputclkctrl_outclk\) & ((\L_38|Mult0|auto_generated|mac_out2~DATAOUT2\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_40|I1\(2),
	datac => \L_38|Mult0|auto_generated|mac_out2~DATAOUT2\,
	datad => \M4S3~inputclkctrl_outclk\,
	combout => \L_40|I1\(2));

-- Location: IOIBUF_X84_Y0_N8
\RDS2[2]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_RDS2(2),
	o => \RDS2[2]~input_o\);

-- Location: LCCOMB_X77_Y14_N28
\L_43|Yout[15]~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_43|Yout[15]~0_combout\ = (!\RDS2[2]~input_o\ & (\RDS2[0]~input_o\ & (\A1S2~input_o\ $ (\RDS2[1]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \A1S2~input_o\,
	datab => \RDS2[2]~input_o\,
	datac => \RDS2[0]~input_o\,
	datad => \RDS2[1]~input_o\,
	combout => \L_43|Yout[15]~0_combout\);

-- Location: LCCOMB_X73_Y13_N20
\L_43|Yout[2]~3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_43|Yout[2]~3_combout\ = (\L_43|Yout[15]~0_combout\ & \L_7|Mux13~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_43|Yout[15]~0_combout\,
	datac => \L_7|Mux13~3_combout\,
	combout => \L_43|Yout[2]~3_combout\);

-- Location: LCCOMB_X80_Y15_N12
\L_41|Yout[15]~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_41|Yout[15]~0_combout\ = (!\RDS2[2]~input_o\ & (\RDS2[0]~input_o\ & (\A1S1~input_o\ $ (\RDS2[1]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000011000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \A1S1~input_o\,
	datab => \RDS2[1]~input_o\,
	datac => \RDS2[2]~input_o\,
	datad => \RDS2[0]~input_o\,
	combout => \L_41|Yout[15]~0_combout\);

-- Location: LCCOMB_X77_Y17_N26
\L_41|Yout[1]~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_41|Yout[1]~2_combout\ = (\L_41|Yout[15]~0_combout\ & \L_7|Mux14~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_41|Yout[15]~0_combout\,
	datad => \L_7|Mux14~3_combout\,
	combout => \L_41|Yout[1]~2_combout\);

-- Location: LCCOMB_X76_Y16_N0
\L_41|Yout[0]~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_41|Yout[0]~1_combout\ = (\L_41|Yout[15]~0_combout\ & \L_7|Mux15~5_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_41|Yout[15]~0_combout\,
	datad => \L_7|Mux15~5_combout\,
	combout => \L_41|Yout[0]~1_combout\);

-- Location: LCCOMB_X76_Y17_N2
\L_45|O[1]~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_45|O[1]~2_combout\ = (\L_43|Yout[1]~2_combout\ & ((\L_41|Yout[1]~2_combout\ & (\L_45|O[0]~1\ & VCC)) # (!\L_41|Yout[1]~2_combout\ & (!\L_45|O[0]~1\)))) # (!\L_43|Yout[1]~2_combout\ & ((\L_41|Yout[1]~2_combout\ & (!\L_45|O[0]~1\)) # 
-- (!\L_41|Yout[1]~2_combout\ & ((\L_45|O[0]~1\) # (GND)))))
-- \L_45|O[1]~3\ = CARRY((\L_43|Yout[1]~2_combout\ & (!\L_41|Yout[1]~2_combout\ & !\L_45|O[0]~1\)) # (!\L_43|Yout[1]~2_combout\ & ((!\L_45|O[0]~1\) # (!\L_41|Yout[1]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011000010111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_43|Yout[1]~2_combout\,
	datab => \L_41|Yout[1]~2_combout\,
	datad => VCC,
	cin => \L_45|O[0]~1\,
	combout => \L_45|O[1]~2_combout\,
	cout => \L_45|O[1]~3\);

-- Location: LCCOMB_X76_Y17_N4
\L_45|O[2]~4\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_45|O[2]~4_combout\ = ((\L_41|Yout[2]~3_combout\ $ (\L_43|Yout[2]~3_combout\ $ (!\L_45|O[1]~3\)))) # (GND)
-- \L_45|O[2]~5\ = CARRY((\L_41|Yout[2]~3_combout\ & ((\L_43|Yout[2]~3_combout\) # (!\L_45|O[1]~3\))) # (!\L_41|Yout[2]~3_combout\ & (\L_43|Yout[2]~3_combout\ & !\L_45|O[1]~3\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100110001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_41|Yout[2]~3_combout\,
	datab => \L_43|Yout[2]~3_combout\,
	datad => VCC,
	cin => \L_45|O[1]~3\,
	combout => \L_45|O[2]~4_combout\,
	cout => \L_45|O[2]~5\);

-- Location: LCCOMB_X73_Y13_N30
\L_47|I1[2]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_47|I1\(2) = (GLOBAL(\A1S3~inputclkctrl_outclk\) & (\L_47|I1\(2))) # (!GLOBAL(\A1S3~inputclkctrl_outclk\) & ((\L_45|O[2]~4_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_47|I1\(2),
	datac => \A1S3~inputclkctrl_outclk\,
	datad => \L_45|O[2]~4_combout\,
	combout => \L_47|I1\(2));

-- Location: LCCOMB_X73_Y16_N22
\L_13|Yout[3]~4\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_13|Yout[3]~4_combout\ = (\L_13|Yout[15]~0_combout\ & \L_7|Mux12~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \L_13|Yout[15]~0_combout\,
	datad => \L_7|Mux12~3_combout\,
	combout => \L_13|Yout[3]~4_combout\);

-- Location: IOIBUF_X82_Y0_N22
\A3S2~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_A3S2,
	o => \A3S2~input_o\);

-- Location: LCCOMB_X77_Y7_N16
\L_12|I1[4]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I1\(4) = (GLOBAL(\L_12|Equal0~1clkctrl_outclk\) & (\L_10|Yout[4]~9_combout\)) # (!GLOBAL(\L_12|Equal0~1clkctrl_outclk\) & ((\L_12|I1\(4))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_10|Yout[4]~9_combout\,
	datac => \L_12|Equal0~1clkctrl_outclk\,
	datad => \L_12|I1\(4),
	combout => \L_12|I1\(4));

-- Location: LCCOMB_X71_Y7_N4
\TM8|Equal3~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM8|Equal3~0_combout\ = (!\YTPD_S2[2]~input_o\ & (\YTPD_S2[1]~input_o\ & \YTPD_S2[0]~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \YTPD_S2[2]~input_o\,
	datac => \YTPD_S2[1]~input_o\,
	datad => \YTPD_S2[0]~input_o\,
	combout => \TM8|Equal3~0_combout\);

-- Location: IOIBUF_X46_Y0_N22
\v3[4]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v3(4),
	o => \v3[4]~input_o\);

-- Location: LCCOMB_X76_Y18_N28
\TM2|Yout[9]~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[9]~2_combout\ = (!\BMS1[0]~input_o\) # (!\BMS1[1]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \BMS1[1]~input_o\,
	datad => \BMS1[0]~input_o\,
	combout => \TM2|Yout[9]~2_combout\);

-- Location: LCCOMB_X57_Y90_N4
\L_3|Equal0~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|Equal0~0_combout\ = (\BDS2[1]~input_o\ & !\BDS2[0]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \BDS2[1]~input_o\,
	datad => \BDS2[0]~input_o\,
	combout => \L_3|Equal0~0_combout\);

-- Location: CLKCTRL_G23
\L_3|Equal0~0clkctrl\ : cycloneiv_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \L_3|Equal0~0clkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \L_3|Equal0~0clkctrl_outclk\);

-- Location: LCCOMB_X76_Y8_N24
\L_3|I1[5]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I1\(5) = (GLOBAL(\L_3|Equal0~0clkctrl_outclk\) & (\TM3|I0\(5))) # (!GLOBAL(\L_3|Equal0~0clkctrl_outclk\) & ((\L_3|I1\(5))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM3|I0\(5),
	datac => \L_3|Equal0~0clkctrl_outclk\,
	datad => \L_3|I1\(5),
	combout => \L_3|I1\(5));

-- Location: LCCOMB_X75_Y7_N24
\L_12|I1[5]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I1\(5) = (GLOBAL(\L_12|Equal0~1clkctrl_outclk\) & (\L_10|Yout[5]~11_combout\)) # (!GLOBAL(\L_12|Equal0~1clkctrl_outclk\) & ((\L_12|I1\(5))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_10|Yout[5]~11_combout\,
	datac => \L_12|Equal0~1clkctrl_outclk\,
	datad => \L_12|I1\(5),
	combout => \L_12|I1\(5));

-- Location: LCCOMB_X72_Y10_N8
\L_3|I2[6]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I2\(6) = (GLOBAL(\L_3|Equal0~1clkctrl_outclk\) & (\TM3|I0\(6))) # (!GLOBAL(\L_3|Equal0~1clkctrl_outclk\) & ((\L_3|I2\(6))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I0\(6),
	datab => \L_3|I2\(6),
	datad => \L_3|Equal0~1clkctrl_outclk\,
	combout => \L_3|I2\(6));

-- Location: LCCOMB_X78_Y15_N0
\L_36|Yout[4]~4\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_36|Yout[4]~4_combout\ = (\L_6|I0\(4)) # ((\TM8|Equal0~0_combout\ & \TM7|I1\(4)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_6|I0\(4),
	datac => \TM8|Equal0~0_combout\,
	datad => \TM7|I1\(4),
	combout => \L_36|Yout[4]~4_combout\);

-- Location: LCCOMB_X77_Y15_N8
\L_34|Yout[4]~5\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_34|Yout[4]~5_combout\ = (\L_34|Yout[0]~0_combout\ & ((\L_7|Mux11~3_combout\) # ((\M4S1~input_o\ & \L_36|Yout[4]~4_combout\)))) # (!\L_34|Yout[0]~0_combout\ & (\M4S1~input_o\ & (\L_36|Yout[4]~4_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_34|Yout[0]~0_combout\,
	datab => \M4S1~input_o\,
	datac => \L_36|Yout[4]~4_combout\,
	datad => \L_7|Mux11~3_combout\,
	combout => \L_34|Yout[4]~5_combout\);

-- Location: LCCOMB_X78_Y15_N4
\L_6|I0[5]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I0\(5) = (GLOBAL(\L_6|I0[15]~0clkctrl_outclk\) & (\L_6|I0\(5))) # (!GLOBAL(\L_6|I0[15]~0clkctrl_outclk\) & ((\TM7|I0\(5))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_6|I0[15]~0clkctrl_outclk\,
	datac => \L_6|I0\(5),
	datad => \TM7|I0\(5),
	combout => \L_6|I0\(5));

-- Location: LCCOMB_X78_Y15_N30
\L_36|Yout[5]~5\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_36|Yout[5]~5_combout\ = (\L_6|I0\(5)) # ((\TM8|Equal0~0_combout\ & \TM7|I1\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110011101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM8|Equal0~0_combout\,
	datab => \L_6|I0\(5),
	datac => \TM7|I1\(5),
	combout => \L_36|Yout[5]~5_combout\);

-- Location: LCCOMB_X76_Y14_N4
\L_61|I1[5]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_61|I1\(5) = (GLOBAL(\A3S3~inputclkctrl_outclk\) & (\L_61|I1\(5))) # (!GLOBAL(\A3S3~inputclkctrl_outclk\) & ((\L_59|O[5]~10_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_61|I1\(5),
	datac => \L_59|O[5]~10_combout\,
	datad => \A3S3~inputclkctrl_outclk\,
	combout => \L_61|I1\(5));

-- Location: LCCOMB_X75_Y14_N6
\L_43|Yout[5]~6\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_43|Yout[5]~6_combout\ = (\L_43|Yout[15]~0_combout\ & \L_7|Mux10~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_43|Yout[15]~0_combout\,
	datac => \L_7|Mux10~3_combout\,
	combout => \L_43|Yout[5]~6_combout\);

-- Location: LCCOMB_X77_Y15_N20
\L_43|Yout[4]~5\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_43|Yout[4]~5_combout\ = (\L_43|Yout[15]~0_combout\ & \L_7|Mux11~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_43|Yout[15]~0_combout\,
	datad => \L_7|Mux11~3_combout\,
	combout => \L_43|Yout[4]~5_combout\);

-- Location: LCCOMB_X75_Y17_N22
\L_41|Yout[3]~4\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_41|Yout[3]~4_combout\ = (\L_41|Yout[15]~0_combout\ & \L_7|Mux12~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_41|Yout[15]~0_combout\,
	datad => \L_7|Mux12~3_combout\,
	combout => \L_41|Yout[3]~4_combout\);

-- Location: LCCOMB_X76_Y17_N6
\L_45|O[3]~6\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_45|O[3]~6_combout\ = (\L_43|Yout[3]~4_combout\ & ((\L_41|Yout[3]~4_combout\ & (\L_45|O[2]~5\ & VCC)) # (!\L_41|Yout[3]~4_combout\ & (!\L_45|O[2]~5\)))) # (!\L_43|Yout[3]~4_combout\ & ((\L_41|Yout[3]~4_combout\ & (!\L_45|O[2]~5\)) # 
-- (!\L_41|Yout[3]~4_combout\ & ((\L_45|O[2]~5\) # (GND)))))
-- \L_45|O[3]~7\ = CARRY((\L_43|Yout[3]~4_combout\ & (!\L_41|Yout[3]~4_combout\ & !\L_45|O[2]~5\)) # (!\L_43|Yout[3]~4_combout\ & ((!\L_45|O[2]~5\) # (!\L_41|Yout[3]~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011000010111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_43|Yout[3]~4_combout\,
	datab => \L_41|Yout[3]~4_combout\,
	datad => VCC,
	cin => \L_45|O[2]~5\,
	combout => \L_45|O[3]~6_combout\,
	cout => \L_45|O[3]~7\);

-- Location: LCCOMB_X76_Y17_N10
\L_45|O[5]~10\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_45|O[5]~10_combout\ = (\L_41|Yout[5]~6_combout\ & ((\L_43|Yout[5]~6_combout\ & (\L_45|O[4]~9\ & VCC)) # (!\L_43|Yout[5]~6_combout\ & (!\L_45|O[4]~9\)))) # (!\L_41|Yout[5]~6_combout\ & ((\L_43|Yout[5]~6_combout\ & (!\L_45|O[4]~9\)) # 
-- (!\L_43|Yout[5]~6_combout\ & ((\L_45|O[4]~9\) # (GND)))))
-- \L_45|O[5]~11\ = CARRY((\L_41|Yout[5]~6_combout\ & (!\L_43|Yout[5]~6_combout\ & !\L_45|O[4]~9\)) # (!\L_41|Yout[5]~6_combout\ & ((!\L_45|O[4]~9\) # (!\L_43|Yout[5]~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011000010111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_41|Yout[5]~6_combout\,
	datab => \L_43|Yout[5]~6_combout\,
	datad => VCC,
	cin => \L_45|O[4]~9\,
	combout => \L_45|O[5]~10_combout\,
	cout => \L_45|O[5]~11\);

-- Location: LCCOMB_X76_Y14_N30
\L_47|I1[5]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_47|I1\(5) = (GLOBAL(\A1S3~inputclkctrl_outclk\) & (\L_47|I1\(5))) # (!GLOBAL(\A1S3~inputclkctrl_outclk\) & ((\L_45|O[5]~10_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_47|I1\(5),
	datac => \L_45|O[5]~10_combout\,
	datad => \A1S3~inputclkctrl_outclk\,
	combout => \L_47|I1\(5));

-- Location: IOIBUF_X75_Y0_N15
\YMS1[1]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_YMS1(1),
	o => \YMS1[1]~input_o\);

-- Location: LCCOMB_X72_Y7_N4
\L_12|I1[6]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I1\(6) = (GLOBAL(\L_12|Equal0~1clkctrl_outclk\) & (\L_10|Yout[6]~13_combout\)) # (!GLOBAL(\L_12|Equal0~1clkctrl_outclk\) & ((\L_12|I1\(6))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010110010101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_10|Yout[6]~13_combout\,
	datab => \L_12|I1\(6),
	datac => \L_12|Equal0~1clkctrl_outclk\,
	combout => \L_12|I1\(6));

-- Location: LCCOMB_X76_Y8_N26
\L_57|Yout[6]~12\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_57|Yout[6]~12_combout\ = (\L_3|I1\(6) & ((\TTS~input_o\) # ((\L_55|Yout[0]~0_combout\ & \TM7|I1\(6))))) # (!\L_3|I1\(6) & (((\L_55|Yout[0]~0_combout\ & \TM7|I1\(6)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_3|I1\(6),
	datab => \TTS~input_o\,
	datac => \L_55|Yout[0]~0_combout\,
	datad => \TM7|I1\(6),
	combout => \L_57|Yout[6]~12_combout\);

-- Location: LCCOMB_X1_Y45_N16
\L_12|Equal0~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|Equal0~0_combout\ = (\GDS2[1]~input_o\) # (\GDS2[0]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \GDS2[1]~input_o\,
	datad => \GDS2[0]~input_o\,
	combout => \L_12|Equal0~0_combout\);

-- Location: CLKCTRL_G2
\L_12|Equal0~0clkctrl\ : cycloneiv_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \L_12|Equal0~0clkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \L_12|Equal0~0clkctrl_outclk\);

-- Location: LCCOMB_X76_Y8_N28
\L_12|I3[6]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I3\(6) = (GLOBAL(\L_12|Equal0~0clkctrl_outclk\) & ((\L_12|I3\(6)))) # (!GLOBAL(\L_12|Equal0~0clkctrl_outclk\) & (\L_10|Yout[6]~13_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_10|Yout[6]~13_combout\,
	datab => \L_12|I3\(6),
	datad => \L_12|Equal0~0clkctrl_outclk\,
	combout => \L_12|I3\(6));

-- Location: LCCOMB_X76_Y8_N10
\L_57|Yout[6]~13\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_57|Yout[6]~13_combout\ = (\A3S2~input_o\ & (\L_57|Yout[6]~12_combout\)) # (!\A3S2~input_o\ & ((\L_12|I3\(6))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \A3S2~input_o\,
	datac => \L_57|Yout[6]~12_combout\,
	datad => \L_12|I3\(6),
	combout => \L_57|Yout[6]~13_combout\);

-- Location: LCCOMB_X80_Y15_N30
\L_55|Yout[15]~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_55|Yout[15]~1_combout\ = (\RDS2[2]~input_o\ & (!\A3S1~input_o\ & (!\RDS2[1]~input_o\ & \RDS2[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \RDS2[2]~input_o\,
	datab => \A3S1~input_o\,
	datac => \RDS2[1]~input_o\,
	datad => \RDS2[0]~input_o\,
	combout => \L_55|Yout[15]~1_combout\);

-- Location: IOIBUF_X70_Y0_N8
\GMS1[1]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_GMS1(1),
	o => \GMS1[1]~input_o\);

-- Location: LCCOMB_X79_Y8_N8
\L_54|I0[3]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_54|I0\(3) = (GLOBAL(\A2S3~inputclkctrl_outclk\) & (\L_52|O[3]~6_combout\)) # (!GLOBAL(\A2S3~inputclkctrl_outclk\) & ((\L_54|I0\(3))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_52|O[3]~6_combout\,
	datac => \L_54|I0\(3),
	datad => \A2S3~inputclkctrl_outclk\,
	combout => \L_54|I0\(3));

-- Location: LCCOMB_X79_Y8_N4
\L_10|Yout[3]~6\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_10|Yout[3]~6_combout\ = (\GMS1[0]~input_o\ & (((\GMS1[1]~input_o\) # (\L_54|I0\(3))))) # (!\GMS1[0]~input_o\ & (\L_26|I1\(3) & (!\GMS1[1]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111011000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_26|I1\(3),
	datab => \GMS1[0]~input_o\,
	datac => \GMS1[1]~input_o\,
	datad => \L_54|I0\(3),
	combout => \L_10|Yout[3]~6_combout\);

-- Location: IOIBUF_X113_Y0_N8
\v1[3]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v1(3),
	o => \v1[3]~input_o\);

-- Location: LCCOMB_X79_Y8_N18
\L_10|Yout[3]~7\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_10|Yout[3]~7_combout\ = (\GMS1[1]~input_o\ & ((\L_10|Yout[3]~6_combout\ & ((\v1[3]~input_o\))) # (!\L_10|Yout[3]~6_combout\ & (\L_26|I0\(3))))) # (!\GMS1[1]~input_o\ & (((\L_10|Yout[3]~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100000111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_26|I0\(3),
	datab => \GMS1[1]~input_o\,
	datac => \L_10|Yout[3]~6_combout\,
	datad => \v1[3]~input_o\,
	combout => \L_10|Yout[3]~7_combout\);

-- Location: LCCOMB_X78_Y7_N4
\L_12|I1[3]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I1\(3) = (GLOBAL(\L_12|Equal0~1clkctrl_outclk\) & (\L_10|Yout[3]~7_combout\)) # (!GLOBAL(\L_12|Equal0~1clkctrl_outclk\) & ((\L_12|I1\(3))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_10|Yout[3]~7_combout\,
	datac => \L_12|Equal0~1clkctrl_outclk\,
	datad => \L_12|I1\(3),
	combout => \L_12|I1\(3));

-- Location: LCCOMB_X76_Y9_N8
\L_33|I1[3]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_33|I1\(3) = (GLOBAL(\M3S3~inputclkctrl_outclk\) & (\L_33|I1\(3))) # (!GLOBAL(\M3S3~inputclkctrl_outclk\) & ((\L_31|Mult0|auto_generated|mac_out2~DATAOUT3\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M3S3~inputclkctrl_outclk\,
	datab => \L_33|I1\(3),
	datad => \L_31|Mult0|auto_generated|mac_out2~DATAOUT3\,
	combout => \L_33|I1\(3));

-- Location: LCCOMB_X76_Y9_N20
\TM6|Yout[3]~72\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[3]~72_combout\ = (\YMS1[0]~input_o\ & (\YMS1[1]~input_o\)) # (!\YMS1[0]~input_o\ & ((\YMS1[1]~input_o\ & ((\L_33|I0\(3)))) # (!\YMS1[1]~input_o\ & (\L_54|I1\(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110010011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YMS1[0]~input_o\,
	datab => \YMS1[1]~input_o\,
	datac => \L_54|I1\(3),
	datad => \L_33|I0\(3),
	combout => \TM6|Yout[3]~72_combout\);

-- Location: LCCOMB_X76_Y9_N6
\TM6|Yout[3]~73\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[3]~73_combout\ = (\YMS1[0]~input_o\ & ((\TM6|Yout[3]~72_combout\ & (\v3[3]~input_o\)) # (!\TM6|Yout[3]~72_combout\ & ((\L_33|I1\(3)))))) # (!\YMS1[0]~input_o\ & (((\TM6|Yout[3]~72_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v3[3]~input_o\,
	datab => \YMS1[0]~input_o\,
	datac => \L_33|I1\(3),
	datad => \TM6|Yout[3]~72_combout\,
	combout => \TM6|Yout[3]~73_combout\);

-- Location: LCCOMB_X76_Y9_N4
\TM7|I0[3]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM7|I0\(3) = (GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM6|Yout[3]~73_combout\))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM7|I0\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM7|I0\(3),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM6|Yout[3]~73_combout\,
	combout => \TM7|I0\(3));

-- Location: LCCOMB_X1_Y46_N4
\L_6|Equal0~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|Equal0~1_combout\ = (!\YDS2[1]~input_o\ & \YDS2[0]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \YDS2[1]~input_o\,
	datad => \YDS2[0]~input_o\,
	combout => \L_6|Equal0~1_combout\);

-- Location: CLKCTRL_G7
\L_6|Equal0~1clkctrl\ : cycloneiv_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \L_6|Equal0~1clkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \L_6|Equal0~1clkctrl_outclk\);

-- Location: LCCOMB_X78_Y7_N14
\L_6|I2[3]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I2\(3) = (GLOBAL(\L_6|Equal0~1clkctrl_outclk\) & ((\TM7|I0\(3)))) # (!GLOBAL(\L_6|Equal0~1clkctrl_outclk\) & (\L_6|I2\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_6|I2\(3),
	datac => \TM7|I0\(3),
	datad => \L_6|Equal0~1clkctrl_outclk\,
	combout => \L_6|I2\(3));

-- Location: LCCOMB_X78_Y7_N0
\L_50|Yout[3]~6\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_50|Yout[3]~6_combout\ = (\L_6|I2\(3)) # ((\TM8|Equal3~0_combout\ & \TM7|I1\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM8|Equal3~0_combout\,
	datac => \L_6|I2\(3),
	datad => \TM7|I1\(3),
	combout => \L_50|Yout[3]~6_combout\);

-- Location: LCCOMB_X78_Y7_N16
\L_50|Yout[3]~7\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_50|Yout[3]~7_combout\ = (\A2S2~input_o\ & (\L_12|I1\(3))) # (!\A2S2~input_o\ & ((\L_50|Yout[3]~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \A2S2~input_o\,
	datac => \L_12|I1\(3),
	datad => \L_50|Yout[3]~6_combout\,
	combout => \L_50|Yout[3]~7_combout\);

-- Location: LCCOMB_X77_Y7_N4
\L_12|I1[1]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I1\(1) = (GLOBAL(\L_12|Equal0~1clkctrl_outclk\) & (\L_10|Yout[1]~3_combout\)) # (!GLOBAL(\L_12|Equal0~1clkctrl_outclk\) & ((\L_12|I1\(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_10|Yout[1]~3_combout\,
	datac => \L_12|Equal0~1clkctrl_outclk\,
	datad => \L_12|I1\(1),
	combout => \L_12|I1\(1));

-- Location: LCCOMB_X77_Y7_N2
\L_6|I2[1]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I2\(1) = (GLOBAL(\L_6|Equal0~1clkctrl_outclk\) & (\TM7|I0\(1))) # (!GLOBAL(\L_6|Equal0~1clkctrl_outclk\) & ((\L_6|I2\(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM7|I0\(1),
	datab => \L_6|I2\(1),
	datad => \L_6|Equal0~1clkctrl_outclk\,
	combout => \L_6|I2\(1));

-- Location: LCCOMB_X77_Y7_N12
\L_50|Yout[1]~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_50|Yout[1]~2_combout\ = (\L_6|I2\(1)) # ((\TM8|Equal3~0_combout\ & \TM7|I1\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM8|Equal3~0_combout\,
	datac => \TM7|I1\(1),
	datad => \L_6|I2\(1),
	combout => \L_50|Yout[1]~2_combout\);

-- Location: LCCOMB_X77_Y7_N22
\L_48|Yout[1]~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_48|Yout[1]~1_combout\ = (\A2S1~input_o\ & (\L_12|I1\(1))) # (!\A2S1~input_o\ & ((\L_50|Yout[1]~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \A2S1~input_o\,
	datac => \L_12|I1\(1),
	datad => \L_50|Yout[1]~2_combout\,
	combout => \L_48|Yout[1]~1_combout\);

-- Location: LCCOMB_X76_Y7_N0
\L_52|O[0]~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_52|O[0]~0_combout\ = (\L_50|Yout[0]~1_combout\ & (\L_48|Yout[0]~0_combout\ $ (VCC))) # (!\L_50|Yout[0]~1_combout\ & (\L_48|Yout[0]~0_combout\ & VCC))
-- \L_52|O[0]~1\ = CARRY((\L_50|Yout[0]~1_combout\ & \L_48|Yout[0]~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110011010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_50|Yout[0]~1_combout\,
	datab => \L_48|Yout[0]~0_combout\,
	datad => VCC,
	combout => \L_52|O[0]~0_combout\,
	cout => \L_52|O[0]~1\);

-- Location: LCCOMB_X76_Y7_N4
\L_52|O[2]~4\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_52|O[2]~4_combout\ = ((\L_50|Yout[2]~5_combout\ $ (\L_48|Yout[2]~2_combout\ $ (!\L_52|O[1]~3\)))) # (GND)
-- \L_52|O[2]~5\ = CARRY((\L_50|Yout[2]~5_combout\ & ((\L_48|Yout[2]~2_combout\) # (!\L_52|O[1]~3\))) # (!\L_50|Yout[2]~5_combout\ & (\L_48|Yout[2]~2_combout\ & !\L_52|O[1]~3\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100110001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_50|Yout[2]~5_combout\,
	datab => \L_48|Yout[2]~2_combout\,
	datad => VCC,
	cin => \L_52|O[1]~3\,
	combout => \L_52|O[2]~4_combout\,
	cout => \L_52|O[2]~5\);

-- Location: LCCOMB_X76_Y7_N6
\L_52|O[3]~6\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_52|O[3]~6_combout\ = (\L_48|Yout[3]~3_combout\ & ((\L_50|Yout[3]~7_combout\ & (\L_52|O[2]~5\ & VCC)) # (!\L_50|Yout[3]~7_combout\ & (!\L_52|O[2]~5\)))) # (!\L_48|Yout[3]~3_combout\ & ((\L_50|Yout[3]~7_combout\ & (!\L_52|O[2]~5\)) # 
-- (!\L_50|Yout[3]~7_combout\ & ((\L_52|O[2]~5\) # (GND)))))
-- \L_52|O[3]~7\ = CARRY((\L_48|Yout[3]~3_combout\ & (!\L_50|Yout[3]~7_combout\ & !\L_52|O[2]~5\)) # (!\L_48|Yout[3]~3_combout\ & ((!\L_52|O[2]~5\) # (!\L_50|Yout[3]~7_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011000010111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_48|Yout[3]~3_combout\,
	datab => \L_50|Yout[3]~7_combout\,
	datad => VCC,
	cin => \L_52|O[2]~5\,
	combout => \L_52|O[3]~6_combout\,
	cout => \L_52|O[3]~7\);

-- Location: LCCOMB_X76_Y9_N30
\L_54|I1[3]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_54|I1\(3) = (GLOBAL(\A2S3~inputclkctrl_outclk\) & ((\L_54|I1\(3)))) # (!GLOBAL(\A2S3~inputclkctrl_outclk\) & (\L_52|O[3]~6_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_52|O[3]~6_combout\,
	datac => \A2S3~inputclkctrl_outclk\,
	datad => \L_54|I1\(3),
	combout => \L_54|I1\(3));

-- Location: LCCOMB_X78_Y9_N8
\TM6|Yout[0]~5\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[0]~5_combout\ = (\YTPM_S1[1]~input_o\) # (\YTPM_S1[0]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011111010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPM_S1[1]~input_o\,
	datac => \YTPM_S1[0]~input_o\,
	combout => \TM6|Yout[0]~5_combout\);

-- Location: IOIBUF_X111_Y0_N8
\v1[7]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v1(7),
	o => \v1[7]~input_o\);

-- Location: LCCOMB_X73_Y8_N22
\L_12|I0[3]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I0\(3) = (GLOBAL(\L_12|I0[15]~0clkctrl_outclk\) & ((\L_12|I0\(3)))) # (!GLOBAL(\L_12|I0[15]~0clkctrl_outclk\) & (\L_10|Yout[3]~7_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_10|Yout[3]~7_combout\,
	datac => \L_12|I0\(3),
	datad => \L_12|I0[15]~0clkctrl_outclk\,
	combout => \L_12|I0\(3));

-- Location: LCCOMB_X78_Y8_N28
\L_12|I2[3]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I2\(3) = (GLOBAL(\L_12|Equal0~2clkctrl_outclk\) & (\L_10|Yout[3]~7_combout\)) # (!GLOBAL(\L_12|Equal0~2clkctrl_outclk\) & ((\L_12|I2\(3))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_10|Yout[3]~7_combout\,
	datac => \L_12|Equal0~2clkctrl_outclk\,
	datad => \L_12|I2\(3),
	combout => \L_12|I2\(3));

-- Location: LCCOMB_X73_Y8_N6
\L_20|Yout[3]~3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_20|Yout[3]~3_combout\ = (\M2S1~input_o\ & (\L_12|I0\(3))) # (!\M2S1~input_o\ & ((\L_12|I2\(3))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \M2S1~input_o\,
	datac => \L_12|I0\(3),
	datad => \L_12|I2\(3),
	combout => \L_20|Yout[3]~3_combout\);

-- Location: LCCOMB_X75_Y9_N22
\L_54|I0[4]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_54|I0\(4) = (GLOBAL(\A2S3~inputclkctrl_outclk\) & ((\L_52|O[4]~8_combout\))) # (!GLOBAL(\A2S3~inputclkctrl_outclk\) & (\L_54|I0\(4)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_54|I0\(4),
	datab => \L_52|O[4]~8_combout\,
	datac => \A2S3~inputclkctrl_outclk\,
	combout => \L_54|I0\(4));

-- Location: IOIBUF_X68_Y0_N1
\v1[6]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v1(6),
	o => \v1[6]~input_o\);

-- Location: LCCOMB_X77_Y8_N6
\L_12|I0[7]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I0\(7) = (GLOBAL(\L_12|I0[15]~0clkctrl_outclk\) & (\L_12|I0\(7))) # (!GLOBAL(\L_12|I0[15]~0clkctrl_outclk\) & ((\L_10|Yout[7]~15_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_12|I0\(7),
	datab => \L_10|Yout[7]~15_combout\,
	datad => \L_12|I0[15]~0clkctrl_outclk\,
	combout => \L_12|I0\(7));

-- Location: LCCOMB_X78_Y8_N6
\L_12|I2[7]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I2\(7) = (GLOBAL(\L_12|Equal0~2clkctrl_outclk\) & ((\L_10|Yout[7]~15_combout\))) # (!GLOBAL(\L_12|Equal0~2clkctrl_outclk\) & (\L_12|I2\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_12|I2\(7),
	datac => \L_12|Equal0~2clkctrl_outclk\,
	datad => \L_10|Yout[7]~15_combout\,
	combout => \L_12|I2\(7));

-- Location: LCCOMB_X78_Y8_N20
\L_20|Yout[7]~7\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_20|Yout[7]~7_combout\ = (\M2S1~input_o\ & (\L_12|I0\(7))) # (!\M2S1~input_o\ & ((\L_12|I2\(7))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M2S1~input_o\,
	datab => \L_12|I0\(7),
	datad => \L_12|I2\(7),
	combout => \L_20|Yout[7]~7_combout\);

-- Location: LCCOMB_X77_Y8_N14
\L_12|I2[8]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I2\(8) = (GLOBAL(\L_12|Equal0~2clkctrl_outclk\) & (\L_10|Yout[8]~17_combout\)) # (!GLOBAL(\L_12|Equal0~2clkctrl_outclk\) & ((\L_12|I2\(8))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010110010101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_10|Yout[8]~17_combout\,
	datab => \L_12|I2\(8),
	datac => \L_12|Equal0~2clkctrl_outclk\,
	combout => \L_12|I2\(8));

-- Location: IOIBUF_X48_Y0_N15
\v1[8]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v1(8),
	o => \v1[8]~input_o\);

-- Location: LCCOMB_X75_Y8_N12
\L_26|I0[8]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_26|I0\(8) = (GLOBAL(\M2S3~inputclkctrl_outclk\) & (\L_24|Mult0|auto_generated|mac_out2~DATAOUT8\)) # (!GLOBAL(\M2S3~inputclkctrl_outclk\) & ((\L_26|I0\(8))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_24|Mult0|auto_generated|mac_out2~DATAOUT8\,
	datac => \L_26|I0\(8),
	datad => \M2S3~inputclkctrl_outclk\,
	combout => \L_26|I0\(8));

-- Location: LCCOMB_X75_Y8_N4
\L_10|Yout[8]~16\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_10|Yout[8]~16_combout\ = (\GMS1[0]~input_o\ & (((\GMS1[1]~input_o\)))) # (!\GMS1[0]~input_o\ & ((\GMS1[1]~input_o\ & ((\L_26|I0\(8)))) # (!\GMS1[1]~input_o\ & (\L_26|I1\(8)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_26|I1\(8),
	datab => \GMS1[0]~input_o\,
	datac => \L_26|I0\(8),
	datad => \GMS1[1]~input_o\,
	combout => \L_10|Yout[8]~16_combout\);

-- Location: LCCOMB_X75_Y8_N6
\L_10|Yout[8]~17\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_10|Yout[8]~17_combout\ = (\L_10|Yout[8]~16_combout\ & (((\v1[8]~input_o\) # (!\GMS1[0]~input_o\)))) # (!\L_10|Yout[8]~16_combout\ & (\L_54|I0\(8) & ((\GMS1[0]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_54|I0\(8),
	datab => \v1[8]~input_o\,
	datac => \L_10|Yout[8]~16_combout\,
	datad => \GMS1[0]~input_o\,
	combout => \L_10|Yout[8]~17_combout\);

-- Location: LCCOMB_X77_Y8_N12
\L_12|I0[8]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I0\(8) = (GLOBAL(\L_12|I0[15]~0clkctrl_outclk\) & (\L_12|I0\(8))) # (!GLOBAL(\L_12|I0[15]~0clkctrl_outclk\) & ((\L_10|Yout[8]~17_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_12|I0\(8),
	datac => \L_10|Yout[8]~17_combout\,
	datad => \L_12|I0[15]~0clkctrl_outclk\,
	combout => \L_12|I0\(8));

-- Location: LCCOMB_X77_Y8_N16
\L_20|Yout[8]~8\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_20|Yout[8]~8_combout\ = (\M2S1~input_o\ & ((\L_12|I0\(8)))) # (!\M2S1~input_o\ & (\L_12|I2\(8)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M2S1~input_o\,
	datac => \L_12|I2\(8),
	datad => \L_12|I0\(8),
	combout => \L_20|Yout[8]~8_combout\);

-- Location: LCCOMB_X76_Y8_N0
\L_12|I0[9]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I0\(9) = (GLOBAL(\L_12|I0[15]~0clkctrl_outclk\) & ((\L_12|I0\(9)))) # (!GLOBAL(\L_12|I0[15]~0clkctrl_outclk\) & (\L_10|Yout[9]~19_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_10|Yout[9]~19_combout\,
	datab => \L_12|I0\(9),
	datad => \L_12|I0[15]~0clkctrl_outclk\,
	combout => \L_12|I0\(9));

-- Location: LCCOMB_X76_Y4_N8
\L_12|I1[10]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I1\(10) = (GLOBAL(\L_12|Equal0~1clkctrl_outclk\) & (\L_10|Yout[10]~21_combout\)) # (!GLOBAL(\L_12|Equal0~1clkctrl_outclk\) & ((\L_12|I1\(10))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_10|Yout[10]~21_combout\,
	datac => \L_12|I1\(10),
	datad => \L_12|Equal0~1clkctrl_outclk\,
	combout => \L_12|I1\(10));

-- Location: IOIBUF_X53_Y0_N8
\v3[10]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v3(10),
	o => \v3[10]~input_o\);

-- Location: IOIBUF_X117_Y28_N8
\v2[9]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v2(9),
	o => \v2[9]~input_o\);

-- Location: IOIBUF_X117_Y18_N8
\v2[10]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v2(10),
	o => \v2[10]~input_o\);

-- Location: LCCOMB_X77_Y10_N12
\TM2|Yout[10]~43\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[10]~43_combout\ = (\BTPM_S1~input_o\ & ((\v2[10]~input_o\))) # (!\BTPM_S1~input_o\ & (\L_33|I0\(10)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \BTPM_S1~input_o\,
	datac => \L_33|I0\(10),
	datad => \v2[10]~input_o\,
	combout => \TM2|Yout[10]~43_combout\);

-- Location: LCCOMB_X77_Y10_N30
\TM3|I1[10]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM3|I1\(10) = (GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM3|I1\(10))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM2|Yout[10]~43_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I1\(10),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM2|Yout[10]~43_combout\,
	combout => \TM3|I1\(10));

-- Location: LCCOMB_X77_Y10_N26
\TM4|I0[10]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM4|I0\(10) = (GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & ((\TM3|I1\(10)))) # (!GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & (\TM4|I0\(10)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM4|I0\(10),
	datac => \TM3|I1\(10),
	datad => \BTPD_S2~inputclkctrl_outclk\,
	combout => \TM4|I0\(10));

-- Location: LCCOMB_X77_Y13_N26
\L_3|I2[10]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I2\(10) = (GLOBAL(\L_3|Equal0~1clkctrl_outclk\) & (\TM3|I0\(10))) # (!GLOBAL(\L_3|Equal0~1clkctrl_outclk\) & ((\L_3|I2\(10))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I0\(10),
	datac => \L_3|I2\(10),
	datad => \L_3|Equal0~1clkctrl_outclk\,
	combout => \L_3|I2\(10));

-- Location: IOIBUF_X117_Y11_N1
\v3[8]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v3(8),
	o => \v3[8]~input_o\);

-- Location: IOIBUF_X61_Y0_N22
\v2[11]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v2(11),
	o => \v2[11]~input_o\);

-- Location: LCCOMB_X75_Y13_N2
\L_61|I1[13]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_61|I1\(13) = (GLOBAL(\A3S3~inputclkctrl_outclk\) & (\L_61|I1\(13))) # (!GLOBAL(\A3S3~inputclkctrl_outclk\) & ((\L_59|O[13]~26_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_61|I1\(13),
	datac => \L_59|O[13]~26_combout\,
	datad => \A3S3~inputclkctrl_outclk\,
	combout => \L_61|I1\(13));

-- Location: LCCOMB_X75_Y14_N30
\L_13|Yout[5]~6\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_13|Yout[5]~6_combout\ = (\L_13|Yout[15]~0_combout\ & \L_7|Mux10~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_13|Yout[15]~0_combout\,
	datac => \L_7|Mux10~3_combout\,
	combout => \L_13|Yout[5]~6_combout\);

-- Location: LCCOMB_X75_Y14_N20
\L_61|I1[6]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_61|I1\(6) = (GLOBAL(\A3S3~inputclkctrl_outclk\) & (\L_61|I1\(6))) # (!GLOBAL(\A3S3~inputclkctrl_outclk\) & ((\L_59|O[6]~12_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_61|I1\(6),
	datac => \L_59|O[6]~12_combout\,
	datad => \A3S3~inputclkctrl_outclk\,
	combout => \L_61|I1\(6));

-- Location: LCCOMB_X76_Y8_N14
\L_12|I3[9]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I3\(9) = (GLOBAL(\L_12|Equal0~0clkctrl_outclk\) & (\L_12|I3\(9))) # (!GLOBAL(\L_12|Equal0~0clkctrl_outclk\) & ((\L_10|Yout[9]~19_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_12|I3\(9),
	datac => \L_10|Yout[9]~19_combout\,
	datad => \L_12|Equal0~0clkctrl_outclk\,
	combout => \L_12|I3\(9));

-- Location: LCCOMB_X76_Y4_N4
\L_12|I1[9]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I1\(9) = (GLOBAL(\L_12|Equal0~1clkctrl_outclk\) & ((\L_10|Yout[9]~19_combout\))) # (!GLOBAL(\L_12|Equal0~1clkctrl_outclk\) & (\L_12|I1\(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_12|I1\(9),
	datac => \L_10|Yout[9]~19_combout\,
	datad => \L_12|Equal0~1clkctrl_outclk\,
	combout => \L_12|I1\(9));

-- Location: LCCOMB_X73_Y9_N26
\L_33|I1[9]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_33|I1\(9) = (GLOBAL(\M3S3~inputclkctrl_outclk\) & (\L_33|I1\(9))) # (!GLOBAL(\M3S3~inputclkctrl_outclk\) & ((\L_31|Mult0|auto_generated|mac_out2~DATAOUT9\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_33|I1\(9),
	datac => \L_31|Mult0|auto_generated|mac_out2~DATAOUT9\,
	datad => \M3S3~inputclkctrl_outclk\,
	combout => \L_33|I1\(9));

-- Location: LCCOMB_X73_Y9_N28
\TM6|Yout[9]~84\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[9]~84_combout\ = (\YMS1[1]~input_o\ & (((\L_33|I0\(9)) # (\YMS1[0]~input_o\)))) # (!\YMS1[1]~input_o\ & (\L_54|I1\(9) & ((!\YMS1[0]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_54|I1\(9),
	datab => \YMS1[1]~input_o\,
	datac => \L_33|I0\(9),
	datad => \YMS1[0]~input_o\,
	combout => \TM6|Yout[9]~84_combout\);

-- Location: LCCOMB_X73_Y9_N10
\TM6|Yout[9]~85\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[9]~85_combout\ = (\YMS1[0]~input_o\ & ((\TM6|Yout[9]~84_combout\ & (\v3[9]~input_o\)) # (!\TM6|Yout[9]~84_combout\ & ((\L_33|I1\(9)))))) # (!\YMS1[0]~input_o\ & (((\TM6|Yout[9]~84_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v3[9]~input_o\,
	datab => \YMS1[0]~input_o\,
	datac => \L_33|I1\(9),
	datad => \TM6|Yout[9]~84_combout\,
	combout => \TM6|Yout[9]~85_combout\);

-- Location: LCCOMB_X73_Y9_N12
\TM7|I0[9]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM7|I0\(9) = (GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM6|Yout[9]~85_combout\))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM7|I0\(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM7|I0\(9),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM6|Yout[9]~85_combout\,
	combout => \TM7|I0\(9));

-- Location: LCCOMB_X76_Y4_N26
\L_6|I2[9]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I2\(9) = (GLOBAL(\L_6|Equal0~1clkctrl_outclk\) & ((\TM7|I0\(9)))) # (!GLOBAL(\L_6|Equal0~1clkctrl_outclk\) & (\L_6|I2\(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_6|I2\(9),
	datac => \TM7|I0\(9),
	datad => \L_6|Equal0~1clkctrl_outclk\,
	combout => \L_6|I2\(9));

-- Location: LCCOMB_X76_Y4_N12
\L_50|Yout[9]~18\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_50|Yout[9]~18_combout\ = (\L_6|I2\(9)) # ((\TM8|Equal3~0_combout\ & \TM7|I1\(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM8|Equal3~0_combout\,
	datac => \TM7|I1\(9),
	datad => \L_6|I2\(9),
	combout => \L_50|Yout[9]~18_combout\);

-- Location: LCCOMB_X76_Y4_N2
\L_48|Yout[9]~9\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_48|Yout[9]~9_combout\ = (\A2S1~input_o\ & (\L_12|I1\(9))) # (!\A2S1~input_o\ & ((\L_50|Yout[9]~18_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \A2S1~input_o\,
	datac => \L_12|I1\(9),
	datad => \L_50|Yout[9]~18_combout\,
	combout => \L_48|Yout[9]~9_combout\);

-- Location: LCCOMB_X75_Y4_N30
\L_12|I1[8]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I1\(8) = (GLOBAL(\L_12|Equal0~1clkctrl_outclk\) & (\L_10|Yout[8]~17_combout\)) # (!GLOBAL(\L_12|Equal0~1clkctrl_outclk\) & ((\L_12|I1\(8))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_10|Yout[8]~17_combout\,
	datac => \L_12|I1\(8),
	datad => \L_12|Equal0~1clkctrl_outclk\,
	combout => \L_12|I1\(8));

-- Location: LCCOMB_X75_Y4_N4
\L_6|I2[8]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I2\(8) = (GLOBAL(\L_6|Equal0~1clkctrl_outclk\) & ((\TM7|I0\(8)))) # (!GLOBAL(\L_6|Equal0~1clkctrl_outclk\) & (\L_6|I2\(8)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_6|Equal0~1clkctrl_outclk\,
	datac => \L_6|I2\(8),
	datad => \TM7|I0\(8),
	combout => \L_6|I2\(8));

-- Location: LCCOMB_X76_Y7_N8
\L_52|O[4]~8\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_52|O[4]~8_combout\ = ((\L_50|Yout[4]~9_combout\ $ (\L_48|Yout[4]~4_combout\ $ (!\L_52|O[3]~7\)))) # (GND)
-- \L_52|O[4]~9\ = CARRY((\L_50|Yout[4]~9_combout\ & ((\L_48|Yout[4]~4_combout\) # (!\L_52|O[3]~7\))) # (!\L_50|Yout[4]~9_combout\ & (\L_48|Yout[4]~4_combout\ & !\L_52|O[3]~7\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100110001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_50|Yout[4]~9_combout\,
	datab => \L_48|Yout[4]~4_combout\,
	datad => VCC,
	cin => \L_52|O[3]~7\,
	combout => \L_52|O[4]~8_combout\,
	cout => \L_52|O[4]~9\);

-- Location: LCCOMB_X76_Y7_N10
\L_52|O[5]~10\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_52|O[5]~10_combout\ = (\L_50|Yout[5]~11_combout\ & ((\L_48|Yout[5]~5_combout\ & (\L_52|O[4]~9\ & VCC)) # (!\L_48|Yout[5]~5_combout\ & (!\L_52|O[4]~9\)))) # (!\L_50|Yout[5]~11_combout\ & ((\L_48|Yout[5]~5_combout\ & (!\L_52|O[4]~9\)) # 
-- (!\L_48|Yout[5]~5_combout\ & ((\L_52|O[4]~9\) # (GND)))))
-- \L_52|O[5]~11\ = CARRY((\L_50|Yout[5]~11_combout\ & (!\L_48|Yout[5]~5_combout\ & !\L_52|O[4]~9\)) # (!\L_50|Yout[5]~11_combout\ & ((!\L_52|O[4]~9\) # (!\L_48|Yout[5]~5_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011000010111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_50|Yout[5]~11_combout\,
	datab => \L_48|Yout[5]~5_combout\,
	datad => VCC,
	cin => \L_52|O[4]~9\,
	combout => \L_52|O[5]~10_combout\,
	cout => \L_52|O[5]~11\);

-- Location: LCCOMB_X76_Y7_N12
\L_52|O[6]~12\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_52|O[6]~12_combout\ = ((\L_48|Yout[6]~6_combout\ $ (\L_50|Yout[6]~13_combout\ $ (!\L_52|O[5]~11\)))) # (GND)
-- \L_52|O[6]~13\ = CARRY((\L_48|Yout[6]~6_combout\ & ((\L_50|Yout[6]~13_combout\) # (!\L_52|O[5]~11\))) # (!\L_48|Yout[6]~6_combout\ & (\L_50|Yout[6]~13_combout\ & !\L_52|O[5]~11\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100110001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_48|Yout[6]~6_combout\,
	datab => \L_50|Yout[6]~13_combout\,
	datad => VCC,
	cin => \L_52|O[5]~11\,
	combout => \L_52|O[6]~12_combout\,
	cout => \L_52|O[6]~13\);

-- Location: LCCOMB_X76_Y7_N14
\L_52|O[7]~14\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_52|O[7]~14_combout\ = (\L_48|Yout[7]~7_combout\ & ((\L_50|Yout[7]~15_combout\ & (\L_52|O[6]~13\ & VCC)) # (!\L_50|Yout[7]~15_combout\ & (!\L_52|O[6]~13\)))) # (!\L_48|Yout[7]~7_combout\ & ((\L_50|Yout[7]~15_combout\ & (!\L_52|O[6]~13\)) # 
-- (!\L_50|Yout[7]~15_combout\ & ((\L_52|O[6]~13\) # (GND)))))
-- \L_52|O[7]~15\ = CARRY((\L_48|Yout[7]~7_combout\ & (!\L_50|Yout[7]~15_combout\ & !\L_52|O[6]~13\)) # (!\L_48|Yout[7]~7_combout\ & ((!\L_52|O[6]~13\) # (!\L_50|Yout[7]~15_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011000010111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_48|Yout[7]~7_combout\,
	datab => \L_50|Yout[7]~15_combout\,
	datad => VCC,
	cin => \L_52|O[6]~13\,
	combout => \L_52|O[7]~14_combout\,
	cout => \L_52|O[7]~15\);

-- Location: LCCOMB_X79_Y9_N8
\L_54|I1[7]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_54|I1\(7) = (GLOBAL(\A2S3~inputclkctrl_outclk\) & (\L_54|I1\(7))) # (!GLOBAL(\A2S3~inputclkctrl_outclk\) & ((\L_52|O[7]~14_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_54|I1\(7),
	datac => \L_52|O[7]~14_combout\,
	datad => \A2S3~inputclkctrl_outclk\,
	combout => \L_54|I1\(7));

-- Location: LCCOMB_X78_Y9_N4
\L_33|I1[7]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_33|I1\(7) = (GLOBAL(\M3S3~inputclkctrl_outclk\) & (\L_33|I1\(7))) # (!GLOBAL(\M3S3~inputclkctrl_outclk\) & ((\L_31|Mult0|auto_generated|mac_out2~DATAOUT7\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_33|I1\(7),
	datac => \M3S3~inputclkctrl_outclk\,
	datad => \L_31|Mult0|auto_generated|mac_out2~DATAOUT7\,
	combout => \L_33|I1\(7));

-- Location: LCCOMB_X78_Y12_N26
\L_61|I0[7]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_61|I0\(7) = (GLOBAL(\A3S3~inputclkctrl_outclk\) & (\L_59|O[7]~14_combout\)) # (!GLOBAL(\A3S3~inputclkctrl_outclk\) & ((\L_61|I0\(7))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_59|O[7]~14_combout\,
	datac => \L_61|I0\(7),
	datad => \A3S3~inputclkctrl_outclk\,
	combout => \L_61|I0\(7));

-- Location: LCCOMB_X75_Y16_N24
\L_40|I1[10]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_40|I1\(10) = (GLOBAL(\M4S3~inputclkctrl_outclk\) & (\L_40|I1\(10))) # (!GLOBAL(\M4S3~inputclkctrl_outclk\) & ((\L_38|Mult0|auto_generated|mac_out2~DATAOUT10\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_40|I1\(10),
	datac => \L_38|Mult0|auto_generated|mac_out2~DATAOUT10\,
	datad => \M4S3~inputclkctrl_outclk\,
	combout => \L_40|I1\(10));

-- Location: LCCOMB_X76_Y18_N4
\L_3|I1[10]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I1\(10) = (GLOBAL(\L_3|Equal0~0clkctrl_outclk\) & (\TM3|I0\(10))) # (!GLOBAL(\L_3|Equal0~0clkctrl_outclk\) & ((\L_3|I1\(10))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I0\(10),
	datac => \L_3|I1\(10),
	datad => \L_3|Equal0~0clkctrl_outclk\,
	combout => \L_3|I1\(10));

-- Location: LCCOMB_X77_Y9_N30
\L_54|I1[10]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_54|I1\(10) = (GLOBAL(\A2S3~inputclkctrl_outclk\) & ((\L_54|I1\(10)))) # (!GLOBAL(\A2S3~inputclkctrl_outclk\) & (\L_52|O[10]~20_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_52|O[10]~20_combout\,
	datac => \L_54|I1\(10),
	datad => \A2S3~inputclkctrl_outclk\,
	combout => \L_54|I1\(10));

-- Location: LCCOMB_X77_Y10_N2
\L_33|I1[10]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_33|I1\(10) = (GLOBAL(\M3S3~inputclkctrl_outclk\) & (\L_33|I1\(10))) # (!GLOBAL(\M3S3~inputclkctrl_outclk\) & ((\L_31|Mult0|auto_generated|mac_out2~DATAOUT10\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_33|I1\(10),
	datac => \L_31|Mult0|auto_generated|mac_out2~DATAOUT10\,
	datad => \M3S3~inputclkctrl_outclk\,
	combout => \L_33|I1\(10));

-- Location: LCCOMB_X77_Y10_N0
\TM6|Yout[10]~42\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[10]~42_combout\ = (!\YTPM_S1[1]~input_o\ & ((\L_40|I0\(10)) # (!\YTPM_S1[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPM_S1[0]~input_o\,
	datac => \YTPM_S1[1]~input_o\,
	datad => \L_40|I0\(10),
	combout => \TM6|Yout[10]~42_combout\);

-- Location: LCCOMB_X77_Y10_N10
\TM6|Yout[10]~43\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[10]~43_combout\ = (\TM6|Yout[0]~0_combout\ & ((\TM6|Yout[10]~42_combout\ & ((\v3[10]~input_o\))) # (!\TM6|Yout[10]~42_combout\ & (\L_61|I0\(10))))) # (!\TM6|Yout[0]~0_combout\ & (((\TM6|Yout[10]~42_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_61|I0\(10),
	datab => \v3[10]~input_o\,
	datac => \TM6|Yout[0]~0_combout\,
	datad => \TM6|Yout[10]~42_combout\,
	combout => \TM6|Yout[10]~43_combout\);

-- Location: LCCOMB_X77_Y10_N16
\TM6|Yout[10]~44\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[10]~44_combout\ = (\YTPM_S1[0]~input_o\ & ((\YTPM_S1[1]~input_o\ & (\L_33|I1\(10))) # (!\YTPM_S1[1]~input_o\ & ((\TM6|Yout[10]~43_combout\))))) # (!\YTPM_S1[0]~input_o\ & (((\TM6|Yout[10]~43_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111011110000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPM_S1[0]~input_o\,
	datab => \YTPM_S1[1]~input_o\,
	datac => \L_33|I1\(10),
	datad => \TM6|Yout[10]~43_combout\,
	combout => \TM6|Yout[10]~44_combout\);

-- Location: LCCOMB_X77_Y10_N6
\TM6|Yout[10]~45\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[10]~45_combout\ = (\YTPM_S1[2]~input_o\ & (\L_54|I1\(10))) # (!\YTPM_S1[2]~input_o\ & ((\TM6|Yout[10]~44_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \YTPM_S1[2]~input_o\,
	datac => \L_54|I1\(10),
	datad => \TM6|Yout[10]~44_combout\,
	combout => \TM6|Yout[10]~45_combout\);

-- Location: LCCOMB_X77_Y10_N22
\TM7|I1[10]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM7|I1\(10) = (GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM7|I1\(10))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM6|Yout[10]~45_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM7|I1\(10),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM6|Yout[10]~45_combout\,
	combout => \TM7|I1\(10));

-- Location: LCCOMB_X75_Y16_N14
\L_57|Yout[10]~20\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_57|Yout[10]~20_combout\ = (\TTS~input_o\ & ((\L_3|I1\(10)) # ((\L_55|Yout[0]~0_combout\ & \TM7|I1\(10))))) # (!\TTS~input_o\ & (\L_55|Yout[0]~0_combout\ & ((\TM7|I1\(10)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TTS~input_o\,
	datab => \L_55|Yout[0]~0_combout\,
	datac => \L_3|I1\(10),
	datad => \TM7|I1\(10),
	combout => \L_57|Yout[10]~20_combout\);

-- Location: LCCOMB_X75_Y16_N4
\L_55|Yout[10]~12\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_55|Yout[10]~12_combout\ = (\L_55|Yout[15]~1_combout\ & ((\L_7|Mux5~3_combout\) # ((\A3S1~input_o\ & \L_57|Yout[10]~20_combout\)))) # (!\L_55|Yout[15]~1_combout\ & (\A3S1~input_o\ & (\L_57|Yout[10]~20_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_55|Yout[15]~1_combout\,
	datab => \A3S1~input_o\,
	datac => \L_57|Yout[10]~20_combout\,
	datad => \L_7|Mux5~3_combout\,
	combout => \L_55|Yout[10]~12_combout\);

-- Location: LCCOMB_X77_Y8_N4
\L_57|Yout[8]~16\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_57|Yout[8]~16_combout\ = (\L_3|I1\(8) & ((\TTS~input_o\) # ((\TM7|I1\(8) & \L_55|Yout[0]~0_combout\)))) # (!\L_3|I1\(8) & (((\TM7|I1\(8) & \L_55|Yout[0]~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_3|I1\(8),
	datab => \TTS~input_o\,
	datac => \TM7|I1\(8),
	datad => \L_55|Yout[0]~0_combout\,
	combout => \L_57|Yout[8]~16_combout\);

-- Location: LCCOMB_X77_Y8_N18
\L_12|I3[8]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I3\(8) = (GLOBAL(\L_12|Equal0~0clkctrl_outclk\) & (\L_12|I3\(8))) # (!GLOBAL(\L_12|Equal0~0clkctrl_outclk\) & ((\L_10|Yout[8]~17_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_12|I3\(8),
	datac => \L_10|Yout[8]~17_combout\,
	datad => \L_12|Equal0~0clkctrl_outclk\,
	combout => \L_12|I3\(8));

-- Location: LCCOMB_X77_Y8_N8
\L_57|Yout[8]~17\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_57|Yout[8]~17_combout\ = (\A3S2~input_o\ & (\L_57|Yout[8]~16_combout\)) # (!\A3S2~input_o\ & ((\L_12|I3\(8))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \A3S2~input_o\,
	datac => \L_57|Yout[8]~16_combout\,
	datad => \L_12|I3\(8),
	combout => \L_57|Yout[8]~17_combout\);

-- Location: LCCOMB_X76_Y12_N12
\L_59|O[6]~12\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_59|O[6]~12_combout\ = ((\L_55|Yout[6]~8_combout\ $ (\L_57|Yout[6]~13_combout\ $ (!\L_59|O[5]~11\)))) # (GND)
-- \L_59|O[6]~13\ = CARRY((\L_55|Yout[6]~8_combout\ & ((\L_57|Yout[6]~13_combout\) # (!\L_59|O[5]~11\))) # (!\L_55|Yout[6]~8_combout\ & (\L_57|Yout[6]~13_combout\ & !\L_59|O[5]~11\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100110001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_55|Yout[6]~8_combout\,
	datab => \L_57|Yout[6]~13_combout\,
	datad => VCC,
	cin => \L_59|O[5]~11\,
	combout => \L_59|O[6]~12_combout\,
	cout => \L_59|O[6]~13\);

-- Location: LCCOMB_X76_Y12_N14
\L_59|O[7]~14\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_59|O[7]~14_combout\ = (\L_55|Yout[7]~9_combout\ & ((\L_57|Yout[7]~15_combout\ & (\L_59|O[6]~13\ & VCC)) # (!\L_57|Yout[7]~15_combout\ & (!\L_59|O[6]~13\)))) # (!\L_55|Yout[7]~9_combout\ & ((\L_57|Yout[7]~15_combout\ & (!\L_59|O[6]~13\)) # 
-- (!\L_57|Yout[7]~15_combout\ & ((\L_59|O[6]~13\) # (GND)))))
-- \L_59|O[7]~15\ = CARRY((\L_55|Yout[7]~9_combout\ & (!\L_57|Yout[7]~15_combout\ & !\L_59|O[6]~13\)) # (!\L_55|Yout[7]~9_combout\ & ((!\L_59|O[6]~13\) # (!\L_57|Yout[7]~15_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011000010111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_55|Yout[7]~9_combout\,
	datab => \L_57|Yout[7]~15_combout\,
	datad => VCC,
	cin => \L_59|O[6]~13\,
	combout => \L_59|O[7]~14_combout\,
	cout => \L_59|O[7]~15\);

-- Location: LCCOMB_X76_Y12_N16
\L_59|O[8]~16\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_59|O[8]~16_combout\ = ((\L_55|Yout[8]~10_combout\ $ (\L_57|Yout[8]~17_combout\ $ (!\L_59|O[7]~15\)))) # (GND)
-- \L_59|O[8]~17\ = CARRY((\L_55|Yout[8]~10_combout\ & ((\L_57|Yout[8]~17_combout\) # (!\L_59|O[7]~15\))) # (!\L_55|Yout[8]~10_combout\ & (\L_57|Yout[8]~17_combout\ & !\L_59|O[7]~15\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100110001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_55|Yout[8]~10_combout\,
	datab => \L_57|Yout[8]~17_combout\,
	datad => VCC,
	cin => \L_59|O[7]~15\,
	combout => \L_59|O[8]~16_combout\,
	cout => \L_59|O[8]~17\);

-- Location: LCCOMB_X76_Y12_N18
\L_59|O[9]~18\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_59|O[9]~18_combout\ = (\L_55|Yout[9]~11_combout\ & ((\L_57|Yout[9]~19_combout\ & (\L_59|O[8]~17\ & VCC)) # (!\L_57|Yout[9]~19_combout\ & (!\L_59|O[8]~17\)))) # (!\L_55|Yout[9]~11_combout\ & ((\L_57|Yout[9]~19_combout\ & (!\L_59|O[8]~17\)) # 
-- (!\L_57|Yout[9]~19_combout\ & ((\L_59|O[8]~17\) # (GND)))))
-- \L_59|O[9]~19\ = CARRY((\L_55|Yout[9]~11_combout\ & (!\L_57|Yout[9]~19_combout\ & !\L_59|O[8]~17\)) # (!\L_55|Yout[9]~11_combout\ & ((!\L_59|O[8]~17\) # (!\L_57|Yout[9]~19_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011000010111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_55|Yout[9]~11_combout\,
	datab => \L_57|Yout[9]~19_combout\,
	datad => VCC,
	cin => \L_59|O[8]~17\,
	combout => \L_59|O[9]~18_combout\,
	cout => \L_59|O[9]~19\);

-- Location: LCCOMB_X76_Y12_N20
\L_59|O[10]~20\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_59|O[10]~20_combout\ = ((\L_57|Yout[10]~21_combout\ $ (\L_55|Yout[10]~12_combout\ $ (!\L_59|O[9]~19\)))) # (GND)
-- \L_59|O[10]~21\ = CARRY((\L_57|Yout[10]~21_combout\ & ((\L_55|Yout[10]~12_combout\) # (!\L_59|O[9]~19\))) # (!\L_57|Yout[10]~21_combout\ & (\L_55|Yout[10]~12_combout\ & !\L_59|O[9]~19\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100110001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_57|Yout[10]~21_combout\,
	datab => \L_55|Yout[10]~12_combout\,
	datad => VCC,
	cin => \L_59|O[9]~19\,
	combout => \L_59|O[10]~20_combout\,
	cout => \L_59|O[10]~21\);

-- Location: LCCOMB_X75_Y16_N18
\L_61|I1[10]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_61|I1\(10) = (GLOBAL(\A3S3~inputclkctrl_outclk\) & (\L_61|I1\(10))) # (!GLOBAL(\A3S3~inputclkctrl_outclk\) & ((\L_59|O[10]~20_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_61|I1\(10),
	datac => \L_59|O[10]~20_combout\,
	datad => \A3S3~inputclkctrl_outclk\,
	combout => \L_61|I1\(10));

-- Location: LCCOMB_X77_Y14_N26
\L_13|Yout[7]~8\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_13|Yout[7]~8_combout\ = (\L_7|Mux8~3_combout\ & \L_13|Yout[15]~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \L_7|Mux8~3_combout\,
	datad => \L_13|Yout[15]~0_combout\,
	combout => \L_13|Yout[7]~8_combout\);

-- Location: LCCOMB_X77_Y15_N4
\L_40|I1[8]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_40|I1\(8) = (GLOBAL(\M4S3~inputclkctrl_outclk\) & (\L_40|I1\(8))) # (!GLOBAL(\M4S3~inputclkctrl_outclk\) & ((\L_38|Mult0|auto_generated|mac_out2~DATAOUT8\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_40|I1\(8),
	datac => \L_38|Mult0|auto_generated|mac_out2~DATAOUT8\,
	datad => \M4S3~inputclkctrl_outclk\,
	combout => \L_40|I1\(8));

-- Location: LCCOMB_X77_Y15_N14
\L_61|I1[8]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_61|I1\(8) = (GLOBAL(\A3S3~inputclkctrl_outclk\) & ((\L_61|I1\(8)))) # (!GLOBAL(\A3S3~inputclkctrl_outclk\) & (\L_59|O[8]~16_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_59|O[8]~16_combout\,
	datab => \L_61|I1\(8),
	datac => \A3S3~inputclkctrl_outclk\,
	combout => \L_61|I1\(8));

-- Location: LCCOMB_X77_Y15_N26
\L_41|Yout[8]~9\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_41|Yout[8]~9_combout\ = (\L_41|Yout[15]~0_combout\ & \L_7|Mux7~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_41|Yout[15]~0_combout\,
	datad => \L_7|Mux7~3_combout\,
	combout => \L_41|Yout[8]~9_combout\);

-- Location: LCCOMB_X77_Y14_N12
\L_41|Yout[7]~8\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_41|Yout[7]~8_combout\ = (\L_41|Yout[15]~0_combout\ & \L_7|Mux8~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_41|Yout[15]~0_combout\,
	datac => \L_7|Mux8~3_combout\,
	combout => \L_41|Yout[7]~8_combout\);

-- Location: LCCOMB_X75_Y14_N12
\L_43|Yout[6]~7\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_43|Yout[6]~7_combout\ = (\L_43|Yout[15]~0_combout\ & \L_7|Mux9~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_43|Yout[15]~0_combout\,
	datad => \L_7|Mux9~3_combout\,
	combout => \L_43|Yout[6]~7_combout\);

-- Location: LCCOMB_X76_Y17_N12
\L_45|O[6]~12\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_45|O[6]~12_combout\ = ((\L_41|Yout[6]~7_combout\ $ (\L_43|Yout[6]~7_combout\ $ (!\L_45|O[5]~11\)))) # (GND)
-- \L_45|O[6]~13\ = CARRY((\L_41|Yout[6]~7_combout\ & ((\L_43|Yout[6]~7_combout\) # (!\L_45|O[5]~11\))) # (!\L_41|Yout[6]~7_combout\ & (\L_43|Yout[6]~7_combout\ & !\L_45|O[5]~11\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100110001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_41|Yout[6]~7_combout\,
	datab => \L_43|Yout[6]~7_combout\,
	datad => VCC,
	cin => \L_45|O[5]~11\,
	combout => \L_45|O[6]~12_combout\,
	cout => \L_45|O[6]~13\);

-- Location: LCCOMB_X76_Y17_N14
\L_45|O[7]~14\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_45|O[7]~14_combout\ = (\L_43|Yout[7]~8_combout\ & ((\L_41|Yout[7]~8_combout\ & (\L_45|O[6]~13\ & VCC)) # (!\L_41|Yout[7]~8_combout\ & (!\L_45|O[6]~13\)))) # (!\L_43|Yout[7]~8_combout\ & ((\L_41|Yout[7]~8_combout\ & (!\L_45|O[6]~13\)) # 
-- (!\L_41|Yout[7]~8_combout\ & ((\L_45|O[6]~13\) # (GND)))))
-- \L_45|O[7]~15\ = CARRY((\L_43|Yout[7]~8_combout\ & (!\L_41|Yout[7]~8_combout\ & !\L_45|O[6]~13\)) # (!\L_43|Yout[7]~8_combout\ & ((!\L_45|O[6]~13\) # (!\L_41|Yout[7]~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011000010111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_43|Yout[7]~8_combout\,
	datab => \L_41|Yout[7]~8_combout\,
	datad => VCC,
	cin => \L_45|O[6]~13\,
	combout => \L_45|O[7]~14_combout\,
	cout => \L_45|O[7]~15\);

-- Location: LCCOMB_X76_Y17_N16
\L_45|O[8]~16\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_45|O[8]~16_combout\ = ((\L_43|Yout[8]~9_combout\ $ (\L_41|Yout[8]~9_combout\ $ (!\L_45|O[7]~15\)))) # (GND)
-- \L_45|O[8]~17\ = CARRY((\L_43|Yout[8]~9_combout\ & ((\L_41|Yout[8]~9_combout\) # (!\L_45|O[7]~15\))) # (!\L_43|Yout[8]~9_combout\ & (\L_41|Yout[8]~9_combout\ & !\L_45|O[7]~15\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100110001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_43|Yout[8]~9_combout\,
	datab => \L_41|Yout[8]~9_combout\,
	datad => VCC,
	cin => \L_45|O[7]~15\,
	combout => \L_45|O[8]~16_combout\,
	cout => \L_45|O[8]~17\);

-- Location: LCCOMB_X77_Y16_N4
\L_47|I1[8]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_47|I1\(8) = (GLOBAL(\A1S3~inputclkctrl_outclk\) & (\L_47|I1\(8))) # (!GLOBAL(\A1S3~inputclkctrl_outclk\) & ((\L_45|O[8]~16_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_47|I1\(8),
	datac => \L_45|O[8]~16_combout\,
	datad => \A1S3~inputclkctrl_outclk\,
	combout => \L_47|I1\(8));

-- Location: LCCOMB_X77_Y16_N14
\L_47|I0[8]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_47|I0\(8) = (GLOBAL(\A1S3~inputclkctrl_outclk\) & ((\L_45|O[8]~16_combout\))) # (!GLOBAL(\A1S3~inputclkctrl_outclk\) & (\L_47|I0\(8)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_47|I0\(8),
	datac => \L_45|O[8]~16_combout\,
	datad => \A1S3~inputclkctrl_outclk\,
	combout => \L_47|I0\(8));

-- Location: LCCOMB_X73_Y16_N28
\L_13|Yout[9]~10\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_13|Yout[9]~10_combout\ = (\L_13|Yout[15]~0_combout\ & \L_7|Mux6~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \L_13|Yout[15]~0_combout\,
	datad => \L_7|Mux6~3_combout\,
	combout => \L_13|Yout[9]~10_combout\);

-- Location: LCCOMB_X75_Y16_N20
\L_13|Yout[10]~11\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_13|Yout[10]~11_combout\ = (\L_7|Mux5~3_combout\ & \L_13|Yout[15]~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \L_7|Mux5~3_combout\,
	datad => \L_13|Yout[15]~0_combout\,
	combout => \L_13|Yout[10]~11_combout\);

-- Location: LCCOMB_X76_Y13_N8
\L_61|I1[11]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_61|I1\(11) = (GLOBAL(\A3S3~inputclkctrl_outclk\) & ((\L_61|I1\(11)))) # (!GLOBAL(\A3S3~inputclkctrl_outclk\) & (\L_59|O[11]~22_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_59|O[11]~22_combout\,
	datac => \L_61|I1\(11),
	datad => \A3S3~inputclkctrl_outclk\,
	combout => \L_61|I1\(11));

-- Location: LCCOMB_X76_Y13_N20
\L_41|Yout[11]~12\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_41|Yout[11]~12_combout\ = (\L_41|Yout[15]~0_combout\ & \L_7|Mux4~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_41|Yout[15]~0_combout\,
	datad => \L_7|Mux4~3_combout\,
	combout => \L_41|Yout[11]~12_combout\);

-- Location: LCCOMB_X75_Y16_N2
\L_43|Yout[10]~11\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_43|Yout[10]~11_combout\ = (\L_43|Yout[15]~0_combout\ & \L_7|Mux5~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_43|Yout[15]~0_combout\,
	datac => \L_7|Mux5~3_combout\,
	combout => \L_43|Yout[10]~11_combout\);

-- Location: LCCOMB_X75_Y17_N28
\L_43|Yout[9]~10\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_43|Yout[9]~10_combout\ = (\L_43|Yout[15]~0_combout\ & \L_7|Mux6~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_43|Yout[15]~0_combout\,
	datad => \L_7|Mux6~3_combout\,
	combout => \L_43|Yout[9]~10_combout\);

-- Location: LCCOMB_X76_Y17_N18
\L_45|O[9]~18\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_45|O[9]~18_combout\ = (\L_41|Yout[9]~10_combout\ & ((\L_43|Yout[9]~10_combout\ & (\L_45|O[8]~17\ & VCC)) # (!\L_43|Yout[9]~10_combout\ & (!\L_45|O[8]~17\)))) # (!\L_41|Yout[9]~10_combout\ & ((\L_43|Yout[9]~10_combout\ & (!\L_45|O[8]~17\)) # 
-- (!\L_43|Yout[9]~10_combout\ & ((\L_45|O[8]~17\) # (GND)))))
-- \L_45|O[9]~19\ = CARRY((\L_41|Yout[9]~10_combout\ & (!\L_43|Yout[9]~10_combout\ & !\L_45|O[8]~17\)) # (!\L_41|Yout[9]~10_combout\ & ((!\L_45|O[8]~17\) # (!\L_43|Yout[9]~10_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011000010111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_41|Yout[9]~10_combout\,
	datab => \L_43|Yout[9]~10_combout\,
	datad => VCC,
	cin => \L_45|O[8]~17\,
	combout => \L_45|O[9]~18_combout\,
	cout => \L_45|O[9]~19\);

-- Location: LCCOMB_X76_Y17_N20
\L_45|O[10]~20\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_45|O[10]~20_combout\ = ((\L_41|Yout[10]~11_combout\ $ (\L_43|Yout[10]~11_combout\ $ (!\L_45|O[9]~19\)))) # (GND)
-- \L_45|O[10]~21\ = CARRY((\L_41|Yout[10]~11_combout\ & ((\L_43|Yout[10]~11_combout\) # (!\L_45|O[9]~19\))) # (!\L_41|Yout[10]~11_combout\ & (\L_43|Yout[10]~11_combout\ & !\L_45|O[9]~19\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100110001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_41|Yout[10]~11_combout\,
	datab => \L_43|Yout[10]~11_combout\,
	datad => VCC,
	cin => \L_45|O[9]~19\,
	combout => \L_45|O[10]~20_combout\,
	cout => \L_45|O[10]~21\);

-- Location: LCCOMB_X76_Y17_N22
\L_45|O[11]~22\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_45|O[11]~22_combout\ = (\L_43|Yout[11]~12_combout\ & ((\L_41|Yout[11]~12_combout\ & (\L_45|O[10]~21\ & VCC)) # (!\L_41|Yout[11]~12_combout\ & (!\L_45|O[10]~21\)))) # (!\L_43|Yout[11]~12_combout\ & ((\L_41|Yout[11]~12_combout\ & (!\L_45|O[10]~21\)) # 
-- (!\L_41|Yout[11]~12_combout\ & ((\L_45|O[10]~21\) # (GND)))))
-- \L_45|O[11]~23\ = CARRY((\L_43|Yout[11]~12_combout\ & (!\L_41|Yout[11]~12_combout\ & !\L_45|O[10]~21\)) # (!\L_43|Yout[11]~12_combout\ & ((!\L_45|O[10]~21\) # (!\L_41|Yout[11]~12_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011000010111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_43|Yout[11]~12_combout\,
	datab => \L_41|Yout[11]~12_combout\,
	datad => VCC,
	cin => \L_45|O[10]~21\,
	combout => \L_45|O[11]~22_combout\,
	cout => \L_45|O[11]~23\);

-- Location: LCCOMB_X76_Y13_N10
\L_47|I0[11]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_47|I0\(11) = (GLOBAL(\A1S3~inputclkctrl_outclk\) & ((\L_45|O[11]~22_combout\))) # (!GLOBAL(\A1S3~inputclkctrl_outclk\) & (\L_47|I0\(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_47|I0\(11),
	datac => \L_45|O[11]~22_combout\,
	datad => \A1S3~inputclkctrl_outclk\,
	combout => \L_47|I0\(11));

-- Location: LCCOMB_X76_Y13_N14
\L_7|Mux4~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux4~0_combout\ = (\RMS1[0]~input_o\ & (((\RMS1[1]~input_o\)))) # (!\RMS1[0]~input_o\ & ((\RMS1[1]~input_o\ & ((\L_47|I0\(11)))) # (!\RMS1[1]~input_o\ & (\v0[11]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001011000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v0[11]~input_o\,
	datab => \RMS1[0]~input_o\,
	datac => \RMS1[1]~input_o\,
	datad => \L_47|I0\(11),
	combout => \L_7|Mux4~0_combout\);

-- Location: LCCOMB_X75_Y13_N18
\L_13|Yout[13]~14\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_13|Yout[13]~14_combout\ = (\L_13|Yout[15]~0_combout\ & \L_7|Mux2~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_13|Yout[15]~0_combout\,
	datad => \L_7|Mux2~3_combout\,
	combout => \L_13|Yout[13]~14_combout\);

-- Location: LCCOMB_X75_Y7_N2
\L_6|I2[11]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I2\(11) = (GLOBAL(\L_6|Equal0~1clkctrl_outclk\) & (\TM7|I0\(11))) # (!GLOBAL(\L_6|Equal0~1clkctrl_outclk\) & ((\L_6|I2\(11))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM7|I0\(11),
	datab => \L_6|I2\(11),
	datad => \L_6|Equal0~1clkctrl_outclk\,
	combout => \L_6|I2\(11));

-- Location: LCCOMB_X75_Y7_N22
\L_50|Yout[11]~22\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_50|Yout[11]~22_combout\ = (\L_6|I2\(11)) # ((\TM8|Equal3~0_combout\ & \TM7|I1\(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM8|Equal3~0_combout\,
	datac => \TM7|I1\(11),
	datad => \L_6|I2\(11),
	combout => \L_50|Yout[11]~22_combout\);

-- Location: LCCOMB_X75_Y7_N12
\L_12|I1[11]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I1\(11) = (GLOBAL(\L_12|Equal0~1clkctrl_outclk\) & (\L_10|Yout[11]~23_combout\)) # (!GLOBAL(\L_12|Equal0~1clkctrl_outclk\) & ((\L_12|I1\(11))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_10|Yout[11]~23_combout\,
	datac => \L_12|Equal0~1clkctrl_outclk\,
	datad => \L_12|I1\(11),
	combout => \L_12|I1\(11));

-- Location: LCCOMB_X75_Y7_N28
\L_48|Yout[11]~11\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_48|Yout[11]~11_combout\ = (\A2S1~input_o\ & ((\L_12|I1\(11)))) # (!\A2S1~input_o\ & (\L_50|Yout[11]~22_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \A2S1~input_o\,
	datac => \L_50|Yout[11]~22_combout\,
	datad => \L_12|I1\(11),
	combout => \L_48|Yout[11]~11_combout\);

-- Location: LCCOMB_X76_Y7_N18
\L_52|O[9]~18\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_52|O[9]~18_combout\ = (\L_50|Yout[9]~19_combout\ & ((\L_48|Yout[9]~9_combout\ & (\L_52|O[8]~17\ & VCC)) # (!\L_48|Yout[9]~9_combout\ & (!\L_52|O[8]~17\)))) # (!\L_50|Yout[9]~19_combout\ & ((\L_48|Yout[9]~9_combout\ & (!\L_52|O[8]~17\)) # 
-- (!\L_48|Yout[9]~9_combout\ & ((\L_52|O[8]~17\) # (GND)))))
-- \L_52|O[9]~19\ = CARRY((\L_50|Yout[9]~19_combout\ & (!\L_48|Yout[9]~9_combout\ & !\L_52|O[8]~17\)) # (!\L_50|Yout[9]~19_combout\ & ((!\L_52|O[8]~17\) # (!\L_48|Yout[9]~9_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011000010111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_50|Yout[9]~19_combout\,
	datab => \L_48|Yout[9]~9_combout\,
	datad => VCC,
	cin => \L_52|O[8]~17\,
	combout => \L_52|O[9]~18_combout\,
	cout => \L_52|O[9]~19\);

-- Location: LCCOMB_X76_Y7_N20
\L_52|O[10]~20\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_52|O[10]~20_combout\ = ((\L_48|Yout[10]~10_combout\ $ (\L_50|Yout[10]~21_combout\ $ (!\L_52|O[9]~19\)))) # (GND)
-- \L_52|O[10]~21\ = CARRY((\L_48|Yout[10]~10_combout\ & ((\L_50|Yout[10]~21_combout\) # (!\L_52|O[9]~19\))) # (!\L_48|Yout[10]~10_combout\ & (\L_50|Yout[10]~21_combout\ & !\L_52|O[9]~19\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100110001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_48|Yout[10]~10_combout\,
	datab => \L_50|Yout[10]~21_combout\,
	datad => VCC,
	cin => \L_52|O[9]~19\,
	combout => \L_52|O[10]~20_combout\,
	cout => \L_52|O[10]~21\);

-- Location: LCCOMB_X76_Y7_N22
\L_52|O[11]~22\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_52|O[11]~22_combout\ = (\L_50|Yout[11]~23_combout\ & ((\L_48|Yout[11]~11_combout\ & (\L_52|O[10]~21\ & VCC)) # (!\L_48|Yout[11]~11_combout\ & (!\L_52|O[10]~21\)))) # (!\L_50|Yout[11]~23_combout\ & ((\L_48|Yout[11]~11_combout\ & (!\L_52|O[10]~21\)) # 
-- (!\L_48|Yout[11]~11_combout\ & ((\L_52|O[10]~21\) # (GND)))))
-- \L_52|O[11]~23\ = CARRY((\L_50|Yout[11]~23_combout\ & (!\L_48|Yout[11]~11_combout\ & !\L_52|O[10]~21\)) # (!\L_50|Yout[11]~23_combout\ & ((!\L_52|O[10]~21\) # (!\L_48|Yout[11]~11_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011000010111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_50|Yout[11]~23_combout\,
	datab => \L_48|Yout[11]~11_combout\,
	datad => VCC,
	cin => \L_52|O[10]~21\,
	combout => \L_52|O[11]~22_combout\,
	cout => \L_52|O[11]~23\);

-- Location: LCCOMB_X75_Y9_N4
\L_54|I1[11]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_54|I1\(11) = (GLOBAL(\A2S3~inputclkctrl_outclk\) & (\L_54|I1\(11))) # (!GLOBAL(\A2S3~inputclkctrl_outclk\) & ((\L_52|O[11]~22_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_54|I1\(11),
	datac => \A2S3~inputclkctrl_outclk\,
	datad => \L_52|O[11]~22_combout\,
	combout => \L_54|I1\(11));

-- Location: LCCOMB_X73_Y12_N4
\L_33|I1[11]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_33|I1\(11) = (GLOBAL(\M3S3~inputclkctrl_outclk\) & (\L_33|I1\(11))) # (!GLOBAL(\M3S3~inputclkctrl_outclk\) & ((\L_31|Mult0|auto_generated|mac_out2~DATAOUT11\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_33|I1\(11),
	datac => \L_31|Mult0|auto_generated|mac_out2~DATAOUT11\,
	datad => \M3S3~inputclkctrl_outclk\,
	combout => \L_33|I1\(11));

-- Location: IOIBUF_X57_Y91_N8
\A2S2~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_A2S2,
	o => \A2S2~input_o\);

-- Location: LCCOMB_X77_Y7_N18
\L_12|I1[12]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I1\(12) = (GLOBAL(\L_12|Equal0~1clkctrl_outclk\) & (\L_10|Yout[12]~25_combout\)) # (!GLOBAL(\L_12|Equal0~1clkctrl_outclk\) & ((\L_12|I1\(12))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_10|Yout[12]~25_combout\,
	datac => \L_12|Equal0~1clkctrl_outclk\,
	datad => \L_12|I1\(12),
	combout => \L_12|I1\(12));

-- Location: LCCOMB_X78_Y7_N20
\L_6|I2[12]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I2\(12) = (GLOBAL(\L_6|Equal0~1clkctrl_outclk\) & ((\TM7|I0\(12)))) # (!GLOBAL(\L_6|Equal0~1clkctrl_outclk\) & (\L_6|I2\(12)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_6|I2\(12),
	datac => \TM7|I0\(12),
	datad => \L_6|Equal0~1clkctrl_outclk\,
	combout => \L_6|I2\(12));

-- Location: LCCOMB_X77_Y13_N8
\L_57|Yout[12]~24\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_57|Yout[12]~24_combout\ = (\L_3|I1\(12) & ((\TTS~input_o\) # ((\TM7|I1\(12) & \L_55|Yout[0]~0_combout\)))) # (!\L_3|I1\(12) & (\TM7|I1\(12) & ((\L_55|Yout[0]~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_3|I1\(12),
	datab => \TM7|I1\(12),
	datac => \TTS~input_o\,
	datad => \L_55|Yout[0]~0_combout\,
	combout => \L_57|Yout[12]~24_combout\);

-- Location: IOIBUF_X48_Y0_N8
\v1[12]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v1(12),
	o => \v1[12]~input_o\);

-- Location: LCCOMB_X77_Y9_N14
\L_54|I0[12]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_54|I0\(12) = (GLOBAL(\A2S3~inputclkctrl_outclk\) & ((\L_52|O[12]~24_combout\))) # (!GLOBAL(\A2S3~inputclkctrl_outclk\) & (\L_54|I0\(12)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_54|I0\(12),
	datac => \L_52|O[12]~24_combout\,
	datad => \A2S3~inputclkctrl_outclk\,
	combout => \L_54|I0\(12));

-- Location: LCCOMB_X77_Y6_N30
\L_12|I2[12]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I2\(12) = (GLOBAL(\L_12|Equal0~2clkctrl_outclk\) & (\L_10|Yout[12]~25_combout\)) # (!GLOBAL(\L_12|Equal0~2clkctrl_outclk\) & ((\L_12|I2\(12))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_10|Yout[12]~25_combout\,
	datac => \L_12|I2\(12),
	datad => \L_12|Equal0~2clkctrl_outclk\,
	combout => \L_12|I2\(12));

-- Location: LCCOMB_X77_Y6_N0
\L_12|I0[12]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I0\(12) = (GLOBAL(\L_12|I0[15]~0clkctrl_outclk\) & ((\L_12|I0\(12)))) # (!GLOBAL(\L_12|I0[15]~0clkctrl_outclk\) & (\L_10|Yout[12]~25_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_10|Yout[12]~25_combout\,
	datac => \L_12|I0[15]~0clkctrl_outclk\,
	datad => \L_12|I0\(12),
	combout => \L_12|I0\(12));

-- Location: LCCOMB_X77_Y6_N22
\L_20|Yout[12]~12\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_20|Yout[12]~12_combout\ = (\M2S1~input_o\ & ((\L_12|I0\(12)))) # (!\M2S1~input_o\ & (\L_12|I2\(12)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M2S1~input_o\,
	datac => \L_12|I2\(12),
	datad => \L_12|I0\(12),
	combout => \L_20|Yout[12]~12_combout\);

-- Location: LCCOMB_X77_Y5_N0
\L_54|I1[13]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_54|I1\(13) = (GLOBAL(\A2S3~inputclkctrl_outclk\) & (\L_54|I1\(13))) # (!GLOBAL(\A2S3~inputclkctrl_outclk\) & ((\L_52|O[13]~26_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \A2S3~inputclkctrl_outclk\,
	datac => \L_54|I1\(13),
	datad => \L_52|O[13]~26_combout\,
	combout => \L_54|I1\(13));

-- Location: LCCOMB_X73_Y14_N22
\L_40|I0[14]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_40|I0\(14) = (GLOBAL(\M4S3~inputclkctrl_outclk\) & ((\L_38|Mult0|auto_generated|mac_out2~DATAOUT14\))) # (!GLOBAL(\M4S3~inputclkctrl_outclk\) & (\L_40|I0\(14)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \M4S3~inputclkctrl_outclk\,
	datac => \L_40|I0\(14),
	datad => \L_38|Mult0|auto_generated|mac_out2~DATAOUT14\,
	combout => \L_40|I0\(14));

-- Location: LCCOMB_X72_Y7_N8
\L_12|I1[14]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I1\(14) = (GLOBAL(\L_12|Equal0~1clkctrl_outclk\) & (\L_10|Yout[14]~29_combout\)) # (!GLOBAL(\L_12|Equal0~1clkctrl_outclk\) & ((\L_12|I1\(14))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010110010101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_10|Yout[14]~29_combout\,
	datab => \L_12|I1\(14),
	datac => \L_12|Equal0~1clkctrl_outclk\,
	combout => \L_12|I1\(14));

-- Location: LCCOMB_X79_Y10_N20
\L_3|I2[15]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I2\(15) = (GLOBAL(\L_3|Equal0~1clkctrl_outclk\) & (\TM3|I0\(15))) # (!GLOBAL(\L_3|Equal0~1clkctrl_outclk\) & ((\L_3|I2\(15))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I0\(15),
	datac => \L_3|Equal0~1clkctrl_outclk\,
	datad => \L_3|I2\(15),
	combout => \L_3|I2\(15));

-- Location: LCCOMB_X76_Y11_N6
\TM3|I1[15]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM3|I1\(15) = (GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM3|I1\(15)))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM2|Yout[15]~48_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM2|Yout[15]~48_combout\,
	datac => \TM3|I1\(15),
	datad => \TTS~inputclkctrl_outclk\,
	combout => \TM3|I1\(15));

-- Location: LCCOMB_X76_Y11_N30
\TM4|I0[15]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM4|I0\(15) = (GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & ((\TM3|I1\(15)))) # (!GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & (\TM4|I0\(15)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \BTPD_S2~inputclkctrl_outclk\,
	datac => \TM4|I0\(15),
	datad => \TM3|I1\(15),
	combout => \TM4|I0\(15));

-- Location: LCCOMB_X79_Y10_N18
\L_3|I0[15]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I0\(15) = (GLOBAL(\L_3|I0[15]~0clkctrl_outclk\) & ((\L_3|I0\(15)))) # (!GLOBAL(\L_3|I0[15]~0clkctrl_outclk\) & (\TM3|I0\(15)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I0\(15),
	datab => \L_3|I0\(15),
	datad => \L_3|I0[15]~0clkctrl_outclk\,
	combout => \L_3|I0\(15));

-- Location: LCCOMB_X79_Y10_N6
\L_27|Yout[15]~15\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_27|Yout[15]~15_combout\ = (\M3S1~input_o\ & (((\TM4|I0\(15)) # (\L_3|I0\(15))))) # (!\M3S1~input_o\ & (\L_3|I2\(15)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111011100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M3S1~input_o\,
	datab => \L_3|I2\(15),
	datac => \TM4|I0\(15),
	datad => \L_3|I0\(15),
	combout => \L_27|Yout[15]~15_combout\);

-- Location: IOIBUF_X117_Y8_N1
\v2[0]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v2(0),
	o => \v2[0]~input_o\);

-- Location: IOIBUF_X104_Y0_N8
\v3[13]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v3(13),
	o => \v3[13]~input_o\);

-- Location: LCCOMB_X76_Y6_N10
\L_33|I0[13]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_33|I0\(13) = (GLOBAL(\M3S3~inputclkctrl_outclk\) & ((\L_31|Mult0|auto_generated|mac_out2~DATAOUT13\))) # (!GLOBAL(\M3S3~inputclkctrl_outclk\) & (\L_33|I0\(13)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_33|I0\(13),
	datac => \M3S3~inputclkctrl_outclk\,
	datad => \L_31|Mult0|auto_generated|mac_out2~DATAOUT13\,
	combout => \L_33|I0\(13));

-- Location: LCCOMB_X76_Y6_N28
\TM6|Yout[13]~92\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[13]~92_combout\ = (\YMS1[0]~input_o\ & (\YMS1[1]~input_o\)) # (!\YMS1[0]~input_o\ & ((\YMS1[1]~input_o\ & ((\L_33|I0\(13)))) # (!\YMS1[1]~input_o\ & (\L_54|I1\(13)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110010011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YMS1[0]~input_o\,
	datab => \YMS1[1]~input_o\,
	datac => \L_54|I1\(13),
	datad => \L_33|I0\(13),
	combout => \TM6|Yout[13]~92_combout\);

-- Location: LCCOMB_X76_Y6_N18
\TM6|Yout[13]~93\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[13]~93_combout\ = (\YMS1[0]~input_o\ & ((\TM6|Yout[13]~92_combout\ & (\v3[13]~input_o\)) # (!\TM6|Yout[13]~92_combout\ & ((\L_33|I1\(13)))))) # (!\YMS1[0]~input_o\ & (((\TM6|Yout[13]~92_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YMS1[0]~input_o\,
	datab => \v3[13]~input_o\,
	datac => \L_33|I1\(13),
	datad => \TM6|Yout[13]~92_combout\,
	combout => \TM6|Yout[13]~93_combout\);

-- Location: LCCOMB_X76_Y6_N22
\TM7|I0[13]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM7|I0\(13) = (GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM6|Yout[13]~93_combout\))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM7|I0\(13)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM7|I0\(13),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM6|Yout[13]~93_combout\,
	combout => \TM7|I0\(13));

-- Location: LCCOMB_X75_Y14_N10
\L_6|I0[13]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I0\(13) = (GLOBAL(\L_6|I0[15]~0clkctrl_outclk\) & (\L_6|I0\(13))) # (!GLOBAL(\L_6|I0[15]~0clkctrl_outclk\) & ((\TM7|I0\(13))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_6|I0\(13),
	datab => \TM7|I0\(13),
	datad => \L_6|I0[15]~0clkctrl_outclk\,
	combout => \L_6|I0\(13));

-- Location: LCCOMB_X75_Y13_N8
\L_36|Yout[13]~13\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_36|Yout[13]~13_combout\ = (\L_6|I0\(13)) # ((\TM8|Equal0~0_combout\ & \TM7|I1\(13)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM8|Equal0~0_combout\,
	datac => \L_6|I0\(13),
	datad => \TM7|I1\(13),
	combout => \L_36|Yout[13]~13_combout\);

-- Location: LCCOMB_X75_Y13_N6
\L_34|Yout[13]~14\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_34|Yout[13]~14_combout\ = (\M4S1~input_o\ & ((\L_36|Yout[13]~13_combout\) # ((\L_34|Yout[0]~0_combout\ & \L_7|Mux2~3_combout\)))) # (!\M4S1~input_o\ & (\L_34|Yout[0]~0_combout\ & ((\L_7|Mux2~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M4S1~input_o\,
	datab => \L_34|Yout[0]~0_combout\,
	datac => \L_36|Yout[13]~13_combout\,
	datad => \L_7|Mux2~3_combout\,
	combout => \L_34|Yout[13]~14_combout\);

-- Location: LCCOMB_X73_Y15_N14
\L_6|I0[14]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I0\(14) = (GLOBAL(\L_6|I0[15]~0clkctrl_outclk\) & ((\L_6|I0\(14)))) # (!GLOBAL(\L_6|I0[15]~0clkctrl_outclk\) & (\TM7|I0\(14)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM7|I0\(14),
	datac => \L_6|I0\(14),
	datad => \L_6|I0[15]~0clkctrl_outclk\,
	combout => \L_6|I0\(14));

-- Location: LCCOMB_X73_Y15_N6
\L_36|Yout[14]~14\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_36|Yout[14]~14_combout\ = (\L_6|I0\(14)) # ((\TM8|Equal0~0_combout\ & \TM7|I1\(14)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM8|Equal0~0_combout\,
	datac => \L_6|I0\(14),
	datad => \TM7|I1\(14),
	combout => \L_36|Yout[14]~14_combout\);

-- Location: LCCOMB_X73_Y16_N8
\L_34|Yout[14]~15\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_34|Yout[14]~15_combout\ = (\L_34|Yout[0]~0_combout\ & ((\L_7|Mux1~3_combout\) # ((\M4S1~input_o\ & \L_36|Yout[14]~14_combout\)))) # (!\L_34|Yout[0]~0_combout\ & (\M4S1~input_o\ & ((\L_36|Yout[14]~14_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_34|Yout[0]~0_combout\,
	datab => \M4S1~input_o\,
	datac => \L_7|Mux1~3_combout\,
	datad => \L_36|Yout[14]~14_combout\,
	combout => \L_34|Yout[14]~15_combout\);

-- Location: IOIBUF_X95_Y0_N8
\v3[15]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v3(15),
	o => \v3[15]~input_o\);

-- Location: LCCOMB_X78_Y10_N24
\TM3|I1[1]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM3|I1\(1) = (GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM3|I1\(1)))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM2|Yout[1]~34_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM2|Yout[1]~34_combout\,
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM3|I1\(1),
	combout => \TM3|I1\(1));

-- Location: LCCOMB_X78_Y10_N8
\TM4|I0[1]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM4|I0\(1) = (GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & ((\TM3|I1\(1)))) # (!GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & (\TM4|I0\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM4|I0\(1),
	datac => \BTPD_S2~inputclkctrl_outclk\,
	datad => \TM3|I1\(1),
	combout => \TM4|I0\(1));

-- Location: LCCOMB_X71_Y10_N6
\L_29|Yout[1]~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_29|Yout[1]~1_combout\ = (\M3S2~input_o\ & ((\L_3|I0\(1)) # ((\TM4|I0\(1))))) # (!\M3S2~input_o\ & (((\L_3|I2\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M3S2~input_o\,
	datab => \L_3|I0\(1),
	datac => \L_3|I2\(1),
	datad => \TM4|I0\(1),
	combout => \L_29|Yout[1]~1_combout\);

-- Location: IOIBUF_X68_Y0_N8
\M3S2~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_M3S2,
	o => \M3S2~input_o\);

-- Location: LCCOMB_X70_Y10_N14
\L_29|Yout[2]~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_29|Yout[2]~2_combout\ = (\M3S2~input_o\ & ((\L_3|I0\(2)) # ((\TM4|I0\(2))))) # (!\M3S2~input_o\ & (((\L_3|I2\(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110010111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_3|I0\(2),
	datab => \M3S2~input_o\,
	datac => \L_3|I2\(2),
	datad => \TM4|I0\(2),
	combout => \L_29|Yout[2]~2_combout\);

-- Location: LCCOMB_X70_Y10_N24
\L_29|Yout[3]~3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_29|Yout[3]~3_combout\ = (\M3S2~input_o\ & (((\L_3|I0\(3)) # (\TM4|I0\(3))))) # (!\M3S2~input_o\ & (\L_3|I2\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111011100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_3|I2\(3),
	datab => \M3S2~input_o\,
	datac => \L_3|I0\(3),
	datad => \TM4|I0\(3),
	combout => \L_29|Yout[3]~3_combout\);

-- Location: LCCOMB_X72_Y10_N24
\L_3|I0[4]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I0\(4) = (GLOBAL(\L_3|I0[15]~0clkctrl_outclk\) & (\L_3|I0\(4))) # (!GLOBAL(\L_3|I0[15]~0clkctrl_outclk\) & ((\TM3|I0\(4))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_3|I0\(4),
	datac => \TM3|I0\(4),
	datad => \L_3|I0[15]~0clkctrl_outclk\,
	combout => \L_3|I0\(4));

-- Location: LCCOMB_X72_Y10_N10
\L_29|Yout[4]~4\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_29|Yout[4]~4_combout\ = (\M3S2~input_o\ & ((\TM4|I0\(4)) # ((\L_3|I0\(4))))) # (!\M3S2~input_o\ & (((\L_3|I2\(4)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110010111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM4|I0\(4),
	datab => \M3S2~input_o\,
	datac => \L_3|I2\(4),
	datad => \L_3|I0\(4),
	combout => \L_29|Yout[4]~4_combout\);

-- Location: IOIBUF_X117_Y10_N1
\v2[5]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v2(5),
	o => \v2[5]~input_o\);

-- Location: LCCOMB_X78_Y12_N18
\L_33|I0[5]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_33|I0\(5) = (GLOBAL(\M3S3~inputclkctrl_outclk\) & ((\L_31|Mult0|auto_generated|mac_out2~DATAOUT5\))) # (!GLOBAL(\M3S3~inputclkctrl_outclk\) & (\L_33|I0\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_33|I0\(5),
	datac => \L_31|Mult0|auto_generated|mac_out2~DATAOUT5\,
	datad => \M3S3~inputclkctrl_outclk\,
	combout => \L_33|I0\(5));

-- Location: LCCOMB_X78_Y10_N4
\TM2|Yout[5]~38\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[5]~38_combout\ = (\BTPM_S1~input_o\ & (\v2[5]~input_o\)) # (!\BTPM_S1~input_o\ & ((\L_33|I0\(5))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101100011011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \BTPM_S1~input_o\,
	datab => \v2[5]~input_o\,
	datac => \L_33|I0\(5),
	combout => \TM2|Yout[5]~38_combout\);

-- Location: LCCOMB_X78_Y10_N6
\TM3|I1[5]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM3|I1\(5) = (GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM3|I1\(5))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM2|Yout[5]~38_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I1\(5),
	datac => \TM2|Yout[5]~38_combout\,
	datad => \TTS~inputclkctrl_outclk\,
	combout => \TM3|I1\(5));

-- Location: LCCOMB_X78_Y10_N26
\TM4|I0[5]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM4|I0\(5) = (GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & ((\TM3|I1\(5)))) # (!GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & (\TM4|I0\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM4|I0\(5),
	datac => \BTPD_S2~inputclkctrl_outclk\,
	datad => \TM3|I1\(5),
	combout => \TM4|I0\(5));

-- Location: LCCOMB_X71_Y10_N12
\L_29|Yout[5]~5\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_29|Yout[5]~5_combout\ = (\M3S2~input_o\ & (((\L_3|I0\(5)) # (\TM4|I0\(5))))) # (!\M3S2~input_o\ & (\L_3|I2\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111011100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_3|I2\(5),
	datab => \M3S2~input_o\,
	datac => \L_3|I0\(5),
	datad => \TM4|I0\(5),
	combout => \L_29|Yout[5]~5_combout\);

-- Location: IOIBUF_X61_Y0_N1
\v2[6]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v2(6),
	o => \v2[6]~input_o\);

-- Location: LCCOMB_X72_Y15_N22
\L_40|I0[6]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_40|I0\(6) = (GLOBAL(\M4S3~inputclkctrl_outclk\) & ((\L_38|Mult0|auto_generated|mac_out2~DATAOUT6\))) # (!GLOBAL(\M4S3~inputclkctrl_outclk\) & (\L_40|I0\(6)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_40|I0\(6),
	datac => \L_38|Mult0|auto_generated|mac_out2~DATAOUT6\,
	datad => \M4S3~inputclkctrl_outclk\,
	combout => \L_40|I0\(6));

-- Location: LCCOMB_X72_Y15_N12
\TM2|Yout[6]~13\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[6]~13_combout\ = (\BMS1[1]~input_o\ & (!\BMS1[0]~input_o\)) # (!\BMS1[1]~input_o\ & ((\L_61|I0\(6))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011111100001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \BMS1[1]~input_o\,
	datac => \BMS1[0]~input_o\,
	datad => \L_61|I0\(6),
	combout => \TM2|Yout[6]~13_combout\);

-- Location: LCCOMB_X72_Y15_N10
\TM2|Yout[6]~14\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[6]~14_combout\ = (\BMS1[1]~input_o\ & ((\TM2|Yout[6]~13_combout\ & ((\L_40|I0\(6)))) # (!\TM2|Yout[6]~13_combout\ & (\v2[6]~input_o\)))) # (!\BMS1[1]~input_o\ & (((\TM2|Yout[6]~13_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \BMS1[1]~input_o\,
	datab => \v2[6]~input_o\,
	datac => \L_40|I0\(6),
	datad => \TM2|Yout[6]~13_combout\,
	combout => \TM2|Yout[6]~14_combout\);

-- Location: LCCOMB_X72_Y15_N24
\TM3|I0[6]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM3|I0\(6) = (GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM2|Yout[6]~14_combout\))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM3|I0\(6)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM3|I0\(6),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM2|Yout[6]~14_combout\,
	combout => \TM3|I0\(6));

-- Location: LCCOMB_X72_Y10_N2
\L_3|I0[6]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I0\(6) = (GLOBAL(\L_3|I0[15]~0clkctrl_outclk\) & ((\L_3|I0\(6)))) # (!GLOBAL(\L_3|I0[15]~0clkctrl_outclk\) & (\TM3|I0\(6)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM3|I0\(6),
	datac => \L_3|I0\(6),
	datad => \L_3|I0[15]~0clkctrl_outclk\,
	combout => \L_3|I0\(6));

-- Location: LCCOMB_X72_Y10_N20
\L_29|Yout[6]~6\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_29|Yout[6]~6_combout\ = (\M3S2~input_o\ & ((\TM4|I0\(6)) # ((\L_3|I0\(6))))) # (!\M3S2~input_o\ & (((\L_3|I2\(6)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M3S2~input_o\,
	datab => \TM4|I0\(6),
	datac => \L_3|I2\(6),
	datad => \L_3|I0\(6),
	combout => \L_29|Yout[6]~6_combout\);

-- Location: LCCOMB_X70_Y10_N16
\L_3|I0[7]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I0\(7) = (GLOBAL(\L_3|I0[15]~0clkctrl_outclk\) & ((\L_3|I0\(7)))) # (!GLOBAL(\L_3|I0[15]~0clkctrl_outclk\) & (\TM3|I0\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I0\(7),
	datab => \L_3|I0\(7),
	datac => \L_3|I0[15]~0clkctrl_outclk\,
	combout => \L_3|I0\(7));

-- Location: LCCOMB_X70_Y10_N10
\L_29|Yout[7]~7\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_29|Yout[7]~7_combout\ = (\M3S2~input_o\ & (((\TM4|I0\(7)) # (\L_3|I0\(7))))) # (!\M3S2~input_o\ & (\L_3|I2\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111011100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_3|I2\(7),
	datab => \M3S2~input_o\,
	datac => \TM4|I0\(7),
	datad => \L_3|I0\(7),
	combout => \L_29|Yout[7]~7_combout\);

-- Location: LCCOMB_X79_Y10_N22
\L_3|I0[8]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I0\(8) = (GLOBAL(\L_3|I0[15]~0clkctrl_outclk\) & ((\L_3|I0\(8)))) # (!GLOBAL(\L_3|I0[15]~0clkctrl_outclk\) & (\TM3|I0\(8)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM3|I0\(8),
	datac => \L_3|I0\(8),
	datad => \L_3|I0[15]~0clkctrl_outclk\,
	combout => \L_3|I0\(8));

-- Location: LCCOMB_X75_Y11_N20
\TM2|Yout[8]~41\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[8]~41_combout\ = (\BTPM_S1~input_o\ & (\v2[8]~input_o\)) # (!\BTPM_S1~input_o\ & ((\L_33|I0\(8))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011100010111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v2[8]~input_o\,
	datab => \BTPM_S1~input_o\,
	datac => \L_33|I0\(8),
	combout => \TM2|Yout[8]~41_combout\);

-- Location: LCCOMB_X75_Y11_N6
\TM3|I1[8]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM3|I1\(8) = (GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM3|I1\(8))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM2|Yout[8]~41_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TTS~inputclkctrl_outclk\,
	datac => \TM3|I1\(8),
	datad => \TM2|Yout[8]~41_combout\,
	combout => \TM3|I1\(8));

-- Location: LCCOMB_X75_Y11_N30
\TM4|I0[8]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM4|I0\(8) = (GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & ((\TM3|I1\(8)))) # (!GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & (\TM4|I0\(8)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM4|I0\(8),
	datac => \BTPD_S2~inputclkctrl_outclk\,
	datad => \TM3|I1\(8),
	combout => \TM4|I0\(8));

-- Location: LCCOMB_X79_Y10_N8
\L_29|Yout[8]~8\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_29|Yout[8]~8_combout\ = (\M3S2~input_o\ & (((\L_3|I0\(8)) # (\TM4|I0\(8))))) # (!\M3S2~input_o\ & (\L_3|I2\(8)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111011100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M3S2~input_o\,
	datab => \L_3|I2\(8),
	datac => \L_3|I0\(8),
	datad => \TM4|I0\(8),
	combout => \L_29|Yout[8]~8_combout\);

-- Location: IOIBUF_X75_Y0_N1
\M4S2~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_M4S2,
	o => \M4S2~input_o\);

-- Location: LCCOMB_X78_Y16_N24
\L_36|Yout[0]~16\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_36|Yout[0]~16_combout\ = (\RDS2[2]~input_o\ & (!\M4S2~input_o\ & (!\RDS2[1]~input_o\ & !\RDS2[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \RDS2[2]~input_o\,
	datab => \M4S2~input_o\,
	datac => \RDS2[1]~input_o\,
	datad => \RDS2[0]~input_o\,
	combout => \L_36|Yout[0]~16_combout\);

-- Location: LCCOMB_X75_Y16_N30
\L_36|Yout[0]~17\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_36|Yout[0]~17_combout\ = (\M4S2~input_o\ & ((\L_36|Yout[0]~0_combout\) # ((\L_36|Yout[0]~16_combout\ & \L_7|Mux15~5_combout\)))) # (!\M4S2~input_o\ & (\L_36|Yout[0]~16_combout\ & ((\L_7|Mux15~5_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M4S2~input_o\,
	datab => \L_36|Yout[0]~16_combout\,
	datac => \L_36|Yout[0]~0_combout\,
	datad => \L_7|Mux15~5_combout\,
	combout => \L_36|Yout[0]~17_combout\);

-- Location: LCCOMB_X78_Y15_N2
\L_36|Yout[1]~18\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_36|Yout[1]~18_combout\ = (\M4S2~input_o\ & ((\L_36|Yout[1]~1_combout\) # ((\L_36|Yout[0]~16_combout\ & \L_7|Mux14~3_combout\)))) # (!\M4S2~input_o\ & (\L_36|Yout[0]~16_combout\ & ((\L_7|Mux14~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M4S2~input_o\,
	datab => \L_36|Yout[0]~16_combout\,
	datac => \L_36|Yout[1]~1_combout\,
	datad => \L_7|Mux14~3_combout\,
	combout => \L_36|Yout[1]~18_combout\);

-- Location: LCCOMB_X73_Y15_N16
\L_36|Yout[2]~19\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_36|Yout[2]~19_combout\ = (\L_36|Yout[0]~16_combout\ & ((\L_7|Mux13~3_combout\) # ((\M4S2~input_o\ & \L_36|Yout[2]~2_combout\)))) # (!\L_36|Yout[0]~16_combout\ & (\M4S2~input_o\ & ((\L_36|Yout[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_36|Yout[0]~16_combout\,
	datab => \M4S2~input_o\,
	datac => \L_7|Mux13~3_combout\,
	datad => \L_36|Yout[2]~2_combout\,
	combout => \L_36|Yout[2]~19_combout\);

-- Location: LCCOMB_X73_Y15_N12
\L_6|I0[3]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I0\(3) = (GLOBAL(\L_6|I0[15]~0clkctrl_outclk\) & (\L_6|I0\(3))) # (!GLOBAL(\L_6|I0[15]~0clkctrl_outclk\) & ((\TM7|I0\(3))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_6|I0\(3),
	datab => \TM7|I0\(3),
	datad => \L_6|I0[15]~0clkctrl_outclk\,
	combout => \L_6|I0\(3));

-- Location: LCCOMB_X73_Y15_N24
\L_36|Yout[3]~3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_36|Yout[3]~3_combout\ = (\L_6|I0\(3)) # ((\TM8|Equal0~0_combout\ & \TM7|I1\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM8|Equal0~0_combout\,
	datac => \TM7|I1\(3),
	datad => \L_6|I0\(3),
	combout => \L_36|Yout[3]~3_combout\);

-- Location: LCCOMB_X73_Y15_N22
\L_36|Yout[3]~20\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_36|Yout[3]~20_combout\ = (\L_36|Yout[0]~16_combout\ & ((\L_7|Mux12~3_combout\) # ((\M4S2~input_o\ & \L_36|Yout[3]~3_combout\)))) # (!\L_36|Yout[0]~16_combout\ & (\M4S2~input_o\ & ((\L_36|Yout[3]~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_36|Yout[0]~16_combout\,
	datab => \M4S2~input_o\,
	datac => \L_7|Mux12~3_combout\,
	datad => \L_36|Yout[3]~3_combout\,
	combout => \L_36|Yout[3]~20_combout\);

-- Location: LCCOMB_X78_Y15_N24
\L_36|Yout[4]~21\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_36|Yout[4]~21_combout\ = (\M4S2~input_o\ & ((\L_36|Yout[4]~4_combout\) # ((\L_36|Yout[0]~16_combout\ & \L_7|Mux11~3_combout\)))) # (!\M4S2~input_o\ & (((\L_36|Yout[0]~16_combout\ & \L_7|Mux11~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M4S2~input_o\,
	datab => \L_36|Yout[4]~4_combout\,
	datac => \L_36|Yout[0]~16_combout\,
	datad => \L_7|Mux11~3_combout\,
	combout => \L_36|Yout[4]~21_combout\);

-- Location: LCCOMB_X75_Y15_N6
\L_36|Yout[5]~22\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_36|Yout[5]~22_combout\ = (\L_36|Yout[0]~16_combout\ & ((\L_7|Mux10~3_combout\) # ((\M4S2~input_o\ & \L_36|Yout[5]~5_combout\)))) # (!\L_36|Yout[0]~16_combout\ & (\M4S2~input_o\ & (\L_36|Yout[5]~5_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_36|Yout[0]~16_combout\,
	datab => \M4S2~input_o\,
	datac => \L_36|Yout[5]~5_combout\,
	datad => \L_7|Mux10~3_combout\,
	combout => \L_36|Yout[5]~22_combout\);

-- Location: LCCOMB_X75_Y14_N0
\L_36|Yout[6]~23\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_36|Yout[6]~23_combout\ = (\M4S2~input_o\ & ((\L_36|Yout[6]~6_combout\) # ((\L_36|Yout[0]~16_combout\ & \L_7|Mux9~3_combout\)))) # (!\M4S2~input_o\ & (((\L_36|Yout[0]~16_combout\ & \L_7|Mux9~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M4S2~input_o\,
	datab => \L_36|Yout[6]~6_combout\,
	datac => \L_36|Yout[0]~16_combout\,
	datad => \L_7|Mux9~3_combout\,
	combout => \L_36|Yout[6]~23_combout\);

-- Location: LCCOMB_X78_Y9_N16
\L_6|I0[7]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I0\(7) = (GLOBAL(\L_6|I0[15]~0clkctrl_outclk\) & ((\L_6|I0\(7)))) # (!GLOBAL(\L_6|I0[15]~0clkctrl_outclk\) & (\TM7|I0\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM7|I0\(7),
	datab => \L_6|I0\(7),
	datad => \L_6|I0[15]~0clkctrl_outclk\,
	combout => \L_6|I0\(7));

-- Location: LCCOMB_X78_Y9_N14
\L_36|Yout[7]~7\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_36|Yout[7]~7_combout\ = (\L_6|I0\(7)) # ((\TM8|Equal0~0_combout\ & \TM7|I1\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM8|Equal0~0_combout\,
	datac => \TM7|I1\(7),
	datad => \L_6|I0\(7),
	combout => \L_36|Yout[7]~7_combout\);

-- Location: LCCOMB_X77_Y14_N0
\L_36|Yout[7]~24\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_36|Yout[7]~24_combout\ = (\M4S2~input_o\ & ((\L_36|Yout[7]~7_combout\) # ((\L_36|Yout[0]~16_combout\ & \L_7|Mux8~3_combout\)))) # (!\M4S2~input_o\ & (\L_36|Yout[0]~16_combout\ & (\L_7|Mux8~3_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M4S2~input_o\,
	datab => \L_36|Yout[0]~16_combout\,
	datac => \L_7|Mux8~3_combout\,
	datad => \L_36|Yout[7]~7_combout\,
	combout => \L_36|Yout[7]~24_combout\);

-- Location: LCCOMB_X78_Y15_N14
\L_36|Yout[8]~25\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_36|Yout[8]~25_combout\ = (\M4S2~input_o\ & ((\L_36|Yout[8]~8_combout\) # ((\L_36|Yout[0]~16_combout\ & \L_7|Mux7~3_combout\)))) # (!\M4S2~input_o\ & (\L_36|Yout[0]~16_combout\ & (\L_7|Mux7~3_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M4S2~input_o\,
	datab => \L_36|Yout[0]~16_combout\,
	datac => \L_7|Mux7~3_combout\,
	datad => \L_36|Yout[8]~8_combout\,
	combout => \L_36|Yout[8]~25_combout\);

-- Location: LCCOMB_X73_Y9_N6
\L_6|I0[9]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I0\(9) = (GLOBAL(\L_6|I0[15]~0clkctrl_outclk\) & (\L_6|I0\(9))) # (!GLOBAL(\L_6|I0[15]~0clkctrl_outclk\) & ((\TM7|I0\(9))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_6|I0\(9),
	datab => \TM7|I0\(9),
	datad => \L_6|I0[15]~0clkctrl_outclk\,
	combout => \L_6|I0\(9));

-- Location: LCCOMB_X73_Y9_N16
\L_36|Yout[9]~9\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_36|Yout[9]~9_combout\ = (\L_6|I0\(9)) # ((\TM8|Equal0~0_combout\ & \TM7|I1\(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM8|Equal0~0_combout\,
	datac => \TM7|I1\(9),
	datad => \L_6|I0\(9),
	combout => \L_36|Yout[9]~9_combout\);

-- Location: LCCOMB_X73_Y15_N4
\L_36|Yout[9]~26\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_36|Yout[9]~26_combout\ = (\L_36|Yout[0]~16_combout\ & ((\L_7|Mux6~3_combout\) # ((\M4S2~input_o\ & \L_36|Yout[9]~9_combout\)))) # (!\L_36|Yout[0]~16_combout\ & (\M4S2~input_o\ & ((\L_36|Yout[9]~9_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_36|Yout[0]~16_combout\,
	datab => \M4S2~input_o\,
	datac => \L_7|Mux6~3_combout\,
	datad => \L_36|Yout[9]~9_combout\,
	combout => \L_36|Yout[9]~26_combout\);

-- Location: LCCOMB_X75_Y15_N22
\L_6|I0[10]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I0\(10) = (GLOBAL(\L_6|I0[15]~0clkctrl_outclk\) & (\L_6|I0\(10))) # (!GLOBAL(\L_6|I0[15]~0clkctrl_outclk\) & ((\TM7|I0\(10))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_6|I0[15]~0clkctrl_outclk\,
	datac => \L_6|I0\(10),
	datad => \TM7|I0\(10),
	combout => \L_6|I0\(10));

-- Location: LCCOMB_X75_Y15_N14
\L_36|Yout[10]~10\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_36|Yout[10]~10_combout\ = (\L_6|I0\(10)) # ((\TM8|Equal0~0_combout\ & \TM7|I1\(10)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM8|Equal0~0_combout\,
	datac => \L_6|I0\(10),
	datad => \TM7|I1\(10),
	combout => \L_36|Yout[10]~10_combout\);

-- Location: LCCOMB_X75_Y15_N16
\L_36|Yout[10]~27\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_36|Yout[10]~27_combout\ = (\M4S2~input_o\ & ((\L_36|Yout[10]~10_combout\) # ((\L_36|Yout[0]~16_combout\ & \L_7|Mux5~3_combout\)))) # (!\M4S2~input_o\ & (\L_36|Yout[0]~16_combout\ & ((\L_7|Mux5~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M4S2~input_o\,
	datab => \L_36|Yout[0]~16_combout\,
	datac => \L_36|Yout[10]~10_combout\,
	datad => \L_7|Mux5~3_combout\,
	combout => \L_36|Yout[10]~27_combout\);

-- Location: LCCOMB_X75_Y15_N30
\L_36|Yout[11]~28\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_36|Yout[11]~28_combout\ = (\L_36|Yout[0]~16_combout\ & ((\L_7|Mux4~3_combout\) # ((\L_36|Yout[11]~11_combout\ & \M4S2~input_o\)))) # (!\L_36|Yout[0]~16_combout\ & (\L_36|Yout[11]~11_combout\ & (\M4S2~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_36|Yout[0]~16_combout\,
	datab => \L_36|Yout[11]~11_combout\,
	datac => \M4S2~input_o\,
	datad => \L_7|Mux4~3_combout\,
	combout => \L_36|Yout[11]~28_combout\);

-- Location: LCCOMB_X75_Y15_N8
\L_36|Yout[12]~29\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_36|Yout[12]~29_combout\ = (\L_36|Yout[0]~16_combout\ & ((\L_7|Mux3~3_combout\) # ((\L_36|Yout[12]~12_combout\ & \M4S2~input_o\)))) # (!\L_36|Yout[0]~16_combout\ & (\L_36|Yout[12]~12_combout\ & (\M4S2~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_36|Yout[0]~16_combout\,
	datab => \L_36|Yout[12]~12_combout\,
	datac => \M4S2~input_o\,
	datad => \L_7|Mux3~3_combout\,
	combout => \L_36|Yout[12]~29_combout\);

-- Location: LCCOMB_X75_Y13_N0
\L_36|Yout[13]~30\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_36|Yout[13]~30_combout\ = (\L_36|Yout[0]~16_combout\ & ((\L_7|Mux2~3_combout\) # ((\M4S2~input_o\ & \L_36|Yout[13]~13_combout\)))) # (!\L_36|Yout[0]~16_combout\ & (\M4S2~input_o\ & (\L_36|Yout[13]~13_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_36|Yout[0]~16_combout\,
	datab => \M4S2~input_o\,
	datac => \L_36|Yout[13]~13_combout\,
	datad => \L_7|Mux2~3_combout\,
	combout => \L_36|Yout[13]~30_combout\);

-- Location: LCCOMB_X73_Y15_N2
\L_36|Yout[14]~31\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_36|Yout[14]~31_combout\ = (\L_36|Yout[0]~16_combout\ & ((\L_7|Mux1~3_combout\) # ((\M4S2~input_o\ & \L_36|Yout[14]~14_combout\)))) # (!\L_36|Yout[0]~16_combout\ & (\M4S2~input_o\ & ((\L_36|Yout[14]~14_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_36|Yout[0]~16_combout\,
	datab => \M4S2~input_o\,
	datac => \L_7|Mux1~3_combout\,
	datad => \L_36|Yout[14]~14_combout\,
	combout => \L_36|Yout[14]~31_combout\);

-- Location: LCCOMB_X75_Y19_N10
\L_13|Yout[15]~16\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_13|Yout[15]~16_combout\ = (\L_13|Yout[15]~0_combout\ & \L_7|Mux0~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \L_13|Yout[15]~0_combout\,
	datad => \L_7|Mux0~3_combout\,
	combout => \L_13|Yout[15]~16_combout\);

-- Location: LCCOMB_X78_Y16_N22
\L_15|Yout[15]~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_15|Yout[15]~0_combout\ = (!\RDS2[2]~input_o\ & (!\RDS2[0]~input_o\ & (\M1S2~input_o\ $ (\RDS2[1]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M1S2~input_o\,
	datab => \RDS2[1]~input_o\,
	datac => \RDS2[2]~input_o\,
	datad => \RDS2[0]~input_o\,
	combout => \L_15|Yout[15]~0_combout\);

-- Location: LCCOMB_X76_Y16_N12
\L_15|Yout[0]~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_15|Yout[0]~1_combout\ = (\L_15|Yout[15]~0_combout\ & \L_7|Mux15~5_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \L_15|Yout[15]~0_combout\,
	datad => \L_7|Mux15~5_combout\,
	combout => \L_15|Yout[0]~1_combout\);

-- Location: LCCOMB_X78_Y16_N4
\L_15|Yout[1]~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_15|Yout[1]~2_combout\ = (\L_15|Yout[15]~0_combout\ & \L_7|Mux14~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_15|Yout[15]~0_combout\,
	datad => \L_7|Mux14~3_combout\,
	combout => \L_15|Yout[1]~2_combout\);

-- Location: LCCOMB_X73_Y13_N26
\L_15|Yout[2]~3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_15|Yout[2]~3_combout\ = (\L_15|Yout[15]~0_combout\ & \L_7|Mux13~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_15|Yout[15]~0_combout\,
	datac => \L_7|Mux13~3_combout\,
	combout => \L_15|Yout[2]~3_combout\);

-- Location: LCCOMB_X73_Y16_N24
\L_15|Yout[3]~4\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_15|Yout[3]~4_combout\ = (\L_15|Yout[15]~0_combout\ & \L_7|Mux12~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \L_15|Yout[15]~0_combout\,
	datad => \L_7|Mux12~3_combout\,
	combout => \L_15|Yout[3]~4_combout\);

-- Location: LCCOMB_X77_Y15_N28
\L_15|Yout[4]~5\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_15|Yout[4]~5_combout\ = (\L_15|Yout[15]~0_combout\ & \L_7|Mux11~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_15|Yout[15]~0_combout\,
	datad => \L_7|Mux11~3_combout\,
	combout => \L_15|Yout[4]~5_combout\);

-- Location: LCCOMB_X75_Y14_N26
\L_15|Yout[5]~6\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_15|Yout[5]~6_combout\ = (\L_15|Yout[15]~0_combout\ & \L_7|Mux10~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_15|Yout[15]~0_combout\,
	datac => \L_7|Mux10~3_combout\,
	combout => \L_15|Yout[5]~6_combout\);

-- Location: LCCOMB_X75_Y14_N16
\L_15|Yout[6]~7\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_15|Yout[6]~7_combout\ = (\L_15|Yout[15]~0_combout\ & \L_7|Mux9~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_15|Yout[15]~0_combout\,
	datad => \L_7|Mux9~3_combout\,
	combout => \L_15|Yout[6]~7_combout\);

-- Location: LCCOMB_X77_Y14_N8
\L_15|Yout[7]~8\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_15|Yout[7]~8_combout\ = (\L_7|Mux8~3_combout\ & \L_15|Yout[15]~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \L_7|Mux8~3_combout\,
	datad => \L_15|Yout[15]~0_combout\,
	combout => \L_15|Yout[7]~8_combout\);

-- Location: LCCOMB_X77_Y15_N22
\L_15|Yout[8]~9\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_15|Yout[8]~9_combout\ = (\L_15|Yout[15]~0_combout\ & \L_7|Mux7~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_15|Yout[15]~0_combout\,
	datad => \L_7|Mux7~3_combout\,
	combout => \L_15|Yout[8]~9_combout\);

-- Location: LCCOMB_X75_Y16_N16
\L_15|Yout[9]~10\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_15|Yout[9]~10_combout\ = (\L_15|Yout[15]~0_combout\ & \L_7|Mux6~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_15|Yout[15]~0_combout\,
	datac => \L_7|Mux6~3_combout\,
	combout => \L_15|Yout[9]~10_combout\);

-- Location: LCCOMB_X75_Y16_N26
\L_15|Yout[10]~11\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_15|Yout[10]~11_combout\ = (\L_15|Yout[15]~0_combout\ & \L_7|Mux5~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_15|Yout[15]~0_combout\,
	datac => \L_7|Mux5~3_combout\,
	combout => \L_15|Yout[10]~11_combout\);

-- Location: LCCOMB_X76_Y13_N18
\L_15|Yout[11]~12\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_15|Yout[11]~12_combout\ = (\L_15|Yout[15]~0_combout\ & \L_7|Mux4~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \L_15|Yout[15]~0_combout\,
	datad => \L_7|Mux4~3_combout\,
	combout => \L_15|Yout[11]~12_combout\);

-- Location: LCCOMB_X75_Y16_N28
\L_15|Yout[12]~13\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_15|Yout[12]~13_combout\ = (\L_15|Yout[15]~0_combout\ & \L_7|Mux3~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_15|Yout[15]~0_combout\,
	datac => \L_7|Mux3~3_combout\,
	combout => \L_15|Yout[12]~13_combout\);

-- Location: LCCOMB_X75_Y13_N12
\L_15|Yout[13]~14\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_15|Yout[13]~14_combout\ = (\L_15|Yout[15]~0_combout\ & \L_7|Mux2~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_15|Yout[15]~0_combout\,
	datad => \L_7|Mux2~3_combout\,
	combout => \L_15|Yout[13]~14_combout\);

-- Location: LCCOMB_X73_Y16_N10
\L_15|Yout[14]~15\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_15|Yout[14]~15_combout\ = (\L_15|Yout[15]~0_combout\ & \L_7|Mux1~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_15|Yout[15]~0_combout\,
	datac => \L_7|Mux1~3_combout\,
	combout => \L_15|Yout[14]~15_combout\);

-- Location: LCCOMB_X75_Y19_N8
\L_15|Yout[15]~16\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_15|Yout[15]~16_combout\ = (\L_15|Yout[15]~0_combout\ & \L_7|Mux0~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_15|Yout[15]~0_combout\,
	datad => \L_7|Mux0~3_combout\,
	combout => \L_15|Yout[15]~16_combout\);

-- Location: DSPMULT_X74_Y16_N0
\L_17|Mult0|auto_generated|mac_mult1\ : cycloneiv_mac_mult
-- pragma translate_off
GENERIC MAP (
	dataa_clock => "none",
	dataa_width => 18,
	datab_clock => "none",
	datab_width => 18,
	signa_clock => "none",
	signb_clock => "none")
-- pragma translate_on
PORT MAP (
	signa => GND,
	signb => GND,
	dataa => \L_17|Mult0|auto_generated|mac_mult1_DATAA_bus\,
	datab => \L_17|Mult0|auto_generated|mac_mult1_DATAB_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	dataout => \L_17|Mult0|auto_generated|mac_mult1_DATAOUT_bus\);

-- Location: LCCOMB_X75_Y19_N2
\L_19|I0[15]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_19|I0\(15) = (GLOBAL(\M1S3~inputclkctrl_outclk\) & ((\L_17|Mult0|auto_generated|mac_out2~DATAOUT15\))) # (!GLOBAL(\M1S3~inputclkctrl_outclk\) & (\L_19|I0\(15)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_19|I0\(15),
	datac => \L_17|Mult0|auto_generated|mac_out2~DATAOUT15\,
	datad => \M1S3~inputclkctrl_outclk\,
	combout => \L_19|I0\(15));

-- Location: LCCOMB_X75_Y17_N18
\L_41|Yout[15]~16\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_41|Yout[15]~16_combout\ = (\L_41|Yout[15]~0_combout\ & \L_7|Mux0~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_41|Yout[15]~0_combout\,
	datad => \L_7|Mux0~3_combout\,
	combout => \L_41|Yout[15]~16_combout\);

-- Location: LCCOMB_X75_Y17_N12
\L_43|Yout[15]~16\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_43|Yout[15]~16_combout\ = (\L_43|Yout[15]~0_combout\ & \L_7|Mux0~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \L_43|Yout[15]~0_combout\,
	datad => \L_7|Mux0~3_combout\,
	combout => \L_43|Yout[15]~16_combout\);

-- Location: LCCOMB_X77_Y17_N14
\L_41|Yout[14]~15\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_41|Yout[14]~15_combout\ = (\L_41|Yout[15]~0_combout\ & \L_7|Mux1~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_41|Yout[15]~0_combout\,
	datad => \L_7|Mux1~3_combout\,
	combout => \L_41|Yout[14]~15_combout\);

-- Location: LCCOMB_X75_Y13_N22
\L_41|Yout[13]~14\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_41|Yout[13]~14_combout\ = (\L_41|Yout[15]~0_combout\ & \L_7|Mux2~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \L_41|Yout[15]~0_combout\,
	datad => \L_7|Mux2~3_combout\,
	combout => \L_41|Yout[13]~14_combout\);

-- Location: LCCOMB_X75_Y17_N6
\L_41|Yout[12]~13\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_41|Yout[12]~13_combout\ = (\L_7|Mux3~3_combout\ & \L_41|Yout[15]~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_7|Mux3~3_combout\,
	datad => \L_41|Yout[15]~0_combout\,
	combout => \L_41|Yout[12]~13_combout\);

-- Location: LCCOMB_X76_Y17_N24
\L_45|O[12]~24\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_45|O[12]~24_combout\ = ((\L_43|Yout[12]~13_combout\ $ (\L_41|Yout[12]~13_combout\ $ (!\L_45|O[11]~23\)))) # (GND)
-- \L_45|O[12]~25\ = CARRY((\L_43|Yout[12]~13_combout\ & ((\L_41|Yout[12]~13_combout\) # (!\L_45|O[11]~23\))) # (!\L_43|Yout[12]~13_combout\ & (\L_41|Yout[12]~13_combout\ & !\L_45|O[11]~23\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100110001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_43|Yout[12]~13_combout\,
	datab => \L_41|Yout[12]~13_combout\,
	datad => VCC,
	cin => \L_45|O[11]~23\,
	combout => \L_45|O[12]~24_combout\,
	cout => \L_45|O[12]~25\);

-- Location: LCCOMB_X76_Y17_N26
\L_45|O[13]~26\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_45|O[13]~26_combout\ = (\L_43|Yout[13]~14_combout\ & ((\L_41|Yout[13]~14_combout\ & (\L_45|O[12]~25\ & VCC)) # (!\L_41|Yout[13]~14_combout\ & (!\L_45|O[12]~25\)))) # (!\L_43|Yout[13]~14_combout\ & ((\L_41|Yout[13]~14_combout\ & (!\L_45|O[12]~25\)) # 
-- (!\L_41|Yout[13]~14_combout\ & ((\L_45|O[12]~25\) # (GND)))))
-- \L_45|O[13]~27\ = CARRY((\L_43|Yout[13]~14_combout\ & (!\L_41|Yout[13]~14_combout\ & !\L_45|O[12]~25\)) # (!\L_43|Yout[13]~14_combout\ & ((!\L_45|O[12]~25\) # (!\L_41|Yout[13]~14_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011000010111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_43|Yout[13]~14_combout\,
	datab => \L_41|Yout[13]~14_combout\,
	datad => VCC,
	cin => \L_45|O[12]~25\,
	combout => \L_45|O[13]~26_combout\,
	cout => \L_45|O[13]~27\);

-- Location: LCCOMB_X76_Y17_N28
\L_45|O[14]~28\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_45|O[14]~28_combout\ = ((\L_43|Yout[14]~15_combout\ $ (\L_41|Yout[14]~15_combout\ $ (!\L_45|O[13]~27\)))) # (GND)
-- \L_45|O[14]~29\ = CARRY((\L_43|Yout[14]~15_combout\ & ((\L_41|Yout[14]~15_combout\) # (!\L_45|O[13]~27\))) # (!\L_43|Yout[14]~15_combout\ & (\L_41|Yout[14]~15_combout\ & !\L_45|O[13]~27\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100110001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_43|Yout[14]~15_combout\,
	datab => \L_41|Yout[14]~15_combout\,
	datad => VCC,
	cin => \L_45|O[13]~27\,
	combout => \L_45|O[14]~28_combout\,
	cout => \L_45|O[14]~29\);

-- Location: LCCOMB_X76_Y17_N30
\L_45|O[15]~30\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_45|O[15]~30_combout\ = \L_41|Yout[15]~16_combout\ $ (\L_45|O[14]~29\ $ (\L_43|Yout[15]~16_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100111100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \L_41|Yout[15]~16_combout\,
	datad => \L_43|Yout[15]~16_combout\,
	cin => \L_45|O[14]~29\,
	combout => \L_45|O[15]~30_combout\);

-- Location: LCCOMB_X75_Y19_N28
\L_47|I0[15]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_47|I0\(15) = (GLOBAL(\A1S3~inputclkctrl_outclk\) & ((\L_45|O[15]~30_combout\))) # (!GLOBAL(\A1S3~inputclkctrl_outclk\) & (\L_47|I0\(15)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_47|I0\(15),
	datac => \A1S3~inputclkctrl_outclk\,
	datad => \L_45|O[15]~30_combout\,
	combout => \L_47|I0\(15));

-- Location: LCCOMB_X75_Y19_N12
\L_7|Mux0~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux0~0_combout\ = (\RMS1[0]~input_o\ & (((\RMS1[1]~input_o\)))) # (!\RMS1[0]~input_o\ & ((\RMS1[1]~input_o\ & ((\L_47|I0\(15)))) # (!\RMS1[1]~input_o\ & (\v0[15]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001011000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v0[15]~input_o\,
	datab => \RMS1[0]~input_o\,
	datac => \RMS1[1]~input_o\,
	datad => \L_47|I0\(15),
	combout => \L_7|Mux0~0_combout\);

-- Location: LCCOMB_X75_Y19_N30
\L_7|Mux0~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux0~1_combout\ = (\RMS1[0]~input_o\ & ((\L_7|Mux0~0_combout\ & (\L_19|I1\(15))) # (!\L_7|Mux0~0_combout\ & ((\L_19|I0\(15)))))) # (!\RMS1[0]~input_o\ & (((\L_7|Mux0~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_19|I1\(15),
	datab => \L_19|I0\(15),
	datac => \RMS1[0]~input_o\,
	datad => \L_7|Mux0~0_combout\,
	combout => \L_7|Mux0~1_combout\);

-- Location: LCCOMB_X75_Y19_N4
\L_47|I1[15]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_47|I1\(15) = (GLOBAL(\A1S3~inputclkctrl_outclk\) & (\L_47|I1\(15))) # (!GLOBAL(\A1S3~inputclkctrl_outclk\) & ((\L_45|O[15]~30_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_47|I1\(15),
	datac => \A1S3~inputclkctrl_outclk\,
	datad => \L_45|O[15]~30_combout\,
	combout => \L_47|I1\(15));

-- Location: DSPMULT_X74_Y15_N0
\L_38|Mult0|auto_generated|mac_mult1\ : cycloneiv_mac_mult
-- pragma translate_off
GENERIC MAP (
	dataa_clock => "none",
	dataa_width => 18,
	datab_clock => "none",
	datab_width => 18,
	signa_clock => "none",
	signb_clock => "none")
-- pragma translate_on
PORT MAP (
	signa => GND,
	signb => GND,
	dataa => \L_38|Mult0|auto_generated|mac_mult1_DATAA_bus\,
	datab => \L_38|Mult0|auto_generated|mac_mult1_DATAB_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	dataout => \L_38|Mult0|auto_generated|mac_mult1_DATAOUT_bus\);

-- Location: DSPOUT_X74_Y15_N2
\L_38|Mult0|auto_generated|mac_out2\ : cycloneiv_mac_out
-- pragma translate_off
GENERIC MAP (
	dataa_width => 36,
	output_clock => "none")
-- pragma translate_on
PORT MAP (
	dataa => \L_38|Mult0|auto_generated|mac_out2_DATAA_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	dataout => \L_38|Mult0|auto_generated|mac_out2_DATAOUT_bus\);

-- Location: LCCOMB_X75_Y15_N12
\L_40|I1[15]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_40|I1\(15) = (GLOBAL(\M4S3~inputclkctrl_outclk\) & (\L_40|I1\(15))) # (!GLOBAL(\M4S3~inputclkctrl_outclk\) & ((\L_38|Mult0|auto_generated|mac_out2~DATAOUT15\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_40|I1\(15),
	datac => \M4S3~inputclkctrl_outclk\,
	datad => \L_38|Mult0|auto_generated|mac_out2~DATAOUT15\,
	combout => \L_40|I1\(15));

-- Location: LCCOMB_X75_Y19_N24
\L_7|Mux0~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux0~2_combout\ = (\L_7|Mux15~3_combout\ & (((\L_7|Mux15~0_combout\)))) # (!\L_7|Mux15~3_combout\ & ((\L_7|Mux15~0_combout\ & ((\L_40|I1\(15)))) # (!\L_7|Mux15~0_combout\ & (\L_47|I1\(15)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101001000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_7|Mux15~3_combout\,
	datab => \L_47|I1\(15),
	datac => \L_40|I1\(15),
	datad => \L_7|Mux15~0_combout\,
	combout => \L_7|Mux0~2_combout\);

-- Location: LCCOMB_X75_Y19_N18
\L_7|Mux0~3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux0~3_combout\ = (\L_7|Mux15~3_combout\ & ((\L_7|Mux0~2_combout\ & (\L_61|I1\(15))) # (!\L_7|Mux0~2_combout\ & ((\L_7|Mux0~1_combout\))))) # (!\L_7|Mux15~3_combout\ & (((\L_7|Mux0~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_61|I1\(15),
	datab => \L_7|Mux15~3_combout\,
	datac => \L_7|Mux0~1_combout\,
	datad => \L_7|Mux0~2_combout\,
	combout => \L_7|Mux0~3_combout\);

-- Location: LCCOMB_X75_Y19_N20
\L_36|Yout[15]~32\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_36|Yout[15]~32_combout\ = (\M4S2~input_o\ & ((\L_36|Yout[15]~15_combout\) # ((\L_36|Yout[0]~16_combout\ & \L_7|Mux0~3_combout\)))) # (!\M4S2~input_o\ & (((\L_36|Yout[0]~16_combout\ & \L_7|Mux0~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M4S2~input_o\,
	datab => \L_36|Yout[15]~15_combout\,
	datac => \L_36|Yout[0]~16_combout\,
	datad => \L_7|Mux0~3_combout\,
	combout => \L_36|Yout[15]~32_combout\);

-- Location: LCCOMB_X73_Y17_N8
\L_40|I0[9]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_40|I0\(9) = (GLOBAL(\M4S3~inputclkctrl_outclk\) & ((\L_38|Mult0|auto_generated|mac_out2~DATAOUT9\))) # (!GLOBAL(\M4S3~inputclkctrl_outclk\) & (\L_40|I0\(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_40|I0\(9),
	datac => \L_38|Mult0|auto_generated|mac_out2~DATAOUT9\,
	datad => \M4S3~inputclkctrl_outclk\,
	combout => \L_40|I0\(9));

-- Location: LCCOMB_X72_Y12_N6
\L_61|I0[9]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_61|I0\(9) = (GLOBAL(\A3S3~inputclkctrl_outclk\) & ((\L_59|O[9]~18_combout\))) # (!GLOBAL(\A3S3~inputclkctrl_outclk\) & (\L_61|I0\(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_61|I0\(9),
	datac => \A3S3~inputclkctrl_outclk\,
	datad => \L_59|O[9]~18_combout\,
	combout => \L_61|I0\(9));

-- Location: LCCOMB_X73_Y17_N12
\TM2|Yout[9]~20\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[9]~20_combout\ = (\TM2|Yout[9]~19_combout\ & (((\L_40|I0\(9))) # (!\TM2|Yout[9]~2_combout\))) # (!\TM2|Yout[9]~19_combout\ & (\TM2|Yout[9]~2_combout\ & ((\L_61|I0\(9)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110011010100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM2|Yout[9]~19_combout\,
	datab => \TM2|Yout[9]~2_combout\,
	datac => \L_40|I0\(9),
	datad => \L_61|I0\(9),
	combout => \TM2|Yout[9]~20_combout\);

-- Location: LCCOMB_X73_Y17_N30
\TM3|I0[9]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM3|I0\(9) = (GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM2|Yout[9]~20_combout\))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM3|I0\(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I0\(9),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM2|Yout[9]~20_combout\,
	combout => \TM3|I0\(9));

-- Location: LCCOMB_X75_Y17_N20
\L_3|I2[9]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I2\(9) = (GLOBAL(\L_3|Equal0~1clkctrl_outclk\) & (\TM3|I0\(9))) # (!GLOBAL(\L_3|Equal0~1clkctrl_outclk\) & ((\L_3|I2\(9))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM3|I0\(9),
	datac => \L_3|Equal0~1clkctrl_outclk\,
	datad => \L_3|I2\(9),
	combout => \L_3|I2\(9));

-- Location: LCCOMB_X77_Y13_N4
\L_3|I0[9]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I0\(9) = (GLOBAL(\L_3|I0[15]~0clkctrl_outclk\) & ((\L_3|I0\(9)))) # (!GLOBAL(\L_3|I0[15]~0clkctrl_outclk\) & (\TM3|I0\(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM3|I0\(9),
	datac => \L_3|I0\(9),
	datad => \L_3|I0[15]~0clkctrl_outclk\,
	combout => \L_3|I0\(9));

-- Location: LCCOMB_X75_Y10_N10
\L_29|Yout[9]~9\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_29|Yout[9]~9_combout\ = (\M3S2~input_o\ & ((\TM4|I0\(9)) # ((\L_3|I0\(9))))) # (!\M3S2~input_o\ & (((\L_3|I2\(9)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M3S2~input_o\,
	datab => \TM4|I0\(9),
	datac => \L_3|I2\(9),
	datad => \L_3|I0\(9),
	combout => \L_29|Yout[9]~9_combout\);

-- Location: LCCOMB_X77_Y10_N14
\L_29|Yout[10]~10\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_29|Yout[10]~10_combout\ = (\M3S2~input_o\ & ((\TM4|I0\(10)) # ((\L_3|I0\(10))))) # (!\M3S2~input_o\ & (((\L_3|I2\(10)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M3S2~input_o\,
	datab => \TM4|I0\(10),
	datac => \L_3|I2\(10),
	datad => \L_3|I0\(10),
	combout => \L_29|Yout[10]~10_combout\);

-- Location: LCCOMB_X72_Y10_N26
\L_3|I2[11]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I2\(11) = (GLOBAL(\L_3|Equal0~1clkctrl_outclk\) & ((\TM3|I0\(11)))) # (!GLOBAL(\L_3|Equal0~1clkctrl_outclk\) & (\L_3|I2\(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_3|I2\(11),
	datab => \TM3|I0\(11),
	datad => \L_3|Equal0~1clkctrl_outclk\,
	combout => \L_3|I2\(11));

-- Location: LCCOMB_X72_Y10_N0
\L_3|I0[11]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I0\(11) = (GLOBAL(\L_3|I0[15]~0clkctrl_outclk\) & (\L_3|I0\(11))) # (!GLOBAL(\L_3|I0[15]~0clkctrl_outclk\) & ((\TM3|I0\(11))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_3|I0\(11),
	datac => \TM3|I0\(11),
	datad => \L_3|I0[15]~0clkctrl_outclk\,
	combout => \L_3|I0\(11));

-- Location: LCCOMB_X72_Y10_N18
\L_29|Yout[11]~11\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_29|Yout[11]~11_combout\ = (\M3S2~input_o\ & ((\TM4|I0\(11)) # ((\L_3|I0\(11))))) # (!\M3S2~input_o\ & (((\L_3|I2\(11)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M3S2~input_o\,
	datab => \TM4|I0\(11),
	datac => \L_3|I2\(11),
	datad => \L_3|I0\(11),
	combout => \L_29|Yout[11]~11_combout\);

-- Location: IOIBUF_X111_Y0_N15
\v2[12]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v2(12),
	o => \v2[12]~input_o\);

-- Location: LCCOMB_X79_Y15_N20
\L_40|I0[12]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_40|I0\(12) = (GLOBAL(\M4S3~inputclkctrl_outclk\) & ((\L_38|Mult0|auto_generated|mac_out2~DATAOUT12\))) # (!GLOBAL(\M4S3~inputclkctrl_outclk\) & (\L_40|I0\(12)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_40|I0\(12),
	datac => \M4S3~inputclkctrl_outclk\,
	datad => \L_38|Mult0|auto_generated|mac_out2~DATAOUT12\,
	combout => \L_40|I0\(12));

-- Location: LCCOMB_X78_Y15_N28
\TM2|Yout[12]~25\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[12]~25_combout\ = (\BMS1[1]~input_o\ & (!\BMS1[0]~input_o\)) # (!\BMS1[1]~input_o\ & ((\L_61|I0\(12))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011111100001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \BMS1[1]~input_o\,
	datac => \BMS1[0]~input_o\,
	datad => \L_61|I0\(12),
	combout => \TM2|Yout[12]~25_combout\);

-- Location: LCCOMB_X79_Y15_N24
\TM2|Yout[12]~26\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[12]~26_combout\ = (\BMS1[1]~input_o\ & ((\TM2|Yout[12]~25_combout\ & ((\L_40|I0\(12)))) # (!\TM2|Yout[12]~25_combout\ & (\v2[12]~input_o\)))) # (!\BMS1[1]~input_o\ & (((\TM2|Yout[12]~25_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \BMS1[1]~input_o\,
	datab => \v2[12]~input_o\,
	datac => \L_40|I0\(12),
	datad => \TM2|Yout[12]~25_combout\,
	combout => \TM2|Yout[12]~26_combout\);

-- Location: LCCOMB_X79_Y15_N10
\TM3|I0[12]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM3|I0\(12) = (GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM2|Yout[12]~26_combout\))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM3|I0\(12)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I0\(12),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM2|Yout[12]~26_combout\,
	combout => \TM3|I0\(12));

-- Location: LCCOMB_X79_Y10_N12
\L_3|I2[12]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I2\(12) = (GLOBAL(\L_3|Equal0~1clkctrl_outclk\) & ((\TM3|I0\(12)))) # (!GLOBAL(\L_3|Equal0~1clkctrl_outclk\) & (\L_3|I2\(12)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_3|I2\(12),
	datac => \TM3|I0\(12),
	datad => \L_3|Equal0~1clkctrl_outclk\,
	combout => \L_3|I2\(12));

-- Location: LCCOMB_X79_Y10_N2
\L_29|Yout[12]~12\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_29|Yout[12]~12_combout\ = (\M3S2~input_o\ & ((\L_3|I0\(12)) # ((\TM4|I0\(12))))) # (!\M3S2~input_o\ & (((\L_3|I2\(12)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101111001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_3|I0\(12),
	datab => \M3S2~input_o\,
	datac => \TM4|I0\(12),
	datad => \L_3|I2\(12),
	combout => \L_29|Yout[12]~12_combout\);

-- Location: LCCOMB_X76_Y6_N12
\TM2|Yout[13]~46\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[13]~46_combout\ = (\BTPM_S1~input_o\ & (\v2[13]~input_o\)) # (!\BTPM_S1~input_o\ & ((\L_33|I0\(13))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v2[13]~input_o\,
	datac => \BTPM_S1~input_o\,
	datad => \L_33|I0\(13),
	combout => \TM2|Yout[13]~46_combout\);

-- Location: LCCOMB_X75_Y10_N26
\TM3|I1[13]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM3|I1\(13) = (GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM3|I1\(13))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM2|Yout[13]~46_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I1\(13),
	datac => \TM2|Yout[13]~46_combout\,
	datad => \TTS~inputclkctrl_outclk\,
	combout => \TM3|I1\(13));

-- Location: LCCOMB_X75_Y10_N22
\TM4|I0[13]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM4|I0\(13) = (GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & ((\TM3|I1\(13)))) # (!GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & (\TM4|I0\(13)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM4|I0\(13),
	datac => \BTPD_S2~inputclkctrl_outclk\,
	datad => \TM3|I1\(13),
	combout => \TM4|I0\(13));

-- Location: LCCOMB_X71_Y10_N18
\L_3|I0[13]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I0\(13) = (GLOBAL(\L_3|I0[15]~0clkctrl_outclk\) & (\L_3|I0\(13))) # (!GLOBAL(\L_3|I0[15]~0clkctrl_outclk\) & ((\TM3|I0\(13))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_3|I0\(13),
	datac => \TM3|I0\(13),
	datad => \L_3|I0[15]~0clkctrl_outclk\,
	combout => \L_3|I0\(13));

-- Location: LCCOMB_X75_Y10_N24
\L_29|Yout[13]~13\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_29|Yout[13]~13_combout\ = (\M3S2~input_o\ & ((\TM4|I0\(13)) # ((\L_3|I0\(13))))) # (!\M3S2~input_o\ & (((\L_3|I2\(13)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M3S2~input_o\,
	datab => \TM4|I0\(13),
	datac => \L_3|I2\(13),
	datad => \L_3|I0\(13),
	combout => \L_29|Yout[13]~13_combout\);

-- Location: LCCOMB_X79_Y10_N14
\L_3|I0[14]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I0\(14) = (GLOBAL(\L_3|I0[15]~0clkctrl_outclk\) & (\L_3|I0\(14))) # (!GLOBAL(\L_3|I0[15]~0clkctrl_outclk\) & ((\TM3|I0\(14))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_3|I0\(14),
	datac => \TM3|I0\(14),
	datad => \L_3|I0[15]~0clkctrl_outclk\,
	combout => \L_3|I0\(14));

-- Location: IOIBUF_X97_Y0_N8
\v2[14]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v2(14),
	o => \v2[14]~input_o\);

-- Location: LCCOMB_X73_Y10_N28
\TM2|Yout[14]~47\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[14]~47_combout\ = (\BTPM_S1~input_o\ & (\v2[14]~input_o\)) # (!\BTPM_S1~input_o\ & ((\L_33|I0\(14))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \BTPM_S1~input_o\,
	datab => \v2[14]~input_o\,
	datad => \L_33|I0\(14),
	combout => \TM2|Yout[14]~47_combout\);

-- Location: LCCOMB_X73_Y10_N10
\TM3|I1[14]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM3|I1\(14) = (GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM3|I1\(14))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM2|Yout[14]~47_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I1\(14),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM2|Yout[14]~47_combout\,
	combout => \TM3|I1\(14));

-- Location: LCCOMB_X73_Y10_N4
\TM4|I0[14]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM4|I0\(14) = (GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & ((\TM3|I1\(14)))) # (!GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & (\TM4|I0\(14)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM4|I0\(14),
	datac => \BTPD_S2~inputclkctrl_outclk\,
	datad => \TM3|I1\(14),
	combout => \TM4|I0\(14));

-- Location: LCCOMB_X79_Y10_N0
\L_29|Yout[14]~14\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_29|Yout[14]~14_combout\ = (\M3S2~input_o\ & (((\L_3|I0\(14)) # (\TM4|I0\(14))))) # (!\M3S2~input_o\ & (\L_3|I2\(14)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111011100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M3S2~input_o\,
	datab => \L_3|I2\(14),
	datac => \L_3|I0\(14),
	datad => \TM4|I0\(14),
	combout => \L_29|Yout[14]~14_combout\);

-- Location: LCCOMB_X79_Y10_N30
\L_29|Yout[15]~15\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_29|Yout[15]~15_combout\ = (\M3S2~input_o\ & (((\TM4|I0\(15)) # (\L_3|I0\(15))))) # (!\M3S2~input_o\ & (\L_3|I2\(15)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111011100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M3S2~input_o\,
	datab => \L_3|I2\(15),
	datac => \TM4|I0\(15),
	datad => \L_3|I0\(15),
	combout => \L_29|Yout[15]~15_combout\);

-- Location: DSPMULT_X74_Y10_N0
\L_31|Mult0|auto_generated|mac_mult1\ : cycloneiv_mac_mult
-- pragma translate_off
GENERIC MAP (
	dataa_clock => "none",
	dataa_width => 18,
	datab_clock => "none",
	datab_width => 18,
	signa_clock => "none",
	signb_clock => "none")
-- pragma translate_on
PORT MAP (
	signa => GND,
	signb => GND,
	dataa => \L_31|Mult0|auto_generated|mac_mult1_DATAA_bus\,
	datab => \L_31|Mult0|auto_generated|mac_mult1_DATAB_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	dataout => \L_31|Mult0|auto_generated|mac_mult1_DATAOUT_bus\);

-- Location: DSPOUT_X74_Y10_N2
\L_31|Mult0|auto_generated|mac_out2\ : cycloneiv_mac_out
-- pragma translate_off
GENERIC MAP (
	dataa_width => 36,
	output_clock => "none")
-- pragma translate_on
PORT MAP (
	dataa => \L_31|Mult0|auto_generated|mac_out2_DATAA_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	dataout => \L_31|Mult0|auto_generated|mac_out2_DATAOUT_bus\);

-- Location: LCCOMB_X76_Y11_N14
\L_33|I1[15]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_33|I1\(15) = (GLOBAL(\M3S3~inputclkctrl_outclk\) & (\L_33|I1\(15))) # (!GLOBAL(\M3S3~inputclkctrl_outclk\) & ((\L_31|Mult0|auto_generated|mac_out2~DATAOUT15\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_33|I1\(15),
	datac => \M3S3~inputclkctrl_outclk\,
	datad => \L_31|Mult0|auto_generated|mac_out2~DATAOUT15\,
	combout => \L_33|I1\(15));

-- Location: IOIBUF_X106_Y0_N1
\v1[15]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v1(15),
	o => \v1[15]~input_o\);

-- Location: IOIBUF_X48_Y0_N1
\v1[14]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v1(14),
	o => \v1[14]~input_o\);

-- Location: LCCOMB_X77_Y8_N0
\L_12|I0[15]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I0\(15) = (GLOBAL(\L_12|I0[15]~0clkctrl_outclk\) & ((\L_12|I0\(15)))) # (!GLOBAL(\L_12|I0[15]~0clkctrl_outclk\) & (\L_10|Yout[15]~31_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_10|Yout[15]~31_combout\,
	datab => \L_12|I0\(15),
	datad => \L_12|I0[15]~0clkctrl_outclk\,
	combout => \L_12|I0\(15));

-- Location: LCCOMB_X77_Y8_N20
\L_20|Yout[15]~15\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_20|Yout[15]~15_combout\ = (\M2S1~input_o\ & ((\L_12|I0\(15)))) # (!\M2S1~input_o\ & (\L_12|I2\(15)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_12|I2\(15),
	datac => \M2S1~input_o\,
	datad => \L_12|I0\(15),
	combout => \L_20|Yout[15]~15_combout\);

-- Location: IOIBUF_X70_Y0_N1
\M2S2~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_M2S2,
	o => \M2S2~input_o\);

-- Location: LCCOMB_X72_Y9_N18
\L_33|I1[0]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_33|I1\(0) = (GLOBAL(\M3S3~inputclkctrl_outclk\) & (\L_33|I1\(0))) # (!GLOBAL(\M3S3~inputclkctrl_outclk\) & ((\L_31|Mult0|auto_generated|mac_out2~dataout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_33|I1\(0),
	datac => \M3S3~inputclkctrl_outclk\,
	datad => \L_31|Mult0|auto_generated|mac_out2~dataout\,
	combout => \L_33|I1\(0));

-- Location: LCCOMB_X72_Y9_N2
\TM6|Yout[0]~66\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[0]~66_combout\ = (\YMS1[0]~input_o\ & ((\YMS1[1]~input_o\) # ((\L_33|I1\(0))))) # (!\YMS1[0]~input_o\ & (!\YMS1[1]~input_o\ & (\L_54|I1\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101010011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YMS1[0]~input_o\,
	datab => \YMS1[1]~input_o\,
	datac => \L_54|I1\(0),
	datad => \L_33|I1\(0),
	combout => \TM6|Yout[0]~66_combout\);

-- Location: LCCOMB_X72_Y9_N12
\TM6|Yout[0]~67\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[0]~67_combout\ = (\YMS1[1]~input_o\ & ((\TM6|Yout[0]~66_combout\ & (\v3[0]~input_o\)) # (!\TM6|Yout[0]~66_combout\ & ((\L_33|I0\(0)))))) # (!\YMS1[1]~input_o\ & (((\TM6|Yout[0]~66_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v3[0]~input_o\,
	datab => \YMS1[1]~input_o\,
	datac => \L_33|I0\(0),
	datad => \TM6|Yout[0]~66_combout\,
	combout => \TM6|Yout[0]~67_combout\);

-- Location: LCCOMB_X72_Y9_N30
\TM7|I0[0]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM7|I0\(0) = (GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM6|Yout[0]~67_combout\))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM7|I0\(0)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM7|I0\(0),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM6|Yout[0]~67_combout\,
	combout => \TM7|I0\(0));

-- Location: LCCOMB_X5_Y1_N6
\L_6|Equal0~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|Equal0~2_combout\ = (\YDS2[1]~input_o\ & !\YDS2[0]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \YDS2[1]~input_o\,
	datad => \YDS2[0]~input_o\,
	combout => \L_6|Equal0~2_combout\);

-- Location: CLKCTRL_G24
\L_6|Equal0~2clkctrl\ : cycloneiv_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \L_6|Equal0~2clkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \L_6|Equal0~2clkctrl_outclk\);

-- Location: LCCOMB_X72_Y13_N28
\L_6|I1[0]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I1\(0) = (GLOBAL(\L_6|Equal0~2clkctrl_outclk\) & (\TM7|I0\(0))) # (!GLOBAL(\L_6|Equal0~2clkctrl_outclk\) & ((\L_6|I1\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM7|I0\(0),
	datac => \L_6|Equal0~2clkctrl_outclk\,
	datad => \L_6|I1\(0),
	combout => \L_6|I1\(0));

-- Location: LCCOMB_X73_Y10_N16
\L_22|Yout[0]~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_22|Yout[0]~0_combout\ = (!\M2S2~input_o\ & ((\TTS~input_o\ & ((\L_6|I1\(0)))) # (!\TTS~input_o\ & (\TM4|I1\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001000000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM4|I1\(0),
	datab => \M2S2~input_o\,
	datac => \TTS~input_o\,
	datad => \L_6|I1\(0),
	combout => \L_22|Yout[0]~0_combout\);

-- Location: LCCOMB_X73_Y10_N14
\L_22|Yout[0]~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_22|Yout[0]~1_combout\ = (\L_22|Yout[0]~0_combout\) # ((\M2S2~input_o\ & \L_12|I0\(0)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M2S2~input_o\,
	datac => \L_12|I0\(0),
	datad => \L_22|Yout[0]~0_combout\,
	combout => \L_22|Yout[0]~1_combout\);

-- Location: LCCOMB_X77_Y6_N24
\L_12|I0[1]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I0\(1) = (GLOBAL(\L_12|I0[15]~0clkctrl_outclk\) & ((\L_12|I0\(1)))) # (!GLOBAL(\L_12|I0[15]~0clkctrl_outclk\) & (\L_10|Yout[1]~3_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_10|Yout[1]~3_combout\,
	datac => \L_12|I0[15]~0clkctrl_outclk\,
	datad => \L_12|I0\(1),
	combout => \L_12|I0\(1));

-- Location: LCCOMB_X77_Y6_N28
\L_6|I1[1]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I1\(1) = (GLOBAL(\L_6|Equal0~2clkctrl_outclk\) & (\TM7|I0\(1))) # (!GLOBAL(\L_6|Equal0~2clkctrl_outclk\) & ((\L_6|I1\(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM7|I0\(1),
	datac => \L_6|I1\(1),
	datad => \L_6|Equal0~2clkctrl_outclk\,
	combout => \L_6|I1\(1));

-- Location: LCCOMB_X78_Y10_N28
\TM4|I1[1]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM4|I1\(1) = (GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & ((\TM4|I1\(1)))) # (!GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & (\TM3|I1\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM3|I1\(1),
	datac => \BTPD_S2~inputclkctrl_outclk\,
	datad => \TM4|I1\(1),
	combout => \TM4|I1\(1));

-- Location: LCCOMB_X77_Y6_N16
\L_22|Yout[1]~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_22|Yout[1]~2_combout\ = (!\M2S2~input_o\ & ((\TTS~input_o\ & (\L_6|I1\(1))) # (!\TTS~input_o\ & ((\TM4|I1\(1))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100010101000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M2S2~input_o\,
	datab => \L_6|I1\(1),
	datac => \TTS~input_o\,
	datad => \TM4|I1\(1),
	combout => \L_22|Yout[1]~2_combout\);

-- Location: LCCOMB_X77_Y6_N14
\L_22|Yout[1]~3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_22|Yout[1]~3_combout\ = (\L_22|Yout[1]~2_combout\) # ((\L_12|I0\(1) & \M2S2~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_12|I0\(1),
	datac => \M2S2~input_o\,
	datad => \L_22|Yout[1]~2_combout\,
	combout => \L_22|Yout[1]~3_combout\);

-- Location: LCCOMB_X76_Y10_N28
\TM4|I1[2]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM4|I1\(2) = (GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & (\TM4|I1\(2))) # (!GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & ((\TM3|I1\(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \BTPD_S2~inputclkctrl_outclk\,
	datab => \TM4|I1\(2),
	datad => \TM3|I1\(2),
	combout => \TM4|I1\(2));

-- Location: LCCOMB_X75_Y6_N14
\L_22|Yout[2]~4\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_22|Yout[2]~4_combout\ = (!\M2S2~input_o\ & ((\TTS~input_o\ & (\L_6|I1\(2))) # (!\TTS~input_o\ & ((\TM4|I1\(2))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010001100100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_6|I1\(2),
	datab => \M2S2~input_o\,
	datac => \TTS~input_o\,
	datad => \TM4|I1\(2),
	combout => \L_22|Yout[2]~4_combout\);

-- Location: LCCOMB_X75_Y6_N16
\L_22|Yout[2]~5\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_22|Yout[2]~5_combout\ = (\L_22|Yout[2]~4_combout\) # ((\M2S2~input_o\ & \L_12|I0\(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \M2S2~input_o\,
	datac => \L_22|Yout[2]~4_combout\,
	datad => \L_12|I0\(2),
	combout => \L_22|Yout[2]~5_combout\);

-- Location: LCCOMB_X72_Y13_N14
\L_6|I1[3]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I1\(3) = (GLOBAL(\L_6|Equal0~2clkctrl_outclk\) & (\TM7|I0\(3))) # (!GLOBAL(\L_6|Equal0~2clkctrl_outclk\) & ((\L_6|I1\(3))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010110010101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM7|I0\(3),
	datab => \L_6|I1\(3),
	datac => \L_6|Equal0~2clkctrl_outclk\,
	combout => \L_6|I1\(3));

-- Location: LCCOMB_X73_Y10_N0
\L_22|Yout[3]~6\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_22|Yout[3]~6_combout\ = (!\M2S2~input_o\ & ((\TTS~input_o\ & ((\L_6|I1\(3)))) # (!\TTS~input_o\ & (\TM4|I1\(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001000000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM4|I1\(3),
	datab => \M2S2~input_o\,
	datac => \TTS~input_o\,
	datad => \L_6|I1\(3),
	combout => \L_22|Yout[3]~6_combout\);

-- Location: LCCOMB_X73_Y10_N18
\L_22|Yout[3]~7\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_22|Yout[3]~7_combout\ = (\L_22|Yout[3]~6_combout\) # ((\M2S2~input_o\ & \L_12|I0\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M2S2~input_o\,
	datac => \L_12|I0\(3),
	datad => \L_22|Yout[3]~6_combout\,
	combout => \L_22|Yout[3]~7_combout\);

-- Location: LCCOMB_X73_Y8_N16
\L_12|I0[4]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I0\(4) = (GLOBAL(\L_12|I0[15]~0clkctrl_outclk\) & (\L_12|I0\(4))) # (!GLOBAL(\L_12|I0[15]~0clkctrl_outclk\) & ((\L_10|Yout[4]~9_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_12|I0\(4),
	datac => \L_10|Yout[4]~9_combout\,
	datad => \L_12|I0[15]~0clkctrl_outclk\,
	combout => \L_12|I0\(4));

-- Location: LCCOMB_X73_Y7_N10
\TM2|Yout[4]~37\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[4]~37_combout\ = (\BTPM_S1~input_o\ & (\v2[4]~input_o\)) # (!\BTPM_S1~input_o\ & ((\L_33|I0\(4))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011100010111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v2[4]~input_o\,
	datab => \BTPM_S1~input_o\,
	datac => \L_33|I0\(4),
	combout => \TM2|Yout[4]~37_combout\);

-- Location: LCCOMB_X73_Y7_N26
\TM3|I1[4]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM3|I1\(4) = (GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM3|I1\(4))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM2|Yout[4]~37_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I1\(4),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM2|Yout[4]~37_combout\,
	combout => \TM3|I1\(4));

-- Location: LCCOMB_X72_Y5_N4
\TM4|I1[4]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM4|I1\(4) = (GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & (\TM4|I1\(4))) # (!GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & ((\TM3|I1\(4))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM4|I1\(4),
	datac => \TM3|I1\(4),
	datad => \BTPD_S2~inputclkctrl_outclk\,
	combout => \TM4|I1\(4));

-- Location: LCCOMB_X72_Y5_N22
\L_6|I1[4]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I1\(4) = (GLOBAL(\L_6|Equal0~2clkctrl_outclk\) & ((\TM7|I0\(4)))) # (!GLOBAL(\L_6|Equal0~2clkctrl_outclk\) & (\L_6|I1\(4)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_6|I1\(4),
	datac => \TM7|I0\(4),
	datad => \L_6|Equal0~2clkctrl_outclk\,
	combout => \L_6|I1\(4));

-- Location: LCCOMB_X72_Y5_N12
\L_22|Yout[4]~8\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_22|Yout[4]~8_combout\ = (!\M2S2~input_o\ & ((\TTS~input_o\ & ((\L_6|I1\(4)))) # (!\TTS~input_o\ & (\TM4|I1\(4)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000001000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M2S2~input_o\,
	datab => \TM4|I1\(4),
	datac => \L_6|I1\(4),
	datad => \TTS~input_o\,
	combout => \L_22|Yout[4]~8_combout\);

-- Location: LCCOMB_X73_Y8_N12
\L_22|Yout[4]~9\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_22|Yout[4]~9_combout\ = (\L_22|Yout[4]~8_combout\) # ((\L_12|I0\(4) & \M2S2~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_12|I0\(4),
	datac => \M2S2~input_o\,
	datad => \L_22|Yout[4]~8_combout\,
	combout => \L_22|Yout[4]~9_combout\);

-- Location: LCCOMB_X75_Y6_N24
\L_12|I0[5]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I0\(5) = (GLOBAL(\L_12|I0[15]~0clkctrl_outclk\) & ((\L_12|I0\(5)))) # (!GLOBAL(\L_12|I0[15]~0clkctrl_outclk\) & (\L_10|Yout[5]~11_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_10|Yout[5]~11_combout\,
	datac => \L_12|I0[15]~0clkctrl_outclk\,
	datad => \L_12|I0\(5),
	combout => \L_12|I0\(5));

-- Location: LCCOMB_X75_Y6_N4
\L_6|I1[5]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I1\(5) = (GLOBAL(\L_6|Equal0~2clkctrl_outclk\) & (\TM7|I0\(5))) # (!GLOBAL(\L_6|Equal0~2clkctrl_outclk\) & ((\L_6|I1\(5))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM7|I0\(5),
	datac => \L_6|I1\(5),
	datad => \L_6|Equal0~2clkctrl_outclk\,
	combout => \L_6|I1\(5));

-- Location: LCCOMB_X78_Y10_N10
\TM4|I1[5]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM4|I1\(5) = (GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & ((\TM4|I1\(5)))) # (!GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & (\TM3|I1\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I1\(5),
	datac => \BTPD_S2~inputclkctrl_outclk\,
	datad => \TM4|I1\(5),
	combout => \TM4|I1\(5));

-- Location: LCCOMB_X75_Y6_N6
\L_22|Yout[5]~10\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_22|Yout[5]~10_combout\ = (!\M2S2~input_o\ & ((\TTS~input_o\ & (\L_6|I1\(5))) # (!\TTS~input_o\ & ((\TM4|I1\(5))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000100100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TTS~input_o\,
	datab => \M2S2~input_o\,
	datac => \L_6|I1\(5),
	datad => \TM4|I1\(5),
	combout => \L_22|Yout[5]~10_combout\);

-- Location: LCCOMB_X75_Y6_N28
\L_22|Yout[5]~11\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_22|Yout[5]~11_combout\ = (\L_22|Yout[5]~10_combout\) # ((\L_12|I0\(5) & \M2S2~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_12|I0\(5),
	datac => \M2S2~input_o\,
	datad => \L_22|Yout[5]~10_combout\,
	combout => \L_22|Yout[5]~11_combout\);

-- Location: LCCOMB_X73_Y6_N30
\L_6|I1[6]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I1\(6) = (GLOBAL(\L_6|Equal0~2clkctrl_outclk\) & ((\TM7|I0\(6)))) # (!GLOBAL(\L_6|Equal0~2clkctrl_outclk\) & (\L_6|I1\(6)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_6|I1\(6),
	datac => \TM7|I0\(6),
	datad => \L_6|Equal0~2clkctrl_outclk\,
	combout => \L_6|I1\(6));

-- Location: LCCOMB_X72_Y11_N26
\TM4|I1[6]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM4|I1\(6) = (GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & ((\TM4|I1\(6)))) # (!GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & (\TM3|I1\(6)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM3|I1\(6),
	datac => \TM4|I1\(6),
	datad => \BTPD_S2~inputclkctrl_outclk\,
	combout => \TM4|I1\(6));

-- Location: LCCOMB_X73_Y6_N28
\L_22|Yout[6]~12\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_22|Yout[6]~12_combout\ = (!\M2S2~input_o\ & ((\TTS~input_o\ & (\L_6|I1\(6))) # (!\TTS~input_o\ & ((\TM4|I1\(6))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000101000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M2S2~input_o\,
	datab => \TTS~input_o\,
	datac => \L_6|I1\(6),
	datad => \TM4|I1\(6),
	combout => \L_22|Yout[6]~12_combout\);

-- Location: LCCOMB_X73_Y6_N22
\L_22|Yout[6]~13\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_22|Yout[6]~13_combout\ = (\L_22|Yout[6]~12_combout\) # ((\M2S2~input_o\ & \L_12|I0\(6)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M2S2~input_o\,
	datac => \L_12|I0\(6),
	datad => \L_22|Yout[6]~12_combout\,
	combout => \L_22|Yout[6]~13_combout\);

-- Location: LCCOMB_X76_Y10_N14
\L_6|I1[7]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I1\(7) = (GLOBAL(\L_6|Equal0~2clkctrl_outclk\) & (\TM7|I0\(7))) # (!GLOBAL(\L_6|Equal0~2clkctrl_outclk\) & ((\L_6|I1\(7))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010110010101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM7|I0\(7),
	datab => \L_6|I1\(7),
	datac => \L_6|Equal0~2clkctrl_outclk\,
	combout => \L_6|I1\(7));

-- Location: LCCOMB_X76_Y10_N4
\TM4|I1[7]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM4|I1\(7) = (GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & (\TM4|I1\(7))) # (!GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & ((\TM3|I1\(7))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM4|I1\(7),
	datac => \TM3|I1\(7),
	datad => \BTPD_S2~inputclkctrl_outclk\,
	combout => \TM4|I1\(7));

-- Location: LCCOMB_X76_Y10_N20
\L_22|Yout[7]~14\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_22|Yout[7]~14_combout\ = (!\M2S2~input_o\ & ((\TTS~input_o\ & (\L_6|I1\(7))) # (!\TTS~input_o\ & ((\TM4|I1\(7))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100010001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M2S2~input_o\,
	datab => \L_6|I1\(7),
	datac => \TM4|I1\(7),
	datad => \TTS~input_o\,
	combout => \L_22|Yout[7]~14_combout\);

-- Location: LCCOMB_X75_Y8_N16
\L_22|Yout[7]~15\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_22|Yout[7]~15_combout\ = (\L_22|Yout[7]~14_combout\) # ((\L_12|I0\(7) & \M2S2~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_12|I0\(7),
	datab => \M2S2~input_o\,
	datad => \L_22|Yout[7]~14_combout\,
	combout => \L_22|Yout[7]~15_combout\);

-- Location: LCCOMB_X76_Y10_N10
\L_6|I1[8]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I1\(8) = (GLOBAL(\L_6|Equal0~2clkctrl_outclk\) & ((\TM7|I0\(8)))) # (!GLOBAL(\L_6|Equal0~2clkctrl_outclk\) & (\L_6|I1\(8)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_6|I1\(8),
	datac => \L_6|Equal0~2clkctrl_outclk\,
	datad => \TM7|I0\(8),
	combout => \L_6|I1\(8));

-- Location: LCCOMB_X75_Y11_N0
\L_22|Yout[8]~16\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_22|Yout[8]~16_combout\ = (!\M2S2~input_o\ & ((\TTS~input_o\ & ((\L_6|I1\(8)))) # (!\TTS~input_o\ & (\TM4|I1\(8)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001000000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM4|I1\(8),
	datab => \M2S2~input_o\,
	datac => \TTS~input_o\,
	datad => \L_6|I1\(8),
	combout => \L_22|Yout[8]~16_combout\);

-- Location: LCCOMB_X75_Y11_N14
\L_22|Yout[8]~17\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_22|Yout[8]~17_combout\ = (\L_22|Yout[8]~16_combout\) # ((\M2S2~input_o\ & \L_12|I0\(8)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M2S2~input_o\,
	datac => \L_12|I0\(8),
	datad => \L_22|Yout[8]~16_combout\,
	combout => \L_22|Yout[8]~17_combout\);

-- Location: LCCOMB_X75_Y10_N18
\TM4|I1[9]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM4|I1\(9) = (GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & ((\TM4|I1\(9)))) # (!GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & (\TM3|I1\(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I1\(9),
	datac => \BTPD_S2~inputclkctrl_outclk\,
	datad => \TM4|I1\(9),
	combout => \TM4|I1\(9));

-- Location: LCCOMB_X75_Y10_N28
\L_6|I1[9]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I1\(9) = (GLOBAL(\L_6|Equal0~2clkctrl_outclk\) & ((\TM7|I0\(9)))) # (!GLOBAL(\L_6|Equal0~2clkctrl_outclk\) & (\L_6|I1\(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_6|I1\(9),
	datac => \L_6|Equal0~2clkctrl_outclk\,
	datad => \TM7|I0\(9),
	combout => \L_6|I1\(9));

-- Location: LCCOMB_X75_Y10_N30
\L_22|Yout[9]~18\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_22|Yout[9]~18_combout\ = (!\M2S2~input_o\ & ((\TTS~input_o\ & ((\L_6|I1\(9)))) # (!\TTS~input_o\ & (\TM4|I1\(9)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010000000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M2S2~input_o\,
	datab => \TM4|I1\(9),
	datac => \TTS~input_o\,
	datad => \L_6|I1\(9),
	combout => \L_22|Yout[9]~18_combout\);

-- Location: LCCOMB_X75_Y10_N8
\L_22|Yout[9]~19\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_22|Yout[9]~19_combout\ = (\L_22|Yout[9]~18_combout\) # ((\M2S2~input_o\ & \L_12|I0\(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \M2S2~input_o\,
	datac => \L_22|Yout[9]~18_combout\,
	datad => \L_12|I0\(9),
	combout => \L_22|Yout[9]~19_combout\);

-- Location: LCCOMB_X75_Y6_N26
\L_6|I1[10]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I1\(10) = (GLOBAL(\L_6|Equal0~2clkctrl_outclk\) & (\TM7|I0\(10))) # (!GLOBAL(\L_6|Equal0~2clkctrl_outclk\) & ((\L_6|I1\(10))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM7|I0\(10),
	datac => \L_6|I1\(10),
	datad => \L_6|Equal0~2clkctrl_outclk\,
	combout => \L_6|I1\(10));

-- Location: LCCOMB_X77_Y10_N24
\TM4|I1[10]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM4|I1\(10) = (GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & (\TM4|I1\(10))) # (!GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & ((\TM3|I1\(10))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM4|I1\(10),
	datac => \TM3|I1\(10),
	datad => \BTPD_S2~inputclkctrl_outclk\,
	combout => \TM4|I1\(10));

-- Location: LCCOMB_X75_Y6_N2
\L_22|Yout[10]~20\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_22|Yout[10]~20_combout\ = (!\M2S2~input_o\ & ((\TTS~input_o\ & (\L_6|I1\(10))) # (!\TTS~input_o\ & ((\TM4|I1\(10))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000100100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TTS~input_o\,
	datab => \M2S2~input_o\,
	datac => \L_6|I1\(10),
	datad => \TM4|I1\(10),
	combout => \L_22|Yout[10]~20_combout\);

-- Location: LCCOMB_X75_Y6_N8
\L_22|Yout[10]~21\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_22|Yout[10]~21_combout\ = (\L_22|Yout[10]~20_combout\) # ((\L_12|I0\(10) & \M2S2~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_12|I0\(10),
	datac => \M2S2~input_o\,
	datad => \L_22|Yout[10]~20_combout\,
	combout => \L_22|Yout[10]~21_combout\);

-- Location: LCCOMB_X77_Y8_N24
\L_12|I0[11]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I0\(11) = (GLOBAL(\L_12|I0[15]~0clkctrl_outclk\) & ((\L_12|I0\(11)))) # (!GLOBAL(\L_12|I0[15]~0clkctrl_outclk\) & (\L_10|Yout[11]~23_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_10|Yout[11]~23_combout\,
	datac => \L_12|I0\(11),
	datad => \L_12|I0[15]~0clkctrl_outclk\,
	combout => \L_12|I0\(11));

-- Location: LCCOMB_X73_Y12_N18
\TM6|Yout[11]~88\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[11]~88_combout\ = (\YMS1[0]~input_o\ & (\YMS1[1]~input_o\)) # (!\YMS1[0]~input_o\ & ((\YMS1[1]~input_o\ & ((\L_33|I0\(11)))) # (!\YMS1[1]~input_o\ & (\L_54|I1\(11)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110010011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YMS1[0]~input_o\,
	datab => \YMS1[1]~input_o\,
	datac => \L_54|I1\(11),
	datad => \L_33|I0\(11),
	combout => \TM6|Yout[11]~88_combout\);

-- Location: LCCOMB_X73_Y12_N24
\TM6|Yout[11]~89\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[11]~89_combout\ = (\YMS1[0]~input_o\ & ((\TM6|Yout[11]~88_combout\ & (\v3[11]~input_o\)) # (!\TM6|Yout[11]~88_combout\ & ((\L_33|I1\(11)))))) # (!\YMS1[0]~input_o\ & (((\TM6|Yout[11]~88_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v3[11]~input_o\,
	datab => \YMS1[0]~input_o\,
	datac => \L_33|I1\(11),
	datad => \TM6|Yout[11]~88_combout\,
	combout => \TM6|Yout[11]~89_combout\);

-- Location: LCCOMB_X73_Y12_N2
\TM7|I0[11]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM7|I0\(11) = (GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM6|Yout[11]~89_combout\))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM7|I0\(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM7|I0\(11),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM6|Yout[11]~89_combout\,
	combout => \TM7|I0\(11));

-- Location: LCCOMB_X76_Y10_N16
\L_6|I1[11]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I1\(11) = (GLOBAL(\L_6|Equal0~2clkctrl_outclk\) & (\TM7|I0\(11))) # (!GLOBAL(\L_6|Equal0~2clkctrl_outclk\) & ((\L_6|I1\(11))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_6|Equal0~2clkctrl_outclk\,
	datac => \TM7|I0\(11),
	datad => \L_6|I1\(11),
	combout => \L_6|I1\(11));

-- Location: LCCOMB_X76_Y10_N22
\TM4|I1[11]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM4|I1\(11) = (GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & (\TM4|I1\(11))) # (!GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & ((\TM3|I1\(11))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM4|I1\(11),
	datac => \TM3|I1\(11),
	datad => \BTPD_S2~inputclkctrl_outclk\,
	combout => \TM4|I1\(11));

-- Location: LCCOMB_X76_Y10_N6
\L_22|Yout[11]~22\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_22|Yout[11]~22_combout\ = (!\M2S2~input_o\ & ((\TTS~input_o\ & (\L_6|I1\(11))) # (!\TTS~input_o\ & ((\TM4|I1\(11))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100010001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M2S2~input_o\,
	datab => \L_6|I1\(11),
	datac => \TM4|I1\(11),
	datad => \TTS~input_o\,
	combout => \L_22|Yout[11]~22_combout\);

-- Location: LCCOMB_X76_Y10_N12
\L_22|Yout[11]~23\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_22|Yout[11]~23_combout\ = (\L_22|Yout[11]~22_combout\) # ((\M2S2~input_o\ & \L_12|I0\(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \M2S2~input_o\,
	datac => \L_12|I0\(11),
	datad => \L_22|Yout[11]~22_combout\,
	combout => \L_22|Yout[11]~23_combout\);

-- Location: LCCOMB_X78_Y11_N12
\TM4|I1[12]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM4|I1\(12) = (GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & ((\TM4|I1\(12)))) # (!GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & (\TM3|I1\(12)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I1\(12),
	datac => \TM4|I1\(12),
	datad => \BTPD_S2~inputclkctrl_outclk\,
	combout => \TM4|I1\(12));

-- Location: LCCOMB_X80_Y10_N0
\L_6|I1[12]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I1\(12) = (GLOBAL(\L_6|Equal0~2clkctrl_outclk\) & (\TM7|I0\(12))) # (!GLOBAL(\L_6|Equal0~2clkctrl_outclk\) & ((\L_6|I1\(12))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010110010101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM7|I0\(12),
	datab => \L_6|I1\(12),
	datac => \L_6|Equal0~2clkctrl_outclk\,
	combout => \L_6|I1\(12));

-- Location: LCCOMB_X78_Y11_N20
\L_22|Yout[12]~24\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_22|Yout[12]~24_combout\ = (!\M2S2~input_o\ & ((\TTS~input_o\ & ((\L_6|I1\(12)))) # (!\TTS~input_o\ & (\TM4|I1\(12)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010000000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M2S2~input_o\,
	datab => \TM4|I1\(12),
	datac => \TTS~input_o\,
	datad => \L_6|I1\(12),
	combout => \L_22|Yout[12]~24_combout\);

-- Location: LCCOMB_X78_Y11_N26
\L_22|Yout[12]~25\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_22|Yout[12]~25_combout\ = (\L_22|Yout[12]~24_combout\) # ((\M2S2~input_o\ & \L_12|I0\(12)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \M2S2~input_o\,
	datac => \L_12|I0\(12),
	datad => \L_22|Yout[12]~24_combout\,
	combout => \L_22|Yout[12]~25_combout\);

-- Location: LCCOMB_X75_Y10_N2
\TM4|I1[13]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM4|I1\(13) = (GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & (\TM4|I1\(13))) # (!GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & ((\TM3|I1\(13))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM4|I1\(13),
	datac => \BTPD_S2~inputclkctrl_outclk\,
	datad => \TM3|I1\(13),
	combout => \TM4|I1\(13));

-- Location: LCCOMB_X75_Y10_N0
\L_6|I1[13]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I1\(13) = (GLOBAL(\L_6|Equal0~2clkctrl_outclk\) & ((\TM7|I0\(13)))) # (!GLOBAL(\L_6|Equal0~2clkctrl_outclk\) & (\L_6|I1\(13)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_6|I1\(13),
	datac => \L_6|Equal0~2clkctrl_outclk\,
	datad => \TM7|I0\(13),
	combout => \L_6|I1\(13));

-- Location: LCCOMB_X75_Y10_N14
\L_22|Yout[13]~26\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_22|Yout[13]~26_combout\ = (!\M2S2~input_o\ & ((\TTS~input_o\ & ((\L_6|I1\(13)))) # (!\TTS~input_o\ & (\TM4|I1\(13)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010000000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M2S2~input_o\,
	datab => \TM4|I1\(13),
	datac => \TTS~input_o\,
	datad => \L_6|I1\(13),
	combout => \L_22|Yout[13]~26_combout\);

-- Location: LCCOMB_X75_Y10_N20
\L_22|Yout[13]~27\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_22|Yout[13]~27_combout\ = (\L_22|Yout[13]~26_combout\) # ((\M2S2~input_o\ & \L_12|I0\(13)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \M2S2~input_o\,
	datac => \L_22|Yout[13]~26_combout\,
	datad => \L_12|I0\(13),
	combout => \L_22|Yout[13]~27_combout\);

-- Location: LCCOMB_X73_Y10_N8
\TM4|I1[14]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM4|I1\(14) = (GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & ((\TM4|I1\(14)))) # (!GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & (\TM3|I1\(14)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I1\(14),
	datac => \BTPD_S2~inputclkctrl_outclk\,
	datad => \TM4|I1\(14),
	combout => \TM4|I1\(14));

-- Location: LCCOMB_X72_Y13_N8
\L_6|I1[14]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I1\(14) = (GLOBAL(\L_6|Equal0~2clkctrl_outclk\) & (\TM7|I0\(14))) # (!GLOBAL(\L_6|Equal0~2clkctrl_outclk\) & ((\L_6|I1\(14))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010110010101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM7|I0\(14),
	datab => \L_6|I1\(14),
	datac => \L_6|Equal0~2clkctrl_outclk\,
	combout => \L_6|I1\(14));

-- Location: LCCOMB_X73_Y10_N12
\L_22|Yout[14]~28\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_22|Yout[14]~28_combout\ = (!\M2S2~input_o\ & ((\TTS~input_o\ & ((\L_6|I1\(14)))) # (!\TTS~input_o\ & (\TM4|I1\(14)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010000000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M2S2~input_o\,
	datab => \TM4|I1\(14),
	datac => \TTS~input_o\,
	datad => \L_6|I1\(14),
	combout => \L_22|Yout[14]~28_combout\);

-- Location: LCCOMB_X73_Y10_N26
\L_22|Yout[14]~29\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_22|Yout[14]~29_combout\ = (\L_22|Yout[14]~28_combout\) # ((\M2S2~input_o\ & \L_12|I0\(14)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M2S2~input_o\,
	datac => \L_12|I0\(14),
	datad => \L_22|Yout[14]~28_combout\,
	combout => \L_22|Yout[14]~29_combout\);

-- Location: LCCOMB_X76_Y10_N0
\L_6|I1[15]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I1\(15) = (GLOBAL(\L_6|Equal0~2clkctrl_outclk\) & ((\TM7|I0\(15)))) # (!GLOBAL(\L_6|Equal0~2clkctrl_outclk\) & (\L_6|I1\(15)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_6|I1\(15),
	datac => \L_6|Equal0~2clkctrl_outclk\,
	datad => \TM7|I0\(15),
	combout => \L_6|I1\(15));

-- Location: LCCOMB_X76_Y11_N8
\TM4|I1[15]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM4|I1\(15) = (GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & ((\TM4|I1\(15)))) # (!GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & (\TM3|I1\(15)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I1\(15),
	datab => \TM4|I1\(15),
	datad => \BTPD_S2~inputclkctrl_outclk\,
	combout => \TM4|I1\(15));

-- Location: LCCOMB_X76_Y11_N24
\L_22|Yout[15]~30\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_22|Yout[15]~30_combout\ = (!\M2S2~input_o\ & ((\TTS~input_o\ & (\L_6|I1\(15))) # (!\TTS~input_o\ & ((\TM4|I1\(15))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100010001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M2S2~input_o\,
	datab => \L_6|I1\(15),
	datac => \TM4|I1\(15),
	datad => \TTS~input_o\,
	combout => \L_22|Yout[15]~30_combout\);

-- Location: LCCOMB_X76_Y11_N22
\L_22|Yout[15]~31\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_22|Yout[15]~31_combout\ = (\L_22|Yout[15]~30_combout\) # ((\M2S2~input_o\ & \L_12|I0\(15)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M2S2~input_o\,
	datac => \L_12|I0\(15),
	datad => \L_22|Yout[15]~30_combout\,
	combout => \L_22|Yout[15]~31_combout\);

-- Location: DSPMULT_X74_Y8_N0
\L_24|Mult0|auto_generated|mac_mult1\ : cycloneiv_mac_mult
-- pragma translate_off
GENERIC MAP (
	dataa_clock => "none",
	dataa_width => 18,
	datab_clock => "none",
	datab_width => 18,
	signa_clock => "none",
	signb_clock => "none")
-- pragma translate_on
PORT MAP (
	signa => GND,
	signb => GND,
	dataa => \L_24|Mult0|auto_generated|mac_mult1_DATAA_bus\,
	datab => \L_24|Mult0|auto_generated|mac_mult1_DATAB_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	dataout => \L_24|Mult0|auto_generated|mac_mult1_DATAOUT_bus\);

-- Location: LCCOMB_X75_Y9_N16
\L_26|I1[14]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_26|I1\(14) = (GLOBAL(\M2S3~inputclkctrl_outclk\) & (\L_26|I1\(14))) # (!GLOBAL(\M2S3~inputclkctrl_outclk\) & ((\L_24|Mult0|auto_generated|mac_out2~DATAOUT14\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_26|I1\(14),
	datac => \M2S3~inputclkctrl_outclk\,
	datad => \L_24|Mult0|auto_generated|mac_out2~DATAOUT14\,
	combout => \L_26|I1\(14));

-- Location: LCCOMB_X75_Y9_N18
\L_26|I0[14]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_26|I0\(14) = (GLOBAL(\M2S3~inputclkctrl_outclk\) & ((\L_24|Mult0|auto_generated|mac_out2~DATAOUT14\))) # (!GLOBAL(\M2S3~inputclkctrl_outclk\) & (\L_26|I0\(14)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_26|I0\(14),
	datac => \M2S3~inputclkctrl_outclk\,
	datad => \L_24|Mult0|auto_generated|mac_out2~DATAOUT14\,
	combout => \L_26|I0\(14));

-- Location: LCCOMB_X75_Y9_N28
\L_10|Yout[14]~28\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_10|Yout[14]~28_combout\ = (\GMS1[1]~input_o\ & (((\L_26|I0\(14)) # (\GMS1[0]~input_o\)))) # (!\GMS1[1]~input_o\ & (\L_26|I1\(14) & ((!\GMS1[0]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \GMS1[1]~input_o\,
	datab => \L_26|I1\(14),
	datac => \L_26|I0\(14),
	datad => \GMS1[0]~input_o\,
	combout => \L_10|Yout[14]~28_combout\);

-- Location: LCCOMB_X75_Y9_N6
\L_10|Yout[14]~29\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_10|Yout[14]~29_combout\ = (\GMS1[0]~input_o\ & ((\L_10|Yout[14]~28_combout\ & ((\v1[14]~input_o\))) # (!\L_10|Yout[14]~28_combout\ & (\L_54|I0\(14))))) # (!\GMS1[0]~input_o\ & (((\L_10|Yout[14]~28_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_54|I0\(14),
	datab => \GMS1[0]~input_o\,
	datac => \v1[14]~input_o\,
	datad => \L_10|Yout[14]~28_combout\,
	combout => \L_10|Yout[14]~29_combout\);

-- Location: LCCOMB_X73_Y8_N24
\L_12|I0[14]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I0\(14) = (GLOBAL(\L_12|I0[15]~0clkctrl_outclk\) & (\L_12|I0\(14))) # (!GLOBAL(\L_12|I0[15]~0clkctrl_outclk\) & ((\L_10|Yout[14]~29_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_12|I0\(14),
	datac => \L_10|Yout[14]~29_combout\,
	datad => \L_12|I0[15]~0clkctrl_outclk\,
	combout => \L_12|I0\(14));

-- Location: LCCOMB_X73_Y8_N18
\L_12|I2[14]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I2\(14) = (GLOBAL(\L_12|Equal0~2clkctrl_outclk\) & ((\L_10|Yout[14]~29_combout\))) # (!GLOBAL(\L_12|Equal0~2clkctrl_outclk\) & (\L_12|I2\(14)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_12|I2\(14),
	datac => \L_12|Equal0~2clkctrl_outclk\,
	datad => \L_10|Yout[14]~29_combout\,
	combout => \L_12|I2\(14));

-- Location: LCCOMB_X73_Y8_N26
\L_20|Yout[14]~14\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_20|Yout[14]~14_combout\ = (\M2S1~input_o\ & (\L_12|I0\(14))) # (!\M2S1~input_o\ & ((\L_12|I2\(14))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_12|I0\(14),
	datac => \M2S1~input_o\,
	datad => \L_12|I2\(14),
	combout => \L_20|Yout[14]~14_combout\);

-- Location: LCCOMB_X75_Y8_N10
\L_26|I0[15]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_26|I0\(15) = (GLOBAL(\M2S3~inputclkctrl_outclk\) & ((\L_24|Mult0|auto_generated|mac_out2~DATAOUT15\))) # (!GLOBAL(\M2S3~inputclkctrl_outclk\) & (\L_26|I0\(15)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_26|I0\(15),
	datac => \L_24|Mult0|auto_generated|mac_out2~DATAOUT15\,
	datad => \M2S3~inputclkctrl_outclk\,
	combout => \L_26|I0\(15));

-- Location: LCCOMB_X75_Y8_N28
\L_54|I0[15]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_54|I0\(15) = (GLOBAL(\A2S3~inputclkctrl_outclk\) & ((\L_52|O[15]~30_combout\))) # (!GLOBAL(\A2S3~inputclkctrl_outclk\) & (\L_54|I0\(15)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_54|I0\(15),
	datac => \A2S3~inputclkctrl_outclk\,
	datad => \L_52|O[15]~30_combout\,
	combout => \L_54|I0\(15));

-- Location: LCCOMB_X75_Y8_N8
\L_10|Yout[15]~30\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_10|Yout[15]~30_combout\ = (\GMS1[1]~input_o\ & (((\GMS1[0]~input_o\)))) # (!\GMS1[1]~input_o\ & ((\GMS1[0]~input_o\ & ((\L_54|I0\(15)))) # (!\GMS1[0]~input_o\ & (\L_26|I1\(15)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001011000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_26|I1\(15),
	datab => \GMS1[1]~input_o\,
	datac => \GMS1[0]~input_o\,
	datad => \L_54|I0\(15),
	combout => \L_10|Yout[15]~30_combout\);

-- Location: LCCOMB_X75_Y8_N2
\L_10|Yout[15]~31\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_10|Yout[15]~31_combout\ = (\GMS1[1]~input_o\ & ((\L_10|Yout[15]~30_combout\ & (\v1[15]~input_o\)) # (!\L_10|Yout[15]~30_combout\ & ((\L_26|I0\(15)))))) # (!\GMS1[1]~input_o\ & (((\L_10|Yout[15]~30_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \GMS1[1]~input_o\,
	datab => \v1[15]~input_o\,
	datac => \L_26|I0\(15),
	datad => \L_10|Yout[15]~30_combout\,
	combout => \L_10|Yout[15]~31_combout\);

-- Location: LCCOMB_X72_Y7_N16
\L_12|I1[15]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I1\(15) = (GLOBAL(\L_12|Equal0~1clkctrl_outclk\) & (\L_10|Yout[15]~31_combout\)) # (!GLOBAL(\L_12|Equal0~1clkctrl_outclk\) & ((\L_12|I1\(15))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_10|Yout[15]~31_combout\,
	datac => \L_12|Equal0~1clkctrl_outclk\,
	datad => \L_12|I1\(15),
	combout => \L_12|I1\(15));

-- Location: IOIBUF_X88_Y0_N8
\v2[15]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v2(15),
	o => \v2[15]~input_o\);

-- Location: LCCOMB_X77_Y11_N14
\TM2|Yout[15]~31\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[15]~31_combout\ = (\BMS1[1]~input_o\ & ((\v2[15]~input_o\) # (!\BMS1[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \BMS1[1]~input_o\,
	datac => \BMS1[0]~input_o\,
	datad => \v2[15]~input_o\,
	combout => \TM2|Yout[15]~31_combout\);

-- Location: LCCOMB_X77_Y11_N0
\L_40|I0[15]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_40|I0\(15) = (GLOBAL(\M4S3~inputclkctrl_outclk\) & ((\L_38|Mult0|auto_generated|mac_out2~DATAOUT15\))) # (!GLOBAL(\M4S3~inputclkctrl_outclk\) & (\L_40|I0\(15)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_40|I0\(15),
	datac => \M4S3~inputclkctrl_outclk\,
	datad => \L_38|Mult0|auto_generated|mac_out2~DATAOUT15\,
	combout => \L_40|I0\(15));

-- Location: LCCOMB_X77_Y11_N16
\TM2|Yout[15]~32\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[15]~32_combout\ = (\TM2|Yout[9]~2_combout\ & ((\TM2|Yout[15]~31_combout\ & ((\L_40|I0\(15)))) # (!\TM2|Yout[15]~31_combout\ & (\L_61|I0\(15))))) # (!\TM2|Yout[9]~2_combout\ & (\TM2|Yout[15]~31_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110001100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM2|Yout[9]~2_combout\,
	datab => \TM2|Yout[15]~31_combout\,
	datac => \L_61|I0\(15),
	datad => \L_40|I0\(15),
	combout => \TM2|Yout[15]~32_combout\);

-- Location: LCCOMB_X77_Y11_N26
\TM3|I0[15]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM3|I0\(15) = (GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM2|Yout[15]~32_combout\))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM3|I0\(15)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I0\(15),
	datab => \TM2|Yout[15]~32_combout\,
	datad => \TTS~inputclkctrl_outclk\,
	combout => \TM3|I0\(15));

-- Location: LCCOMB_X77_Y12_N14
\L_3|I1[15]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I1\(15) = (GLOBAL(\L_3|Equal0~0clkctrl_outclk\) & (\TM3|I0\(15))) # (!GLOBAL(\L_3|Equal0~0clkctrl_outclk\) & ((\L_3|I1\(15))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM3|I0\(15),
	datac => \L_3|I1\(15),
	datad => \L_3|Equal0~0clkctrl_outclk\,
	combout => \L_3|I1\(15));

-- Location: LCCOMB_X77_Y12_N24
\L_57|Yout[15]~30\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_57|Yout[15]~30_combout\ = (\L_55|Yout[0]~0_combout\ & ((\TM7|I1\(15)) # ((\L_3|I1\(15) & \TTS~input_o\)))) # (!\L_55|Yout[0]~0_combout\ & (((\L_3|I1\(15) & \TTS~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_55|Yout[0]~0_combout\,
	datab => \TM7|I1\(15),
	datac => \L_3|I1\(15),
	datad => \TTS~input_o\,
	combout => \L_57|Yout[15]~30_combout\);

-- Location: LCCOMB_X77_Y12_N28
\L_12|I3[15]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I3\(15) = (GLOBAL(\L_12|Equal0~0clkctrl_outclk\) & (\L_12|I3\(15))) # (!GLOBAL(\L_12|Equal0~0clkctrl_outclk\) & ((\L_10|Yout[15]~31_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_12|I3\(15),
	datac => \L_12|Equal0~0clkctrl_outclk\,
	datad => \L_10|Yout[15]~31_combout\,
	combout => \L_12|I3\(15));

-- Location: LCCOMB_X77_Y12_N12
\L_57|Yout[15]~31\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_57|Yout[15]~31_combout\ = (\A3S2~input_o\ & (\L_57|Yout[15]~30_combout\)) # (!\A3S2~input_o\ & ((\L_12|I3\(15))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_57|Yout[15]~30_combout\,
	datac => \A3S2~input_o\,
	datad => \L_12|I3\(15),
	combout => \L_57|Yout[15]~31_combout\);

-- Location: LCCOMB_X77_Y12_N6
\L_55|Yout[15]~17\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_55|Yout[15]~17_combout\ = (\A3S1~input_o\ & ((\L_57|Yout[15]~30_combout\) # ((\L_55|Yout[15]~1_combout\ & \L_7|Mux0~3_combout\)))) # (!\A3S1~input_o\ & (((\L_55|Yout[15]~1_combout\ & \L_7|Mux0~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \A3S1~input_o\,
	datab => \L_57|Yout[15]~30_combout\,
	datac => \L_55|Yout[15]~1_combout\,
	datad => \L_7|Mux0~3_combout\,
	combout => \L_55|Yout[15]~17_combout\);

-- Location: LCCOMB_X76_Y12_N22
\L_59|O[11]~22\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_59|O[11]~22_combout\ = (\L_57|Yout[11]~23_combout\ & ((\L_55|Yout[11]~13_combout\ & (\L_59|O[10]~21\ & VCC)) # (!\L_55|Yout[11]~13_combout\ & (!\L_59|O[10]~21\)))) # (!\L_57|Yout[11]~23_combout\ & ((\L_55|Yout[11]~13_combout\ & (!\L_59|O[10]~21\)) # 
-- (!\L_55|Yout[11]~13_combout\ & ((\L_59|O[10]~21\) # (GND)))))
-- \L_59|O[11]~23\ = CARRY((\L_57|Yout[11]~23_combout\ & (!\L_55|Yout[11]~13_combout\ & !\L_59|O[10]~21\)) # (!\L_57|Yout[11]~23_combout\ & ((!\L_59|O[10]~21\) # (!\L_55|Yout[11]~13_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011000010111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_57|Yout[11]~23_combout\,
	datab => \L_55|Yout[11]~13_combout\,
	datad => VCC,
	cin => \L_59|O[10]~21\,
	combout => \L_59|O[11]~22_combout\,
	cout => \L_59|O[11]~23\);

-- Location: LCCOMB_X76_Y12_N24
\L_59|O[12]~24\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_59|O[12]~24_combout\ = ((\L_55|Yout[12]~14_combout\ $ (\L_57|Yout[12]~25_combout\ $ (!\L_59|O[11]~23\)))) # (GND)
-- \L_59|O[12]~25\ = CARRY((\L_55|Yout[12]~14_combout\ & ((\L_57|Yout[12]~25_combout\) # (!\L_59|O[11]~23\))) # (!\L_55|Yout[12]~14_combout\ & (\L_57|Yout[12]~25_combout\ & !\L_59|O[11]~23\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100110001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_55|Yout[12]~14_combout\,
	datab => \L_57|Yout[12]~25_combout\,
	datad => VCC,
	cin => \L_59|O[11]~23\,
	combout => \L_59|O[12]~24_combout\,
	cout => \L_59|O[12]~25\);

-- Location: LCCOMB_X76_Y12_N26
\L_59|O[13]~26\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_59|O[13]~26_combout\ = (\L_57|Yout[13]~27_combout\ & ((\L_55|Yout[13]~15_combout\ & (\L_59|O[12]~25\ & VCC)) # (!\L_55|Yout[13]~15_combout\ & (!\L_59|O[12]~25\)))) # (!\L_57|Yout[13]~27_combout\ & ((\L_55|Yout[13]~15_combout\ & (!\L_59|O[12]~25\)) # 
-- (!\L_55|Yout[13]~15_combout\ & ((\L_59|O[12]~25\) # (GND)))))
-- \L_59|O[13]~27\ = CARRY((\L_57|Yout[13]~27_combout\ & (!\L_55|Yout[13]~15_combout\ & !\L_59|O[12]~25\)) # (!\L_57|Yout[13]~27_combout\ & ((!\L_59|O[12]~25\) # (!\L_55|Yout[13]~15_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011000010111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_57|Yout[13]~27_combout\,
	datab => \L_55|Yout[13]~15_combout\,
	datad => VCC,
	cin => \L_59|O[12]~25\,
	combout => \L_59|O[13]~26_combout\,
	cout => \L_59|O[13]~27\);

-- Location: LCCOMB_X76_Y12_N28
\L_59|O[14]~28\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_59|O[14]~28_combout\ = ((\L_57|Yout[14]~29_combout\ $ (\L_55|Yout[14]~16_combout\ $ (!\L_59|O[13]~27\)))) # (GND)
-- \L_59|O[14]~29\ = CARRY((\L_57|Yout[14]~29_combout\ & ((\L_55|Yout[14]~16_combout\) # (!\L_59|O[13]~27\))) # (!\L_57|Yout[14]~29_combout\ & (\L_55|Yout[14]~16_combout\ & !\L_59|O[13]~27\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100110001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_57|Yout[14]~29_combout\,
	datab => \L_55|Yout[14]~16_combout\,
	datad => VCC,
	cin => \L_59|O[13]~27\,
	combout => \L_59|O[14]~28_combout\,
	cout => \L_59|O[14]~29\);

-- Location: LCCOMB_X76_Y12_N30
\L_59|O[15]~30\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_59|O[15]~30_combout\ = \L_57|Yout[15]~31_combout\ $ (\L_59|O[14]~29\ $ (\L_55|Yout[15]~17_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100111100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \L_57|Yout[15]~31_combout\,
	datad => \L_55|Yout[15]~17_combout\,
	cin => \L_59|O[14]~29\,
	combout => \L_59|O[15]~30_combout\);

-- Location: LCCOMB_X77_Y11_N22
\L_61|I0[15]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_61|I0\(15) = (GLOBAL(\A3S3~inputclkctrl_outclk\) & ((\L_59|O[15]~30_combout\))) # (!GLOBAL(\A3S3~inputclkctrl_outclk\) & (\L_61|I0\(15)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_61|I0\(15),
	datac => \L_59|O[15]~30_combout\,
	datad => \A3S3~inputclkctrl_outclk\,
	combout => \L_61|I0\(15));

-- Location: LCCOMB_X77_Y11_N20
\TM6|Yout[15]~62\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[15]~62_combout\ = (\YTPM_S1[1]~input_o\ & (((\L_61|I0\(15))))) # (!\YTPM_S1[1]~input_o\ & (((\L_40|I0\(15))) # (!\YTPM_S1[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111010001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPM_S1[0]~input_o\,
	datab => \YTPM_S1[1]~input_o\,
	datac => \L_61|I0\(15),
	datad => \L_40|I0\(15),
	combout => \TM6|Yout[15]~62_combout\);

-- Location: LCCOMB_X76_Y11_N28
\L_33|I0[15]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_33|I0\(15) = (GLOBAL(\M3S3~inputclkctrl_outclk\) & ((\L_31|Mult0|auto_generated|mac_out2~DATAOUT15\))) # (!GLOBAL(\M3S3~inputclkctrl_outclk\) & (\L_33|I0\(15)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_33|I0\(15),
	datac => \M3S3~inputclkctrl_outclk\,
	datad => \L_31|Mult0|auto_generated|mac_out2~DATAOUT15\,
	combout => \L_33|I0\(15));

-- Location: LCCOMB_X76_Y11_N2
\TM6|Yout[15]~63\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[15]~63_combout\ = (\TM6|Yout[0]~5_combout\ & (((\TM6|Yout[15]~62_combout\)))) # (!\TM6|Yout[0]~5_combout\ & ((\TM6|Yout[15]~62_combout\ & (\v3[15]~input_o\)) # (!\TM6|Yout[15]~62_combout\ & ((\L_33|I0\(15))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110010111100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM6|Yout[0]~5_combout\,
	datab => \v3[15]~input_o\,
	datac => \TM6|Yout[15]~62_combout\,
	datad => \L_33|I0\(15),
	combout => \TM6|Yout[15]~63_combout\);

-- Location: LCCOMB_X76_Y11_N16
\TM6|Yout[15]~64\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[15]~64_combout\ = (\YTPM_S1[1]~input_o\ & ((\YTPM_S1[0]~input_o\ & (\L_33|I1\(15))) # (!\YTPM_S1[0]~input_o\ & ((\TM6|Yout[15]~63_combout\))))) # (!\YTPM_S1[1]~input_o\ & (((\TM6|Yout[15]~63_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111011110000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPM_S1[1]~input_o\,
	datab => \YTPM_S1[0]~input_o\,
	datac => \L_33|I1\(15),
	datad => \TM6|Yout[15]~63_combout\,
	combout => \TM6|Yout[15]~64_combout\);

-- Location: LCCOMB_X76_Y11_N18
\TM6|Yout[15]~65\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[15]~65_combout\ = (\YTPM_S1[2]~input_o\ & (\L_54|I1\(15))) # (!\YTPM_S1[2]~input_o\ & ((\TM6|Yout[15]~64_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \YTPM_S1[2]~input_o\,
	datac => \L_54|I1\(15),
	datad => \TM6|Yout[15]~64_combout\,
	combout => \TM6|Yout[15]~65_combout\);

-- Location: LCCOMB_X76_Y11_N26
\TM7|I1[15]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM7|I1\(15) = (GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM7|I1\(15))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM6|Yout[15]~65_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TTS~inputclkctrl_outclk\,
	datac => \TM7|I1\(15),
	datad => \TM6|Yout[15]~65_combout\,
	combout => \TM7|I1\(15));

-- Location: LCCOMB_X72_Y7_N18
\L_6|I2[15]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I2\(15) = (GLOBAL(\L_6|Equal0~1clkctrl_outclk\) & ((\TM7|I0\(15)))) # (!GLOBAL(\L_6|Equal0~1clkctrl_outclk\) & (\L_6|I2\(15)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_6|I2\(15),
	datac => \TM7|I0\(15),
	datad => \L_6|Equal0~1clkctrl_outclk\,
	combout => \L_6|I2\(15));

-- Location: LCCOMB_X72_Y7_N12
\L_50|Yout[15]~30\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_50|Yout[15]~30_combout\ = (\L_6|I2\(15)) # ((\TM8|Equal3~0_combout\ & \TM7|I1\(15)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM8|Equal3~0_combout\,
	datac => \TM7|I1\(15),
	datad => \L_6|I2\(15),
	combout => \L_50|Yout[15]~30_combout\);

-- Location: LCCOMB_X72_Y7_N0
\L_50|Yout[15]~31\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_50|Yout[15]~31_combout\ = (\A2S2~input_o\ & (\L_12|I1\(15))) # (!\A2S2~input_o\ & ((\L_50|Yout[15]~30_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \A2S2~input_o\,
	datab => \L_12|I1\(15),
	datad => \L_50|Yout[15]~30_combout\,
	combout => \L_50|Yout[15]~31_combout\);

-- Location: LCCOMB_X72_Y7_N30
\L_48|Yout[15]~15\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_48|Yout[15]~15_combout\ = (\A2S1~input_o\ & (\L_12|I1\(15))) # (!\A2S1~input_o\ & ((\L_50|Yout[15]~30_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_12|I1\(15),
	datac => \A2S1~input_o\,
	datad => \L_50|Yout[15]~30_combout\,
	combout => \L_48|Yout[15]~15_combout\);

-- Location: LCCOMB_X76_Y7_N24
\L_52|O[12]~24\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_52|O[12]~24_combout\ = ((\L_48|Yout[12]~12_combout\ $ (\L_50|Yout[12]~25_combout\ $ (!\L_52|O[11]~23\)))) # (GND)
-- \L_52|O[12]~25\ = CARRY((\L_48|Yout[12]~12_combout\ & ((\L_50|Yout[12]~25_combout\) # (!\L_52|O[11]~23\))) # (!\L_48|Yout[12]~12_combout\ & (\L_50|Yout[12]~25_combout\ & !\L_52|O[11]~23\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100110001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_48|Yout[12]~12_combout\,
	datab => \L_50|Yout[12]~25_combout\,
	datad => VCC,
	cin => \L_52|O[11]~23\,
	combout => \L_52|O[12]~24_combout\,
	cout => \L_52|O[12]~25\);

-- Location: LCCOMB_X76_Y7_N26
\L_52|O[13]~26\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_52|O[13]~26_combout\ = (\L_50|Yout[13]~27_combout\ & ((\L_48|Yout[13]~13_combout\ & (\L_52|O[12]~25\ & VCC)) # (!\L_48|Yout[13]~13_combout\ & (!\L_52|O[12]~25\)))) # (!\L_50|Yout[13]~27_combout\ & ((\L_48|Yout[13]~13_combout\ & (!\L_52|O[12]~25\)) # 
-- (!\L_48|Yout[13]~13_combout\ & ((\L_52|O[12]~25\) # (GND)))))
-- \L_52|O[13]~27\ = CARRY((\L_50|Yout[13]~27_combout\ & (!\L_48|Yout[13]~13_combout\ & !\L_52|O[12]~25\)) # (!\L_50|Yout[13]~27_combout\ & ((!\L_52|O[12]~25\) # (!\L_48|Yout[13]~13_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011000010111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_50|Yout[13]~27_combout\,
	datab => \L_48|Yout[13]~13_combout\,
	datad => VCC,
	cin => \L_52|O[12]~25\,
	combout => \L_52|O[13]~26_combout\,
	cout => \L_52|O[13]~27\);

-- Location: LCCOMB_X76_Y7_N28
\L_52|O[14]~28\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_52|O[14]~28_combout\ = ((\L_48|Yout[14]~14_combout\ $ (\L_50|Yout[14]~29_combout\ $ (!\L_52|O[13]~27\)))) # (GND)
-- \L_52|O[14]~29\ = CARRY((\L_48|Yout[14]~14_combout\ & ((\L_50|Yout[14]~29_combout\) # (!\L_52|O[13]~27\))) # (!\L_48|Yout[14]~14_combout\ & (\L_50|Yout[14]~29_combout\ & !\L_52|O[13]~27\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100110001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_48|Yout[14]~14_combout\,
	datab => \L_50|Yout[14]~29_combout\,
	datad => VCC,
	cin => \L_52|O[13]~27\,
	combout => \L_52|O[14]~28_combout\,
	cout => \L_52|O[14]~29\);

-- Location: LCCOMB_X76_Y7_N30
\L_52|O[15]~30\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_52|O[15]~30_combout\ = \L_50|Yout[15]~31_combout\ $ (\L_52|O[14]~29\ $ (\L_48|Yout[15]~15_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100111100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \L_50|Yout[15]~31_combout\,
	datad => \L_48|Yout[15]~15_combout\,
	cin => \L_52|O[14]~29\,
	combout => \L_52|O[15]~30_combout\);

-- Location: LCCOMB_X76_Y9_N12
\L_54|I1[15]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_54|I1\(15) = (GLOBAL(\A2S3~inputclkctrl_outclk\) & (\L_54|I1\(15))) # (!GLOBAL(\A2S3~inputclkctrl_outclk\) & ((\L_52|O[15]~30_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_54|I1\(15),
	datac => \A2S3~inputclkctrl_outclk\,
	datad => \L_52|O[15]~30_combout\,
	combout => \L_54|I1\(15));

-- Location: LCCOMB_X76_Y11_N0
\TM6|Yout[15]~96\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[15]~96_combout\ = (\YMS1[0]~input_o\ & (\YMS1[1]~input_o\)) # (!\YMS1[0]~input_o\ & ((\YMS1[1]~input_o\ & ((\L_33|I0\(15)))) # (!\YMS1[1]~input_o\ & (\L_54|I1\(15)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110010011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YMS1[0]~input_o\,
	datab => \YMS1[1]~input_o\,
	datac => \L_54|I1\(15),
	datad => \L_33|I0\(15),
	combout => \TM6|Yout[15]~96_combout\);

-- Location: LCCOMB_X76_Y11_N10
\TM6|Yout[15]~97\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[15]~97_combout\ = (\YMS1[0]~input_o\ & ((\TM6|Yout[15]~96_combout\ & (\v3[15]~input_o\)) # (!\TM6|Yout[15]~96_combout\ & ((\L_33|I1\(15)))))) # (!\YMS1[0]~input_o\ & (((\TM6|Yout[15]~96_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YMS1[0]~input_o\,
	datab => \v3[15]~input_o\,
	datac => \L_33|I1\(15),
	datad => \TM6|Yout[15]~96_combout\,
	combout => \TM6|Yout[15]~97_combout\);

-- Location: LCCOMB_X76_Y11_N4
\TM7|I0[15]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM7|I0\(15) = (GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM6|Yout[15]~97_combout\))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM7|I0\(15)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111001000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TTS~inputclkctrl_outclk\,
	datab => \TM7|I0\(15),
	datad => \TM6|Yout[15]~97_combout\,
	combout => \TM7|I0\(15));

-- Location: LCCOMB_X76_Y19_N8
\L_6|I0[15]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I0\(15) = (GLOBAL(\L_6|I0[15]~0clkctrl_outclk\) & ((\L_6|I0\(15)))) # (!GLOBAL(\L_6|I0[15]~0clkctrl_outclk\) & (\TM7|I0\(15)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM7|I0\(15),
	datac => \L_6|I0\(15),
	datad => \L_6|I0[15]~0clkctrl_outclk\,
	combout => \L_6|I0\(15));

-- Location: LCCOMB_X75_Y19_N16
\L_36|Yout[15]~15\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_36|Yout[15]~15_combout\ = (\L_6|I0\(15)) # ((\TM8|Equal0~0_combout\ & \TM7|I1\(15)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM8|Equal0~0_combout\,
	datac => \L_6|I0\(15),
	datad => \TM7|I1\(15),
	combout => \L_36|Yout[15]~15_combout\);

-- Location: LCCOMB_X75_Y19_N14
\L_34|Yout[15]~16\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_34|Yout[15]~16_combout\ = (\M4S1~input_o\ & ((\L_36|Yout[15]~15_combout\) # ((\L_34|Yout[0]~0_combout\ & \L_7|Mux0~3_combout\)))) # (!\M4S1~input_o\ & (((\L_34|Yout[0]~0_combout\ & \L_7|Mux0~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M4S1~input_o\,
	datab => \L_36|Yout[15]~15_combout\,
	datac => \L_34|Yout[0]~0_combout\,
	datad => \L_7|Mux0~3_combout\,
	combout => \L_34|Yout[15]~16_combout\);

-- Location: LCCOMB_X73_Y12_N12
\L_40|I0[0]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_40|I0\(0) = (GLOBAL(\M4S3~inputclkctrl_outclk\) & ((\L_38|Mult0|auto_generated|mac_out2~dataout\))) # (!GLOBAL(\M4S3~inputclkctrl_outclk\) & (\L_40|I0\(0)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_40|I0\(0),
	datac => \M4S3~inputclkctrl_outclk\,
	datad => \L_38|Mult0|auto_generated|mac_out2~dataout\,
	combout => \L_40|I0\(0));

-- Location: LCCOMB_X75_Y12_N14
\L_57|Yout[0]~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_57|Yout[0]~0_combout\ = (\L_3|I1\(0) & ((\TTS~input_o\) # ((\L_55|Yout[0]~0_combout\ & \TM7|I1\(0))))) # (!\L_3|I1\(0) & (((\L_55|Yout[0]~0_combout\ & \TM7|I1\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_3|I1\(0),
	datab => \TTS~input_o\,
	datac => \L_55|Yout[0]~0_combout\,
	datad => \TM7|I1\(0),
	combout => \L_57|Yout[0]~0_combout\);

-- Location: LCCOMB_X75_Y12_N24
\L_12|I3[0]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I3\(0) = (GLOBAL(\L_12|Equal0~0clkctrl_outclk\) & (\L_12|I3\(0))) # (!GLOBAL(\L_12|Equal0~0clkctrl_outclk\) & ((\L_10|Yout[0]~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_12|I3\(0),
	datac => \L_10|Yout[0]~1_combout\,
	datad => \L_12|Equal0~0clkctrl_outclk\,
	combout => \L_12|I3\(0));

-- Location: LCCOMB_X75_Y12_N22
\L_57|Yout[0]~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_57|Yout[0]~1_combout\ = (\A3S2~input_o\ & (\L_57|Yout[0]~0_combout\)) # (!\A3S2~input_o\ & ((\L_12|I3\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \A3S2~input_o\,
	datac => \L_57|Yout[0]~0_combout\,
	datad => \L_12|I3\(0),
	combout => \L_57|Yout[0]~1_combout\);

-- Location: LCCOMB_X76_Y12_N0
\L_59|O[0]~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_59|O[0]~0_combout\ = (\L_55|Yout[0]~2_combout\ & (\L_57|Yout[0]~1_combout\ $ (VCC))) # (!\L_55|Yout[0]~2_combout\ & (\L_57|Yout[0]~1_combout\ & VCC))
-- \L_59|O[0]~1\ = CARRY((\L_55|Yout[0]~2_combout\ & \L_57|Yout[0]~1_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110011010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_55|Yout[0]~2_combout\,
	datab => \L_57|Yout[0]~1_combout\,
	datad => VCC,
	combout => \L_59|O[0]~0_combout\,
	cout => \L_59|O[0]~1\);

-- Location: LCCOMB_X72_Y12_N12
\L_61|I0[0]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_61|I0\(0) = (GLOBAL(\A3S3~inputclkctrl_outclk\) & (\L_59|O[0]~0_combout\)) # (!GLOBAL(\A3S3~inputclkctrl_outclk\) & ((\L_61|I0\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_59|O[0]~0_combout\,
	datac => \A3S3~inputclkctrl_outclk\,
	datad => \L_61|I0\(0),
	combout => \L_61|I0\(0));

-- Location: LCCOMB_X72_Y12_N8
\TM2|Yout[0]~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[0]~0_combout\ = (\BMS1[1]~input_o\ & (!\BMS1[0]~input_o\)) # (!\BMS1[1]~input_o\ & ((\L_61|I0\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011111100001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \BMS1[1]~input_o\,
	datac => \BMS1[0]~input_o\,
	datad => \L_61|I0\(0),
	combout => \TM2|Yout[0]~0_combout\);

-- Location: LCCOMB_X75_Y12_N20
\TM2|Yout[0]~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[0]~1_combout\ = (\BMS1[1]~input_o\ & ((\TM2|Yout[0]~0_combout\ & ((\L_40|I0\(0)))) # (!\TM2|Yout[0]~0_combout\ & (\v2[0]~input_o\)))) # (!\BMS1[1]~input_o\ & (((\TM2|Yout[0]~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \BMS1[1]~input_o\,
	datab => \v2[0]~input_o\,
	datac => \L_40|I0\(0),
	datad => \TM2|Yout[0]~0_combout\,
	combout => \TM2|Yout[0]~1_combout\);

-- Location: LCCOMB_X75_Y12_N0
\TM3|I0[0]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM3|I0\(0) = (GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM2|Yout[0]~1_combout\))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM3|I0\(0)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM3|I0\(0),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM2|Yout[0]~1_combout\,
	combout => \TM3|I0\(0));

-- Location: LCCOMB_X71_Y10_N22
\L_3|I2[0]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I2\(0) = (GLOBAL(\L_3|Equal0~1clkctrl_outclk\) & ((\TM3|I0\(0)))) # (!GLOBAL(\L_3|Equal0~1clkctrl_outclk\) & (\L_3|I2\(0)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_3|I2\(0),
	datac => \TM3|I0\(0),
	datad => \L_3|Equal0~1clkctrl_outclk\,
	combout => \L_3|I2\(0));

-- Location: LCCOMB_X71_Y10_N20
\L_3|I0[0]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I0\(0) = (GLOBAL(\L_3|I0[15]~0clkctrl_outclk\) & (\L_3|I0\(0))) # (!GLOBAL(\L_3|I0[15]~0clkctrl_outclk\) & ((\TM3|I0\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_3|I0\(0),
	datac => \TM3|I0\(0),
	datad => \L_3|I0[15]~0clkctrl_outclk\,
	combout => \L_3|I0\(0));

-- Location: LCCOMB_X71_Y10_N28
\L_29|Yout[0]~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_29|Yout[0]~0_combout\ = (\M3S2~input_o\ & ((\TM4|I0\(0)) # ((\L_3|I0\(0))))) # (!\M3S2~input_o\ & (((\L_3|I2\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M3S2~input_o\,
	datab => \TM4|I0\(0),
	datac => \L_3|I2\(0),
	datad => \L_3|I0\(0),
	combout => \L_29|Yout[0]~0_combout\);

-- Location: LCCOMB_X73_Y10_N2
\L_33|I0[14]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_33|I0\(14) = (GLOBAL(\M3S3~inputclkctrl_outclk\) & ((\L_31|Mult0|auto_generated|mac_out2~DATAOUT14\))) # (!GLOBAL(\M3S3~inputclkctrl_outclk\) & (\L_33|I0\(14)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_33|I0\(14),
	datac => \L_31|Mult0|auto_generated|mac_out2~DATAOUT14\,
	datad => \M3S3~inputclkctrl_outclk\,
	combout => \L_33|I0\(14));

-- Location: LCCOMB_X73_Y10_N20
\L_33|I1[14]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_33|I1\(14) = (GLOBAL(\M3S3~inputclkctrl_outclk\) & (\L_33|I1\(14))) # (!GLOBAL(\M3S3~inputclkctrl_outclk\) & ((\L_31|Mult0|auto_generated|mac_out2~DATAOUT14\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_33|I1\(14),
	datac => \L_31|Mult0|auto_generated|mac_out2~DATAOUT14\,
	datad => \M3S3~inputclkctrl_outclk\,
	combout => \L_33|I1\(14));

-- Location: LCCOMB_X73_Y10_N24
\TM6|Yout[14]~94\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[14]~94_combout\ = (\YMS1[1]~input_o\ & (((\YMS1[0]~input_o\)))) # (!\YMS1[1]~input_o\ & ((\YMS1[0]~input_o\ & ((\L_33|I1\(14)))) # (!\YMS1[0]~input_o\ & (\L_54|I1\(14)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001011000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_54|I1\(14),
	datab => \YMS1[1]~input_o\,
	datac => \YMS1[0]~input_o\,
	datad => \L_33|I1\(14),
	combout => \TM6|Yout[14]~94_combout\);

-- Location: LCCOMB_X73_Y10_N6
\TM6|Yout[14]~95\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[14]~95_combout\ = (\YMS1[1]~input_o\ & ((\TM6|Yout[14]~94_combout\ & (\v3[14]~input_o\)) # (!\TM6|Yout[14]~94_combout\ & ((\L_33|I0\(14)))))) # (!\YMS1[1]~input_o\ & (((\TM6|Yout[14]~94_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v3[14]~input_o\,
	datab => \YMS1[1]~input_o\,
	datac => \L_33|I0\(14),
	datad => \TM6|Yout[14]~94_combout\,
	combout => \TM6|Yout[14]~95_combout\);

-- Location: LCCOMB_X73_Y10_N22
\TM7|I0[14]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM7|I0\(14) = (GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM6|Yout[14]~95_combout\))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM7|I0\(14)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM7|I0\(14),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM6|Yout[14]~95_combout\,
	combout => \TM7|I0\(14));

-- Location: LCCOMB_X72_Y7_N26
\L_6|I2[14]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I2\(14) = (GLOBAL(\L_6|Equal0~1clkctrl_outclk\) & ((\TM7|I0\(14)))) # (!GLOBAL(\L_6|Equal0~1clkctrl_outclk\) & (\L_6|I2\(14)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_6|I2\(14),
	datac => \TM7|I0\(14),
	datad => \L_6|Equal0~1clkctrl_outclk\,
	combout => \L_6|I2\(14));

-- Location: LCCOMB_X72_Y7_N2
\L_50|Yout[14]~28\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_50|Yout[14]~28_combout\ = (\L_6|I2\(14)) # ((\TM8|Equal3~0_combout\ & \TM7|I1\(14)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM8|Equal3~0_combout\,
	datac => \L_6|I2\(14),
	datad => \TM7|I1\(14),
	combout => \L_50|Yout[14]~28_combout\);

-- Location: LCCOMB_X72_Y7_N14
\L_50|Yout[14]~29\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_50|Yout[14]~29_combout\ = (\A2S2~input_o\ & (\L_12|I1\(14))) # (!\A2S2~input_o\ & ((\L_50|Yout[14]~28_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \A2S2~input_o\,
	datac => \L_12|I1\(14),
	datad => \L_50|Yout[14]~28_combout\,
	combout => \L_50|Yout[14]~29_combout\);

-- Location: LCCOMB_X72_Y9_N16
\L_54|I1[14]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_54|I1\(14) = (GLOBAL(\A2S3~inputclkctrl_outclk\) & (\L_54|I1\(14))) # (!GLOBAL(\A2S3~inputclkctrl_outclk\) & ((\L_52|O[14]~28_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \A2S3~inputclkctrl_outclk\,
	datab => \L_54|I1\(14),
	datad => \L_52|O[14]~28_combout\,
	combout => \L_54|I1\(14));

-- Location: LCCOMB_X73_Y14_N14
\TM6|Yout[14]~58\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[14]~58_combout\ = (!\YTPM_S1[1]~input_o\ & ((\L_40|I0\(14)) # (!\YTPM_S1[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000110011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \YTPM_S1[1]~input_o\,
	datac => \L_40|I0\(14),
	datad => \YTPM_S1[0]~input_o\,
	combout => \TM6|Yout[14]~58_combout\);

-- Location: LCCOMB_X73_Y14_N4
\TM6|Yout[14]~59\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[14]~59_combout\ = (\TM6|Yout[0]~0_combout\ & ((\TM6|Yout[14]~58_combout\ & (\v3[14]~input_o\)) # (!\TM6|Yout[14]~58_combout\ & ((\L_61|I0\(14)))))) # (!\TM6|Yout[0]~0_combout\ & (((\TM6|Yout[14]~58_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011110010110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v3[14]~input_o\,
	datab => \TM6|Yout[0]~0_combout\,
	datac => \TM6|Yout[14]~58_combout\,
	datad => \L_61|I0\(14),
	combout => \TM6|Yout[14]~59_combout\);

-- Location: LCCOMB_X73_Y14_N10
\TM6|Yout[14]~60\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[14]~60_combout\ = (\YTPM_S1[0]~input_o\ & ((\YTPM_S1[1]~input_o\ & ((\L_33|I1\(14)))) # (!\YTPM_S1[1]~input_o\ & (\TM6|Yout[14]~59_combout\)))) # (!\YTPM_S1[0]~input_o\ & (((\TM6|Yout[14]~59_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100001110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPM_S1[0]~input_o\,
	datab => \YTPM_S1[1]~input_o\,
	datac => \TM6|Yout[14]~59_combout\,
	datad => \L_33|I1\(14),
	combout => \TM6|Yout[14]~60_combout\);

-- Location: LCCOMB_X73_Y14_N20
\TM6|Yout[14]~61\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[14]~61_combout\ = (\YTPM_S1[2]~input_o\ & (\L_54|I1\(14))) # (!\YTPM_S1[2]~input_o\ & ((\TM6|Yout[14]~60_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPM_S1[2]~input_o\,
	datac => \L_54|I1\(14),
	datad => \TM6|Yout[14]~60_combout\,
	combout => \TM6|Yout[14]~61_combout\);

-- Location: LCCOMB_X73_Y14_N18
\TM7|I1[14]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM7|I1\(14) = (GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM7|I1\(14))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM6|Yout[14]~61_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM7|I1\(14),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM6|Yout[14]~61_combout\,
	combout => \TM7|I1\(14));

-- Location: LCCOMB_X76_Y15_N28
\L_57|Yout[14]~28\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_57|Yout[14]~28_combout\ = (\L_3|I1\(14) & ((\TTS~input_o\) # ((\L_55|Yout[0]~0_combout\ & \TM7|I1\(14))))) # (!\L_3|I1\(14) & (((\L_55|Yout[0]~0_combout\ & \TM7|I1\(14)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_3|I1\(14),
	datab => \TTS~input_o\,
	datac => \L_55|Yout[0]~0_combout\,
	datad => \TM7|I1\(14),
	combout => \L_57|Yout[14]~28_combout\);

-- Location: LCCOMB_X75_Y12_N30
\L_55|Yout[14]~16\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_55|Yout[14]~16_combout\ = (\L_55|Yout[15]~1_combout\ & ((\L_7|Mux1~3_combout\) # ((\A3S1~input_o\ & \L_57|Yout[14]~28_combout\)))) # (!\L_55|Yout[15]~1_combout\ & (\A3S1~input_o\ & ((\L_57|Yout[14]~28_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_55|Yout[15]~1_combout\,
	datab => \A3S1~input_o\,
	datac => \L_7|Mux1~3_combout\,
	datad => \L_57|Yout[14]~28_combout\,
	combout => \L_55|Yout[14]~16_combout\);

-- Location: LCCOMB_X73_Y14_N24
\L_61|I0[14]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_61|I0\(14) = (GLOBAL(\A3S3~inputclkctrl_outclk\) & ((\L_59|O[14]~28_combout\))) # (!GLOBAL(\A3S3~inputclkctrl_outclk\) & (\L_61|I0\(14)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_61|I0\(14),
	datac => \A3S3~inputclkctrl_outclk\,
	datad => \L_59|O[14]~28_combout\,
	combout => \L_61|I0\(14));

-- Location: LCCOMB_X73_Y14_N2
\TM2|Yout[14]~29\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[14]~29_combout\ = (\BMS1[1]~input_o\ & (!\BMS1[0]~input_o\)) # (!\BMS1[1]~input_o\ & ((\L_61|I0\(14))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101111100001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \BMS1[1]~input_o\,
	datac => \BMS1[0]~input_o\,
	datad => \L_61|I0\(14),
	combout => \TM2|Yout[14]~29_combout\);

-- Location: LCCOMB_X73_Y14_N16
\TM2|Yout[14]~30\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[14]~30_combout\ = (\BMS1[1]~input_o\ & ((\TM2|Yout[14]~29_combout\ & ((\L_40|I0\(14)))) # (!\TM2|Yout[14]~29_combout\ & (\v2[14]~input_o\)))) # (!\BMS1[1]~input_o\ & (((\TM2|Yout[14]~29_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v2[14]~input_o\,
	datab => \BMS1[1]~input_o\,
	datac => \L_40|I0\(14),
	datad => \TM2|Yout[14]~29_combout\,
	combout => \TM2|Yout[14]~30_combout\);

-- Location: LCCOMB_X73_Y14_N12
\TM3|I0[14]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM3|I0\(14) = (GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM2|Yout[14]~30_combout\))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM3|I0\(14)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM3|I0\(14),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM2|Yout[14]~30_combout\,
	combout => \TM3|I0\(14));

-- Location: LCCOMB_X79_Y10_N24
\L_3|I2[14]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I2\(14) = (GLOBAL(\L_3|Equal0~1clkctrl_outclk\) & ((\TM3|I0\(14)))) # (!GLOBAL(\L_3|Equal0~1clkctrl_outclk\) & (\L_3|I2\(14)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_3|I2\(14),
	datac => \TM3|I0\(14),
	datad => \L_3|Equal0~1clkctrl_outclk\,
	combout => \L_3|I2\(14));

-- Location: LCCOMB_X79_Y10_N4
\L_27|Yout[14]~14\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_27|Yout[14]~14_combout\ = (\M3S1~input_o\ & (((\L_3|I0\(14)) # (\TM4|I0\(14))))) # (!\M3S1~input_o\ & (\L_3|I2\(14)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111011100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M3S1~input_o\,
	datab => \L_3|I2\(14),
	datac => \L_3|I0\(14),
	datad => \TM4|I0\(14),
	combout => \L_27|Yout[14]~14_combout\);

-- Location: LCCOMB_X76_Y6_N4
\L_33|I1[13]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_33|I1\(13) = (GLOBAL(\M3S3~inputclkctrl_outclk\) & (\L_33|I1\(13))) # (!GLOBAL(\M3S3~inputclkctrl_outclk\) & ((\L_31|Mult0|auto_generated|mac_out2~DATAOUT13\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_33|I1\(13),
	datac => \M3S3~inputclkctrl_outclk\,
	datad => \L_31|Mult0|auto_generated|mac_out2~DATAOUT13\,
	combout => \L_33|I1\(13));

-- Location: LCCOMB_X75_Y15_N28
\L_40|I0[13]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_40|I0\(13) = (GLOBAL(\M4S3~inputclkctrl_outclk\) & ((\L_38|Mult0|auto_generated|mac_out2~DATAOUT13\))) # (!GLOBAL(\M4S3~inputclkctrl_outclk\) & (\L_40|I0\(13)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_40|I0\(13),
	datac => \L_38|Mult0|auto_generated|mac_out2~DATAOUT13\,
	datad => \M4S3~inputclkctrl_outclk\,
	combout => \L_40|I0\(13));

-- Location: LCCOMB_X76_Y6_N0
\TM6|Yout[13]~54\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[13]~54_combout\ = (\YTPM_S1[1]~input_o\ & (((\L_61|I0\(13))))) # (!\YTPM_S1[1]~input_o\ & (((\L_40|I0\(13))) # (!\YTPM_S1[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101101010001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPM_S1[1]~input_o\,
	datab => \YTPM_S1[0]~input_o\,
	datac => \L_40|I0\(13),
	datad => \L_61|I0\(13),
	combout => \TM6|Yout[13]~54_combout\);

-- Location: LCCOMB_X76_Y6_N2
\TM6|Yout[13]~55\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[13]~55_combout\ = (\TM6|Yout[0]~5_combout\ & (((\TM6|Yout[13]~54_combout\)))) # (!\TM6|Yout[0]~5_combout\ & ((\TM6|Yout[13]~54_combout\ & ((\v3[13]~input_o\))) # (!\TM6|Yout[13]~54_combout\ & (\L_33|I0\(13)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_33|I0\(13),
	datab => \v3[13]~input_o\,
	datac => \TM6|Yout[0]~5_combout\,
	datad => \TM6|Yout[13]~54_combout\,
	combout => \TM6|Yout[13]~55_combout\);

-- Location: LCCOMB_X76_Y6_N20
\TM6|Yout[13]~56\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[13]~56_combout\ = (\YTPM_S1[1]~input_o\ & ((\YTPM_S1[0]~input_o\ & (\L_33|I1\(13))) # (!\YTPM_S1[0]~input_o\ & ((\TM6|Yout[13]~55_combout\))))) # (!\YTPM_S1[1]~input_o\ & (((\TM6|Yout[13]~55_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111011110000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPM_S1[1]~input_o\,
	datab => \YTPM_S1[0]~input_o\,
	datac => \L_33|I1\(13),
	datad => \TM6|Yout[13]~55_combout\,
	combout => \TM6|Yout[13]~56_combout\);

-- Location: LCCOMB_X76_Y6_N6
\TM6|Yout[13]~57\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[13]~57_combout\ = (\YTPM_S1[2]~input_o\ & (\L_54|I1\(13))) # (!\YTPM_S1[2]~input_o\ & ((\TM6|Yout[13]~56_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \YTPM_S1[2]~input_o\,
	datac => \L_54|I1\(13),
	datad => \TM6|Yout[13]~56_combout\,
	combout => \TM6|Yout[13]~57_combout\);

-- Location: LCCOMB_X76_Y6_N24
\TM7|I1[13]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM7|I1\(13) = (GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM7|I1\(13))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM6|Yout[13]~57_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM7|I1\(13),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM6|Yout[13]~57_combout\,
	combout => \TM7|I1\(13));

-- Location: LCCOMB_X75_Y7_N10
\L_6|I2[13]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I2\(13) = (GLOBAL(\L_6|Equal0~1clkctrl_outclk\) & ((\TM7|I0\(13)))) # (!GLOBAL(\L_6|Equal0~1clkctrl_outclk\) & (\L_6|I2\(13)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111000100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_6|I2\(13),
	datab => \L_6|Equal0~1clkctrl_outclk\,
	datad => \TM7|I0\(13),
	combout => \L_6|I2\(13));

-- Location: LCCOMB_X75_Y7_N4
\L_50|Yout[13]~26\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_50|Yout[13]~26_combout\ = (\L_6|I2\(13)) # ((\TM8|Equal3~0_combout\ & \TM7|I1\(13)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM8|Equal3~0_combout\,
	datac => \TM7|I1\(13),
	datad => \L_6|I2\(13),
	combout => \L_50|Yout[13]~26_combout\);

-- Location: LCCOMB_X75_Y7_N20
\L_12|I1[13]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I1\(13) = (GLOBAL(\L_12|Equal0~1clkctrl_outclk\) & (\L_10|Yout[13]~27_combout\)) # (!GLOBAL(\L_12|Equal0~1clkctrl_outclk\) & ((\L_12|I1\(13))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_10|Yout[13]~27_combout\,
	datac => \L_12|Equal0~1clkctrl_outclk\,
	datad => \L_12|I1\(13),
	combout => \L_12|I1\(13));

-- Location: LCCOMB_X75_Y7_N18
\L_48|Yout[13]~13\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_48|Yout[13]~13_combout\ = (\A2S1~input_o\ & ((\L_12|I1\(13)))) # (!\A2S1~input_o\ & (\L_50|Yout[13]~26_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \A2S1~input_o\,
	datac => \L_50|Yout[13]~26_combout\,
	datad => \L_12|I1\(13),
	combout => \L_48|Yout[13]~13_combout\);

-- Location: LCCOMB_X77_Y5_N4
\L_54|I0[13]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_54|I0\(13) = (GLOBAL(\A2S3~inputclkctrl_outclk\) & ((\L_52|O[13]~26_combout\))) # (!GLOBAL(\A2S3~inputclkctrl_outclk\) & (\L_54|I0\(13)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \A2S3~inputclkctrl_outclk\,
	datac => \L_54|I0\(13),
	datad => \L_52|O[13]~26_combout\,
	combout => \L_54|I0\(13));

-- Location: LCCOMB_X77_Y5_N22
\L_26|I1[13]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_26|I1\(13) = (GLOBAL(\M2S3~inputclkctrl_outclk\) & (\L_26|I1\(13))) # (!GLOBAL(\M2S3~inputclkctrl_outclk\) & ((\L_24|Mult0|auto_generated|mac_out2~DATAOUT13\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_26|I1\(13),
	datac => \M2S3~inputclkctrl_outclk\,
	datad => \L_24|Mult0|auto_generated|mac_out2~DATAOUT13\,
	combout => \L_26|I1\(13));

-- Location: LCCOMB_X77_Y5_N30
\L_10|Yout[13]~26\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_10|Yout[13]~26_combout\ = (\GMS1[0]~input_o\ & ((\GMS1[1]~input_o\) # ((\L_54|I0\(13))))) # (!\GMS1[0]~input_o\ & (!\GMS1[1]~input_o\ & ((\L_26|I1\(13)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011100110101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \GMS1[0]~input_o\,
	datab => \GMS1[1]~input_o\,
	datac => \L_54|I0\(13),
	datad => \L_26|I1\(13),
	combout => \L_10|Yout[13]~26_combout\);

-- Location: IOIBUF_X117_Y5_N1
\v1[13]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v1(13),
	o => \v1[13]~input_o\);

-- Location: LCCOMB_X77_Y5_N24
\L_10|Yout[13]~27\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_10|Yout[13]~27_combout\ = (\GMS1[1]~input_o\ & ((\L_10|Yout[13]~26_combout\ & ((\v1[13]~input_o\))) # (!\L_10|Yout[13]~26_combout\ & (\L_26|I0\(13))))) # (!\GMS1[1]~input_o\ & (((\L_10|Yout[13]~26_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100000111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_26|I0\(13),
	datab => \GMS1[1]~input_o\,
	datac => \L_10|Yout[13]~26_combout\,
	datad => \v1[13]~input_o\,
	combout => \L_10|Yout[13]~27_combout\);

-- Location: LCCOMB_X76_Y8_N2
\L_12|I0[13]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I0\(13) = (GLOBAL(\L_12|I0[15]~0clkctrl_outclk\) & (\L_12|I0\(13))) # (!GLOBAL(\L_12|I0[15]~0clkctrl_outclk\) & ((\L_10|Yout[13]~27_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_12|I0\(13),
	datac => \L_10|Yout[13]~27_combout\,
	datad => \L_12|I0[15]~0clkctrl_outclk\,
	combout => \L_12|I0\(13));

-- Location: LCCOMB_X73_Y8_N10
\L_12|I2[13]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I2\(13) = (GLOBAL(\L_12|Equal0~2clkctrl_outclk\) & (\L_10|Yout[13]~27_combout\)) # (!GLOBAL(\L_12|Equal0~2clkctrl_outclk\) & ((\L_12|I2\(13))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_12|Equal0~2clkctrl_outclk\,
	datac => \L_10|Yout[13]~27_combout\,
	datad => \L_12|I2\(13),
	combout => \L_12|I2\(13));

-- Location: LCCOMB_X73_Y8_N8
\L_20|Yout[13]~13\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_20|Yout[13]~13_combout\ = (\M2S1~input_o\ & (\L_12|I0\(13))) # (!\M2S1~input_o\ & ((\L_12|I2\(13))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \M2S1~input_o\,
	datac => \L_12|I0\(13),
	datad => \L_12|I2\(13),
	combout => \L_20|Yout[13]~13_combout\);

-- Location: LCCOMB_X75_Y8_N24
\L_26|I1[11]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_26|I1\(11) = (GLOBAL(\M2S3~inputclkctrl_outclk\) & (\L_26|I1\(11))) # (!GLOBAL(\M2S3~inputclkctrl_outclk\) & ((\L_24|Mult0|auto_generated|mac_out2~DATAOUT11\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_26|I1\(11),
	datac => \L_24|Mult0|auto_generated|mac_out2~DATAOUT11\,
	datad => \M2S3~inputclkctrl_outclk\,
	combout => \L_26|I1\(11));

-- Location: LCCOMB_X75_Y8_N18
\L_54|I0[11]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_54|I0\(11) = (GLOBAL(\A2S3~inputclkctrl_outclk\) & ((\L_52|O[11]~22_combout\))) # (!GLOBAL(\A2S3~inputclkctrl_outclk\) & (\L_54|I0\(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_54|I0\(11),
	datac => \A2S3~inputclkctrl_outclk\,
	datad => \L_52|O[11]~22_combout\,
	combout => \L_54|I0\(11));

-- Location: LCCOMB_X75_Y8_N20
\L_10|Yout[11]~22\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_10|Yout[11]~22_combout\ = (\GMS1[0]~input_o\ & (((\L_54|I0\(11)) # (\GMS1[1]~input_o\)))) # (!\GMS1[0]~input_o\ & (\L_26|I1\(11) & ((!\GMS1[1]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \GMS1[0]~input_o\,
	datab => \L_26|I1\(11),
	datac => \L_54|I0\(11),
	datad => \GMS1[1]~input_o\,
	combout => \L_10|Yout[11]~22_combout\);

-- Location: LCCOMB_X75_Y8_N0
\L_26|I0[11]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_26|I0\(11) = (GLOBAL(\M2S3~inputclkctrl_outclk\) & ((\L_24|Mult0|auto_generated|mac_out2~DATAOUT11\))) # (!GLOBAL(\M2S3~inputclkctrl_outclk\) & (\L_26|I0\(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_26|I0\(11),
	datac => \L_24|Mult0|auto_generated|mac_out2~DATAOUT11\,
	datad => \M2S3~inputclkctrl_outclk\,
	combout => \L_26|I0\(11));

-- Location: IOIBUF_X117_Y8_N8
\v1[11]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v1(11),
	o => \v1[11]~input_o\);

-- Location: LCCOMB_X75_Y8_N14
\L_10|Yout[11]~23\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_10|Yout[11]~23_combout\ = (\GMS1[1]~input_o\ & ((\L_10|Yout[11]~22_combout\ & ((\v1[11]~input_o\))) # (!\L_10|Yout[11]~22_combout\ & (\L_26|I0\(11))))) # (!\GMS1[1]~input_o\ & (\L_10|Yout[11]~22_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110001100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \GMS1[1]~input_o\,
	datab => \L_10|Yout[11]~22_combout\,
	datac => \L_26|I0\(11),
	datad => \v1[11]~input_o\,
	combout => \L_10|Yout[11]~23_combout\);

-- Location: LCCOMB_X77_Y8_N22
\L_12|I2[11]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I2\(11) = (GLOBAL(\L_12|Equal0~2clkctrl_outclk\) & ((\L_10|Yout[11]~23_combout\))) # (!GLOBAL(\L_12|Equal0~2clkctrl_outclk\) & (\L_12|I2\(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_12|I2\(11),
	datab => \L_10|Yout[11]~23_combout\,
	datac => \L_12|Equal0~2clkctrl_outclk\,
	combout => \L_12|I2\(11));

-- Location: LCCOMB_X77_Y8_N26
\L_20|Yout[11]~11\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_20|Yout[11]~11_combout\ = (\M2S1~input_o\ & ((\L_12|I0\(11)))) # (!\M2S1~input_o\ & (\L_12|I2\(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M2S1~input_o\,
	datac => \L_12|I2\(11),
	datad => \L_12|I0\(11),
	combout => \L_20|Yout[11]~11_combout\);

-- Location: LCCOMB_X77_Y9_N18
\L_26|I1[12]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_26|I1\(12) = (GLOBAL(\M2S3~inputclkctrl_outclk\) & (\L_26|I1\(12))) # (!GLOBAL(\M2S3~inputclkctrl_outclk\) & ((\L_24|Mult0|auto_generated|mac_out2~DATAOUT12\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_26|I1\(12),
	datac => \M2S3~inputclkctrl_outclk\,
	datad => \L_24|Mult0|auto_generated|mac_out2~DATAOUT12\,
	combout => \L_26|I1\(12));

-- Location: LCCOMB_X77_Y9_N28
\L_26|I0[12]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_26|I0\(12) = (GLOBAL(\M2S3~inputclkctrl_outclk\) & ((\L_24|Mult0|auto_generated|mac_out2~DATAOUT12\))) # (!GLOBAL(\M2S3~inputclkctrl_outclk\) & (\L_26|I0\(12)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_26|I0\(12),
	datac => \M2S3~inputclkctrl_outclk\,
	datad => \L_24|Mult0|auto_generated|mac_out2~DATAOUT12\,
	combout => \L_26|I0\(12));

-- Location: LCCOMB_X77_Y9_N4
\L_10|Yout[12]~24\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_10|Yout[12]~24_combout\ = (\GMS1[1]~input_o\ & (((\GMS1[0]~input_o\) # (\L_26|I0\(12))))) # (!\GMS1[1]~input_o\ & (\L_26|I1\(12) & (!\GMS1[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111010100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \GMS1[1]~input_o\,
	datab => \L_26|I1\(12),
	datac => \GMS1[0]~input_o\,
	datad => \L_26|I0\(12),
	combout => \L_10|Yout[12]~24_combout\);

-- Location: LCCOMB_X77_Y9_N10
\L_10|Yout[12]~25\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_10|Yout[12]~25_combout\ = (\GMS1[0]~input_o\ & ((\L_10|Yout[12]~24_combout\ & (\v1[12]~input_o\)) # (!\L_10|Yout[12]~24_combout\ & ((\L_54|I0\(12)))))) # (!\GMS1[0]~input_o\ & (((\L_10|Yout[12]~24_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \GMS1[0]~input_o\,
	datab => \v1[12]~input_o\,
	datac => \L_54|I0\(12),
	datad => \L_10|Yout[12]~24_combout\,
	combout => \L_10|Yout[12]~25_combout\);

-- Location: LCCOMB_X77_Y9_N20
\L_12|I3[12]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I3\(12) = (GLOBAL(\L_12|Equal0~0clkctrl_outclk\) & (\L_12|I3\(12))) # (!GLOBAL(\L_12|Equal0~0clkctrl_outclk\) & ((\L_10|Yout[12]~25_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_12|I3\(12),
	datac => \L_10|Yout[12]~25_combout\,
	datad => \L_12|Equal0~0clkctrl_outclk\,
	combout => \L_12|I3\(12));

-- Location: LCCOMB_X77_Y13_N18
\L_57|Yout[12]~25\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_57|Yout[12]~25_combout\ = (\A3S2~input_o\ & (\L_57|Yout[12]~24_combout\)) # (!\A3S2~input_o\ & ((\L_12|I3\(12))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \A3S2~input_o\,
	datac => \L_57|Yout[12]~24_combout\,
	datad => \L_12|I3\(12),
	combout => \L_57|Yout[12]~25_combout\);

-- Location: LCCOMB_X78_Y15_N18
\L_61|I0[12]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_61|I0\(12) = (GLOBAL(\A3S3~inputclkctrl_outclk\) & ((\L_59|O[12]~24_combout\))) # (!GLOBAL(\A3S3~inputclkctrl_outclk\) & (\L_61|I0\(12)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_61|I0\(12),
	datac => \L_59|O[12]~24_combout\,
	datad => \A3S3~inputclkctrl_outclk\,
	combout => \L_61|I0\(12));

-- Location: LCCOMB_X78_Y11_N16
\TM6|Yout[12]~50\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[12]~50_combout\ = (!\YTPM_S1[1]~input_o\ & ((\L_40|I0\(12)) # (!\YTPM_S1[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010100000101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPM_S1[1]~input_o\,
	datac => \YTPM_S1[0]~input_o\,
	datad => \L_40|I0\(12),
	combout => \TM6|Yout[12]~50_combout\);

-- Location: LCCOMB_X78_Y11_N22
\TM6|Yout[12]~51\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[12]~51_combout\ = (\TM6|Yout[0]~0_combout\ & ((\TM6|Yout[12]~50_combout\ & (\v3[12]~input_o\)) # (!\TM6|Yout[12]~50_combout\ & ((\L_61|I0\(12)))))) # (!\TM6|Yout[0]~0_combout\ & (((\TM6|Yout[12]~50_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v3[12]~input_o\,
	datab => \TM6|Yout[0]~0_combout\,
	datac => \L_61|I0\(12),
	datad => \TM6|Yout[12]~50_combout\,
	combout => \TM6|Yout[12]~51_combout\);

-- Location: LCCOMB_X78_Y11_N18
\L_33|I1[12]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_33|I1\(12) = (GLOBAL(\M3S3~inputclkctrl_outclk\) & (\L_33|I1\(12))) # (!GLOBAL(\M3S3~inputclkctrl_outclk\) & ((\L_31|Mult0|auto_generated|mac_out2~DATAOUT12\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_33|I1\(12),
	datac => \M3S3~inputclkctrl_outclk\,
	datad => \L_31|Mult0|auto_generated|mac_out2~DATAOUT12\,
	combout => \L_33|I1\(12));

-- Location: LCCOMB_X78_Y11_N28
\TM6|Yout[12]~52\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[12]~52_combout\ = (\YTPM_S1[1]~input_o\ & ((\YTPM_S1[0]~input_o\ & ((\L_33|I1\(12)))) # (!\YTPM_S1[0]~input_o\ & (\TM6|Yout[12]~51_combout\)))) # (!\YTPM_S1[1]~input_o\ & (((\TM6|Yout[12]~51_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100001110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPM_S1[1]~input_o\,
	datab => \YTPM_S1[0]~input_o\,
	datac => \TM6|Yout[12]~51_combout\,
	datad => \L_33|I1\(12),
	combout => \TM6|Yout[12]~52_combout\);

-- Location: LCCOMB_X78_Y11_N2
\TM6|Yout[12]~53\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[12]~53_combout\ = (\YTPM_S1[2]~input_o\ & (\L_54|I1\(12))) # (!\YTPM_S1[2]~input_o\ & ((\TM6|Yout[12]~52_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \YTPM_S1[2]~input_o\,
	datac => \L_54|I1\(12),
	datad => \TM6|Yout[12]~52_combout\,
	combout => \TM6|Yout[12]~53_combout\);

-- Location: LCCOMB_X78_Y11_N14
\TM7|I1[12]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM7|I1\(12) = (GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM7|I1\(12))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM6|Yout[12]~53_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TTS~inputclkctrl_outclk\,
	datab => \TM7|I1\(12),
	datad => \TM6|Yout[12]~53_combout\,
	combout => \TM7|I1\(12));

-- Location: LCCOMB_X78_Y7_N24
\L_50|Yout[12]~24\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_50|Yout[12]~24_combout\ = (\L_6|I2\(12)) # ((\TM8|Equal3~0_combout\ & \TM7|I1\(12)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM8|Equal3~0_combout\,
	datab => \L_6|I2\(12),
	datad => \TM7|I1\(12),
	combout => \L_50|Yout[12]~24_combout\);

-- Location: LCCOMB_X77_Y7_N14
\L_50|Yout[12]~25\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_50|Yout[12]~25_combout\ = (\A2S2~input_o\ & (\L_12|I1\(12))) # (!\A2S2~input_o\ & ((\L_50|Yout[12]~24_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \A2S2~input_o\,
	datac => \L_12|I1\(12),
	datad => \L_50|Yout[12]~24_combout\,
	combout => \L_50|Yout[12]~25_combout\);

-- Location: LCCOMB_X77_Y9_N24
\L_54|I1[12]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_54|I1\(12) = (GLOBAL(\A2S3~inputclkctrl_outclk\) & (\L_54|I1\(12))) # (!GLOBAL(\A2S3~inputclkctrl_outclk\) & ((\L_52|O[12]~24_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_54|I1\(12),
	datac => \L_52|O[12]~24_combout\,
	datad => \A2S3~inputclkctrl_outclk\,
	combout => \L_54|I1\(12));

-- Location: LCCOMB_X78_Y11_N24
\TM6|Yout[12]~90\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[12]~90_combout\ = (\YMS1[0]~input_o\ & ((\YMS1[1]~input_o\) # ((\L_33|I1\(12))))) # (!\YMS1[0]~input_o\ & (!\YMS1[1]~input_o\ & (\L_54|I1\(12))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101010011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YMS1[0]~input_o\,
	datab => \YMS1[1]~input_o\,
	datac => \L_54|I1\(12),
	datad => \L_33|I1\(12),
	combout => \TM6|Yout[12]~90_combout\);

-- Location: LCCOMB_X78_Y11_N6
\TM6|Yout[12]~91\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[12]~91_combout\ = (\YMS1[1]~input_o\ & ((\TM6|Yout[12]~90_combout\ & (\v3[12]~input_o\)) # (!\TM6|Yout[12]~90_combout\ & ((\L_33|I0\(12)))))) # (!\YMS1[1]~input_o\ & (((\TM6|Yout[12]~90_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v3[12]~input_o\,
	datab => \YMS1[1]~input_o\,
	datac => \L_33|I0\(12),
	datad => \TM6|Yout[12]~90_combout\,
	combout => \TM6|Yout[12]~91_combout\);

-- Location: LCCOMB_X78_Y11_N8
\TM7|I0[12]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM7|I0\(12) = (GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM6|Yout[12]~91_combout\))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM7|I0\(12)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111001000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TTS~inputclkctrl_outclk\,
	datab => \TM7|I0\(12),
	datad => \TM6|Yout[12]~91_combout\,
	combout => \TM7|I0\(12));

-- Location: LCCOMB_X75_Y15_N26
\L_6|I0[12]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I0\(12) = (GLOBAL(\L_6|I0[15]~0clkctrl_outclk\) & (\L_6|I0\(12))) # (!GLOBAL(\L_6|I0[15]~0clkctrl_outclk\) & ((\TM7|I0\(12))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_6|I0[15]~0clkctrl_outclk\,
	datac => \L_6|I0\(12),
	datad => \TM7|I0\(12),
	combout => \L_6|I0\(12));

-- Location: LCCOMB_X75_Y15_N20
\L_36|Yout[12]~12\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_36|Yout[12]~12_combout\ = (\L_6|I0\(12)) # ((\TM8|Equal0~0_combout\ & \TM7|I1\(12)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM8|Equal0~0_combout\,
	datac => \L_6|I0\(12),
	datad => \TM7|I1\(12),
	combout => \L_36|Yout[12]~12_combout\);

-- Location: LCCOMB_X75_Y18_N26
\L_34|Yout[12]~13\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_34|Yout[12]~13_combout\ = (\M4S1~input_o\ & ((\L_36|Yout[12]~12_combout\) # ((\L_34|Yout[0]~0_combout\ & \L_7|Mux3~3_combout\)))) # (!\M4S1~input_o\ & (\L_34|Yout[0]~0_combout\ & ((\L_7|Mux3~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M4S1~input_o\,
	datab => \L_34|Yout[0]~0_combout\,
	datac => \L_36|Yout[12]~12_combout\,
	datad => \L_7|Mux3~3_combout\,
	combout => \L_34|Yout[12]~13_combout\);

-- Location: LCCOMB_X73_Y12_N28
\L_40|I0[11]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_40|I0\(11) = (GLOBAL(\M4S3~inputclkctrl_outclk\) & ((\L_38|Mult0|auto_generated|mac_out2~DATAOUT11\))) # (!GLOBAL(\M4S3~inputclkctrl_outclk\) & (\L_40|I0\(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_40|I0\(11),
	datac => \M4S3~inputclkctrl_outclk\,
	datad => \L_38|Mult0|auto_generated|mac_out2~DATAOUT11\,
	combout => \L_40|I0\(11));

-- Location: LCCOMB_X72_Y12_N4
\TM2|Yout[11]~24\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[11]~24_combout\ = (\TM2|Yout[11]~23_combout\ & (((\L_40|I0\(11)) # (!\TM2|Yout[9]~2_combout\)))) # (!\TM2|Yout[11]~23_combout\ & (\L_61|I0\(11) & (\TM2|Yout[9]~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101001001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM2|Yout[11]~23_combout\,
	datab => \L_61|I0\(11),
	datac => \TM2|Yout[9]~2_combout\,
	datad => \L_40|I0\(11),
	combout => \TM2|Yout[11]~24_combout\);

-- Location: LCCOMB_X72_Y12_N14
\TM3|I0[11]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM3|I0\(11) = (GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM2|Yout[11]~24_combout\))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM3|I0\(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM3|I0\(11),
	datac => \TM2|Yout[11]~24_combout\,
	datad => \TTS~inputclkctrl_outclk\,
	combout => \TM3|I0\(11));

-- Location: LCCOMB_X72_Y12_N2
\L_3|I1[11]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I1\(11) = (GLOBAL(\L_3|Equal0~0clkctrl_outclk\) & ((\TM3|I0\(11)))) # (!GLOBAL(\L_3|Equal0~0clkctrl_outclk\) & (\L_3|I1\(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_3|I1\(11),
	datac => \TM3|I0\(11),
	datad => \L_3|Equal0~0clkctrl_outclk\,
	combout => \L_3|I1\(11));

-- Location: LCCOMB_X76_Y8_N18
\L_57|Yout[11]~22\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_57|Yout[11]~22_combout\ = (\TTS~input_o\ & ((\L_3|I1\(11)) # ((\L_55|Yout[0]~0_combout\ & \TM7|I1\(11))))) # (!\TTS~input_o\ & (\L_55|Yout[0]~0_combout\ & ((\TM7|I1\(11)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TTS~input_o\,
	datab => \L_55|Yout[0]~0_combout\,
	datac => \L_3|I1\(11),
	datad => \TM7|I1\(11),
	combout => \L_57|Yout[11]~22_combout\);

-- Location: LCCOMB_X76_Y11_N20
\L_55|Yout[11]~13\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_55|Yout[11]~13_combout\ = (\L_55|Yout[15]~1_combout\ & ((\L_7|Mux4~3_combout\) # ((\A3S1~input_o\ & \L_57|Yout[11]~22_combout\)))) # (!\L_55|Yout[15]~1_combout\ & (\A3S1~input_o\ & ((\L_57|Yout[11]~22_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_55|Yout[15]~1_combout\,
	datab => \A3S1~input_o\,
	datac => \L_7|Mux4~3_combout\,
	datad => \L_57|Yout[11]~22_combout\,
	combout => \L_55|Yout[11]~13_combout\);

-- Location: LCCOMB_X72_Y12_N16
\L_61|I0[11]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_61|I0\(11) = (GLOBAL(\A3S3~inputclkctrl_outclk\) & ((\L_59|O[11]~22_combout\))) # (!GLOBAL(\A3S3~inputclkctrl_outclk\) & (\L_61|I0\(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_61|I0\(11),
	datac => \A3S3~inputclkctrl_outclk\,
	datad => \L_59|O[11]~22_combout\,
	combout => \L_61|I0\(11));

-- Location: LCCOMB_X73_Y12_N30
\TM6|Yout[11]~46\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[11]~46_combout\ = (\YTPM_S1[1]~input_o\ & (((\L_61|I0\(11))))) # (!\YTPM_S1[1]~input_o\ & (((\L_40|I0\(11))) # (!\YTPM_S1[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111010001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPM_S1[0]~input_o\,
	datab => \YTPM_S1[1]~input_o\,
	datac => \L_61|I0\(11),
	datad => \L_40|I0\(11),
	combout => \TM6|Yout[11]~46_combout\);

-- Location: LCCOMB_X73_Y12_N20
\TM6|Yout[11]~47\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[11]~47_combout\ = (\TM6|Yout[0]~5_combout\ & (((\TM6|Yout[11]~46_combout\)))) # (!\TM6|Yout[0]~5_combout\ & ((\TM6|Yout[11]~46_combout\ & (\v3[11]~input_o\)) # (!\TM6|Yout[11]~46_combout\ & ((\L_33|I0\(11))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110001111100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v3[11]~input_o\,
	datab => \TM6|Yout[0]~5_combout\,
	datac => \TM6|Yout[11]~46_combout\,
	datad => \L_33|I0\(11),
	combout => \TM6|Yout[11]~47_combout\);

-- Location: LCCOMB_X73_Y12_N10
\TM6|Yout[11]~48\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[11]~48_combout\ = (\YTPM_S1[0]~input_o\ & ((\YTPM_S1[1]~input_o\ & (\L_33|I1\(11))) # (!\YTPM_S1[1]~input_o\ & ((\TM6|Yout[11]~47_combout\))))) # (!\YTPM_S1[0]~input_o\ & (((\TM6|Yout[11]~47_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111011110000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPM_S1[0]~input_o\,
	datab => \YTPM_S1[1]~input_o\,
	datac => \L_33|I1\(11),
	datad => \TM6|Yout[11]~47_combout\,
	combout => \TM6|Yout[11]~48_combout\);

-- Location: LCCOMB_X73_Y12_N0
\TM6|Yout[11]~49\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[11]~49_combout\ = (\YTPM_S1[2]~input_o\ & (\L_54|I1\(11))) # (!\YTPM_S1[2]~input_o\ & ((\TM6|Yout[11]~48_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \YTPM_S1[2]~input_o\,
	datac => \L_54|I1\(11),
	datad => \TM6|Yout[11]~48_combout\,
	combout => \TM6|Yout[11]~49_combout\);

-- Location: LCCOMB_X73_Y12_N8
\TM7|I1[11]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM7|I1\(11) = (GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM7|I1\(11))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM6|Yout[11]~49_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM7|I1\(11),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM6|Yout[11]~49_combout\,
	combout => \TM7|I1\(11));

-- Location: LCCOMB_X75_Y15_N0
\L_6|I0[11]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I0\(11) = (GLOBAL(\L_6|I0[15]~0clkctrl_outclk\) & (\L_6|I0\(11))) # (!GLOBAL(\L_6|I0[15]~0clkctrl_outclk\) & ((\TM7|I0\(11))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_6|I0\(11),
	datac => \TM7|I0\(11),
	datad => \L_6|I0[15]~0clkctrl_outclk\,
	combout => \L_6|I0\(11));

-- Location: LCCOMB_X75_Y15_N24
\L_36|Yout[11]~11\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_36|Yout[11]~11_combout\ = (\L_6|I0\(11)) # ((\TM8|Equal0~0_combout\ & \TM7|I1\(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM8|Equal0~0_combout\,
	datac => \TM7|I1\(11),
	datad => \L_6|I0\(11),
	combout => \L_36|Yout[11]~11_combout\);

-- Location: LCCOMB_X75_Y15_N2
\L_34|Yout[11]~12\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_34|Yout[11]~12_combout\ = (\L_34|Yout[0]~0_combout\ & ((\L_7|Mux4~3_combout\) # ((\L_36|Yout[11]~11_combout\ & \M4S1~input_o\)))) # (!\L_34|Yout[0]~0_combout\ & (\L_36|Yout[11]~11_combout\ & (\M4S1~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_34|Yout[0]~0_combout\,
	datab => \L_36|Yout[11]~11_combout\,
	datac => \M4S1~input_o\,
	datad => \L_7|Mux4~3_combout\,
	combout => \L_34|Yout[11]~12_combout\);

-- Location: LCCOMB_X73_Y16_N2
\L_40|I1[14]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_40|I1\(14) = (GLOBAL(\M4S3~inputclkctrl_outclk\) & (\L_40|I1\(14))) # (!GLOBAL(\M4S3~inputclkctrl_outclk\) & ((\L_38|Mult0|auto_generated|mac_out2~DATAOUT14\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_40|I1\(14),
	datac => \M4S3~inputclkctrl_outclk\,
	datad => \L_38|Mult0|auto_generated|mac_out2~DATAOUT14\,
	combout => \L_40|I1\(14));

-- Location: LCCOMB_X72_Y12_N24
\L_61|I1[14]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_61|I1\(14) = (GLOBAL(\A3S3~inputclkctrl_outclk\) & (\L_61|I1\(14))) # (!GLOBAL(\A3S3~inputclkctrl_outclk\) & ((\L_59|O[14]~28_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_61|I1\(14),
	datac => \A3S3~inputclkctrl_outclk\,
	datad => \L_59|O[14]~28_combout\,
	combout => \L_61|I1\(14));

-- Location: LCCOMB_X73_Y16_N0
\L_19|I1[14]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_19|I1\(14) = (GLOBAL(\M1S3~inputclkctrl_outclk\) & (\L_19|I1\(14))) # (!GLOBAL(\M1S3~inputclkctrl_outclk\) & ((\L_17|Mult0|auto_generated|mac_out2~DATAOUT14\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_19|I1\(14),
	datac => \L_17|Mult0|auto_generated|mac_out2~DATAOUT14\,
	datad => \M1S3~inputclkctrl_outclk\,
	combout => \L_19|I1\(14));

-- Location: LCCOMB_X73_Y16_N4
\L_47|I0[14]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_47|I0\(14) = (GLOBAL(\A1S3~inputclkctrl_outclk\) & ((\L_45|O[14]~28_combout\))) # (!GLOBAL(\A1S3~inputclkctrl_outclk\) & (\L_47|I0\(14)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_47|I0\(14),
	datac => \A1S3~inputclkctrl_outclk\,
	datad => \L_45|O[14]~28_combout\,
	combout => \L_47|I0\(14));

-- Location: IOIBUF_X66_Y0_N22
\v0[14]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v0(14),
	o => \v0[14]~input_o\);

-- Location: LCCOMB_X73_Y16_N6
\L_19|I0[14]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_19|I0\(14) = (GLOBAL(\M1S3~inputclkctrl_outclk\) & ((\L_17|Mult0|auto_generated|mac_out2~DATAOUT14\))) # (!GLOBAL(\M1S3~inputclkctrl_outclk\) & (\L_19|I0\(14)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_19|I0\(14),
	datac => \L_17|Mult0|auto_generated|mac_out2~DATAOUT14\,
	datad => \M1S3~inputclkctrl_outclk\,
	combout => \L_19|I0\(14));

-- Location: LCCOMB_X73_Y16_N16
\L_7|Mux1~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux1~0_combout\ = (\RMS1[0]~input_o\ & (((\RMS1[1]~input_o\) # (\L_19|I0\(14))))) # (!\RMS1[0]~input_o\ & (\v0[14]~input_o\ & (!\RMS1[1]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111010100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \RMS1[0]~input_o\,
	datab => \v0[14]~input_o\,
	datac => \RMS1[1]~input_o\,
	datad => \L_19|I0\(14),
	combout => \L_7|Mux1~0_combout\);

-- Location: LCCOMB_X73_Y16_N26
\L_7|Mux1~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux1~1_combout\ = (\RMS1[1]~input_o\ & ((\L_7|Mux1~0_combout\ & (\L_19|I1\(14))) # (!\L_7|Mux1~0_combout\ & ((\L_47|I0\(14)))))) # (!\RMS1[1]~input_o\ & (((\L_7|Mux1~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \RMS1[1]~input_o\,
	datab => \L_19|I1\(14),
	datac => \L_47|I0\(14),
	datad => \L_7|Mux1~0_combout\,
	combout => \L_7|Mux1~1_combout\);

-- Location: LCCOMB_X73_Y16_N18
\L_47|I1[14]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_47|I1\(14) = (GLOBAL(\A1S3~inputclkctrl_outclk\) & (\L_47|I1\(14))) # (!GLOBAL(\A1S3~inputclkctrl_outclk\) & ((\L_45|O[14]~28_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_47|I1\(14),
	datac => \A1S3~inputclkctrl_outclk\,
	datad => \L_45|O[14]~28_combout\,
	combout => \L_47|I1\(14));

-- Location: LCCOMB_X73_Y16_N12
\L_7|Mux1~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux1~2_combout\ = (\L_7|Mux15~3_combout\ & ((\L_7|Mux15~0_combout\) # ((\L_7|Mux1~1_combout\)))) # (!\L_7|Mux15~3_combout\ & (!\L_7|Mux15~0_combout\ & ((\L_47|I1\(14)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011100110101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_7|Mux15~3_combout\,
	datab => \L_7|Mux15~0_combout\,
	datac => \L_7|Mux1~1_combout\,
	datad => \L_47|I1\(14),
	combout => \L_7|Mux1~2_combout\);

-- Location: LCCOMB_X73_Y16_N30
\L_7|Mux1~3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux1~3_combout\ = (\L_7|Mux15~0_combout\ & ((\L_7|Mux1~2_combout\ & ((\L_61|I1\(14)))) # (!\L_7|Mux1~2_combout\ & (\L_40|I1\(14))))) # (!\L_7|Mux15~0_combout\ & (((\L_7|Mux1~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_7|Mux15~0_combout\,
	datab => \L_40|I1\(14),
	datac => \L_61|I1\(14),
	datad => \L_7|Mux1~2_combout\,
	combout => \L_7|Mux1~3_combout\);

-- Location: LCCOMB_X73_Y16_N14
\L_13|Yout[14]~15\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_13|Yout[14]~15_combout\ = (\L_13|Yout[15]~0_combout\ & \L_7|Mux1~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_13|Yout[15]~0_combout\,
	datac => \L_7|Mux1~3_combout\,
	combout => \L_13|Yout[14]~15_combout\);

-- Location: LCCOMB_X75_Y18_N2
\L_19|I1[12]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_19|I1\(12) = (GLOBAL(\M1S3~inputclkctrl_outclk\) & (\L_19|I1\(12))) # (!GLOBAL(\M1S3~inputclkctrl_outclk\) & ((\L_17|Mult0|auto_generated|mac_out2~DATAOUT12\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M1S3~inputclkctrl_outclk\,
	datab => \L_19|I1\(12),
	datad => \L_17|Mult0|auto_generated|mac_out2~DATAOUT12\,
	combout => \L_19|I1\(12));

-- Location: LCCOMB_X75_Y18_N24
\L_19|I0[12]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_19|I0\(12) = (GLOBAL(\M1S3~inputclkctrl_outclk\) & ((\L_17|Mult0|auto_generated|mac_out2~DATAOUT12\))) # (!GLOBAL(\M1S3~inputclkctrl_outclk\) & (\L_19|I0\(12)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111001000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M1S3~inputclkctrl_outclk\,
	datab => \L_19|I0\(12),
	datad => \L_17|Mult0|auto_generated|mac_out2~DATAOUT12\,
	combout => \L_19|I0\(12));

-- Location: LCCOMB_X75_Y18_N30
\L_7|Mux3~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux3~0_combout\ = (\RMS1[1]~input_o\ & (((\RMS1[0]~input_o\)))) # (!\RMS1[1]~input_o\ & ((\RMS1[0]~input_o\ & ((\L_19|I0\(12)))) # (!\RMS1[0]~input_o\ & (\v0[12]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001011000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v0[12]~input_o\,
	datab => \RMS1[1]~input_o\,
	datac => \RMS1[0]~input_o\,
	datad => \L_19|I0\(12),
	combout => \L_7|Mux3~0_combout\);

-- Location: LCCOMB_X75_Y18_N18
\L_47|I0[12]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_47|I0\(12) = (GLOBAL(\A1S3~inputclkctrl_outclk\) & ((\L_45|O[12]~24_combout\))) # (!GLOBAL(\A1S3~inputclkctrl_outclk\) & (\L_47|I0\(12)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_47|I0\(12),
	datac => \A1S3~inputclkctrl_outclk\,
	datad => \L_45|O[12]~24_combout\,
	combout => \L_47|I0\(12));

-- Location: LCCOMB_X75_Y18_N4
\L_7|Mux3~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux3~1_combout\ = (\RMS1[1]~input_o\ & ((\L_7|Mux3~0_combout\ & (\L_19|I1\(12))) # (!\L_7|Mux3~0_combout\ & ((\L_47|I0\(12)))))) # (!\RMS1[1]~input_o\ & (((\L_7|Mux3~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101101011010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \RMS1[1]~input_o\,
	datab => \L_19|I1\(12),
	datac => \L_7|Mux3~0_combout\,
	datad => \L_47|I0\(12),
	combout => \L_7|Mux3~1_combout\);

-- Location: LCCOMB_X75_Y18_N0
\L_47|I1[12]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_47|I1\(12) = (GLOBAL(\A1S3~inputclkctrl_outclk\) & (\L_47|I1\(12))) # (!GLOBAL(\A1S3~inputclkctrl_outclk\) & ((\L_45|O[12]~24_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_47|I1\(12),
	datac => \A1S3~inputclkctrl_outclk\,
	datad => \L_45|O[12]~24_combout\,
	combout => \L_47|I1\(12));

-- Location: LCCOMB_X75_Y18_N14
\L_7|Mux3~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux3~2_combout\ = (\L_7|Mux15~3_combout\ & ((\L_7|Mux15~0_combout\) # ((\L_7|Mux3~1_combout\)))) # (!\L_7|Mux15~3_combout\ & (!\L_7|Mux15~0_combout\ & ((\L_47|I1\(12)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011100110101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_7|Mux15~3_combout\,
	datab => \L_7|Mux15~0_combout\,
	datac => \L_7|Mux3~1_combout\,
	datad => \L_47|I1\(12),
	combout => \L_7|Mux3~2_combout\);

-- Location: LCCOMB_X75_Y18_N10
\L_61|I1[12]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_61|I1\(12) = (GLOBAL(\A3S3~inputclkctrl_outclk\) & (\L_61|I1\(12))) # (!GLOBAL(\A3S3~inputclkctrl_outclk\) & ((\L_59|O[12]~24_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_61|I1\(12),
	datac => \L_59|O[12]~24_combout\,
	datad => \A3S3~inputclkctrl_outclk\,
	combout => \L_61|I1\(12));

-- Location: LCCOMB_X75_Y18_N16
\L_7|Mux3~3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux3~3_combout\ = (\L_7|Mux15~0_combout\ & ((\L_7|Mux3~2_combout\ & ((\L_61|I1\(12)))) # (!\L_7|Mux3~2_combout\ & (\L_40|I1\(12))))) # (!\L_7|Mux15~0_combout\ & (((\L_7|Mux3~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100000111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_40|I1\(12),
	datab => \L_7|Mux15~0_combout\,
	datac => \L_7|Mux3~2_combout\,
	datad => \L_61|I1\(12),
	combout => \L_7|Mux3~3_combout\);

-- Location: LCCOMB_X75_Y16_N22
\L_13|Yout[12]~13\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_13|Yout[12]~13_combout\ = (\L_7|Mux3~3_combout\ & \L_13|Yout[15]~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \L_7|Mux3~3_combout\,
	datad => \L_13|Yout[15]~0_combout\,
	combout => \L_13|Yout[12]~13_combout\);

-- Location: LCCOMB_X76_Y13_N24
\L_19|I1[11]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_19|I1\(11) = (GLOBAL(\M1S3~inputclkctrl_outclk\) & (\L_19|I1\(11))) # (!GLOBAL(\M1S3~inputclkctrl_outclk\) & ((\L_17|Mult0|auto_generated|mac_out2~DATAOUT11\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_19|I1\(11),
	datac => \M1S3~inputclkctrl_outclk\,
	datad => \L_17|Mult0|auto_generated|mac_out2~DATAOUT11\,
	combout => \L_19|I1\(11));

-- Location: LCCOMB_X76_Y13_N4
\L_7|Mux4~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux4~1_combout\ = (\RMS1[0]~input_o\ & ((\L_7|Mux4~0_combout\ & ((\L_19|I1\(11)))) # (!\L_7|Mux4~0_combout\ & (\L_19|I0\(11))))) # (!\RMS1[0]~input_o\ & (((\L_7|Mux4~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100000111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_19|I0\(11),
	datab => \RMS1[0]~input_o\,
	datac => \L_7|Mux4~0_combout\,
	datad => \L_19|I1\(11),
	combout => \L_7|Mux4~1_combout\);

-- Location: LCCOMB_X76_Y13_N26
\L_47|I1[11]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_47|I1\(11) = (GLOBAL(\A1S3~inputclkctrl_outclk\) & (\L_47|I1\(11))) # (!GLOBAL(\A1S3~inputclkctrl_outclk\) & ((\L_45|O[11]~22_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_47|I1\(11),
	datac => \L_45|O[11]~22_combout\,
	datad => \A1S3~inputclkctrl_outclk\,
	combout => \L_47|I1\(11));

-- Location: LCCOMB_X75_Y15_N10
\L_40|I1[11]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_40|I1\(11) = (GLOBAL(\M4S3~inputclkctrl_outclk\) & (\L_40|I1\(11))) # (!GLOBAL(\M4S3~inputclkctrl_outclk\) & ((\L_38|Mult0|auto_generated|mac_out2~DATAOUT11\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_40|I1\(11),
	datac => \M4S3~inputclkctrl_outclk\,
	datad => \L_38|Mult0|auto_generated|mac_out2~DATAOUT11\,
	combout => \L_40|I1\(11));

-- Location: LCCOMB_X76_Y13_N2
\L_7|Mux4~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux4~2_combout\ = (\L_7|Mux15~0_combout\ & ((\L_7|Mux15~3_combout\) # ((\L_40|I1\(11))))) # (!\L_7|Mux15~0_combout\ & (!\L_7|Mux15~3_combout\ & (\L_47|I1\(11))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101010011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_7|Mux15~0_combout\,
	datab => \L_7|Mux15~3_combout\,
	datac => \L_47|I1\(11),
	datad => \L_40|I1\(11),
	combout => \L_7|Mux4~2_combout\);

-- Location: LCCOMB_X76_Y13_N16
\L_7|Mux4~3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux4~3_combout\ = (\L_7|Mux15~3_combout\ & ((\L_7|Mux4~2_combout\ & (\L_61|I1\(11))) # (!\L_7|Mux4~2_combout\ & ((\L_7|Mux4~1_combout\))))) # (!\L_7|Mux15~3_combout\ & (((\L_7|Mux4~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_7|Mux15~3_combout\,
	datab => \L_61|I1\(11),
	datac => \L_7|Mux4~1_combout\,
	datad => \L_7|Mux4~2_combout\,
	combout => \L_7|Mux4~3_combout\);

-- Location: LCCOMB_X76_Y13_N0
\L_13|Yout[11]~12\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_13|Yout[11]~12_combout\ = (\L_13|Yout[15]~0_combout\ & \L_7|Mux4~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \L_13|Yout[15]~0_combout\,
	datad => \L_7|Mux4~3_combout\,
	combout => \L_13|Yout[11]~12_combout\);

-- Location: LCCOMB_X77_Y16_N26
\L_19|I1[8]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_19|I1\(8) = (GLOBAL(\M1S3~inputclkctrl_outclk\) & (\L_19|I1\(8))) # (!GLOBAL(\M1S3~inputclkctrl_outclk\) & ((\L_17|Mult0|auto_generated|mac_out2~DATAOUT8\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_19|I1\(8),
	datac => \M1S3~inputclkctrl_outclk\,
	datad => \L_17|Mult0|auto_generated|mac_out2~DATAOUT8\,
	combout => \L_19|I1\(8));

-- Location: LCCOMB_X77_Y16_N24
\L_19|I0[8]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_19|I0\(8) = (GLOBAL(\M1S3~inputclkctrl_outclk\) & ((\L_17|Mult0|auto_generated|mac_out2~DATAOUT8\))) # (!GLOBAL(\M1S3~inputclkctrl_outclk\) & (\L_19|I0\(8)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_19|I0\(8),
	datac => \M1S3~inputclkctrl_outclk\,
	datad => \L_17|Mult0|auto_generated|mac_out2~DATAOUT8\,
	combout => \L_19|I0\(8));

-- Location: LCCOMB_X77_Y16_N20
\L_7|Mux7~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux7~0_combout\ = (\RMS1[1]~input_o\ & (((\RMS1[0]~input_o\)))) # (!\RMS1[1]~input_o\ & ((\RMS1[0]~input_o\ & ((\L_19|I0\(8)))) # (!\RMS1[0]~input_o\ & (\v0[8]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001011000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v0[8]~input_o\,
	datab => \RMS1[1]~input_o\,
	datac => \RMS1[0]~input_o\,
	datad => \L_19|I0\(8),
	combout => \L_7|Mux7~0_combout\);

-- Location: LCCOMB_X77_Y16_N18
\L_7|Mux7~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux7~1_combout\ = (\RMS1[1]~input_o\ & ((\L_7|Mux7~0_combout\ & ((\L_19|I1\(8)))) # (!\L_7|Mux7~0_combout\ & (\L_47|I0\(8))))) # (!\RMS1[1]~input_o\ & (((\L_7|Mux7~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \RMS1[1]~input_o\,
	datab => \L_47|I0\(8),
	datac => \L_19|I1\(8),
	datad => \L_7|Mux7~0_combout\,
	combout => \L_7|Mux7~1_combout\);

-- Location: LCCOMB_X77_Y16_N8
\L_7|Mux7~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux7~2_combout\ = (\L_7|Mux15~3_combout\ & ((\L_7|Mux15~0_combout\) # ((\L_7|Mux7~1_combout\)))) # (!\L_7|Mux15~3_combout\ & (!\L_7|Mux15~0_combout\ & (\L_47|I1\(8))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101010011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_7|Mux15~3_combout\,
	datab => \L_7|Mux15~0_combout\,
	datac => \L_47|I1\(8),
	datad => \L_7|Mux7~1_combout\,
	combout => \L_7|Mux7~2_combout\);

-- Location: LCCOMB_X77_Y15_N6
\L_7|Mux7~3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux7~3_combout\ = (\L_7|Mux15~0_combout\ & ((\L_7|Mux7~2_combout\ & ((\L_61|I1\(8)))) # (!\L_7|Mux7~2_combout\ & (\L_40|I1\(8))))) # (!\L_7|Mux15~0_combout\ & (((\L_7|Mux7~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_7|Mux15~0_combout\,
	datab => \L_40|I1\(8),
	datac => \L_61|I1\(8),
	datad => \L_7|Mux7~2_combout\,
	combout => \L_7|Mux7~3_combout\);

-- Location: LCCOMB_X77_Y15_N2
\L_13|Yout[8]~9\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_13|Yout[8]~9_combout\ = (\L_13|Yout[15]~0_combout\ & \L_7|Mux7~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_13|Yout[15]~0_combout\,
	datad => \L_7|Mux7~3_combout\,
	combout => \L_13|Yout[8]~9_combout\);

-- Location: LCCOMB_X73_Y18_N0
\L_19|I1[10]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_19|I1\(10) = (GLOBAL(\M1S3~inputclkctrl_outclk\) & (\L_19|I1\(10))) # (!GLOBAL(\M1S3~inputclkctrl_outclk\) & ((\L_17|Mult0|auto_generated|mac_out2~DATAOUT10\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_19|I1\(10),
	datac => \M1S3~inputclkctrl_outclk\,
	datad => \L_17|Mult0|auto_generated|mac_out2~DATAOUT10\,
	combout => \L_19|I1\(10));

-- Location: LCCOMB_X75_Y18_N6
\L_19|I0[10]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_19|I0\(10) = (GLOBAL(\M1S3~inputclkctrl_outclk\) & ((\L_17|Mult0|auto_generated|mac_out2~DATAOUT10\))) # (!GLOBAL(\M1S3~inputclkctrl_outclk\) & (\L_19|I0\(10)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_19|I0\(10),
	datac => \L_17|Mult0|auto_generated|mac_out2~DATAOUT10\,
	datad => \M1S3~inputclkctrl_outclk\,
	combout => \L_19|I0\(10));

-- Location: LCCOMB_X75_Y18_N8
\L_7|Mux5~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux5~0_combout\ = (\RMS1[0]~input_o\ & (((\RMS1[1]~input_o\) # (\L_19|I0\(10))))) # (!\RMS1[0]~input_o\ & (\v0[10]~input_o\ & (!\RMS1[1]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111011000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v0[10]~input_o\,
	datab => \RMS1[0]~input_o\,
	datac => \RMS1[1]~input_o\,
	datad => \L_19|I0\(10),
	combout => \L_7|Mux5~0_combout\);

-- Location: LCCOMB_X75_Y18_N12
\L_47|I0[10]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_47|I0\(10) = (GLOBAL(\A1S3~inputclkctrl_outclk\) & ((\L_45|O[10]~20_combout\))) # (!GLOBAL(\A1S3~inputclkctrl_outclk\) & (\L_47|I0\(10)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_47|I0\(10),
	datac => \A1S3~inputclkctrl_outclk\,
	datad => \L_45|O[10]~20_combout\,
	combout => \L_47|I0\(10));

-- Location: LCCOMB_X75_Y18_N22
\L_7|Mux5~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux5~1_combout\ = (\RMS1[1]~input_o\ & ((\L_7|Mux5~0_combout\ & (\L_19|I1\(10))) # (!\L_7|Mux5~0_combout\ & ((\L_47|I0\(10)))))) # (!\RMS1[1]~input_o\ & (((\L_7|Mux5~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101101011010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \RMS1[1]~input_o\,
	datab => \L_19|I1\(10),
	datac => \L_7|Mux5~0_combout\,
	datad => \L_47|I0\(10),
	combout => \L_7|Mux5~1_combout\);

-- Location: LCCOMB_X75_Y18_N28
\L_47|I1[10]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_47|I1\(10) = (GLOBAL(\A1S3~inputclkctrl_outclk\) & (\L_47|I1\(10))) # (!GLOBAL(\A1S3~inputclkctrl_outclk\) & ((\L_45|O[10]~20_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_47|I1\(10),
	datac => \A1S3~inputclkctrl_outclk\,
	datad => \L_45|O[10]~20_combout\,
	combout => \L_47|I1\(10));

-- Location: LCCOMB_X75_Y18_N20
\L_7|Mux5~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux5~2_combout\ = (\L_7|Mux15~3_combout\ & ((\L_7|Mux15~0_combout\) # ((\L_7|Mux5~1_combout\)))) # (!\L_7|Mux15~3_combout\ & (!\L_7|Mux15~0_combout\ & ((\L_47|I1\(10)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011100110101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_7|Mux15~3_combout\,
	datab => \L_7|Mux15~0_combout\,
	datac => \L_7|Mux5~1_combout\,
	datad => \L_47|I1\(10),
	combout => \L_7|Mux5~2_combout\);

-- Location: LCCOMB_X75_Y16_N8
\L_7|Mux5~3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux5~3_combout\ = (\L_7|Mux15~0_combout\ & ((\L_7|Mux5~2_combout\ & ((\L_61|I1\(10)))) # (!\L_7|Mux5~2_combout\ & (\L_40|I1\(10))))) # (!\L_7|Mux15~0_combout\ & (((\L_7|Mux5~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_7|Mux15~0_combout\,
	datab => \L_40|I1\(10),
	datac => \L_61|I1\(10),
	datad => \L_7|Mux5~2_combout\,
	combout => \L_7|Mux5~3_combout\);

-- Location: LCCOMB_X75_Y16_N12
\L_34|Yout[10]~11\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_34|Yout[10]~11_combout\ = (\M4S1~input_o\ & ((\L_36|Yout[10]~10_combout\) # ((\L_34|Yout[0]~0_combout\ & \L_7|Mux5~3_combout\)))) # (!\M4S1~input_o\ & (\L_34|Yout[0]~0_combout\ & (\L_7|Mux5~3_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M4S1~input_o\,
	datab => \L_34|Yout[0]~0_combout\,
	datac => \L_7|Mux5~3_combout\,
	datad => \L_36|Yout[10]~10_combout\,
	combout => \L_34|Yout[10]~11_combout\);

-- Location: LCCOMB_X73_Y12_N14
\L_40|I0[7]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_40|I0\(7) = (GLOBAL(\M4S3~inputclkctrl_outclk\) & ((\L_38|Mult0|auto_generated|mac_out2~DATAOUT7\))) # (!GLOBAL(\M4S3~inputclkctrl_outclk\) & (\L_40|I0\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_40|I0\(7),
	datac => \M4S3~inputclkctrl_outclk\,
	datad => \L_38|Mult0|auto_generated|mac_out2~DATAOUT7\,
	combout => \L_40|I0\(7));

-- Location: LCCOMB_X78_Y9_N2
\TM6|Yout[7]~30\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[7]~30_combout\ = (\YTPM_S1[1]~input_o\ & (((\L_61|I0\(7))))) # (!\YTPM_S1[1]~input_o\ & (((\L_40|I0\(7))) # (!\YTPM_S1[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110110001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPM_S1[1]~input_o\,
	datab => \YTPM_S1[0]~input_o\,
	datac => \L_61|I0\(7),
	datad => \L_40|I0\(7),
	combout => \TM6|Yout[7]~30_combout\);

-- Location: LCCOMB_X78_Y9_N20
\TM6|Yout[7]~31\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[7]~31_combout\ = (\TM6|Yout[0]~5_combout\ & (((\TM6|Yout[7]~30_combout\)))) # (!\TM6|Yout[0]~5_combout\ & ((\TM6|Yout[7]~30_combout\ & (\v3[7]~input_o\)) # (!\TM6|Yout[7]~30_combout\ & ((\L_33|I0\(7))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v3[7]~input_o\,
	datab => \L_33|I0\(7),
	datac => \TM6|Yout[0]~5_combout\,
	datad => \TM6|Yout[7]~30_combout\,
	combout => \TM6|Yout[7]~31_combout\);

-- Location: LCCOMB_X78_Y9_N6
\TM6|Yout[7]~32\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[7]~32_combout\ = (\YTPM_S1[1]~input_o\ & ((\YTPM_S1[0]~input_o\ & (\L_33|I1\(7))) # (!\YTPM_S1[0]~input_o\ & ((\TM6|Yout[7]~31_combout\))))) # (!\YTPM_S1[1]~input_o\ & (((\TM6|Yout[7]~31_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111011110000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPM_S1[1]~input_o\,
	datab => \YTPM_S1[0]~input_o\,
	datac => \L_33|I1\(7),
	datad => \TM6|Yout[7]~31_combout\,
	combout => \TM6|Yout[7]~32_combout\);

-- Location: LCCOMB_X78_Y9_N28
\TM6|Yout[7]~33\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[7]~33_combout\ = (\YTPM_S1[2]~input_o\ & (\L_54|I1\(7))) # (!\YTPM_S1[2]~input_o\ & ((\TM6|Yout[7]~32_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPM_S1[2]~input_o\,
	datac => \L_54|I1\(7),
	datad => \TM6|Yout[7]~32_combout\,
	combout => \TM6|Yout[7]~33_combout\);

-- Location: LCCOMB_X78_Y9_N24
\TM7|I1[7]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM7|I1\(7) = (GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM7|I1\(7))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM6|Yout[7]~33_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM7|I1\(7),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM6|Yout[7]~33_combout\,
	combout => \TM7|I1\(7));

-- Location: LCCOMB_X78_Y7_N2
\L_6|I2[7]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I2\(7) = (GLOBAL(\L_6|Equal0~1clkctrl_outclk\) & (\TM7|I0\(7))) # (!GLOBAL(\L_6|Equal0~1clkctrl_outclk\) & ((\L_6|I2\(7))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM7|I0\(7),
	datab => \L_6|I2\(7),
	datad => \L_6|Equal0~1clkctrl_outclk\,
	combout => \L_6|I2\(7));

-- Location: LCCOMB_X78_Y7_N26
\L_50|Yout[7]~14\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_50|Yout[7]~14_combout\ = (\L_6|I2\(7)) # ((\TM8|Equal3~0_combout\ & \TM7|I1\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM8|Equal3~0_combout\,
	datac => \TM7|I1\(7),
	datad => \L_6|I2\(7),
	combout => \L_50|Yout[7]~14_combout\);

-- Location: LCCOMB_X78_Y7_N12
\L_12|I1[7]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I1\(7) = (GLOBAL(\L_12|Equal0~1clkctrl_outclk\) & (\L_10|Yout[7]~15_combout\)) # (!GLOBAL(\L_12|Equal0~1clkctrl_outclk\) & ((\L_12|I1\(7))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_10|Yout[7]~15_combout\,
	datac => \L_12|Equal0~1clkctrl_outclk\,
	datad => \L_12|I1\(7),
	combout => \L_12|I1\(7));

-- Location: LCCOMB_X78_Y7_N18
\L_50|Yout[7]~15\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_50|Yout[7]~15_combout\ = (\A2S2~input_o\ & ((\L_12|I1\(7)))) # (!\A2S2~input_o\ & (\L_50|Yout[7]~14_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \A2S2~input_o\,
	datac => \L_50|Yout[7]~14_combout\,
	datad => \L_12|I1\(7),
	combout => \L_50|Yout[7]~15_combout\);

-- Location: LCCOMB_X76_Y7_N16
\L_52|O[8]~16\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_52|O[8]~16_combout\ = ((\L_50|Yout[8]~17_combout\ $ (\L_48|Yout[8]~8_combout\ $ (!\L_52|O[7]~15\)))) # (GND)
-- \L_52|O[8]~17\ = CARRY((\L_50|Yout[8]~17_combout\ & ((\L_48|Yout[8]~8_combout\) # (!\L_52|O[7]~15\))) # (!\L_50|Yout[8]~17_combout\ & (\L_48|Yout[8]~8_combout\ & !\L_52|O[7]~15\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100110001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_50|Yout[8]~17_combout\,
	datab => \L_48|Yout[8]~8_combout\,
	datad => VCC,
	cin => \L_52|O[7]~15\,
	combout => \L_52|O[8]~16_combout\,
	cout => \L_52|O[8]~17\);

-- Location: LCCOMB_X75_Y9_N14
\L_54|I1[8]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_54|I1\(8) = (GLOBAL(\A2S3~inputclkctrl_outclk\) & (\L_54|I1\(8))) # (!GLOBAL(\A2S3~inputclkctrl_outclk\) & ((\L_52|O[8]~16_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_54|I1\(8),
	datac => \A2S3~inputclkctrl_outclk\,
	datad => \L_52|O[8]~16_combout\,
	combout => \L_54|I1\(8));

-- Location: LCCOMB_X79_Y12_N16
\L_61|I0[8]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_61|I0\(8) = (GLOBAL(\A3S3~inputclkctrl_outclk\) & ((\L_59|O[8]~16_combout\))) # (!GLOBAL(\A3S3~inputclkctrl_outclk\) & (\L_61|I0\(8)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_61|I0\(8),
	datac => \L_59|O[8]~16_combout\,
	datad => \A3S3~inputclkctrl_outclk\,
	combout => \L_61|I0\(8));

-- Location: LCCOMB_X75_Y11_N28
\TM6|Yout[8]~34\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[8]~34_combout\ = (!\YTPM_S1[1]~input_o\ & ((\L_40|I0\(8)) # (!\YTPM_S1[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \YTPM_S1[1]~input_o\,
	datac => \YTPM_S1[0]~input_o\,
	datad => \L_40|I0\(8),
	combout => \TM6|Yout[8]~34_combout\);

-- Location: LCCOMB_X75_Y11_N22
\TM6|Yout[8]~35\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[8]~35_combout\ = (\TM6|Yout[0]~0_combout\ & ((\TM6|Yout[8]~34_combout\ & (\v3[8]~input_o\)) # (!\TM6|Yout[8]~34_combout\ & ((\L_61|I0\(8)))))) # (!\TM6|Yout[0]~0_combout\ & (((\TM6|Yout[8]~34_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM6|Yout[0]~0_combout\,
	datab => \v3[8]~input_o\,
	datac => \L_61|I0\(8),
	datad => \TM6|Yout[8]~34_combout\,
	combout => \TM6|Yout[8]~35_combout\);

-- Location: LCCOMB_X75_Y11_N2
\L_33|I1[8]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_33|I1\(8) = (GLOBAL(\M3S3~inputclkctrl_outclk\) & (\L_33|I1\(8))) # (!GLOBAL(\M3S3~inputclkctrl_outclk\) & ((\L_31|Mult0|auto_generated|mac_out2~DATAOUT8\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_33|I1\(8),
	datac => \M3S3~inputclkctrl_outclk\,
	datad => \L_31|Mult0|auto_generated|mac_out2~DATAOUT8\,
	combout => \L_33|I1\(8));

-- Location: LCCOMB_X75_Y11_N16
\TM6|Yout[8]~36\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[8]~36_combout\ = (\YTPM_S1[0]~input_o\ & ((\YTPM_S1[1]~input_o\ & ((\L_33|I1\(8)))) # (!\YTPM_S1[1]~input_o\ & (\TM6|Yout[8]~35_combout\)))) # (!\YTPM_S1[0]~input_o\ & (((\TM6|Yout[8]~35_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100001110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPM_S1[0]~input_o\,
	datab => \YTPM_S1[1]~input_o\,
	datac => \TM6|Yout[8]~35_combout\,
	datad => \L_33|I1\(8),
	combout => \TM6|Yout[8]~36_combout\);

-- Location: LCCOMB_X75_Y11_N18
\TM6|Yout[8]~37\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[8]~37_combout\ = (\YTPM_S1[2]~input_o\ & (\L_54|I1\(8))) # (!\YTPM_S1[2]~input_o\ & ((\TM6|Yout[8]~36_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPM_S1[2]~input_o\,
	datac => \L_54|I1\(8),
	datad => \TM6|Yout[8]~36_combout\,
	combout => \TM6|Yout[8]~37_combout\);

-- Location: LCCOMB_X75_Y11_N26
\TM7|I1[8]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM7|I1\(8) = (GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM7|I1\(8))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM6|Yout[8]~37_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TTS~inputclkctrl_outclk\,
	datab => \TM7|I1\(8),
	datad => \TM6|Yout[8]~37_combout\,
	combout => \TM7|I1\(8));

-- Location: LCCOMB_X75_Y4_N28
\L_50|Yout[8]~16\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_50|Yout[8]~16_combout\ = (\L_6|I2\(8)) # ((\TM8|Equal3~0_combout\ & \TM7|I1\(8)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM8|Equal3~0_combout\,
	datac => \L_6|I2\(8),
	datad => \TM7|I1\(8),
	combout => \L_50|Yout[8]~16_combout\);

-- Location: LCCOMB_X75_Y4_N18
\L_48|Yout[8]~8\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_48|Yout[8]~8_combout\ = (\A2S1~input_o\ & (\L_12|I1\(8))) # (!\A2S1~input_o\ & ((\L_50|Yout[8]~16_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \A2S1~input_o\,
	datac => \L_12|I1\(8),
	datad => \L_50|Yout[8]~16_combout\,
	combout => \L_48|Yout[8]~8_combout\);

-- Location: LCCOMB_X72_Y9_N26
\L_54|I1[9]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_54|I1\(9) = (GLOBAL(\A2S3~inputclkctrl_outclk\) & (\L_54|I1\(9))) # (!GLOBAL(\A2S3~inputclkctrl_outclk\) & ((\L_52|O[9]~18_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_54|I1\(9),
	datac => \L_52|O[9]~18_combout\,
	datad => \A2S3~inputclkctrl_outclk\,
	combout => \L_54|I1\(9));

-- Location: LCCOMB_X73_Y9_N24
\TM6|Yout[9]~38\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[9]~38_combout\ = (\YTPM_S1[1]~input_o\ & (((\L_61|I0\(9))))) # (!\YTPM_S1[1]~input_o\ & (((\L_40|I0\(9))) # (!\YTPM_S1[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111010001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPM_S1[0]~input_o\,
	datab => \YTPM_S1[1]~input_o\,
	datac => \L_61|I0\(9),
	datad => \L_40|I0\(9),
	combout => \TM6|Yout[9]~38_combout\);

-- Location: LCCOMB_X73_Y9_N18
\TM6|Yout[9]~39\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[9]~39_combout\ = (\TM6|Yout[0]~5_combout\ & (((\TM6|Yout[9]~38_combout\)))) # (!\TM6|Yout[0]~5_combout\ & ((\TM6|Yout[9]~38_combout\ & (\v3[9]~input_o\)) # (!\TM6|Yout[9]~38_combout\ & ((\L_33|I0\(9))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v3[9]~input_o\,
	datab => \TM6|Yout[0]~5_combout\,
	datac => \L_33|I0\(9),
	datad => \TM6|Yout[9]~38_combout\,
	combout => \TM6|Yout[9]~39_combout\);

-- Location: LCCOMB_X73_Y9_N20
\TM6|Yout[9]~40\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[9]~40_combout\ = (\YTPM_S1[0]~input_o\ & ((\YTPM_S1[1]~input_o\ & (\L_33|I1\(9))) # (!\YTPM_S1[1]~input_o\ & ((\TM6|Yout[9]~39_combout\))))) # (!\YTPM_S1[0]~input_o\ & (((\TM6|Yout[9]~39_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111011110000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPM_S1[0]~input_o\,
	datab => \YTPM_S1[1]~input_o\,
	datac => \L_33|I1\(9),
	datad => \TM6|Yout[9]~39_combout\,
	combout => \TM6|Yout[9]~40_combout\);

-- Location: LCCOMB_X73_Y9_N2
\TM6|Yout[9]~41\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[9]~41_combout\ = (\YTPM_S1[2]~input_o\ & (\L_54|I1\(9))) # (!\YTPM_S1[2]~input_o\ & ((\TM6|Yout[9]~40_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \YTPM_S1[2]~input_o\,
	datac => \L_54|I1\(9),
	datad => \TM6|Yout[9]~40_combout\,
	combout => \TM6|Yout[9]~41_combout\);

-- Location: LCCOMB_X73_Y9_N30
\TM7|I1[9]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM7|I1\(9) = (GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM7|I1\(9))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM6|Yout[9]~41_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM7|I1\(9),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM6|Yout[9]~41_combout\,
	combout => \TM7|I1\(9));

-- Location: LCCOMB_X73_Y17_N18
\L_3|I1[9]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I1\(9) = (GLOBAL(\L_3|Equal0~0clkctrl_outclk\) & ((\TM3|I0\(9)))) # (!GLOBAL(\L_3|Equal0~0clkctrl_outclk\) & (\L_3|I1\(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_3|I1\(9),
	datac => \TM3|I0\(9),
	datad => \L_3|Equal0~0clkctrl_outclk\,
	combout => \L_3|I1\(9));

-- Location: LCCOMB_X76_Y8_N8
\L_57|Yout[9]~18\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_57|Yout[9]~18_combout\ = (\TTS~input_o\ & ((\L_3|I1\(9)) # ((\L_55|Yout[0]~0_combout\ & \TM7|I1\(9))))) # (!\TTS~input_o\ & (\L_55|Yout[0]~0_combout\ & (\TM7|I1\(9))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TTS~input_o\,
	datab => \L_55|Yout[0]~0_combout\,
	datac => \TM7|I1\(9),
	datad => \L_3|I1\(9),
	combout => \L_57|Yout[9]~18_combout\);

-- Location: LCCOMB_X76_Y8_N20
\L_57|Yout[9]~19\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_57|Yout[9]~19_combout\ = (\A3S2~input_o\ & ((\L_57|Yout[9]~18_combout\))) # (!\A3S2~input_o\ & (\L_12|I3\(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_12|I3\(9),
	datac => \L_57|Yout[9]~18_combout\,
	datad => \A3S2~input_o\,
	combout => \L_57|Yout[9]~19_combout\);

-- Location: LCCOMB_X72_Y12_N26
\L_61|I1[9]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_61|I1\(9) = (GLOBAL(\A3S3~inputclkctrl_outclk\) & (\L_61|I1\(9))) # (!GLOBAL(\A3S3~inputclkctrl_outclk\) & ((\L_59|O[9]~18_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010110010101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_61|I1\(9),
	datab => \L_59|O[9]~18_combout\,
	datac => \A3S3~inputclkctrl_outclk\,
	combout => \L_61|I1\(9));

-- Location: LCCOMB_X72_Y16_N2
\L_47|I1[9]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_47|I1\(9) = (GLOBAL(\A1S3~inputclkctrl_outclk\) & (\L_47|I1\(9))) # (!GLOBAL(\A1S3~inputclkctrl_outclk\) & ((\L_45|O[9]~18_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_47|I1\(9),
	datac => \L_45|O[9]~18_combout\,
	datad => \A1S3~inputclkctrl_outclk\,
	combout => \L_47|I1\(9));

-- Location: LCCOMB_X73_Y15_N10
\L_40|I1[9]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_40|I1\(9) = (GLOBAL(\M4S3~inputclkctrl_outclk\) & (\L_40|I1\(9))) # (!GLOBAL(\M4S3~inputclkctrl_outclk\) & ((\L_38|Mult0|auto_generated|mac_out2~DATAOUT9\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_40|I1\(9),
	datac => \L_38|Mult0|auto_generated|mac_out2~DATAOUT9\,
	datad => \M4S3~inputclkctrl_outclk\,
	combout => \L_40|I1\(9));

-- Location: LCCOMB_X72_Y16_N28
\L_7|Mux6~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux6~2_combout\ = (\L_7|Mux15~0_combout\ & ((\L_7|Mux15~3_combout\) # ((\L_40|I1\(9))))) # (!\L_7|Mux15~0_combout\ & (!\L_7|Mux15~3_combout\ & (\L_47|I1\(9))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101010011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_7|Mux15~0_combout\,
	datab => \L_7|Mux15~3_combout\,
	datac => \L_47|I1\(9),
	datad => \L_40|I1\(9),
	combout => \L_7|Mux6~2_combout\);

-- Location: LCCOMB_X72_Y16_N30
\L_7|Mux6~3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux6~3_combout\ = (\L_7|Mux15~3_combout\ & ((\L_7|Mux6~2_combout\ & ((\L_61|I1\(9)))) # (!\L_7|Mux6~2_combout\ & (\L_7|Mux6~1_combout\)))) # (!\L_7|Mux15~3_combout\ & (((\L_7|Mux6~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_7|Mux6~1_combout\,
	datab => \L_7|Mux15~3_combout\,
	datac => \L_61|I1\(9),
	datad => \L_7|Mux6~2_combout\,
	combout => \L_7|Mux6~3_combout\);

-- Location: LCCOMB_X73_Y15_N28
\L_34|Yout[9]~10\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_34|Yout[9]~10_combout\ = (\M4S1~input_o\ & ((\L_36|Yout[9]~9_combout\) # ((\L_34|Yout[0]~0_combout\ & \L_7|Mux6~3_combout\)))) # (!\M4S1~input_o\ & (\L_34|Yout[0]~0_combout\ & (\L_7|Mux6~3_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M4S1~input_o\,
	datab => \L_34|Yout[0]~0_combout\,
	datac => \L_7|Mux6~3_combout\,
	datad => \L_36|Yout[9]~9_combout\,
	combout => \L_34|Yout[9]~10_combout\);

-- Location: LCCOMB_X75_Y14_N22
\L_40|I1[6]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_40|I1\(6) = (GLOBAL(\M4S3~inputclkctrl_outclk\) & (\L_40|I1\(6))) # (!GLOBAL(\M4S3~inputclkctrl_outclk\) & ((\L_38|Mult0|auto_generated|mac_out2~DATAOUT6\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_40|I1\(6),
	datac => \M4S3~inputclkctrl_outclk\,
	datad => \L_38|Mult0|auto_generated|mac_out2~DATAOUT6\,
	combout => \L_40|I1\(6));

-- Location: LCCOMB_X76_Y14_N8
\L_47|I1[6]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_47|I1\(6) = (GLOBAL(\A1S3~inputclkctrl_outclk\) & (\L_47|I1\(6))) # (!GLOBAL(\A1S3~inputclkctrl_outclk\) & ((\L_45|O[6]~12_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_47|I1\(6),
	datac => \L_45|O[6]~12_combout\,
	datad => \A1S3~inputclkctrl_outclk\,
	combout => \L_47|I1\(6));

-- Location: LCCOMB_X76_Y14_N22
\L_47|I0[6]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_47|I0\(6) = (GLOBAL(\A1S3~inputclkctrl_outclk\) & (\L_45|O[6]~12_combout\)) # (!GLOBAL(\A1S3~inputclkctrl_outclk\) & ((\L_47|I0\(6))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_45|O[6]~12_combout\,
	datac => \L_47|I0\(6),
	datad => \A1S3~inputclkctrl_outclk\,
	combout => \L_47|I0\(6));

-- Location: LCCOMB_X76_Y14_N24
\L_19|I0[6]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_19|I0\(6) = (GLOBAL(\M1S3~inputclkctrl_outclk\) & ((\L_17|Mult0|auto_generated|mac_out2~DATAOUT6\))) # (!GLOBAL(\M1S3~inputclkctrl_outclk\) & (\L_19|I0\(6)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_19|I0\(6),
	datac => \M1S3~inputclkctrl_outclk\,
	datad => \L_17|Mult0|auto_generated|mac_out2~DATAOUT6\,
	combout => \L_19|I0\(6));

-- Location: LCCOMB_X76_Y14_N10
\L_7|Mux9~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux9~0_combout\ = (\RMS1[1]~input_o\ & (((\RMS1[0]~input_o\)))) # (!\RMS1[1]~input_o\ & ((\RMS1[0]~input_o\ & ((\L_19|I0\(6)))) # (!\RMS1[0]~input_o\ & (\v0[6]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001011000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v0[6]~input_o\,
	datab => \RMS1[1]~input_o\,
	datac => \RMS1[0]~input_o\,
	datad => \L_19|I0\(6),
	combout => \L_7|Mux9~0_combout\);

-- Location: LCCOMB_X76_Y14_N16
\L_7|Mux9~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux9~1_combout\ = (\RMS1[1]~input_o\ & ((\L_7|Mux9~0_combout\ & (\L_19|I1\(6))) # (!\L_7|Mux9~0_combout\ & ((\L_47|I0\(6)))))) # (!\RMS1[1]~input_o\ & (((\L_7|Mux9~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_19|I1\(6),
	datab => \RMS1[1]~input_o\,
	datac => \L_47|I0\(6),
	datad => \L_7|Mux9~0_combout\,
	combout => \L_7|Mux9~1_combout\);

-- Location: LCCOMB_X76_Y14_N18
\L_7|Mux9~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux9~2_combout\ = (\L_7|Mux15~3_combout\ & ((\L_7|Mux15~0_combout\) # ((\L_7|Mux9~1_combout\)))) # (!\L_7|Mux15~3_combout\ & (!\L_7|Mux15~0_combout\ & (\L_47|I1\(6))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101010011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_7|Mux15~3_combout\,
	datab => \L_7|Mux15~0_combout\,
	datac => \L_47|I1\(6),
	datad => \L_7|Mux9~1_combout\,
	combout => \L_7|Mux9~2_combout\);

-- Location: LCCOMB_X75_Y14_N28
\L_7|Mux9~3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux9~3_combout\ = (\L_7|Mux15~0_combout\ & ((\L_7|Mux9~2_combout\ & (\L_61|I1\(6))) # (!\L_7|Mux9~2_combout\ & ((\L_40|I1\(6)))))) # (!\L_7|Mux15~0_combout\ & (((\L_7|Mux9~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_7|Mux15~0_combout\,
	datab => \L_61|I1\(6),
	datac => \L_40|I1\(6),
	datad => \L_7|Mux9~2_combout\,
	combout => \L_7|Mux9~3_combout\);

-- Location: LCCOMB_X75_Y14_N8
\L_13|Yout[6]~7\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_13|Yout[6]~7_combout\ = (\L_13|Yout[15]~0_combout\ & \L_7|Mux9~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_13|Yout[15]~0_combout\,
	datad => \L_7|Mux9~3_combout\,
	combout => \L_13|Yout[6]~7_combout\);

-- Location: LCCOMB_X75_Y13_N14
\L_19|I1[13]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_19|I1\(13) = (GLOBAL(\M1S3~inputclkctrl_outclk\) & (\L_19|I1\(13))) # (!GLOBAL(\M1S3~inputclkctrl_outclk\) & ((\L_17|Mult0|auto_generated|mac_out2~DATAOUT13\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_19|I1\(13),
	datac => \L_17|Mult0|auto_generated|mac_out2~DATAOUT13\,
	datad => \M1S3~inputclkctrl_outclk\,
	combout => \L_19|I1\(13));

-- Location: LCCOMB_X75_Y13_N30
\L_19|I0[13]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_19|I0\(13) = (GLOBAL(\M1S3~inputclkctrl_outclk\) & ((\L_17|Mult0|auto_generated|mac_out2~DATAOUT13\))) # (!GLOBAL(\M1S3~inputclkctrl_outclk\) & (\L_19|I0\(13)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_19|I0\(13),
	datac => \L_17|Mult0|auto_generated|mac_out2~DATAOUT13\,
	datad => \M1S3~inputclkctrl_outclk\,
	combout => \L_19|I0\(13));

-- Location: IOIBUF_X99_Y0_N1
\v0[13]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v0(13),
	o => \v0[13]~input_o\);

-- Location: LCCOMB_X75_Y13_N28
\L_47|I0[13]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_47|I0\(13) = (GLOBAL(\A1S3~inputclkctrl_outclk\) & ((\L_45|O[13]~26_combout\))) # (!GLOBAL(\A1S3~inputclkctrl_outclk\) & (\L_47|I0\(13)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_47|I0\(13),
	datac => \A1S3~inputclkctrl_outclk\,
	datad => \L_45|O[13]~26_combout\,
	combout => \L_47|I0\(13));

-- Location: LCCOMB_X75_Y13_N20
\L_7|Mux2~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux2~0_combout\ = (\RMS1[0]~input_o\ & (\RMS1[1]~input_o\)) # (!\RMS1[0]~input_o\ & ((\RMS1[1]~input_o\ & ((\L_47|I0\(13)))) # (!\RMS1[1]~input_o\ & (\v0[13]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110010011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \RMS1[0]~input_o\,
	datab => \RMS1[1]~input_o\,
	datac => \v0[13]~input_o\,
	datad => \L_47|I0\(13),
	combout => \L_7|Mux2~0_combout\);

-- Location: LCCOMB_X75_Y13_N26
\L_7|Mux2~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux2~1_combout\ = (\RMS1[0]~input_o\ & ((\L_7|Mux2~0_combout\ & (\L_19|I1\(13))) # (!\L_7|Mux2~0_combout\ & ((\L_19|I0\(13)))))) # (!\RMS1[0]~input_o\ & (((\L_7|Mux2~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \RMS1[0]~input_o\,
	datab => \L_19|I1\(13),
	datac => \L_19|I0\(13),
	datad => \L_7|Mux2~0_combout\,
	combout => \L_7|Mux2~1_combout\);

-- Location: LCCOMB_X75_Y13_N4
\L_47|I1[13]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_47|I1\(13) = (GLOBAL(\A1S3~inputclkctrl_outclk\) & (\L_47|I1\(13))) # (!GLOBAL(\A1S3~inputclkctrl_outclk\) & ((\L_45|O[13]~26_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_47|I1\(13),
	datac => \A1S3~inputclkctrl_outclk\,
	datad => \L_45|O[13]~26_combout\,
	combout => \L_47|I1\(13));

-- Location: LCCOMB_X76_Y15_N14
\L_40|I1[13]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_40|I1\(13) = (GLOBAL(\M4S3~inputclkctrl_outclk\) & (\L_40|I1\(13))) # (!GLOBAL(\M4S3~inputclkctrl_outclk\) & ((\L_38|Mult0|auto_generated|mac_out2~DATAOUT13\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_40|I1\(13),
	datac => \L_38|Mult0|auto_generated|mac_out2~DATAOUT13\,
	datad => \M4S3~inputclkctrl_outclk\,
	combout => \L_40|I1\(13));

-- Location: LCCOMB_X75_Y13_N24
\L_7|Mux2~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux2~2_combout\ = (\L_7|Mux15~3_combout\ & (\L_7|Mux15~0_combout\)) # (!\L_7|Mux15~3_combout\ & ((\L_7|Mux15~0_combout\ & ((\L_40|I1\(13)))) # (!\L_7|Mux15~0_combout\ & (\L_47|I1\(13)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110010011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_7|Mux15~3_combout\,
	datab => \L_7|Mux15~0_combout\,
	datac => \L_47|I1\(13),
	datad => \L_40|I1\(13),
	combout => \L_7|Mux2~2_combout\);

-- Location: LCCOMB_X75_Y13_N10
\L_7|Mux2~3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux2~3_combout\ = (\L_7|Mux15~3_combout\ & ((\L_7|Mux2~2_combout\ & (\L_61|I1\(13))) # (!\L_7|Mux2~2_combout\ & ((\L_7|Mux2~1_combout\))))) # (!\L_7|Mux15~3_combout\ & (((\L_7|Mux2~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_7|Mux15~3_combout\,
	datab => \L_61|I1\(13),
	datac => \L_7|Mux2~1_combout\,
	datad => \L_7|Mux2~2_combout\,
	combout => \L_7|Mux2~3_combout\);

-- Location: LCCOMB_X76_Y18_N26
\L_3|I1[13]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I1\(13) = (GLOBAL(\L_3|Equal0~0clkctrl_outclk\) & (\TM3|I0\(13))) # (!GLOBAL(\L_3|Equal0~0clkctrl_outclk\) & ((\L_3|I1\(13))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM3|I0\(13),
	datac => \L_3|I1\(13),
	datad => \L_3|Equal0~0clkctrl_outclk\,
	combout => \L_3|I1\(13));

-- Location: LCCOMB_X77_Y5_N28
\L_57|Yout[13]~26\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_57|Yout[13]~26_combout\ = (\TM7|I1\(13) & ((\L_55|Yout[0]~0_combout\) # ((\TTS~input_o\ & \L_3|I1\(13))))) # (!\TM7|I1\(13) & (\TTS~input_o\ & ((\L_3|I1\(13)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM7|I1\(13),
	datab => \TTS~input_o\,
	datac => \L_55|Yout[0]~0_combout\,
	datad => \L_3|I1\(13),
	combout => \L_57|Yout[13]~26_combout\);

-- Location: LCCOMB_X77_Y5_N26
\L_55|Yout[13]~15\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_55|Yout[13]~15_combout\ = (\A3S1~input_o\ & ((\L_57|Yout[13]~26_combout\) # ((\L_55|Yout[15]~1_combout\ & \L_7|Mux2~3_combout\)))) # (!\A3S1~input_o\ & (\L_55|Yout[15]~1_combout\ & (\L_7|Mux2~3_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \A3S1~input_o\,
	datab => \L_55|Yout[15]~1_combout\,
	datac => \L_7|Mux2~3_combout\,
	datad => \L_57|Yout[13]~26_combout\,
	combout => \L_55|Yout[13]~15_combout\);

-- Location: LCCOMB_X77_Y14_N18
\L_61|I0[13]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_61|I0\(13) = (GLOBAL(\A3S3~inputclkctrl_outclk\) & ((\L_59|O[13]~26_combout\))) # (!GLOBAL(\A3S3~inputclkctrl_outclk\) & (\L_61|I0\(13)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_61|I0\(13),
	datac => \A3S3~inputclkctrl_outclk\,
	datad => \L_59|O[13]~26_combout\,
	combout => \L_61|I0\(13));

-- Location: LCCOMB_X76_Y18_N6
\TM2|Yout[13]~28\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[13]~28_combout\ = (\TM2|Yout[13]~27_combout\ & (((\L_40|I0\(13))) # (!\TM2|Yout[9]~2_combout\))) # (!\TM2|Yout[13]~27_combout\ & (\TM2|Yout[9]~2_combout\ & (\L_61|I0\(13))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101001100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM2|Yout[13]~27_combout\,
	datab => \TM2|Yout[9]~2_combout\,
	datac => \L_61|I0\(13),
	datad => \L_40|I0\(13),
	combout => \TM2|Yout[13]~28_combout\);

-- Location: LCCOMB_X76_Y18_N0
\TM3|I0[13]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM3|I0\(13) = (GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM2|Yout[13]~28_combout\))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM3|I0\(13)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM3|I0\(13),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM2|Yout[13]~28_combout\,
	combout => \TM3|I0\(13));

-- Location: LCCOMB_X71_Y10_N16
\L_3|I2[13]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I2\(13) = (GLOBAL(\L_3|Equal0~1clkctrl_outclk\) & ((\TM3|I0\(13)))) # (!GLOBAL(\L_3|Equal0~1clkctrl_outclk\) & (\L_3|I2\(13)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_3|I2\(13),
	datac => \TM3|I0\(13),
	datad => \L_3|Equal0~1clkctrl_outclk\,
	combout => \L_3|I2\(13));

-- Location: LCCOMB_X71_Y10_N10
\L_27|Yout[13]~13\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_27|Yout[13]~13_combout\ = (\M3S1~input_o\ & (((\TM4|I0\(13)) # (\L_3|I0\(13))))) # (!\M3S1~input_o\ & (\L_3|I2\(13)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111011100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M3S1~input_o\,
	datab => \L_3|I2\(13),
	datac => \TM4|I0\(13),
	datad => \L_3|I0\(13),
	combout => \L_27|Yout[13]~13_combout\);

-- Location: LCCOMB_X78_Y11_N4
\L_33|I0[12]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_33|I0\(12) = (GLOBAL(\M3S3~inputclkctrl_outclk\) & ((\L_31|Mult0|auto_generated|mac_out2~DATAOUT12\))) # (!GLOBAL(\M3S3~inputclkctrl_outclk\) & (\L_33|I0\(12)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_33|I0\(12),
	datac => \M3S3~inputclkctrl_outclk\,
	datad => \L_31|Mult0|auto_generated|mac_out2~DATAOUT12\,
	combout => \L_33|I0\(12));

-- Location: LCCOMB_X78_Y11_N0
\TM2|Yout[12]~45\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[12]~45_combout\ = (\BTPM_S1~input_o\ & ((\v2[12]~input_o\))) # (!\BTPM_S1~input_o\ & (\L_33|I0\(12)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \BTPM_S1~input_o\,
	datac => \L_33|I0\(12),
	datad => \v2[12]~input_o\,
	combout => \TM2|Yout[12]~45_combout\);

-- Location: LCCOMB_X78_Y11_N10
\TM3|I1[12]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM3|I1\(12) = (GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM3|I1\(12))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM2|Yout[12]~45_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TTS~inputclkctrl_outclk\,
	datac => \TM3|I1\(12),
	datad => \TM2|Yout[12]~45_combout\,
	combout => \TM3|I1\(12));

-- Location: LCCOMB_X78_Y11_N30
\TM4|I0[12]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM4|I0\(12) = (GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & ((\TM3|I1\(12)))) # (!GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & (\TM4|I0\(12)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM4|I0\(12),
	datac => \BTPD_S2~inputclkctrl_outclk\,
	datad => \TM3|I1\(12),
	combout => \TM4|I0\(12));

-- Location: LCCOMB_X79_Y10_N10
\L_27|Yout[12]~12\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_27|Yout[12]~12_combout\ = (\M3S1~input_o\ & ((\L_3|I0\(12)) # ((\TM4|I0\(12))))) # (!\M3S1~input_o\ & (((\L_3|I2\(12)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101111001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_3|I0\(12),
	datab => \M3S1~input_o\,
	datac => \TM4|I0\(12),
	datad => \L_3|I2\(12),
	combout => \L_27|Yout[12]~12_combout\);

-- Location: LCCOMB_X73_Y12_N6
\L_33|I0[11]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_33|I0\(11) = (GLOBAL(\M3S3~inputclkctrl_outclk\) & ((\L_31|Mult0|auto_generated|mac_out2~DATAOUT11\))) # (!GLOBAL(\M3S3~inputclkctrl_outclk\) & (\L_33|I0\(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_33|I0\(11),
	datac => \L_31|Mult0|auto_generated|mac_out2~DATAOUT11\,
	datad => \M3S3~inputclkctrl_outclk\,
	combout => \L_33|I0\(11));

-- Location: LCCOMB_X73_Y12_N26
\TM2|Yout[11]~44\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[11]~44_combout\ = (\BTPM_S1~input_o\ & (\v2[11]~input_o\)) # (!\BTPM_S1~input_o\ & ((\L_33|I0\(11))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \v2[11]~input_o\,
	datac => \BTPM_S1~input_o\,
	datad => \L_33|I0\(11),
	combout => \TM2|Yout[11]~44_combout\);

-- Location: LCCOMB_X76_Y10_N8
\TM3|I1[11]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM3|I1\(11) = (GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM3|I1\(11))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM2|Yout[11]~44_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM3|I1\(11),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM2|Yout[11]~44_combout\,
	combout => \TM3|I1\(11));

-- Location: LCCOMB_X72_Y10_N14
\TM4|I0[11]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM4|I0\(11) = (GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & ((\TM3|I1\(11)))) # (!GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & (\TM4|I0\(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM4|I0\(11),
	datac => \BTPD_S2~inputclkctrl_outclk\,
	datad => \TM3|I1\(11),
	combout => \TM4|I0\(11));

-- Location: LCCOMB_X72_Y10_N28
\L_27|Yout[11]~11\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_27|Yout[11]~11_combout\ = (\M3S1~input_o\ & (((\TM4|I0\(11)) # (\L_3|I0\(11))))) # (!\M3S1~input_o\ & (\L_3|I2\(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111011100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_3|I2\(11),
	datab => \M3S1~input_o\,
	datac => \TM4|I0\(11),
	datad => \L_3|I0\(11),
	combout => \L_27|Yout[11]~11_combout\);

-- Location: LCCOMB_X75_Y11_N8
\L_33|I0[8]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_33|I0\(8) = (GLOBAL(\M3S3~inputclkctrl_outclk\) & ((\L_31|Mult0|auto_generated|mac_out2~DATAOUT8\))) # (!GLOBAL(\M3S3~inputclkctrl_outclk\) & (\L_33|I0\(8)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_33|I0\(8),
	datac => \M3S3~inputclkctrl_outclk\,
	datad => \L_31|Mult0|auto_generated|mac_out2~DATAOUT8\,
	combout => \L_33|I0\(8));

-- Location: LCCOMB_X75_Y11_N24
\TM6|Yout[8]~82\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[8]~82_combout\ = (\YMS1[0]~input_o\ & ((\YMS1[1]~input_o\) # ((\L_33|I1\(8))))) # (!\YMS1[0]~input_o\ & (!\YMS1[1]~input_o\ & (\L_54|I1\(8))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101010011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YMS1[0]~input_o\,
	datab => \YMS1[1]~input_o\,
	datac => \L_54|I1\(8),
	datad => \L_33|I1\(8),
	combout => \TM6|Yout[8]~82_combout\);

-- Location: LCCOMB_X75_Y11_N10
\TM6|Yout[8]~83\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[8]~83_combout\ = (\YMS1[1]~input_o\ & ((\TM6|Yout[8]~82_combout\ & (\v3[8]~input_o\)) # (!\TM6|Yout[8]~82_combout\ & ((\L_33|I0\(8)))))) # (!\YMS1[1]~input_o\ & (((\TM6|Yout[8]~82_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YMS1[1]~input_o\,
	datab => \v3[8]~input_o\,
	datac => \L_33|I0\(8),
	datad => \TM6|Yout[8]~82_combout\,
	combout => \TM6|Yout[8]~83_combout\);

-- Location: LCCOMB_X75_Y11_N4
\TM7|I0[8]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM7|I0\(8) = (GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM6|Yout[8]~83_combout\))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM7|I0\(8)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111001000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TTS~inputclkctrl_outclk\,
	datab => \TM7|I0\(8),
	datad => \TM6|Yout[8]~83_combout\,
	combout => \TM7|I0\(8));

-- Location: LCCOMB_X78_Y15_N22
\L_6|I0[8]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I0\(8) = (GLOBAL(\L_6|I0[15]~0clkctrl_outclk\) & ((\L_6|I0\(8)))) # (!GLOBAL(\L_6|I0[15]~0clkctrl_outclk\) & (\TM7|I0\(8)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM7|I0\(8),
	datac => \L_6|I0\(8),
	datad => \L_6|I0[15]~0clkctrl_outclk\,
	combout => \L_6|I0\(8));

-- Location: LCCOMB_X78_Y15_N20
\L_36|Yout[8]~8\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_36|Yout[8]~8_combout\ = (\L_6|I0\(8)) # ((\TM8|Equal0~0_combout\ & \TM7|I1\(8)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM8|Equal0~0_combout\,
	datac => \L_6|I0\(8),
	datad => \TM7|I1\(8),
	combout => \L_36|Yout[8]~8_combout\);

-- Location: LCCOMB_X77_Y15_N18
\L_34|Yout[8]~9\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_34|Yout[8]~9_combout\ = (\L_34|Yout[0]~0_combout\ & ((\L_7|Mux7~3_combout\) # ((\M4S1~input_o\ & \L_36|Yout[8]~8_combout\)))) # (!\L_34|Yout[0]~0_combout\ & (\M4S1~input_o\ & (\L_36|Yout[8]~8_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_34|Yout[0]~0_combout\,
	datab => \M4S1~input_o\,
	datac => \L_36|Yout[8]~8_combout\,
	datad => \L_7|Mux7~3_combout\,
	combout => \L_34|Yout[8]~9_combout\);

-- Location: LCCOMB_X76_Y18_N8
\L_40|I0[10]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_40|I0\(10) = (GLOBAL(\M4S3~inputclkctrl_outclk\) & ((\L_38|Mult0|auto_generated|mac_out2~DATAOUT10\))) # (!GLOBAL(\M4S3~inputclkctrl_outclk\) & (\L_40|I0\(10)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_40|I0\(10),
	datac => \M4S3~inputclkctrl_outclk\,
	datad => \L_38|Mult0|auto_generated|mac_out2~DATAOUT10\,
	combout => \L_40|I0\(10));

-- Location: LCCOMB_X76_Y14_N14
\L_61|I0[10]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_61|I0\(10) = (GLOBAL(\A3S3~inputclkctrl_outclk\) & ((\L_59|O[10]~20_combout\))) # (!GLOBAL(\A3S3~inputclkctrl_outclk\) & (\L_61|I0\(10)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_61|I0\(10),
	datac => \L_59|O[10]~20_combout\,
	datad => \A3S3~inputclkctrl_outclk\,
	combout => \L_61|I0\(10));

-- Location: LCCOMB_X76_Y18_N24
\TM2|Yout[10]~21\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[10]~21_combout\ = (\BMS1[1]~input_o\ & (!\BMS1[0]~input_o\)) # (!\BMS1[1]~input_o\ & ((\L_61|I0\(10))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011111100001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \BMS1[1]~input_o\,
	datac => \BMS1[0]~input_o\,
	datad => \L_61|I0\(10),
	combout => \TM2|Yout[10]~21_combout\);

-- Location: LCCOMB_X76_Y18_N2
\TM2|Yout[10]~22\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[10]~22_combout\ = (\BMS1[1]~input_o\ & ((\TM2|Yout[10]~21_combout\ & ((\L_40|I0\(10)))) # (!\TM2|Yout[10]~21_combout\ & (\v2[10]~input_o\)))) # (!\BMS1[1]~input_o\ & (((\TM2|Yout[10]~21_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v2[10]~input_o\,
	datab => \BMS1[1]~input_o\,
	datac => \L_40|I0\(10),
	datad => \TM2|Yout[10]~21_combout\,
	combout => \TM2|Yout[10]~22_combout\);

-- Location: LCCOMB_X76_Y18_N30
\TM3|I0[10]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM3|I0\(10) = (GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM2|Yout[10]~22_combout\))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM3|I0\(10)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I0\(10),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM2|Yout[10]~22_combout\,
	combout => \TM3|I0\(10));

-- Location: LCCOMB_X77_Y13_N16
\L_3|I0[10]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I0\(10) = (GLOBAL(\L_3|I0[15]~0clkctrl_outclk\) & (\L_3|I0\(10))) # (!GLOBAL(\L_3|I0[15]~0clkctrl_outclk\) & ((\TM3|I0\(10))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_3|I0\(10),
	datac => \TM3|I0\(10),
	datad => \L_3|I0[15]~0clkctrl_outclk\,
	combout => \L_3|I0\(10));

-- Location: LCCOMB_X77_Y10_N28
\L_27|Yout[10]~10\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_27|Yout[10]~10_combout\ = (\M3S1~input_o\ & ((\TM4|I0\(10)) # ((\L_3|I0\(10))))) # (!\M3S1~input_o\ & (((\L_3|I2\(10)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M3S1~input_o\,
	datab => \TM4|I0\(10),
	datac => \L_3|I2\(10),
	datad => \L_3|I0\(10),
	combout => \L_27|Yout[10]~10_combout\);

-- Location: LCCOMB_X73_Y9_N4
\L_33|I0[9]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_33|I0\(9) = (GLOBAL(\M3S3~inputclkctrl_outclk\) & ((\L_31|Mult0|auto_generated|mac_out2~DATAOUT9\))) # (!GLOBAL(\M3S3~inputclkctrl_outclk\) & (\L_33|I0\(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_33|I0\(9),
	datac => \L_31|Mult0|auto_generated|mac_out2~DATAOUT9\,
	datad => \M3S3~inputclkctrl_outclk\,
	combout => \L_33|I0\(9));

-- Location: LCCOMB_X75_Y10_N6
\TM2|Yout[9]~42\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[9]~42_combout\ = (\BTPM_S1~input_o\ & (\v2[9]~input_o\)) # (!\BTPM_S1~input_o\ & ((\L_33|I0\(9))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \BTPM_S1~input_o\,
	datab => \v2[9]~input_o\,
	datad => \L_33|I0\(9),
	combout => \TM2|Yout[9]~42_combout\);

-- Location: LCCOMB_X75_Y10_N12
\TM3|I1[9]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM3|I1\(9) = (GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM3|I1\(9))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM2|Yout[9]~42_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I1\(9),
	datab => \TTS~inputclkctrl_outclk\,
	datad => \TM2|Yout[9]~42_combout\,
	combout => \TM3|I1\(9));

-- Location: LCCOMB_X75_Y10_N4
\TM4|I0[9]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM4|I0\(9) = (GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & ((\TM3|I1\(9)))) # (!GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & (\TM4|I0\(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM4|I0\(9),
	datac => \BTPD_S2~inputclkctrl_outclk\,
	datad => \TM3|I1\(9),
	combout => \TM4|I0\(9));

-- Location: LCCOMB_X75_Y10_N16
\L_27|Yout[9]~9\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_27|Yout[9]~9_combout\ = (\M3S1~input_o\ & ((\TM4|I0\(9)) # ((\L_3|I0\(9))))) # (!\M3S1~input_o\ & (((\L_3|I2\(9)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M3S1~input_o\,
	datab => \TM4|I0\(9),
	datac => \L_3|I2\(9),
	datad => \L_3|I0\(9),
	combout => \L_27|Yout[9]~9_combout\);

-- Location: LCCOMB_X77_Y10_N4
\L_33|I0[10]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_33|I0\(10) = (GLOBAL(\M3S3~inputclkctrl_outclk\) & ((\L_31|Mult0|auto_generated|mac_out2~DATAOUT10\))) # (!GLOBAL(\M3S3~inputclkctrl_outclk\) & (\L_33|I0\(10)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_33|I0\(10),
	datac => \L_31|Mult0|auto_generated|mac_out2~DATAOUT10\,
	datad => \M3S3~inputclkctrl_outclk\,
	combout => \L_33|I0\(10));

-- Location: LCCOMB_X77_Y10_N20
\TM6|Yout[10]~86\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[10]~86_combout\ = (\YMS1[0]~input_o\ & ((\YMS1[1]~input_o\) # ((\L_33|I1\(10))))) # (!\YMS1[0]~input_o\ & (!\YMS1[1]~input_o\ & (\L_54|I1\(10))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101010011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YMS1[0]~input_o\,
	datab => \YMS1[1]~input_o\,
	datac => \L_54|I1\(10),
	datad => \L_33|I1\(10),
	combout => \TM6|Yout[10]~86_combout\);

-- Location: LCCOMB_X77_Y10_N18
\TM6|Yout[10]~87\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[10]~87_combout\ = (\YMS1[1]~input_o\ & ((\TM6|Yout[10]~86_combout\ & (\v3[10]~input_o\)) # (!\TM6|Yout[10]~86_combout\ & ((\L_33|I0\(10)))))) # (!\YMS1[1]~input_o\ & (((\TM6|Yout[10]~86_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YMS1[1]~input_o\,
	datab => \v3[10]~input_o\,
	datac => \L_33|I0\(10),
	datad => \TM6|Yout[10]~86_combout\,
	combout => \TM6|Yout[10]~87_combout\);

-- Location: LCCOMB_X77_Y10_N8
\TM7|I0[10]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM7|I0\(10) = (GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM6|Yout[10]~87_combout\))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM7|I0\(10)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM7|I0\(10),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM6|Yout[10]~87_combout\,
	combout => \TM7|I0\(10));

-- Location: LCCOMB_X76_Y4_N30
\L_6|I2[10]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I2\(10) = (GLOBAL(\L_6|Equal0~1clkctrl_outclk\) & (\TM7|I0\(10))) # (!GLOBAL(\L_6|Equal0~1clkctrl_outclk\) & ((\L_6|I2\(10))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM7|I0\(10),
	datac => \L_6|I2\(10),
	datad => \L_6|Equal0~1clkctrl_outclk\,
	combout => \L_6|I2\(10));

-- Location: LCCOMB_X76_Y4_N10
\L_50|Yout[10]~20\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_50|Yout[10]~20_combout\ = (\L_6|I2\(10)) # ((\TM8|Equal3~0_combout\ & \TM7|I1\(10)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM8|Equal3~0_combout\,
	datac => \L_6|I2\(10),
	datad => \TM7|I1\(10),
	combout => \L_50|Yout[10]~20_combout\);

-- Location: LCCOMB_X76_Y4_N18
\L_50|Yout[10]~21\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_50|Yout[10]~21_combout\ = (\A2S2~input_o\ & (\L_12|I1\(10))) # (!\A2S2~input_o\ & ((\L_50|Yout[10]~20_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \A2S2~input_o\,
	datac => \L_12|I1\(10),
	datad => \L_50|Yout[10]~20_combout\,
	combout => \L_50|Yout[10]~21_combout\);

-- Location: LCCOMB_X76_Y5_N28
\L_54|I0[10]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_54|I0\(10) = (GLOBAL(\A2S3~inputclkctrl_outclk\) & ((\L_52|O[10]~20_combout\))) # (!GLOBAL(\A2S3~inputclkctrl_outclk\) & (\L_54|I0\(10)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_54|I0\(10),
	datac => \L_52|O[10]~20_combout\,
	datad => \A2S3~inputclkctrl_outclk\,
	combout => \L_54|I0\(10));

-- Location: LCCOMB_X75_Y5_N20
\L_26|I1[10]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_26|I1\(10) = (GLOBAL(\M2S3~inputclkctrl_outclk\) & (\L_26|I1\(10))) # (!GLOBAL(\M2S3~inputclkctrl_outclk\) & ((\L_24|Mult0|auto_generated|mac_out2~DATAOUT10\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_26|I1\(10),
	datac => \M2S3~inputclkctrl_outclk\,
	datad => \L_24|Mult0|auto_generated|mac_out2~DATAOUT10\,
	combout => \L_26|I1\(10));

-- Location: LCCOMB_X75_Y5_N2
\L_26|I0[10]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_26|I0\(10) = (GLOBAL(\M2S3~inputclkctrl_outclk\) & ((\L_24|Mult0|auto_generated|mac_out2~DATAOUT10\))) # (!GLOBAL(\M2S3~inputclkctrl_outclk\) & (\L_26|I0\(10)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_26|I0\(10),
	datac => \M2S3~inputclkctrl_outclk\,
	datad => \L_24|Mult0|auto_generated|mac_out2~DATAOUT10\,
	combout => \L_26|I0\(10));

-- Location: LCCOMB_X75_Y5_N8
\L_10|Yout[10]~20\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_10|Yout[10]~20_combout\ = (\GMS1[1]~input_o\ & (((\L_26|I0\(10)) # (\GMS1[0]~input_o\)))) # (!\GMS1[1]~input_o\ & (\L_26|I1\(10) & ((!\GMS1[0]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \GMS1[1]~input_o\,
	datab => \L_26|I1\(10),
	datac => \L_26|I0\(10),
	datad => \GMS1[0]~input_o\,
	combout => \L_10|Yout[10]~20_combout\);

-- Location: LCCOMB_X75_Y5_N10
\L_10|Yout[10]~21\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_10|Yout[10]~21_combout\ = (\L_10|Yout[10]~20_combout\ & ((\v1[10]~input_o\) # ((!\GMS1[0]~input_o\)))) # (!\L_10|Yout[10]~20_combout\ & (((\L_54|I0\(10) & \GMS1[0]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v1[10]~input_o\,
	datab => \L_54|I0\(10),
	datac => \L_10|Yout[10]~20_combout\,
	datad => \GMS1[0]~input_o\,
	combout => \L_10|Yout[10]~21_combout\);

-- Location: LCCOMB_X75_Y6_N20
\L_12|I0[10]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I0\(10) = (GLOBAL(\L_12|I0[15]~0clkctrl_outclk\) & ((\L_12|I0\(10)))) # (!GLOBAL(\L_12|I0[15]~0clkctrl_outclk\) & (\L_10|Yout[10]~21_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_10|Yout[10]~21_combout\,
	datac => \L_12|I0[15]~0clkctrl_outclk\,
	datad => \L_12|I0\(10),
	combout => \L_12|I0\(10));

-- Location: LCCOMB_X76_Y5_N2
\L_12|I2[10]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I2\(10) = (GLOBAL(\L_12|Equal0~2clkctrl_outclk\) & (\L_10|Yout[10]~21_combout\)) # (!GLOBAL(\L_12|Equal0~2clkctrl_outclk\) & ((\L_12|I2\(10))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_10|Yout[10]~21_combout\,
	datab => \L_12|I2\(10),
	datad => \L_12|Equal0~2clkctrl_outclk\,
	combout => \L_12|I2\(10));

-- Location: LCCOMB_X75_Y6_N0
\L_20|Yout[10]~10\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_20|Yout[10]~10_combout\ = (\M2S1~input_o\ & (\L_12|I0\(10))) # (!\M2S1~input_o\ & ((\L_12|I2\(10))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M2S1~input_o\,
	datab => \L_12|I0\(10),
	datad => \L_12|I2\(10),
	combout => \L_20|Yout[10]~10_combout\);

-- Location: LCCOMB_X79_Y8_N16
\L_26|I0[9]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_26|I0\(9) = (GLOBAL(\M2S3~inputclkctrl_outclk\) & ((\L_24|Mult0|auto_generated|mac_out2~DATAOUT9\))) # (!GLOBAL(\M2S3~inputclkctrl_outclk\) & (\L_26|I0\(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_26|I0\(9),
	datac => \M2S3~inputclkctrl_outclk\,
	datad => \L_24|Mult0|auto_generated|mac_out2~DATAOUT9\,
	combout => \L_26|I0\(9));

-- Location: LCCOMB_X79_Y8_N20
\L_26|I1[9]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_26|I1\(9) = (GLOBAL(\M2S3~inputclkctrl_outclk\) & (\L_26|I1\(9))) # (!GLOBAL(\M2S3~inputclkctrl_outclk\) & ((\L_24|Mult0|auto_generated|mac_out2~DATAOUT9\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_26|I1\(9),
	datac => \M2S3~inputclkctrl_outclk\,
	datad => \L_24|Mult0|auto_generated|mac_out2~DATAOUT9\,
	combout => \L_26|I1\(9));

-- Location: LCCOMB_X79_Y8_N2
\L_54|I0[9]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_54|I0\(9) = (GLOBAL(\A2S3~inputclkctrl_outclk\) & ((\L_52|O[9]~18_combout\))) # (!GLOBAL(\A2S3~inputclkctrl_outclk\) & (\L_54|I0\(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_54|I0\(9),
	datac => \L_52|O[9]~18_combout\,
	datad => \A2S3~inputclkctrl_outclk\,
	combout => \L_54|I0\(9));

-- Location: LCCOMB_X79_Y8_N28
\L_10|Yout[9]~18\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_10|Yout[9]~18_combout\ = (\GMS1[1]~input_o\ & (((\GMS1[0]~input_o\)))) # (!\GMS1[1]~input_o\ & ((\GMS1[0]~input_o\ & ((\L_54|I0\(9)))) # (!\GMS1[0]~input_o\ & (\L_26|I1\(9)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101001000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \GMS1[1]~input_o\,
	datab => \L_26|I1\(9),
	datac => \L_54|I0\(9),
	datad => \GMS1[0]~input_o\,
	combout => \L_10|Yout[9]~18_combout\);

-- Location: LCCOMB_X79_Y8_N14
\L_10|Yout[9]~19\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_10|Yout[9]~19_combout\ = (\GMS1[1]~input_o\ & ((\L_10|Yout[9]~18_combout\ & (\v1[9]~input_o\)) # (!\L_10|Yout[9]~18_combout\ & ((\L_26|I0\(9)))))) # (!\GMS1[1]~input_o\ & (((\L_10|Yout[9]~18_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v1[9]~input_o\,
	datab => \L_26|I0\(9),
	datac => \GMS1[1]~input_o\,
	datad => \L_10|Yout[9]~18_combout\,
	combout => \L_10|Yout[9]~19_combout\);

-- Location: LCCOMB_X79_Y8_N6
\L_12|I2[9]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I2\(9) = (GLOBAL(\L_12|Equal0~2clkctrl_outclk\) & (\L_10|Yout[9]~19_combout\)) # (!GLOBAL(\L_12|Equal0~2clkctrl_outclk\) & ((\L_12|I2\(9))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_10|Yout[9]~19_combout\,
	datac => \L_12|Equal0~2clkctrl_outclk\,
	datad => \L_12|I2\(9),
	combout => \L_12|I2\(9));

-- Location: LCCOMB_X79_Y8_N12
\L_20|Yout[9]~9\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_20|Yout[9]~9_combout\ = (\M2S1~input_o\ & (\L_12|I0\(9))) # (!\M2S1~input_o\ & ((\L_12|I2\(9))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M2S1~input_o\,
	datac => \L_12|I0\(9),
	datad => \L_12|I2\(9),
	combout => \L_20|Yout[9]~9_combout\);

-- Location: LCCOMB_X72_Y8_N24
\L_26|I0[6]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_26|I0\(6) = (GLOBAL(\M2S3~inputclkctrl_outclk\) & ((\L_24|Mult0|auto_generated|mac_out2~DATAOUT6\))) # (!GLOBAL(\M2S3~inputclkctrl_outclk\) & (\L_26|I0\(6)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_26|I0\(6),
	datac => \L_24|Mult0|auto_generated|mac_out2~DATAOUT6\,
	datad => \M2S3~inputclkctrl_outclk\,
	combout => \L_26|I0\(6));

-- Location: LCCOMB_X72_Y8_N4
\L_10|Yout[6]~12\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_10|Yout[6]~12_combout\ = (\GMS1[0]~input_o\ & (((\GMS1[1]~input_o\)))) # (!\GMS1[0]~input_o\ & ((\GMS1[1]~input_o\ & ((\L_26|I0\(6)))) # (!\GMS1[1]~input_o\ & (\L_26|I1\(6)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_26|I1\(6),
	datab => \L_26|I0\(6),
	datac => \GMS1[0]~input_o\,
	datad => \GMS1[1]~input_o\,
	combout => \L_10|Yout[6]~12_combout\);

-- Location: LCCOMB_X72_Y8_N18
\L_10|Yout[6]~13\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_10|Yout[6]~13_combout\ = (\L_10|Yout[6]~12_combout\ & (((\v1[6]~input_o\) # (!\GMS1[0]~input_o\)))) # (!\L_10|Yout[6]~12_combout\ & (\L_54|I0\(6) & ((\GMS1[0]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_54|I0\(6),
	datab => \v1[6]~input_o\,
	datac => \L_10|Yout[6]~12_combout\,
	datad => \GMS1[0]~input_o\,
	combout => \L_10|Yout[6]~13_combout\);

-- Location: LCCOMB_X73_Y6_N12
\L_12|I0[6]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I0\(6) = (GLOBAL(\L_12|I0[15]~0clkctrl_outclk\) & ((\L_12|I0\(6)))) # (!GLOBAL(\L_12|I0[15]~0clkctrl_outclk\) & (\L_10|Yout[6]~13_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_10|Yout[6]~13_combout\,
	datac => \L_12|I0[15]~0clkctrl_outclk\,
	datad => \L_12|I0\(6),
	combout => \L_12|I0\(6));

-- Location: LCCOMB_X73_Y8_N0
\L_12|I2[6]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I2\(6) = (GLOBAL(\L_12|Equal0~2clkctrl_outclk\) & (\L_10|Yout[6]~13_combout\)) # (!GLOBAL(\L_12|Equal0~2clkctrl_outclk\) & ((\L_12|I2\(6))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_10|Yout[6]~13_combout\,
	datac => \L_12|Equal0~2clkctrl_outclk\,
	datad => \L_12|I2\(6),
	combout => \L_12|I2\(6));

-- Location: LCCOMB_X73_Y8_N30
\L_20|Yout[6]~6\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_20|Yout[6]~6_combout\ = (\M2S1~input_o\ & (\L_12|I0\(6))) # (!\M2S1~input_o\ & ((\L_12|I2\(6))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \M2S1~input_o\,
	datac => \L_12|I0\(6),
	datad => \L_12|I2\(6),
	combout => \L_20|Yout[6]~6_combout\);

-- Location: LCCOMB_X75_Y5_N0
\L_26|I0[5]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_26|I0\(5) = (GLOBAL(\M2S3~inputclkctrl_outclk\) & (\L_24|Mult0|auto_generated|mac_out2~DATAOUT5\)) # (!GLOBAL(\M2S3~inputclkctrl_outclk\) & ((\L_26|I0\(5))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M2S3~inputclkctrl_outclk\,
	datac => \L_24|Mult0|auto_generated|mac_out2~DATAOUT5\,
	datad => \L_26|I0\(5),
	combout => \L_26|I0\(5));

-- Location: IOIBUF_X117_Y5_N8
\v1[5]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v1(5),
	o => \v1[5]~input_o\);

-- Location: LCCOMB_X75_Y5_N28
\L_26|I1[5]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_26|I1\(5) = (GLOBAL(\M2S3~inputclkctrl_outclk\) & ((\L_26|I1\(5)))) # (!GLOBAL(\M2S3~inputclkctrl_outclk\) & (\L_24|Mult0|auto_generated|mac_out2~DATAOUT5\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M2S3~inputclkctrl_outclk\,
	datac => \L_24|Mult0|auto_generated|mac_out2~DATAOUT5\,
	datad => \L_26|I1\(5),
	combout => \L_26|I1\(5));

-- Location: LCCOMB_X75_Y5_N6
\L_54|I0[5]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_54|I0\(5) = (GLOBAL(\A2S3~inputclkctrl_outclk\) & ((\L_52|O[5]~10_combout\))) # (!GLOBAL(\A2S3~inputclkctrl_outclk\) & (\L_54|I0\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111000100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_54|I0\(5),
	datab => \A2S3~inputclkctrl_outclk\,
	datad => \L_52|O[5]~10_combout\,
	combout => \L_54|I0\(5));

-- Location: LCCOMB_X75_Y5_N4
\L_10|Yout[5]~10\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_10|Yout[5]~10_combout\ = (\GMS1[0]~input_o\ & (((\GMS1[1]~input_o\) # (\L_54|I0\(5))))) # (!\GMS1[0]~input_o\ & (\L_26|I1\(5) & (!\GMS1[1]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111010100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \GMS1[0]~input_o\,
	datab => \L_26|I1\(5),
	datac => \GMS1[1]~input_o\,
	datad => \L_54|I0\(5),
	combout => \L_10|Yout[5]~10_combout\);

-- Location: LCCOMB_X75_Y5_N22
\L_10|Yout[5]~11\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_10|Yout[5]~11_combout\ = (\GMS1[1]~input_o\ & ((\L_10|Yout[5]~10_combout\ & ((\v1[5]~input_o\))) # (!\L_10|Yout[5]~10_combout\ & (\L_26|I0\(5))))) # (!\GMS1[1]~input_o\ & (((\L_10|Yout[5]~10_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \GMS1[1]~input_o\,
	datab => \L_26|I0\(5),
	datac => \v1[5]~input_o\,
	datad => \L_10|Yout[5]~10_combout\,
	combout => \L_10|Yout[5]~11_combout\);

-- Location: LCCOMB_X75_Y6_N22
\L_12|I2[5]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I2\(5) = (GLOBAL(\L_12|Equal0~2clkctrl_outclk\) & (\L_10|Yout[5]~11_combout\)) # (!GLOBAL(\L_12|Equal0~2clkctrl_outclk\) & ((\L_12|I2\(5))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_10|Yout[5]~11_combout\,
	datac => \L_12|I2\(5),
	datad => \L_12|Equal0~2clkctrl_outclk\,
	combout => \L_12|I2\(5));

-- Location: LCCOMB_X75_Y6_N30
\L_20|Yout[5]~5\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_20|Yout[5]~5_combout\ = (\M2S1~input_o\ & ((\L_12|I0\(5)))) # (!\M2S1~input_o\ & (\L_12|I2\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M2S1~input_o\,
	datac => \L_12|I2\(5),
	datad => \L_12|I0\(5),
	combout => \L_20|Yout[5]~5_combout\);

-- Location: LCCOMB_X75_Y9_N0
\L_26|I0[4]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_26|I0\(4) = (GLOBAL(\M2S3~inputclkctrl_outclk\) & ((\L_24|Mult0|auto_generated|mac_out2~DATAOUT4\))) # (!GLOBAL(\M2S3~inputclkctrl_outclk\) & (\L_26|I0\(4)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_26|I0\(4),
	datac => \M2S3~inputclkctrl_outclk\,
	datad => \L_24|Mult0|auto_generated|mac_out2~DATAOUT4\,
	combout => \L_26|I0\(4));

-- Location: LCCOMB_X75_Y9_N8
\L_10|Yout[4]~8\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_10|Yout[4]~8_combout\ = (\GMS1[0]~input_o\ & (((\GMS1[1]~input_o\)))) # (!\GMS1[0]~input_o\ & ((\GMS1[1]~input_o\ & ((\L_26|I0\(4)))) # (!\GMS1[1]~input_o\ & (\L_26|I1\(4)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_26|I1\(4),
	datab => \GMS1[0]~input_o\,
	datac => \L_26|I0\(4),
	datad => \GMS1[1]~input_o\,
	combout => \L_10|Yout[4]~8_combout\);

-- Location: LCCOMB_X75_Y9_N26
\L_10|Yout[4]~9\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_10|Yout[4]~9_combout\ = (\L_10|Yout[4]~8_combout\ & ((\v1[4]~input_o\) # ((!\GMS1[0]~input_o\)))) # (!\L_10|Yout[4]~8_combout\ & (((\L_54|I0\(4) & \GMS1[0]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v1[4]~input_o\,
	datab => \L_54|I0\(4),
	datac => \L_10|Yout[4]~8_combout\,
	datad => \GMS1[0]~input_o\,
	combout => \L_10|Yout[4]~9_combout\);

-- Location: LCCOMB_X73_Y8_N14
\L_12|I2[4]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I2\(4) = (GLOBAL(\L_12|Equal0~2clkctrl_outclk\) & ((\L_10|Yout[4]~9_combout\))) # (!GLOBAL(\L_12|Equal0~2clkctrl_outclk\) & (\L_12|I2\(4)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_12|I2\(4),
	datac => \L_12|Equal0~2clkctrl_outclk\,
	datad => \L_10|Yout[4]~9_combout\,
	combout => \L_12|I2\(4));

-- Location: LCCOMB_X73_Y8_N20
\L_20|Yout[4]~4\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_20|Yout[4]~4_combout\ = (\M2S1~input_o\ & ((\L_12|I0\(4)))) # (!\M2S1~input_o\ & (\L_12|I2\(4)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \M2S1~input_o\,
	datac => \L_12|I2\(4),
	datad => \L_12|I0\(4),
	combout => \L_20|Yout[4]~4_combout\);

-- Location: LCCOMB_X77_Y9_N16
\L_26|I1[7]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_26|I1\(7) = (GLOBAL(\M2S3~inputclkctrl_outclk\) & (\L_26|I1\(7))) # (!GLOBAL(\M2S3~inputclkctrl_outclk\) & ((\L_24|Mult0|auto_generated|mac_out2~DATAOUT7\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_26|I1\(7),
	datac => \M2S3~inputclkctrl_outclk\,
	datad => \L_24|Mult0|auto_generated|mac_out2~DATAOUT7\,
	combout => \L_26|I1\(7));

-- Location: LCCOMB_X77_Y9_N2
\L_54|I0[7]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_54|I0\(7) = (GLOBAL(\A2S3~inputclkctrl_outclk\) & ((\L_52|O[7]~14_combout\))) # (!GLOBAL(\A2S3~inputclkctrl_outclk\) & (\L_54|I0\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_54|I0\(7),
	datac => \L_52|O[7]~14_combout\,
	datad => \A2S3~inputclkctrl_outclk\,
	combout => \L_54|I0\(7));

-- Location: LCCOMB_X77_Y9_N8
\L_10|Yout[7]~14\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_10|Yout[7]~14_combout\ = (\GMS1[0]~input_o\ & (((\L_54|I0\(7)) # (\GMS1[1]~input_o\)))) # (!\GMS1[0]~input_o\ & (\L_26|I1\(7) & ((!\GMS1[1]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \GMS1[0]~input_o\,
	datab => \L_26|I1\(7),
	datac => \L_54|I0\(7),
	datad => \GMS1[1]~input_o\,
	combout => \L_10|Yout[7]~14_combout\);

-- Location: LCCOMB_X77_Y9_N6
\L_10|Yout[7]~15\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_10|Yout[7]~15_combout\ = (\GMS1[1]~input_o\ & ((\L_10|Yout[7]~14_combout\ & ((\v1[7]~input_o\))) # (!\L_10|Yout[7]~14_combout\ & (\L_26|I0\(7))))) # (!\GMS1[1]~input_o\ & (((\L_10|Yout[7]~14_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_26|I0\(7),
	datab => \GMS1[1]~input_o\,
	datac => \v1[7]~input_o\,
	datad => \L_10|Yout[7]~14_combout\,
	combout => \L_10|Yout[7]~15_combout\);

-- Location: LCCOMB_X77_Y9_N22
\L_12|I3[7]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I3\(7) = (GLOBAL(\L_12|Equal0~0clkctrl_outclk\) & ((\L_12|I3\(7)))) # (!GLOBAL(\L_12|Equal0~0clkctrl_outclk\) & (\L_10|Yout[7]~15_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_10|Yout[7]~15_combout\,
	datac => \L_12|I3\(7),
	datad => \L_12|Equal0~0clkctrl_outclk\,
	combout => \L_12|I3\(7));

-- Location: LCCOMB_X79_Y12_N4
\L_57|Yout[7]~15\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_57|Yout[7]~15_combout\ = (\A3S2~input_o\ & (\L_57|Yout[7]~14_combout\)) # (!\A3S2~input_o\ & ((\L_12|I3\(7))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_57|Yout[7]~14_combout\,
	datac => \A3S2~input_o\,
	datad => \L_12|I3\(7),
	combout => \L_57|Yout[7]~15_combout\);

-- Location: LCCOMB_X77_Y14_N4
\L_61|I1[7]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_61|I1\(7) = (GLOBAL(\A3S3~inputclkctrl_outclk\) & ((\L_61|I1\(7)))) # (!GLOBAL(\A3S3~inputclkctrl_outclk\) & (\L_59|O[7]~14_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_59|O[7]~14_combout\,
	datac => \L_61|I1\(7),
	datad => \A3S3~inputclkctrl_outclk\,
	combout => \L_61|I1\(7));

-- Location: LCCOMB_X77_Y14_N22
\L_47|I1[7]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_47|I1\(7) = (GLOBAL(\A1S3~inputclkctrl_outclk\) & (\L_47|I1\(7))) # (!GLOBAL(\A1S3~inputclkctrl_outclk\) & ((\L_45|O[7]~14_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_47|I1\(7),
	datac => \A1S3~inputclkctrl_outclk\,
	datad => \L_45|O[7]~14_combout\,
	combout => \L_47|I1\(7));

-- Location: LCCOMB_X77_Y14_N16
\L_40|I1[7]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_40|I1\(7) = (GLOBAL(\M4S3~inputclkctrl_outclk\) & (\L_40|I1\(7))) # (!GLOBAL(\M4S3~inputclkctrl_outclk\) & ((\L_38|Mult0|auto_generated|mac_out2~DATAOUT7\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_40|I1\(7),
	datac => \L_38|Mult0|auto_generated|mac_out2~DATAOUT7\,
	datad => \M4S3~inputclkctrl_outclk\,
	combout => \L_40|I1\(7));

-- Location: LCCOMB_X77_Y14_N24
\L_7|Mux8~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux8~2_combout\ = (\L_7|Mux15~3_combout\ & (\L_7|Mux15~0_combout\)) # (!\L_7|Mux15~3_combout\ & ((\L_7|Mux15~0_combout\ & ((\L_40|I1\(7)))) # (!\L_7|Mux15~0_combout\ & (\L_47|I1\(7)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110010011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_7|Mux15~3_combout\,
	datab => \L_7|Mux15~0_combout\,
	datac => \L_47|I1\(7),
	datad => \L_40|I1\(7),
	combout => \L_7|Mux8~2_combout\);

-- Location: LCCOMB_X77_Y14_N30
\L_7|Mux8~3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux8~3_combout\ = (\L_7|Mux15~3_combout\ & ((\L_7|Mux8~2_combout\ & ((\L_61|I1\(7)))) # (!\L_7|Mux8~2_combout\ & (\L_7|Mux8~1_combout\)))) # (!\L_7|Mux15~3_combout\ & (((\L_7|Mux8~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_7|Mux8~1_combout\,
	datab => \L_7|Mux15~3_combout\,
	datac => \L_61|I1\(7),
	datad => \L_7|Mux8~2_combout\,
	combout => \L_7|Mux8~3_combout\);

-- Location: LCCOMB_X77_Y14_N14
\L_34|Yout[7]~8\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_34|Yout[7]~8_combout\ = (\L_34|Yout[0]~0_combout\ & ((\L_7|Mux8~3_combout\) # ((\M4S1~input_o\ & \L_36|Yout[7]~7_combout\)))) # (!\L_34|Yout[0]~0_combout\ & (\M4S1~input_o\ & ((\L_36|Yout[7]~7_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_34|Yout[0]~0_combout\,
	datab => \M4S1~input_o\,
	datac => \L_7|Mux8~3_combout\,
	datad => \L_36|Yout[7]~7_combout\,
	combout => \L_34|Yout[7]~8_combout\);

-- Location: LCCOMB_X75_Y14_N14
\L_40|I0[3]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_40|I0\(3) = (GLOBAL(\M4S3~inputclkctrl_outclk\) & ((\L_38|Mult0|auto_generated|mac_out2~DATAOUT3\))) # (!GLOBAL(\M4S3~inputclkctrl_outclk\) & (\L_40|I0\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_40|I0\(3),
	datac => \M4S3~inputclkctrl_outclk\,
	datad => \L_38|Mult0|auto_generated|mac_out2~DATAOUT3\,
	combout => \L_40|I0\(3));

-- Location: LCCOMB_X77_Y12_N4
\L_12|I3[2]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I3\(2) = (GLOBAL(\L_12|Equal0~0clkctrl_outclk\) & (\L_12|I3\(2))) # (!GLOBAL(\L_12|Equal0~0clkctrl_outclk\) & ((\L_10|Yout[2]~5_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_12|I3\(2),
	datac => \L_12|Equal0~0clkctrl_outclk\,
	datad => \L_10|Yout[2]~5_combout\,
	combout => \L_12|I3\(2));

-- Location: LCCOMB_X73_Y11_N24
\L_61|I0[2]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_61|I0\(2) = (GLOBAL(\A3S3~inputclkctrl_outclk\) & (\L_59|O[2]~4_combout\)) # (!GLOBAL(\A3S3~inputclkctrl_outclk\) & ((\L_61|I0\(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_59|O[2]~4_combout\,
	datac => \A3S3~inputclkctrl_outclk\,
	datad => \L_61|I0\(2),
	combout => \L_61|I0\(2));

-- Location: LCCOMB_X73_Y11_N4
\TM2|Yout[2]~5\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[2]~5_combout\ = (\BMS1[1]~input_o\ & (!\BMS1[0]~input_o\)) # (!\BMS1[1]~input_o\ & ((\L_61|I0\(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101111100001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \BMS1[1]~input_o\,
	datac => \BMS1[0]~input_o\,
	datad => \L_61|I0\(2),
	combout => \TM2|Yout[2]~5_combout\);

-- Location: LCCOMB_X73_Y11_N18
\TM2|Yout[2]~6\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[2]~6_combout\ = (\BMS1[1]~input_o\ & ((\TM2|Yout[2]~5_combout\ & ((\L_40|I0\(2)))) # (!\TM2|Yout[2]~5_combout\ & (\v2[2]~input_o\)))) # (!\BMS1[1]~input_o\ & (((\TM2|Yout[2]~5_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100001011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \BMS1[1]~input_o\,
	datab => \v2[2]~input_o\,
	datac => \TM2|Yout[2]~5_combout\,
	datad => \L_40|I0\(2),
	combout => \TM2|Yout[2]~6_combout\);

-- Location: LCCOMB_X73_Y11_N26
\TM3|I0[2]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM3|I0\(2) = (GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM2|Yout[2]~6_combout\))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM3|I0\(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111000100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I0\(2),
	datab => \TTS~inputclkctrl_outclk\,
	datad => \TM2|Yout[2]~6_combout\,
	combout => \TM3|I0\(2));

-- Location: LCCOMB_X77_Y12_N2
\L_3|I1[2]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I1\(2) = (GLOBAL(\L_3|Equal0~0clkctrl_outclk\) & ((\TM3|I0\(2)))) # (!GLOBAL(\L_3|Equal0~0clkctrl_outclk\) & (\L_3|I1\(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_3|I1\(2),
	datac => \TM3|I0\(2),
	datad => \L_3|Equal0~0clkctrl_outclk\,
	combout => \L_3|I1\(2));

-- Location: LCCOMB_X77_Y12_N26
\L_57|Yout[2]~4\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_57|Yout[2]~4_combout\ = (\TTS~input_o\ & ((\L_3|I1\(2)) # ((\L_55|Yout[0]~0_combout\ & \TM7|I1\(2))))) # (!\TTS~input_o\ & (((\L_55|Yout[0]~0_combout\ & \TM7|I1\(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TTS~input_o\,
	datab => \L_3|I1\(2),
	datac => \L_55|Yout[0]~0_combout\,
	datad => \TM7|I1\(2),
	combout => \L_57|Yout[2]~4_combout\);

-- Location: LCCOMB_X77_Y12_N10
\L_57|Yout[2]~5\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_57|Yout[2]~5_combout\ = (\A3S2~input_o\ & ((\L_57|Yout[2]~4_combout\))) # (!\A3S2~input_o\ & (\L_12|I3\(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110010011100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \A3S2~input_o\,
	datab => \L_12|I3\(2),
	datac => \L_57|Yout[2]~4_combout\,
	combout => \L_57|Yout[2]~5_combout\);

-- Location: LCCOMB_X76_Y12_N2
\L_59|O[1]~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_59|O[1]~2_combout\ = (\L_57|Yout[1]~3_combout\ & ((\L_55|Yout[1]~3_combout\ & (\L_59|O[0]~1\ & VCC)) # (!\L_55|Yout[1]~3_combout\ & (!\L_59|O[0]~1\)))) # (!\L_57|Yout[1]~3_combout\ & ((\L_55|Yout[1]~3_combout\ & (!\L_59|O[0]~1\)) # 
-- (!\L_55|Yout[1]~3_combout\ & ((\L_59|O[0]~1\) # (GND)))))
-- \L_59|O[1]~3\ = CARRY((\L_57|Yout[1]~3_combout\ & (!\L_55|Yout[1]~3_combout\ & !\L_59|O[0]~1\)) # (!\L_57|Yout[1]~3_combout\ & ((!\L_59|O[0]~1\) # (!\L_55|Yout[1]~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011000010111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_57|Yout[1]~3_combout\,
	datab => \L_55|Yout[1]~3_combout\,
	datad => VCC,
	cin => \L_59|O[0]~1\,
	combout => \L_59|O[1]~2_combout\,
	cout => \L_59|O[1]~3\);

-- Location: LCCOMB_X76_Y12_N6
\L_59|O[3]~6\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_59|O[3]~6_combout\ = (\L_57|Yout[3]~7_combout\ & ((\L_55|Yout[3]~5_combout\ & (\L_59|O[2]~5\ & VCC)) # (!\L_55|Yout[3]~5_combout\ & (!\L_59|O[2]~5\)))) # (!\L_57|Yout[3]~7_combout\ & ((\L_55|Yout[3]~5_combout\ & (!\L_59|O[2]~5\)) # 
-- (!\L_55|Yout[3]~5_combout\ & ((\L_59|O[2]~5\) # (GND)))))
-- \L_59|O[3]~7\ = CARRY((\L_57|Yout[3]~7_combout\ & (!\L_55|Yout[3]~5_combout\ & !\L_59|O[2]~5\)) # (!\L_57|Yout[3]~7_combout\ & ((!\L_59|O[2]~5\) # (!\L_55|Yout[3]~5_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011000010111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_57|Yout[3]~7_combout\,
	datab => \L_55|Yout[3]~5_combout\,
	datad => VCC,
	cin => \L_59|O[2]~5\,
	combout => \L_59|O[3]~6_combout\,
	cout => \L_59|O[3]~7\);

-- Location: LCCOMB_X76_Y13_N22
\L_61|I0[3]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_61|I0\(3) = (GLOBAL(\A3S3~inputclkctrl_outclk\) & (\L_59|O[3]~6_combout\)) # (!GLOBAL(\A3S3~inputclkctrl_outclk\) & ((\L_61|I0\(3))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_59|O[3]~6_combout\,
	datac => \L_61|I0\(3),
	datad => \A3S3~inputclkctrl_outclk\,
	combout => \L_61|I0\(3));

-- Location: LCCOMB_X76_Y9_N28
\TM6|Yout[3]~14\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[3]~14_combout\ = (\YTPM_S1[1]~input_o\ & (((\L_61|I0\(3))))) # (!\YTPM_S1[1]~input_o\ & (((\L_40|I0\(3))) # (!\YTPM_S1[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110100110001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPM_S1[0]~input_o\,
	datab => \YTPM_S1[1]~input_o\,
	datac => \L_40|I0\(3),
	datad => \L_61|I0\(3),
	combout => \TM6|Yout[3]~14_combout\);

-- Location: LCCOMB_X76_Y9_N2
\TM6|Yout[3]~15\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[3]~15_combout\ = (\TM6|Yout[0]~5_combout\ & (((\TM6|Yout[3]~14_combout\)))) # (!\TM6|Yout[0]~5_combout\ & ((\TM6|Yout[3]~14_combout\ & (\v3[3]~input_o\)) # (!\TM6|Yout[3]~14_combout\ & ((\L_33|I0\(3))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v3[3]~input_o\,
	datab => \TM6|Yout[0]~5_combout\,
	datac => \L_33|I0\(3),
	datad => \TM6|Yout[3]~14_combout\,
	combout => \TM6|Yout[3]~15_combout\);

-- Location: LCCOMB_X76_Y9_N16
\TM6|Yout[3]~16\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[3]~16_combout\ = (\YTPM_S1[0]~input_o\ & ((\YTPM_S1[1]~input_o\ & (\L_33|I1\(3))) # (!\YTPM_S1[1]~input_o\ & ((\TM6|Yout[3]~15_combout\))))) # (!\YTPM_S1[0]~input_o\ & (((\TM6|Yout[3]~15_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111011110000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPM_S1[0]~input_o\,
	datab => \YTPM_S1[1]~input_o\,
	datac => \L_33|I1\(3),
	datad => \TM6|Yout[3]~15_combout\,
	combout => \TM6|Yout[3]~16_combout\);

-- Location: LCCOMB_X76_Y9_N18
\TM6|Yout[3]~17\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[3]~17_combout\ = (\YTPM_S1[2]~input_o\ & (\L_54|I1\(3))) # (!\YTPM_S1[2]~input_o\ & ((\TM6|Yout[3]~16_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPM_S1[2]~input_o\,
	datac => \L_54|I1\(3),
	datad => \TM6|Yout[3]~16_combout\,
	combout => \TM6|Yout[3]~17_combout\);

-- Location: LCCOMB_X76_Y9_N22
\TM7|I1[3]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM7|I1\(3) = (GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM7|I1\(3))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM6|Yout[3]~17_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM7|I1\(3),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM6|Yout[3]~17_combout\,
	combout => \TM7|I1\(3));

-- Location: LCCOMB_X76_Y10_N24
\TM2|Yout[3]~7\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[3]~7_combout\ = (\BMS1[1]~input_o\ & ((\v2[3]~input_o\) # (!\BMS1[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \BMS1[1]~input_o\,
	datab => \v2[3]~input_o\,
	datad => \BMS1[0]~input_o\,
	combout => \TM2|Yout[3]~7_combout\);

-- Location: LCCOMB_X76_Y10_N18
\TM2|Yout[3]~8\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[3]~8_combout\ = (\TM2|Yout[9]~2_combout\ & ((\TM2|Yout[3]~7_combout\ & ((\L_40|I0\(3)))) # (!\TM2|Yout[3]~7_combout\ & (\L_61|I0\(3))))) # (!\TM2|Yout[9]~2_combout\ & (\TM2|Yout[3]~7_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110001100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM2|Yout[9]~2_combout\,
	datab => \TM2|Yout[3]~7_combout\,
	datac => \L_61|I0\(3),
	datad => \L_40|I0\(3),
	combout => \TM2|Yout[3]~8_combout\);

-- Location: LCCOMB_X76_Y10_N30
\TM3|I0[3]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM3|I0\(3) = (GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM2|Yout[3]~8_combout\))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM3|I0\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I0\(3),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM2|Yout[3]~8_combout\,
	combout => \TM3|I0\(3));

-- Location: LCCOMB_X80_Y8_N4
\L_3|I1[3]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I1\(3) = (GLOBAL(\L_3|Equal0~0clkctrl_outclk\) & (\TM3|I0\(3))) # (!GLOBAL(\L_3|Equal0~0clkctrl_outclk\) & ((\L_3|I1\(3))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM3|I0\(3),
	datac => \L_3|I1\(3),
	datad => \L_3|Equal0~0clkctrl_outclk\,
	combout => \L_3|I1\(3));

-- Location: LCCOMB_X76_Y5_N4
\L_57|Yout[3]~6\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_57|Yout[3]~6_combout\ = (\TTS~input_o\ & ((\L_3|I1\(3)) # ((\L_55|Yout[0]~0_combout\ & \TM7|I1\(3))))) # (!\TTS~input_o\ & (\L_55|Yout[0]~0_combout\ & (\TM7|I1\(3))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TTS~input_o\,
	datab => \L_55|Yout[0]~0_combout\,
	datac => \TM7|I1\(3),
	datad => \L_3|I1\(3),
	combout => \L_57|Yout[3]~6_combout\);

-- Location: LCCOMB_X76_Y5_N22
\L_55|Yout[3]~5\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_55|Yout[3]~5_combout\ = (\A3S1~input_o\ & ((\L_57|Yout[3]~6_combout\) # ((\L_55|Yout[15]~1_combout\ & \L_7|Mux12~3_combout\)))) # (!\A3S1~input_o\ & (\L_55|Yout[15]~1_combout\ & ((\L_7|Mux12~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \A3S1~input_o\,
	datab => \L_55|Yout[15]~1_combout\,
	datac => \L_57|Yout[3]~6_combout\,
	datad => \L_7|Mux12~3_combout\,
	combout => \L_55|Yout[3]~5_combout\);

-- Location: LCCOMB_X76_Y12_N8
\L_59|O[4]~8\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_59|O[4]~8_combout\ = ((\L_55|Yout[4]~6_combout\ $ (\L_57|Yout[4]~9_combout\ $ (!\L_59|O[3]~7\)))) # (GND)
-- \L_59|O[4]~9\ = CARRY((\L_55|Yout[4]~6_combout\ & ((\L_57|Yout[4]~9_combout\) # (!\L_59|O[3]~7\))) # (!\L_55|Yout[4]~6_combout\ & (\L_57|Yout[4]~9_combout\ & !\L_59|O[3]~7\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100110001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_55|Yout[4]~6_combout\,
	datab => \L_57|Yout[4]~9_combout\,
	datad => VCC,
	cin => \L_59|O[3]~7\,
	combout => \L_59|O[4]~8_combout\,
	cout => \L_59|O[4]~9\);

-- Location: LCCOMB_X76_Y12_N10
\L_59|O[5]~10\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_59|O[5]~10_combout\ = (\L_55|Yout[5]~7_combout\ & ((\L_57|Yout[5]~11_combout\ & (\L_59|O[4]~9\ & VCC)) # (!\L_57|Yout[5]~11_combout\ & (!\L_59|O[4]~9\)))) # (!\L_55|Yout[5]~7_combout\ & ((\L_57|Yout[5]~11_combout\ & (!\L_59|O[4]~9\)) # 
-- (!\L_57|Yout[5]~11_combout\ & ((\L_59|O[4]~9\) # (GND)))))
-- \L_59|O[5]~11\ = CARRY((\L_55|Yout[5]~7_combout\ & (!\L_57|Yout[5]~11_combout\ & !\L_59|O[4]~9\)) # (!\L_55|Yout[5]~7_combout\ & ((!\L_59|O[4]~9\) # (!\L_57|Yout[5]~11_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011000010111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \L_55|Yout[5]~7_combout\,
	datab => \L_57|Yout[5]~11_combout\,
	datad => VCC,
	cin => \L_59|O[4]~9\,
	combout => \L_59|O[5]~10_combout\,
	cout => \L_59|O[5]~11\);

-- Location: LCCOMB_X72_Y15_N20
\L_61|I0[6]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_61|I0\(6) = (GLOBAL(\A3S3~inputclkctrl_outclk\) & ((\L_59|O[6]~12_combout\))) # (!GLOBAL(\A3S3~inputclkctrl_outclk\) & (\L_61|I0\(6)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_61|I0\(6),
	datac => \A3S3~inputclkctrl_outclk\,
	datad => \L_59|O[6]~12_combout\,
	combout => \L_61|I0\(6));

-- Location: LCCOMB_X72_Y11_N24
\TM6|Yout[6]~26\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[6]~26_combout\ = (!\YTPM_S1[1]~input_o\ & ((\L_40|I0\(6)) # (!\YTPM_S1[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \YTPM_S1[1]~input_o\,
	datac => \YTPM_S1[0]~input_o\,
	datad => \L_40|I0\(6),
	combout => \TM6|Yout[6]~26_combout\);

-- Location: LCCOMB_X72_Y11_N22
\TM6|Yout[6]~27\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[6]~27_combout\ = (\TM6|Yout[0]~0_combout\ & ((\TM6|Yout[6]~26_combout\ & (\v3[6]~input_o\)) # (!\TM6|Yout[6]~26_combout\ & ((\L_61|I0\(6)))))) # (!\TM6|Yout[0]~0_combout\ & (((\TM6|Yout[6]~26_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v3[6]~input_o\,
	datab => \TM6|Yout[0]~0_combout\,
	datac => \L_61|I0\(6),
	datad => \TM6|Yout[6]~26_combout\,
	combout => \TM6|Yout[6]~27_combout\);

-- Location: LCCOMB_X72_Y11_N10
\L_33|I1[6]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_33|I1\(6) = (GLOBAL(\M3S3~inputclkctrl_outclk\) & (\L_33|I1\(6))) # (!GLOBAL(\M3S3~inputclkctrl_outclk\) & ((\L_31|Mult0|auto_generated|mac_out2~DATAOUT6\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_33|I1\(6),
	datac => \M3S3~inputclkctrl_outclk\,
	datad => \L_31|Mult0|auto_generated|mac_out2~DATAOUT6\,
	combout => \L_33|I1\(6));

-- Location: LCCOMB_X72_Y11_N12
\TM6|Yout[6]~28\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[6]~28_combout\ = (\YTPM_S1[0]~input_o\ & ((\YTPM_S1[1]~input_o\ & ((\L_33|I1\(6)))) # (!\YTPM_S1[1]~input_o\ & (\TM6|Yout[6]~27_combout\)))) # (!\YTPM_S1[0]~input_o\ & (((\TM6|Yout[6]~27_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100001110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPM_S1[0]~input_o\,
	datab => \YTPM_S1[1]~input_o\,
	datac => \TM6|Yout[6]~27_combout\,
	datad => \L_33|I1\(6),
	combout => \TM6|Yout[6]~28_combout\);

-- Location: LCCOMB_X72_Y11_N18
\TM6|Yout[6]~29\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[6]~29_combout\ = (\YTPM_S1[2]~input_o\ & (\L_54|I1\(6))) # (!\YTPM_S1[2]~input_o\ & ((\TM6|Yout[6]~28_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPM_S1[2]~input_o\,
	datac => \L_54|I1\(6),
	datad => \TM6|Yout[6]~28_combout\,
	combout => \TM6|Yout[6]~29_combout\);

-- Location: LCCOMB_X72_Y11_N30
\TM7|I1[6]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM7|I1\(6) = (GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM7|I1\(6))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM6|Yout[6]~29_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TTS~inputclkctrl_outclk\,
	datac => \TM7|I1\(6),
	datad => \TM6|Yout[6]~29_combout\,
	combout => \TM7|I1\(6));

-- Location: LCCOMB_X72_Y7_N10
\L_6|I2[6]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I2\(6) = (GLOBAL(\L_6|Equal0~1clkctrl_outclk\) & ((\TM7|I0\(6)))) # (!GLOBAL(\L_6|Equal0~1clkctrl_outclk\) & (\L_6|I2\(6)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_6|I2\(6),
	datab => \TM7|I0\(6),
	datad => \L_6|Equal0~1clkctrl_outclk\,
	combout => \L_6|I2\(6));

-- Location: LCCOMB_X72_Y7_N28
\L_50|Yout[6]~12\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_50|Yout[6]~12_combout\ = (\L_6|I2\(6)) # ((\TM8|Equal3~0_combout\ & \TM7|I1\(6)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM8|Equal3~0_combout\,
	datac => \TM7|I1\(6),
	datad => \L_6|I2\(6),
	combout => \L_50|Yout[6]~12_combout\);

-- Location: LCCOMB_X72_Y7_N24
\L_50|Yout[6]~13\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_50|Yout[6]~13_combout\ = (\A2S2~input_o\ & (\L_12|I1\(6))) # (!\A2S2~input_o\ & ((\L_50|Yout[6]~12_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \A2S2~input_o\,
	datac => \L_12|I1\(6),
	datad => \L_50|Yout[6]~12_combout\,
	combout => \L_50|Yout[6]~13_combout\);

-- Location: LCCOMB_X75_Y9_N24
\L_54|I1[6]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_54|I1\(6) = (GLOBAL(\A2S3~inputclkctrl_outclk\) & (\L_54|I1\(6))) # (!GLOBAL(\A2S3~inputclkctrl_outclk\) & ((\L_52|O[6]~12_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_54|I1\(6),
	datac => \A2S3~inputclkctrl_outclk\,
	datad => \L_52|O[6]~12_combout\,
	combout => \L_54|I1\(6));

-- Location: LCCOMB_X72_Y11_N16
\TM6|Yout[6]~78\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[6]~78_combout\ = (\YMS1[0]~input_o\ & ((\YMS1[1]~input_o\) # ((\L_33|I1\(6))))) # (!\YMS1[0]~input_o\ & (!\YMS1[1]~input_o\ & (\L_54|I1\(6))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101010011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YMS1[0]~input_o\,
	datab => \YMS1[1]~input_o\,
	datac => \L_54|I1\(6),
	datad => \L_33|I1\(6),
	combout => \TM6|Yout[6]~78_combout\);

-- Location: LCCOMB_X72_Y11_N6
\TM6|Yout[6]~79\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[6]~79_combout\ = (\YMS1[1]~input_o\ & ((\TM6|Yout[6]~78_combout\ & (\v3[6]~input_o\)) # (!\TM6|Yout[6]~78_combout\ & ((\L_33|I0\(6)))))) # (!\YMS1[1]~input_o\ & (((\TM6|Yout[6]~78_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v3[6]~input_o\,
	datab => \L_33|I0\(6),
	datac => \YMS1[1]~input_o\,
	datad => \TM6|Yout[6]~78_combout\,
	combout => \TM6|Yout[6]~79_combout\);

-- Location: LCCOMB_X72_Y11_N28
\TM7|I0[6]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM7|I0\(6) = (GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM6|Yout[6]~79_combout\))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM7|I0\(6)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111001000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TTS~inputclkctrl_outclk\,
	datab => \TM7|I0\(6),
	datad => \TM6|Yout[6]~79_combout\,
	combout => \TM7|I0\(6));

-- Location: LCCOMB_X75_Y14_N24
\L_6|I0[6]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I0\(6) = (GLOBAL(\L_6|I0[15]~0clkctrl_outclk\) & (\L_6|I0\(6))) # (!GLOBAL(\L_6|I0[15]~0clkctrl_outclk\) & ((\TM7|I0\(6))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_6|I0\(6),
	datac => \TM7|I0\(6),
	datad => \L_6|I0[15]~0clkctrl_outclk\,
	combout => \L_6|I0\(6));

-- Location: LCCOMB_X75_Y14_N4
\L_36|Yout[6]~6\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_36|Yout[6]~6_combout\ = (\L_6|I0\(6)) # ((\TM8|Equal0~0_combout\ & \TM7|I1\(6)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM8|Equal0~0_combout\,
	datab => \L_6|I0\(6),
	datad => \TM7|I1\(6),
	combout => \L_36|Yout[6]~6_combout\);

-- Location: LCCOMB_X75_Y14_N18
\L_34|Yout[6]~7\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_34|Yout[6]~7_combout\ = (\M4S1~input_o\ & ((\L_36|Yout[6]~6_combout\) # ((\L_34|Yout[0]~0_combout\ & \L_7|Mux9~3_combout\)))) # (!\M4S1~input_o\ & (\L_34|Yout[0]~0_combout\ & ((\L_7|Mux9~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M4S1~input_o\,
	datab => \L_34|Yout[0]~0_combout\,
	datac => \L_36|Yout[6]~6_combout\,
	datad => \L_7|Mux9~3_combout\,
	combout => \L_34|Yout[6]~7_combout\);

-- Location: LCCOMB_X76_Y15_N16
\L_40|I1[5]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_40|I1\(5) = (GLOBAL(\M4S3~inputclkctrl_outclk\) & (\L_40|I1\(5))) # (!GLOBAL(\M4S3~inputclkctrl_outclk\) & ((\L_38|Mult0|auto_generated|mac_out2~DATAOUT5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_40|I1\(5),
	datac => \L_38|Mult0|auto_generated|mac_out2~DATAOUT5\,
	datad => \M4S3~inputclkctrl_outclk\,
	combout => \L_40|I1\(5));

-- Location: LCCOMB_X76_Y14_N26
\L_7|Mux10~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux10~2_combout\ = (\L_7|Mux15~3_combout\ & (\L_7|Mux15~0_combout\)) # (!\L_7|Mux15~3_combout\ & ((\L_7|Mux15~0_combout\ & ((\L_40|I1\(5)))) # (!\L_7|Mux15~0_combout\ & (\L_47|I1\(5)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110010011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_7|Mux15~3_combout\,
	datab => \L_7|Mux15~0_combout\,
	datac => \L_47|I1\(5),
	datad => \L_40|I1\(5),
	combout => \L_7|Mux10~2_combout\);

-- Location: LCCOMB_X76_Y14_N2
\L_19|I0[5]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_19|I0\(5) = (GLOBAL(\M1S3~inputclkctrl_outclk\) & ((\L_17|Mult0|auto_generated|mac_out2~DATAOUT5\))) # (!GLOBAL(\M1S3~inputclkctrl_outclk\) & (\L_19|I0\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_19|I0\(5),
	datac => \M1S3~inputclkctrl_outclk\,
	datad => \L_17|Mult0|auto_generated|mac_out2~DATAOUT5\,
	combout => \L_19|I0\(5));

-- Location: LCCOMB_X77_Y17_N0
\L_47|I0[5]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_47|I0\(5) = (GLOBAL(\A1S3~inputclkctrl_outclk\) & (\L_45|O[5]~10_combout\)) # (!GLOBAL(\A1S3~inputclkctrl_outclk\) & ((\L_47|I0\(5))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_45|O[5]~10_combout\,
	datab => \L_47|I0\(5),
	datad => \A1S3~inputclkctrl_outclk\,
	combout => \L_47|I0\(5));

-- Location: LCCOMB_X77_Y17_N30
\L_7|Mux10~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux10~0_combout\ = (\RMS1[0]~input_o\ & (((\RMS1[1]~input_o\)))) # (!\RMS1[0]~input_o\ & ((\RMS1[1]~input_o\ & ((\L_47|I0\(5)))) # (!\RMS1[1]~input_o\ & (\v0[5]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001011000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v0[5]~input_o\,
	datab => \RMS1[0]~input_o\,
	datac => \RMS1[1]~input_o\,
	datad => \L_47|I0\(5),
	combout => \L_7|Mux10~0_combout\);

-- Location: LCCOMB_X76_Y14_N20
\L_7|Mux10~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux10~1_combout\ = (\RMS1[0]~input_o\ & ((\L_7|Mux10~0_combout\ & (\L_19|I1\(5))) # (!\L_7|Mux10~0_combout\ & ((\L_19|I0\(5)))))) # (!\RMS1[0]~input_o\ & (((\L_7|Mux10~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_19|I1\(5),
	datab => \L_19|I0\(5),
	datac => \RMS1[0]~input_o\,
	datad => \L_7|Mux10~0_combout\,
	combout => \L_7|Mux10~1_combout\);

-- Location: LCCOMB_X76_Y14_N0
\L_7|Mux10~3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux10~3_combout\ = (\L_7|Mux15~3_combout\ & ((\L_7|Mux10~2_combout\ & (\L_61|I1\(5))) # (!\L_7|Mux10~2_combout\ & ((\L_7|Mux10~1_combout\))))) # (!\L_7|Mux15~3_combout\ & (((\L_7|Mux10~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101101011010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_7|Mux15~3_combout\,
	datab => \L_61|I1\(5),
	datac => \L_7|Mux10~2_combout\,
	datad => \L_7|Mux10~1_combout\,
	combout => \L_7|Mux10~3_combout\);

-- Location: LCCOMB_X75_Y15_N4
\L_34|Yout[5]~6\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_34|Yout[5]~6_combout\ = (\L_34|Yout[0]~0_combout\ & ((\L_7|Mux10~3_combout\) # ((\M4S1~input_o\ & \L_36|Yout[5]~5_combout\)))) # (!\L_34|Yout[0]~0_combout\ & (\M4S1~input_o\ & (\L_36|Yout[5]~5_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_34|Yout[0]~0_combout\,
	datab => \M4S1~input_o\,
	datac => \L_36|Yout[5]~5_combout\,
	datad => \L_7|Mux10~3_combout\,
	combout => \L_34|Yout[5]~6_combout\);

-- Location: LCCOMB_X78_Y15_N12
\L_40|I0[8]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_40|I0\(8) = (GLOBAL(\M4S3~inputclkctrl_outclk\) & ((\L_38|Mult0|auto_generated|mac_out2~DATAOUT8\))) # (!GLOBAL(\M4S3~inputclkctrl_outclk\) & (\L_40|I0\(8)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_40|I0\(8),
	datac => \M4S3~inputclkctrl_outclk\,
	datad => \L_38|Mult0|auto_generated|mac_out2~DATAOUT8\,
	combout => \L_40|I0\(8));

-- Location: LCCOMB_X79_Y12_N24
\TM2|Yout[8]~17\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[8]~17_combout\ = (\BMS1[1]~input_o\ & (!\BMS1[0]~input_o\)) # (!\BMS1[1]~input_o\ & ((\L_61|I0\(8))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111011101000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \BMS1[0]~input_o\,
	datab => \BMS1[1]~input_o\,
	datad => \L_61|I0\(8),
	combout => \TM2|Yout[8]~17_combout\);

-- Location: LCCOMB_X79_Y12_N18
\TM2|Yout[8]~18\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[8]~18_combout\ = (\BMS1[1]~input_o\ & ((\TM2|Yout[8]~17_combout\ & ((\L_40|I0\(8)))) # (!\TM2|Yout[8]~17_combout\ & (\v2[8]~input_o\)))) # (!\BMS1[1]~input_o\ & (((\TM2|Yout[8]~17_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v2[8]~input_o\,
	datab => \BMS1[1]~input_o\,
	datac => \L_40|I0\(8),
	datad => \TM2|Yout[8]~17_combout\,
	combout => \TM2|Yout[8]~18_combout\);

-- Location: LCCOMB_X79_Y12_N14
\TM3|I0[8]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM3|I0\(8) = (GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM2|Yout[8]~18_combout\))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM3|I0\(8)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM3|I0\(8),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM2|Yout[8]~18_combout\,
	combout => \TM3|I0\(8));

-- Location: LCCOMB_X79_Y10_N16
\L_3|I2[8]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I2\(8) = (GLOBAL(\L_3|Equal0~1clkctrl_outclk\) & (\TM3|I0\(8))) # (!GLOBAL(\L_3|Equal0~1clkctrl_outclk\) & ((\L_3|I2\(8))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM3|I0\(8),
	datac => \L_3|Equal0~1clkctrl_outclk\,
	datad => \L_3|I2\(8),
	combout => \L_3|I2\(8));

-- Location: LCCOMB_X79_Y10_N28
\L_27|Yout[8]~8\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_27|Yout[8]~8_combout\ = (\M3S1~input_o\ & (((\L_3|I0\(8)) # (\TM4|I0\(8))))) # (!\M3S1~input_o\ & (\L_3|I2\(8)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111011100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M3S1~input_o\,
	datab => \L_3|I2\(8),
	datac => \L_3|I0\(8),
	datad => \TM4|I0\(8),
	combout => \L_27|Yout[8]~8_combout\);

-- Location: LCCOMB_X78_Y9_N18
\L_33|I0[7]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_33|I0\(7) = (GLOBAL(\M3S3~inputclkctrl_outclk\) & ((\L_31|Mult0|auto_generated|mac_out2~DATAOUT7\))) # (!GLOBAL(\M3S3~inputclkctrl_outclk\) & (\L_33|I0\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_33|I0\(7),
	datac => \M3S3~inputclkctrl_outclk\,
	datad => \L_31|Mult0|auto_generated|mac_out2~DATAOUT7\,
	combout => \L_33|I0\(7));

-- Location: LCCOMB_X77_Y9_N0
\TM2|Yout[7]~40\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[7]~40_combout\ = (\BTPM_S1~input_o\ & (\v2[7]~input_o\)) # (!\BTPM_S1~input_o\ & ((\L_33|I0\(7))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v2[7]~input_o\,
	datac => \BTPM_S1~input_o\,
	datad => \L_33|I0\(7),
	combout => \TM2|Yout[7]~40_combout\);

-- Location: LCCOMB_X76_Y10_N2
\TM3|I1[7]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM3|I1\(7) = (GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM3|I1\(7))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM2|Yout[7]~40_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM3|I1\(7),
	datac => \TM2|Yout[7]~40_combout\,
	datad => \TTS~inputclkctrl_outclk\,
	combout => \TM3|I1\(7));

-- Location: LCCOMB_X71_Y10_N30
\TM4|I0[7]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM4|I0\(7) = (GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & ((\TM3|I1\(7)))) # (!GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & (\TM4|I0\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM4|I0\(7),
	datac => \BTPD_S2~inputclkctrl_outclk\,
	datad => \TM3|I1\(7),
	combout => \TM4|I0\(7));

-- Location: LCCOMB_X70_Y10_N12
\L_27|Yout[7]~7\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_27|Yout[7]~7_combout\ = (\M3S1~input_o\ & (((\TM4|I0\(7)) # (\L_3|I0\(7))))) # (!\M3S1~input_o\ & (\L_3|I2\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111011100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_3|I2\(7),
	datab => \M3S1~input_o\,
	datac => \TM4|I0\(7),
	datad => \L_3|I0\(7),
	combout => \L_27|Yout[7]~7_combout\);

-- Location: LCCOMB_X72_Y11_N20
\L_33|I0[6]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_33|I0\(6) = (GLOBAL(\M3S3~inputclkctrl_outclk\) & ((\L_31|Mult0|auto_generated|mac_out2~DATAOUT6\))) # (!GLOBAL(\M3S3~inputclkctrl_outclk\) & (\L_33|I0\(6)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_33|I0\(6),
	datac => \M3S3~inputclkctrl_outclk\,
	datad => \L_31|Mult0|auto_generated|mac_out2~DATAOUT6\,
	combout => \L_33|I0\(6));

-- Location: LCCOMB_X72_Y11_N0
\TM2|Yout[6]~39\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[6]~39_combout\ = (\BTPM_S1~input_o\ & (\v2[6]~input_o\)) # (!\BTPM_S1~input_o\ & ((\L_33|I0\(6))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v2[6]~input_o\,
	datab => \BTPM_S1~input_o\,
	datad => \L_33|I0\(6),
	combout => \TM2|Yout[6]~39_combout\);

-- Location: LCCOMB_X72_Y11_N8
\TM3|I1[6]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM3|I1\(6) = (GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM3|I1\(6))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM2|Yout[6]~39_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TTS~inputclkctrl_outclk\,
	datac => \TM3|I1\(6),
	datad => \TM2|Yout[6]~39_combout\,
	combout => \TM3|I1\(6));

-- Location: LCCOMB_X72_Y10_N4
\TM4|I0[6]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM4|I0\(6) = (GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & ((\TM3|I1\(6)))) # (!GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & (\TM4|I0\(6)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM4|I0\(6),
	datac => \BTPD_S2~inputclkctrl_outclk\,
	datad => \TM3|I1\(6),
	combout => \TM4|I0\(6));

-- Location: LCCOMB_X72_Y10_N6
\L_27|Yout[6]~6\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_27|Yout[6]~6_combout\ = (\M3S1~input_o\ & (((\TM4|I0\(6)) # (\L_3|I0\(6))))) # (!\M3S1~input_o\ & (\L_3|I2\(6)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111011100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M3S1~input_o\,
	datab => \L_3|I2\(6),
	datac => \TM4|I0\(6),
	datad => \L_3|I0\(6),
	combout => \L_27|Yout[6]~6_combout\);

-- Location: LCCOMB_X78_Y12_N0
\L_33|I1[5]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_33|I1\(5) = (GLOBAL(\M3S3~inputclkctrl_outclk\) & (\L_33|I1\(5))) # (!GLOBAL(\M3S3~inputclkctrl_outclk\) & ((\L_31|Mult0|auto_generated|mac_out2~DATAOUT5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_33|I1\(5),
	datac => \L_31|Mult0|auto_generated|mac_out2~DATAOUT5\,
	datad => \M3S3~inputclkctrl_outclk\,
	combout => \L_33|I1\(5));

-- Location: IOIBUF_X90_Y0_N8
\v3[5]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v3(5),
	o => \v3[5]~input_o\);

-- Location: LCCOMB_X78_Y12_N24
\TM6|Yout[5]~76\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[5]~76_combout\ = (\YMS1[0]~input_o\ & (\YMS1[1]~input_o\)) # (!\YMS1[0]~input_o\ & ((\YMS1[1]~input_o\ & ((\L_33|I0\(5)))) # (!\YMS1[1]~input_o\ & (\L_54|I1\(5)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110010011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YMS1[0]~input_o\,
	datab => \YMS1[1]~input_o\,
	datac => \L_54|I1\(5),
	datad => \L_33|I0\(5),
	combout => \TM6|Yout[5]~76_combout\);

-- Location: LCCOMB_X78_Y12_N2
\TM6|Yout[5]~77\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[5]~77_combout\ = (\YMS1[0]~input_o\ & ((\TM6|Yout[5]~76_combout\ & ((\v3[5]~input_o\))) # (!\TM6|Yout[5]~76_combout\ & (\L_33|I1\(5))))) # (!\YMS1[0]~input_o\ & (((\TM6|Yout[5]~76_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YMS1[0]~input_o\,
	datab => \L_33|I1\(5),
	datac => \v3[5]~input_o\,
	datad => \TM6|Yout[5]~76_combout\,
	combout => \TM6|Yout[5]~77_combout\);

-- Location: LCCOMB_X78_Y12_N14
\TM7|I0[5]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM7|I0\(5) = (GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM6|Yout[5]~77_combout\))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM7|I0\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM7|I0\(5),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM6|Yout[5]~77_combout\,
	combout => \TM7|I0\(5));

-- Location: LCCOMB_X75_Y7_N30
\L_6|I2[5]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I2\(5) = (GLOBAL(\L_6|Equal0~1clkctrl_outclk\) & (\TM7|I0\(5))) # (!GLOBAL(\L_6|Equal0~1clkctrl_outclk\) & ((\L_6|I2\(5))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM7|I0\(5),
	datac => \L_6|I2\(5),
	datad => \L_6|Equal0~1clkctrl_outclk\,
	combout => \L_6|I2\(5));

-- Location: LCCOMB_X75_Y7_N0
\L_50|Yout[5]~10\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_50|Yout[5]~10_combout\ = (\L_6|I2\(5)) # ((\TM8|Equal3~0_combout\ & \TM7|I1\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM8|Equal3~0_combout\,
	datac => \L_6|I2\(5),
	datad => \TM7|I1\(5),
	combout => \L_50|Yout[5]~10_combout\);

-- Location: LCCOMB_X75_Y7_N6
\L_48|Yout[5]~5\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_48|Yout[5]~5_combout\ = (\A2S1~input_o\ & (\L_12|I1\(5))) # (!\A2S1~input_o\ & ((\L_50|Yout[5]~10_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_12|I1\(5),
	datac => \A2S1~input_o\,
	datad => \L_50|Yout[5]~10_combout\,
	combout => \L_48|Yout[5]~5_combout\);

-- Location: LCCOMB_X77_Y9_N12
\L_54|I1[5]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_54|I1\(5) = (GLOBAL(\A2S3~inputclkctrl_outclk\) & (\L_54|I1\(5))) # (!GLOBAL(\A2S3~inputclkctrl_outclk\) & ((\L_52|O[5]~10_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_54|I1\(5),
	datac => \L_52|O[5]~10_combout\,
	datad => \A2S3~inputclkctrl_outclk\,
	combout => \L_54|I1\(5));

-- Location: LCCOMB_X78_Y15_N6
\L_40|I0[5]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_40|I0\(5) = (GLOBAL(\M4S3~inputclkctrl_outclk\) & ((\L_38|Mult0|auto_generated|mac_out2~DATAOUT5\))) # (!GLOBAL(\M4S3~inputclkctrl_outclk\) & (\L_40|I0\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_40|I0\(5),
	datac => \M4S3~inputclkctrl_outclk\,
	datad => \L_38|Mult0|auto_generated|mac_out2~DATAOUT5\,
	combout => \L_40|I0\(5));

-- Location: LCCOMB_X78_Y12_N28
\TM6|Yout[5]~22\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[5]~22_combout\ = (\YTPM_S1[1]~input_o\ & (((\L_61|I0\(5))))) # (!\YTPM_S1[1]~input_o\ & (((\L_40|I0\(5))) # (!\YTPM_S1[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111010001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPM_S1[0]~input_o\,
	datab => \YTPM_S1[1]~input_o\,
	datac => \L_61|I0\(5),
	datad => \L_40|I0\(5),
	combout => \TM6|Yout[5]~22_combout\);

-- Location: LCCOMB_X78_Y12_N22
\TM6|Yout[5]~23\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[5]~23_combout\ = (\TM6|Yout[0]~5_combout\ & (((\TM6|Yout[5]~22_combout\)))) # (!\TM6|Yout[0]~5_combout\ & ((\TM6|Yout[5]~22_combout\ & ((\v3[5]~input_o\))) # (!\TM6|Yout[5]~22_combout\ & (\L_33|I0\(5)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101001000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM6|Yout[0]~5_combout\,
	datab => \L_33|I0\(5),
	datac => \v3[5]~input_o\,
	datad => \TM6|Yout[5]~22_combout\,
	combout => \TM6|Yout[5]~23_combout\);

-- Location: LCCOMB_X78_Y12_N20
\TM6|Yout[5]~24\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[5]~24_combout\ = (\YTPM_S1[0]~input_o\ & ((\YTPM_S1[1]~input_o\ & ((\L_33|I1\(5)))) # (!\YTPM_S1[1]~input_o\ & (\TM6|Yout[5]~23_combout\)))) # (!\YTPM_S1[0]~input_o\ & (((\TM6|Yout[5]~23_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100001110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPM_S1[0]~input_o\,
	datab => \YTPM_S1[1]~input_o\,
	datac => \TM6|Yout[5]~23_combout\,
	datad => \L_33|I1\(5),
	combout => \TM6|Yout[5]~24_combout\);

-- Location: LCCOMB_X78_Y12_N6
\TM6|Yout[5]~25\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[5]~25_combout\ = (\YTPM_S1[2]~input_o\ & (\L_54|I1\(5))) # (!\YTPM_S1[2]~input_o\ & ((\TM6|Yout[5]~24_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \YTPM_S1[2]~input_o\,
	datac => \L_54|I1\(5),
	datad => \TM6|Yout[5]~24_combout\,
	combout => \TM6|Yout[5]~25_combout\);

-- Location: LCCOMB_X78_Y12_N8
\TM7|I1[5]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM7|I1\(5) = (GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM7|I1\(5))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM6|Yout[5]~25_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM7|I1\(5),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM6|Yout[5]~25_combout\,
	combout => \TM7|I1\(5));

-- Location: LCCOMB_X76_Y8_N4
\L_57|Yout[5]~10\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_57|Yout[5]~10_combout\ = (\TTS~input_o\ & ((\L_3|I1\(5)) # ((\L_55|Yout[0]~0_combout\ & \TM7|I1\(5))))) # (!\TTS~input_o\ & (((\L_55|Yout[0]~0_combout\ & \TM7|I1\(5)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TTS~input_o\,
	datab => \L_3|I1\(5),
	datac => \L_55|Yout[0]~0_combout\,
	datad => \TM7|I1\(5),
	combout => \L_57|Yout[5]~10_combout\);

-- Location: LCCOMB_X75_Y5_N12
\L_12|I3[5]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I3\(5) = (GLOBAL(\L_12|Equal0~0clkctrl_outclk\) & ((\L_12|I3\(5)))) # (!GLOBAL(\L_12|Equal0~0clkctrl_outclk\) & (\L_10|Yout[5]~11_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_10|Yout[5]~11_combout\,
	datac => \L_12|Equal0~0clkctrl_outclk\,
	datad => \L_12|I3\(5),
	combout => \L_12|I3\(5));

-- Location: LCCOMB_X76_Y8_N16
\L_57|Yout[5]~11\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_57|Yout[5]~11_combout\ = (\A3S2~input_o\ & (\L_57|Yout[5]~10_combout\)) # (!\A3S2~input_o\ & ((\L_12|I3\(5))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \A3S2~input_o\,
	datac => \L_57|Yout[5]~10_combout\,
	datad => \L_12|I3\(5),
	combout => \L_57|Yout[5]~11_combout\);

-- Location: LCCOMB_X78_Y12_N4
\L_61|I0[5]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_61|I0\(5) = (GLOBAL(\A3S3~inputclkctrl_outclk\) & (\L_59|O[5]~10_combout\)) # (!GLOBAL(\A3S3~inputclkctrl_outclk\) & ((\L_61|I0\(5))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_59|O[5]~10_combout\,
	datac => \L_61|I0\(5),
	datad => \A3S3~inputclkctrl_outclk\,
	combout => \L_61|I0\(5));

-- Location: LCCOMB_X78_Y12_N12
\TM2|Yout[5]~12\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[5]~12_combout\ = (\TM2|Yout[5]~11_combout\ & (((\L_40|I0\(5))) # (!\TM2|Yout[9]~2_combout\))) # (!\TM2|Yout[5]~11_combout\ & (\TM2|Yout[9]~2_combout\ & (\L_61|I0\(5))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101001100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM2|Yout[5]~11_combout\,
	datab => \TM2|Yout[9]~2_combout\,
	datac => \L_61|I0\(5),
	datad => \L_40|I0\(5),
	combout => \TM2|Yout[5]~12_combout\);

-- Location: LCCOMB_X78_Y12_N16
\TM3|I0[5]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM3|I0\(5) = (GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM2|Yout[5]~12_combout\))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM3|I0\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I0\(5),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM2|Yout[5]~12_combout\,
	combout => \TM3|I0\(5));

-- Location: LCCOMB_X71_Y10_N8
\L_3|I0[5]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I0\(5) = (GLOBAL(\L_3|I0[15]~0clkctrl_outclk\) & ((\L_3|I0\(5)))) # (!GLOBAL(\L_3|I0[15]~0clkctrl_outclk\) & (\TM3|I0\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM3|I0\(5),
	datac => \L_3|I0\(5),
	datad => \L_3|I0[15]~0clkctrl_outclk\,
	combout => \L_3|I0\(5));

-- Location: LCCOMB_X71_Y10_N26
\L_3|I2[5]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I2\(5) = (GLOBAL(\L_3|Equal0~1clkctrl_outclk\) & (\TM3|I0\(5))) # (!GLOBAL(\L_3|Equal0~1clkctrl_outclk\) & ((\L_3|I2\(5))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM3|I0\(5),
	datac => \L_3|I2\(5),
	datad => \L_3|Equal0~1clkctrl_outclk\,
	combout => \L_3|I2\(5));

-- Location: LCCOMB_X71_Y10_N24
\L_27|Yout[5]~5\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_27|Yout[5]~5_combout\ = (\M3S1~input_o\ & ((\L_3|I0\(5)) # ((\TM4|I0\(5))))) # (!\M3S1~input_o\ & (((\L_3|I2\(5)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M3S1~input_o\,
	datab => \L_3|I0\(5),
	datac => \L_3|I2\(5),
	datad => \TM4|I0\(5),
	combout => \L_27|Yout[5]~5_combout\);

-- Location: LCCOMB_X73_Y7_N14
\L_33|I0[4]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_33|I0\(4) = (GLOBAL(\M3S3~inputclkctrl_outclk\) & ((\L_31|Mult0|auto_generated|mac_out2~DATAOUT4\))) # (!GLOBAL(\M3S3~inputclkctrl_outclk\) & (\L_33|I0\(4)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_33|I0\(4),
	datac => \M3S3~inputclkctrl_outclk\,
	datad => \L_31|Mult0|auto_generated|mac_out2~DATAOUT4\,
	combout => \L_33|I0\(4));

-- Location: LCCOMB_X73_Y7_N8
\L_33|I1[4]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_33|I1\(4) = (GLOBAL(\M3S3~inputclkctrl_outclk\) & (\L_33|I1\(4))) # (!GLOBAL(\M3S3~inputclkctrl_outclk\) & ((\L_31|Mult0|auto_generated|mac_out2~DATAOUT4\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_33|I1\(4),
	datac => \M3S3~inputclkctrl_outclk\,
	datad => \L_31|Mult0|auto_generated|mac_out2~DATAOUT4\,
	combout => \L_33|I1\(4));

-- Location: LCCOMB_X73_Y7_N24
\TM6|Yout[4]~74\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[4]~74_combout\ = (\YMS1[1]~input_o\ & (((\YMS1[0]~input_o\)))) # (!\YMS1[1]~input_o\ & ((\YMS1[0]~input_o\ & ((\L_33|I1\(4)))) # (!\YMS1[0]~input_o\ & (\L_54|I1\(4)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101001000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YMS1[1]~input_o\,
	datab => \L_54|I1\(4),
	datac => \L_33|I1\(4),
	datad => \YMS1[0]~input_o\,
	combout => \TM6|Yout[4]~74_combout\);

-- Location: LCCOMB_X73_Y7_N2
\TM6|Yout[4]~75\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[4]~75_combout\ = (\YMS1[1]~input_o\ & ((\TM6|Yout[4]~74_combout\ & (\v3[4]~input_o\)) # (!\TM6|Yout[4]~74_combout\ & ((\L_33|I0\(4)))))) # (!\YMS1[1]~input_o\ & (((\TM6|Yout[4]~74_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YMS1[1]~input_o\,
	datab => \v3[4]~input_o\,
	datac => \L_33|I0\(4),
	datad => \TM6|Yout[4]~74_combout\,
	combout => \TM6|Yout[4]~75_combout\);

-- Location: LCCOMB_X73_Y7_N22
\TM7|I0[4]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM7|I0\(4) = (GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM6|Yout[4]~75_combout\))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM7|I0\(4)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM7|I0\(4),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM6|Yout[4]~75_combout\,
	combout => \TM7|I0\(4));

-- Location: LCCOMB_X73_Y7_N20
\L_6|I2[4]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I2\(4) = (GLOBAL(\L_6|Equal0~1clkctrl_outclk\) & ((\TM7|I0\(4)))) # (!GLOBAL(\L_6|Equal0~1clkctrl_outclk\) & (\L_6|I2\(4)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_6|I2\(4),
	datac => \TM7|I0\(4),
	datad => \L_6|Equal0~1clkctrl_outclk\,
	combout => \L_6|I2\(4));

-- Location: LCCOMB_X73_Y7_N16
\L_50|Yout[4]~8\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_50|Yout[4]~8_combout\ = (\L_6|I2\(4)) # ((\TM8|Equal3~0_combout\ & \TM7|I1\(4)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM8|Equal3~0_combout\,
	datac => \TM7|I1\(4),
	datad => \L_6|I2\(4),
	combout => \L_50|Yout[4]~8_combout\);

-- Location: LCCOMB_X77_Y7_N24
\L_48|Yout[4]~4\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_48|Yout[4]~4_combout\ = (\A2S1~input_o\ & (\L_12|I1\(4))) # (!\A2S1~input_o\ & ((\L_50|Yout[4]~8_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_12|I1\(4),
	datac => \A2S1~input_o\,
	datad => \L_50|Yout[4]~8_combout\,
	combout => \L_48|Yout[4]~4_combout\);

-- Location: LCCOMB_X72_Y7_N6
\L_54|I1[4]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_54|I1\(4) = (GLOBAL(\A2S3~inputclkctrl_outclk\) & (\L_54|I1\(4))) # (!GLOBAL(\A2S3~inputclkctrl_outclk\) & ((\L_52|O[4]~8_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_54|I1\(4),
	datab => \L_52|O[4]~8_combout\,
	datad => \A2S3~inputclkctrl_outclk\,
	combout => \L_54|I1\(4));

-- Location: LCCOMB_X77_Y12_N22
\L_61|I0[4]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_61|I0\(4) = (GLOBAL(\A3S3~inputclkctrl_outclk\) & (\L_59|O[4]~8_combout\)) # (!GLOBAL(\A3S3~inputclkctrl_outclk\) & ((\L_61|I0\(4))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_59|O[4]~8_combout\,
	datac => \A3S3~inputclkctrl_outclk\,
	datad => \L_61|I0\(4),
	combout => \L_61|I0\(4));

-- Location: LCCOMB_X73_Y7_N28
\TM6|Yout[4]~18\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[4]~18_combout\ = (!\YTPM_S1[1]~input_o\ & ((\L_40|I0\(4)) # (!\YTPM_S1[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \YTPM_S1[0]~input_o\,
	datac => \YTPM_S1[1]~input_o\,
	datad => \L_40|I0\(4),
	combout => \TM6|Yout[4]~18_combout\);

-- Location: LCCOMB_X73_Y7_N6
\TM6|Yout[4]~19\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[4]~19_combout\ = (\TM6|Yout[0]~0_combout\ & ((\TM6|Yout[4]~18_combout\ & (\v3[4]~input_o\)) # (!\TM6|Yout[4]~18_combout\ & ((\L_61|I0\(4)))))) # (!\TM6|Yout[0]~0_combout\ & (((\TM6|Yout[4]~18_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM6|Yout[0]~0_combout\,
	datab => \v3[4]~input_o\,
	datac => \L_61|I0\(4),
	datad => \TM6|Yout[4]~18_combout\,
	combout => \TM6|Yout[4]~19_combout\);

-- Location: LCCOMB_X73_Y7_N12
\TM6|Yout[4]~20\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[4]~20_combout\ = (\YTPM_S1[1]~input_o\ & ((\YTPM_S1[0]~input_o\ & (\L_33|I1\(4))) # (!\YTPM_S1[0]~input_o\ & ((\TM6|Yout[4]~19_combout\))))) # (!\YTPM_S1[1]~input_o\ & (((\TM6|Yout[4]~19_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111011110000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPM_S1[1]~input_o\,
	datab => \YTPM_S1[0]~input_o\,
	datac => \L_33|I1\(4),
	datad => \TM6|Yout[4]~19_combout\,
	combout => \TM6|Yout[4]~20_combout\);

-- Location: LCCOMB_X73_Y7_N18
\TM6|Yout[4]~21\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[4]~21_combout\ = (\YTPM_S1[2]~input_o\ & (\L_54|I1\(4))) # (!\YTPM_S1[2]~input_o\ & ((\TM6|Yout[4]~20_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \YTPM_S1[2]~input_o\,
	datac => \L_54|I1\(4),
	datad => \TM6|Yout[4]~20_combout\,
	combout => \TM6|Yout[4]~21_combout\);

-- Location: LCCOMB_X73_Y7_N0
\TM7|I1[4]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM7|I1\(4) = (GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM7|I1\(4))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM6|Yout[4]~21_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM7|I1\(4),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM6|Yout[4]~21_combout\,
	combout => \TM7|I1\(4));

-- Location: LCCOMB_X75_Y12_N4
\L_57|Yout[4]~8\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_57|Yout[4]~8_combout\ = (\L_3|I1\(4) & ((\TTS~input_o\) # ((\L_55|Yout[0]~0_combout\ & \TM7|I1\(4))))) # (!\L_3|I1\(4) & (((\L_55|Yout[0]~0_combout\ & \TM7|I1\(4)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_3|I1\(4),
	datab => \TTS~input_o\,
	datac => \L_55|Yout[0]~0_combout\,
	datad => \TM7|I1\(4),
	combout => \L_57|Yout[4]~8_combout\);

-- Location: LCCOMB_X75_Y12_N28
\L_57|Yout[4]~9\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_57|Yout[4]~9_combout\ = (\A3S2~input_o\ & ((\L_57|Yout[4]~8_combout\))) # (!\A3S2~input_o\ & (\L_12|I3\(4)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111000100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_12|I3\(4),
	datab => \A3S2~input_o\,
	datad => \L_57|Yout[4]~8_combout\,
	combout => \L_57|Yout[4]~9_combout\);

-- Location: LCCOMB_X77_Y15_N30
\L_61|I1[4]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_61|I1\(4) = (GLOBAL(\A3S3~inputclkctrl_outclk\) & (\L_61|I1\(4))) # (!GLOBAL(\A3S3~inputclkctrl_outclk\) & ((\L_59|O[4]~8_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_61|I1\(4),
	datac => \A3S3~inputclkctrl_outclk\,
	datad => \L_59|O[4]~8_combout\,
	combout => \L_61|I1\(4));

-- Location: LCCOMB_X77_Y17_N22
\L_47|I1[4]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_47|I1\(4) = (GLOBAL(\A1S3~inputclkctrl_outclk\) & ((\L_47|I1\(4)))) # (!GLOBAL(\A1S3~inputclkctrl_outclk\) & (\L_45|O[4]~8_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_45|O[4]~8_combout\,
	datac => \L_47|I1\(4),
	datad => \A1S3~inputclkctrl_outclk\,
	combout => \L_47|I1\(4));

-- Location: LCCOMB_X77_Y17_N4
\L_19|I1[4]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_19|I1\(4) = (GLOBAL(\M1S3~inputclkctrl_outclk\) & (\L_19|I1\(4))) # (!GLOBAL(\M1S3~inputclkctrl_outclk\) & ((\L_17|Mult0|auto_generated|mac_out2~DATAOUT4\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_19|I1\(4),
	datac => \L_17|Mult0|auto_generated|mac_out2~DATAOUT4\,
	datad => \M1S3~inputclkctrl_outclk\,
	combout => \L_19|I1\(4));

-- Location: LCCOMB_X77_Y17_N18
\L_19|I0[4]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_19|I0\(4) = (GLOBAL(\M1S3~inputclkctrl_outclk\) & ((\L_17|Mult0|auto_generated|mac_out2~DATAOUT4\))) # (!GLOBAL(\M1S3~inputclkctrl_outclk\) & (\L_19|I0\(4)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_19|I0\(4),
	datac => \L_17|Mult0|auto_generated|mac_out2~DATAOUT4\,
	datad => \M1S3~inputclkctrl_outclk\,
	combout => \L_19|I0\(4));

-- Location: LCCOMB_X77_Y17_N8
\L_7|Mux11~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux11~0_combout\ = (\RMS1[0]~input_o\ & (((\RMS1[1]~input_o\) # (\L_19|I0\(4))))) # (!\RMS1[0]~input_o\ & (\v0[4]~input_o\ & (!\RMS1[1]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111011000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v0[4]~input_o\,
	datab => \RMS1[0]~input_o\,
	datac => \RMS1[1]~input_o\,
	datad => \L_19|I0\(4),
	combout => \L_7|Mux11~0_combout\);

-- Location: LCCOMB_X77_Y17_N16
\L_47|I0[4]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_47|I0\(4) = (GLOBAL(\A1S3~inputclkctrl_outclk\) & (\L_45|O[4]~8_combout\)) # (!GLOBAL(\A1S3~inputclkctrl_outclk\) & ((\L_47|I0\(4))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_45|O[4]~8_combout\,
	datab => \L_47|I0\(4),
	datad => \A1S3~inputclkctrl_outclk\,
	combout => \L_47|I0\(4));

-- Location: LCCOMB_X77_Y17_N10
\L_7|Mux11~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux11~1_combout\ = (\RMS1[1]~input_o\ & ((\L_7|Mux11~0_combout\ & (\L_19|I1\(4))) # (!\L_7|Mux11~0_combout\ & ((\L_47|I0\(4)))))) # (!\RMS1[1]~input_o\ & (((\L_7|Mux11~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101101011010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \RMS1[1]~input_o\,
	datab => \L_19|I1\(4),
	datac => \L_7|Mux11~0_combout\,
	datad => \L_47|I0\(4),
	combout => \L_7|Mux11~1_combout\);

-- Location: LCCOMB_X77_Y17_N28
\L_7|Mux11~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux11~2_combout\ = (\L_7|Mux15~0_combout\ & (\L_7|Mux15~3_combout\)) # (!\L_7|Mux15~0_combout\ & ((\L_7|Mux15~3_combout\ & ((\L_7|Mux11~1_combout\))) # (!\L_7|Mux15~3_combout\ & (\L_47|I1\(4)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110010011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_7|Mux15~0_combout\,
	datab => \L_7|Mux15~3_combout\,
	datac => \L_47|I1\(4),
	datad => \L_7|Mux11~1_combout\,
	combout => \L_7|Mux11~2_combout\);

-- Location: LCCOMB_X77_Y15_N24
\L_7|Mux11~3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux11~3_combout\ = (\L_7|Mux15~0_combout\ & ((\L_7|Mux11~2_combout\ & ((\L_61|I1\(4)))) # (!\L_7|Mux11~2_combout\ & (\L_40|I1\(4))))) # (!\L_7|Mux15~0_combout\ & (((\L_7|Mux11~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_40|I1\(4),
	datab => \L_7|Mux15~0_combout\,
	datac => \L_61|I1\(4),
	datad => \L_7|Mux11~2_combout\,
	combout => \L_7|Mux11~3_combout\);

-- Location: LCCOMB_X77_Y15_N0
\L_13|Yout[4]~5\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_13|Yout[4]~5_combout\ = (\L_13|Yout[15]~0_combout\ & \L_7|Mux11~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_13|Yout[15]~0_combout\,
	datad => \L_7|Mux11~3_combout\,
	combout => \L_13|Yout[4]~5_combout\);

-- Location: LCCOMB_X73_Y13_N4
\L_19|I1[2]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_19|I1\(2) = (GLOBAL(\M1S3~inputclkctrl_outclk\) & (\L_19|I1\(2))) # (!GLOBAL(\M1S3~inputclkctrl_outclk\) & ((\L_17|Mult0|auto_generated|mac_out2~DATAOUT2\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_19|I1\(2),
	datac => \L_17|Mult0|auto_generated|mac_out2~DATAOUT2\,
	datad => \M1S3~inputclkctrl_outclk\,
	combout => \L_19|I1\(2));

-- Location: LCCOMB_X73_Y13_N8
\L_47|I0[2]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_47|I0\(2) = (GLOBAL(\A1S3~inputclkctrl_outclk\) & (\L_45|O[2]~4_combout\)) # (!GLOBAL(\A1S3~inputclkctrl_outclk\) & ((\L_47|I0\(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_45|O[2]~4_combout\,
	datac => \A1S3~inputclkctrl_outclk\,
	datad => \L_47|I0\(2),
	combout => \L_47|I0\(2));

-- Location: LCCOMB_X73_Y13_N10
\L_19|I0[2]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_19|I0\(2) = (GLOBAL(\M1S3~inputclkctrl_outclk\) & ((\L_17|Mult0|auto_generated|mac_out2~DATAOUT2\))) # (!GLOBAL(\M1S3~inputclkctrl_outclk\) & (\L_19|I0\(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_19|I0\(2),
	datac => \L_17|Mult0|auto_generated|mac_out2~DATAOUT2\,
	datad => \M1S3~inputclkctrl_outclk\,
	combout => \L_19|I0\(2));

-- Location: LCCOMB_X73_Y13_N28
\L_7|Mux13~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux13~0_combout\ = (\RMS1[0]~input_o\ & (((\RMS1[1]~input_o\) # (\L_19|I0\(2))))) # (!\RMS1[0]~input_o\ & (\v0[2]~input_o\ & (!\RMS1[1]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111011000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v0[2]~input_o\,
	datab => \RMS1[0]~input_o\,
	datac => \RMS1[1]~input_o\,
	datad => \L_19|I0\(2),
	combout => \L_7|Mux13~0_combout\);

-- Location: LCCOMB_X73_Y13_N2
\L_7|Mux13~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux13~1_combout\ = (\RMS1[1]~input_o\ & ((\L_7|Mux13~0_combout\ & (\L_19|I1\(2))) # (!\L_7|Mux13~0_combout\ & ((\L_47|I0\(2)))))) # (!\RMS1[1]~input_o\ & (((\L_7|Mux13~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \RMS1[1]~input_o\,
	datab => \L_19|I1\(2),
	datac => \L_47|I0\(2),
	datad => \L_7|Mux13~0_combout\,
	combout => \L_7|Mux13~1_combout\);

-- Location: LCCOMB_X73_Y13_N0
\L_7|Mux13~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux13~2_combout\ = (\L_7|Mux15~3_combout\ & ((\L_7|Mux15~0_combout\) # ((\L_7|Mux13~1_combout\)))) # (!\L_7|Mux15~3_combout\ & (!\L_7|Mux15~0_combout\ & (\L_47|I1\(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101010011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_7|Mux15~3_combout\,
	datab => \L_7|Mux15~0_combout\,
	datac => \L_47|I1\(2),
	datad => \L_7|Mux13~1_combout\,
	combout => \L_7|Mux13~2_combout\);

-- Location: LCCOMB_X73_Y13_N14
\L_7|Mux13~3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux13~3_combout\ = (\L_7|Mux15~0_combout\ & ((\L_7|Mux13~2_combout\ & (\L_61|I1\(2))) # (!\L_7|Mux13~2_combout\ & ((\L_40|I1\(2)))))) # (!\L_7|Mux15~0_combout\ & (((\L_7|Mux13~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_61|I1\(2),
	datab => \L_7|Mux15~0_combout\,
	datac => \L_40|I1\(2),
	datad => \L_7|Mux13~2_combout\,
	combout => \L_7|Mux13~3_combout\);

-- Location: LCCOMB_X73_Y13_N16
\L_13|Yout[2]~3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_13|Yout[2]~3_combout\ = (\L_13|Yout[15]~0_combout\ & \L_7|Mux13~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_13|Yout[15]~0_combout\,
	datac => \L_7|Mux13~3_combout\,
	combout => \L_13|Yout[2]~3_combout\);

-- Location: LCCOMB_X72_Y16_N8
\L_19|I0[3]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_19|I0\(3) = (GLOBAL(\M1S3~inputclkctrl_outclk\) & ((\L_17|Mult0|auto_generated|mac_out2~DATAOUT3\))) # (!GLOBAL(\M1S3~inputclkctrl_outclk\) & (\L_19|I0\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_19|I0\(3),
	datac => \L_17|Mult0|auto_generated|mac_out2~DATAOUT3\,
	datad => \M1S3~inputclkctrl_outclk\,
	combout => \L_19|I0\(3));

-- Location: LCCOMB_X72_Y16_N6
\L_47|I0[3]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_47|I0\(3) = (GLOBAL(\A1S3~inputclkctrl_outclk\) & ((\L_45|O[3]~6_combout\))) # (!GLOBAL(\A1S3~inputclkctrl_outclk\) & (\L_47|I0\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_47|I0\(3),
	datac => \L_45|O[3]~6_combout\,
	datad => \A1S3~inputclkctrl_outclk\,
	combout => \L_47|I0\(3));

-- Location: LCCOMB_X72_Y16_N4
\L_7|Mux12~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux12~0_combout\ = (\RMS1[1]~input_o\ & (((\RMS1[0]~input_o\) # (\L_47|I0\(3))))) # (!\RMS1[1]~input_o\ & (\v0[3]~input_o\ & (!\RMS1[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111011000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v0[3]~input_o\,
	datab => \RMS1[1]~input_o\,
	datac => \RMS1[0]~input_o\,
	datad => \L_47|I0\(3),
	combout => \L_7|Mux12~0_combout\);

-- Location: LCCOMB_X72_Y16_N16
\L_19|I1[3]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_19|I1\(3) = (GLOBAL(\M1S3~inputclkctrl_outclk\) & (\L_19|I1\(3))) # (!GLOBAL(\M1S3~inputclkctrl_outclk\) & ((\L_17|Mult0|auto_generated|mac_out2~DATAOUT3\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_19|I1\(3),
	datac => \L_17|Mult0|auto_generated|mac_out2~DATAOUT3\,
	datad => \M1S3~inputclkctrl_outclk\,
	combout => \L_19|I1\(3));

-- Location: LCCOMB_X72_Y16_N14
\L_7|Mux12~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux12~1_combout\ = (\RMS1[0]~input_o\ & ((\L_7|Mux12~0_combout\ & ((\L_19|I1\(3)))) # (!\L_7|Mux12~0_combout\ & (\L_19|I0\(3))))) # (!\RMS1[0]~input_o\ & (((\L_7|Mux12~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100001011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \RMS1[0]~input_o\,
	datab => \L_19|I0\(3),
	datac => \L_7|Mux12~0_combout\,
	datad => \L_19|I1\(3),
	combout => \L_7|Mux12~1_combout\);

-- Location: LCCOMB_X72_Y16_N26
\L_40|I1[3]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_40|I1\(3) = (GLOBAL(\M4S3~inputclkctrl_outclk\) & (\L_40|I1\(3))) # (!GLOBAL(\M4S3~inputclkctrl_outclk\) & ((\L_38|Mult0|auto_generated|mac_out2~DATAOUT3\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_40|I1\(3),
	datac => \M4S3~inputclkctrl_outclk\,
	datad => \L_38|Mult0|auto_generated|mac_out2~DATAOUT3\,
	combout => \L_40|I1\(3));

-- Location: LCCOMB_X72_Y16_N20
\L_47|I1[3]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_47|I1\(3) = (GLOBAL(\A1S3~inputclkctrl_outclk\) & (\L_47|I1\(3))) # (!GLOBAL(\A1S3~inputclkctrl_outclk\) & ((\L_45|O[3]~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_47|I1\(3),
	datac => \L_45|O[3]~6_combout\,
	datad => \A1S3~inputclkctrl_outclk\,
	combout => \L_47|I1\(3));

-- Location: LCCOMB_X72_Y16_N12
\L_7|Mux12~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux12~2_combout\ = (\L_7|Mux15~0_combout\ & ((\L_7|Mux15~3_combout\) # ((\L_40|I1\(3))))) # (!\L_7|Mux15~0_combout\ & (!\L_7|Mux15~3_combout\ & ((\L_47|I1\(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011100110101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_7|Mux15~0_combout\,
	datab => \L_7|Mux15~3_combout\,
	datac => \L_40|I1\(3),
	datad => \L_47|I1\(3),
	combout => \L_7|Mux12~2_combout\);

-- Location: LCCOMB_X72_Y16_N22
\L_7|Mux12~3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux12~3_combout\ = (\L_7|Mux15~3_combout\ & ((\L_7|Mux12~2_combout\ & (\L_61|I1\(3))) # (!\L_7|Mux12~2_combout\ & ((\L_7|Mux12~1_combout\))))) # (!\L_7|Mux15~3_combout\ & (((\L_7|Mux12~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_61|I1\(3),
	datab => \L_7|Mux15~3_combout\,
	datac => \L_7|Mux12~1_combout\,
	datad => \L_7|Mux12~2_combout\,
	combout => \L_7|Mux12~3_combout\);

-- Location: LCCOMB_X73_Y15_N18
\L_34|Yout[3]~4\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_34|Yout[3]~4_combout\ = (\L_34|Yout[0]~0_combout\ & ((\L_7|Mux12~3_combout\) # ((\M4S1~input_o\ & \L_36|Yout[3]~3_combout\)))) # (!\L_34|Yout[0]~0_combout\ & (\M4S1~input_o\ & ((\L_36|Yout[3]~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_34|Yout[0]~0_combout\,
	datab => \M4S1~input_o\,
	datac => \L_7|Mux12~3_combout\,
	datad => \L_36|Yout[3]~3_combout\,
	combout => \L_34|Yout[3]~4_combout\);

-- Location: LCCOMB_X73_Y15_N8
\L_40|I0[2]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_40|I0\(2) = (GLOBAL(\M4S3~inputclkctrl_outclk\) & ((\L_38|Mult0|auto_generated|mac_out2~DATAOUT2\))) # (!GLOBAL(\M4S3~inputclkctrl_outclk\) & (\L_40|I0\(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_40|I0\(2),
	datac => \L_38|Mult0|auto_generated|mac_out2~DATAOUT2\,
	datad => \M4S3~inputclkctrl_outclk\,
	combout => \L_40|I0\(2));

-- Location: LCCOMB_X73_Y11_N8
\TM6|Yout[2]~10\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[2]~10_combout\ = (!\YTPM_S1[1]~input_o\ & ((\L_40|I0\(2)) # (!\YTPM_S1[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \YTPM_S1[1]~input_o\,
	datac => \YTPM_S1[0]~input_o\,
	datad => \L_40|I0\(2),
	combout => \TM6|Yout[2]~10_combout\);

-- Location: LCCOMB_X73_Y11_N14
\TM6|Yout[2]~11\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[2]~11_combout\ = (\TM6|Yout[0]~0_combout\ & ((\TM6|Yout[2]~10_combout\ & (\v3[2]~input_o\)) # (!\TM6|Yout[2]~10_combout\ & ((\L_61|I0\(2)))))) # (!\TM6|Yout[0]~0_combout\ & (((\TM6|Yout[2]~10_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011110010110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v3[2]~input_o\,
	datab => \TM6|Yout[0]~0_combout\,
	datac => \TM6|Yout[2]~10_combout\,
	datad => \L_61|I0\(2),
	combout => \TM6|Yout[2]~11_combout\);

-- Location: LCCOMB_X73_Y11_N6
\L_33|I1[2]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_33|I1\(2) = (GLOBAL(\M3S3~inputclkctrl_outclk\) & (\L_33|I1\(2))) # (!GLOBAL(\M3S3~inputclkctrl_outclk\) & ((\L_31|Mult0|auto_generated|mac_out2~DATAOUT2\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_33|I1\(2),
	datac => \L_31|Mult0|auto_generated|mac_out2~DATAOUT2\,
	datad => \M3S3~inputclkctrl_outclk\,
	combout => \L_33|I1\(2));

-- Location: LCCOMB_X73_Y11_N16
\TM6|Yout[2]~12\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[2]~12_combout\ = (\YTPM_S1[0]~input_o\ & ((\YTPM_S1[1]~input_o\ & ((\L_33|I1\(2)))) # (!\YTPM_S1[1]~input_o\ & (\TM6|Yout[2]~11_combout\)))) # (!\YTPM_S1[0]~input_o\ & (((\TM6|Yout[2]~11_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100001110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPM_S1[0]~input_o\,
	datab => \YTPM_S1[1]~input_o\,
	datac => \TM6|Yout[2]~11_combout\,
	datad => \L_33|I1\(2),
	combout => \TM6|Yout[2]~12_combout\);

-- Location: LCCOMB_X73_Y11_N2
\TM6|Yout[2]~13\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[2]~13_combout\ = (\YTPM_S1[2]~input_o\ & (\L_54|I1\(2))) # (!\YTPM_S1[2]~input_o\ & ((\TM6|Yout[2]~12_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPM_S1[2]~input_o\,
	datac => \L_54|I1\(2),
	datad => \TM6|Yout[2]~12_combout\,
	combout => \TM6|Yout[2]~13_combout\);

-- Location: LCCOMB_X73_Y11_N22
\TM7|I1[2]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM7|I1\(2) = (GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM7|I1\(2))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM6|Yout[2]~13_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM7|I1\(2),
	datab => \TTS~inputclkctrl_outclk\,
	datad => \TM6|Yout[2]~13_combout\,
	combout => \TM7|I1\(2));

-- Location: LCCOMB_X73_Y15_N0
\L_36|Yout[2]~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_36|Yout[2]~2_combout\ = (\L_6|I0\(2)) # ((\TM7|I1\(2) & \TM8|Equal0~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_6|I0\(2),
	datac => \TM7|I1\(2),
	datad => \TM8|Equal0~0_combout\,
	combout => \L_36|Yout[2]~2_combout\);

-- Location: LCCOMB_X73_Y15_N26
\L_34|Yout[2]~3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_34|Yout[2]~3_combout\ = (\M4S1~input_o\ & ((\L_36|Yout[2]~2_combout\) # ((\L_34|Yout[0]~0_combout\ & \L_7|Mux13~3_combout\)))) # (!\M4S1~input_o\ & (((\L_34|Yout[0]~0_combout\ & \L_7|Mux13~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M4S1~input_o\,
	datab => \L_36|Yout[2]~2_combout\,
	datac => \L_34|Yout[0]~0_combout\,
	datad => \L_7|Mux13~3_combout\,
	combout => \L_34|Yout[2]~3_combout\);

-- Location: LCCOMB_X75_Y15_N18
\L_40|I0[4]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_40|I0\(4) = (GLOBAL(\M4S3~inputclkctrl_outclk\) & ((\L_38|Mult0|auto_generated|mac_out2~DATAOUT4\))) # (!GLOBAL(\M4S3~inputclkctrl_outclk\) & (\L_40|I0\(4)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_40|I0\(4),
	datac => \M4S3~inputclkctrl_outclk\,
	datad => \L_38|Mult0|auto_generated|mac_out2~DATAOUT4\,
	combout => \L_40|I0\(4));

-- Location: LCCOMB_X75_Y12_N18
\TM2|Yout[4]~9\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[4]~9_combout\ = (\BMS1[1]~input_o\ & (!\BMS1[0]~input_o\)) # (!\BMS1[1]~input_o\ & ((\L_61|I0\(4))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101111100001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \BMS1[1]~input_o\,
	datac => \BMS1[0]~input_o\,
	datad => \L_61|I0\(4),
	combout => \TM2|Yout[4]~9_combout\);

-- Location: LCCOMB_X75_Y12_N16
\TM2|Yout[4]~10\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[4]~10_combout\ = (\BMS1[1]~input_o\ & ((\TM2|Yout[4]~9_combout\ & ((\L_40|I0\(4)))) # (!\TM2|Yout[4]~9_combout\ & (\v2[4]~input_o\)))) # (!\BMS1[1]~input_o\ & (((\TM2|Yout[4]~9_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \BMS1[1]~input_o\,
	datab => \v2[4]~input_o\,
	datac => \L_40|I0\(4),
	datad => \TM2|Yout[4]~9_combout\,
	combout => \TM2|Yout[4]~10_combout\);

-- Location: LCCOMB_X75_Y12_N26
\TM3|I0[4]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM3|I0\(4) = (GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM2|Yout[4]~10_combout\))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM3|I0\(4)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I0\(4),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM2|Yout[4]~10_combout\,
	combout => \TM3|I0\(4));

-- Location: LCCOMB_X72_Y10_N30
\L_3|I2[4]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I2\(4) = (GLOBAL(\L_3|Equal0~1clkctrl_outclk\) & ((\TM3|I0\(4)))) # (!GLOBAL(\L_3|Equal0~1clkctrl_outclk\) & (\L_3|I2\(4)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_3|I2\(4),
	datac => \L_3|Equal0~1clkctrl_outclk\,
	datad => \TM3|I0\(4),
	combout => \L_3|I2\(4));

-- Location: LCCOMB_X72_Y10_N16
\L_27|Yout[4]~4\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_27|Yout[4]~4_combout\ = (\M3S1~input_o\ & ((\TM4|I0\(4)) # ((\L_3|I0\(4))))) # (!\M3S1~input_o\ & (((\L_3|I2\(4)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110010111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM4|I0\(4),
	datab => \M3S1~input_o\,
	datac => \L_3|I2\(4),
	datad => \L_3|I0\(4),
	combout => \L_27|Yout[4]~4_combout\);

-- Location: LCCOMB_X76_Y9_N10
\L_33|I0[3]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_33|I0\(3) = (GLOBAL(\M3S3~inputclkctrl_outclk\) & ((\L_31|Mult0|auto_generated|mac_out2~DATAOUT3\))) # (!GLOBAL(\M3S3~inputclkctrl_outclk\) & (\L_33|I0\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_33|I0\(3),
	datac => \L_31|Mult0|auto_generated|mac_out2~DATAOUT3\,
	datad => \M3S3~inputclkctrl_outclk\,
	combout => \L_33|I0\(3));

-- Location: LCCOMB_X76_Y9_N0
\TM2|Yout[3]~36\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[3]~36_combout\ = (\BTPM_S1~input_o\ & (\v2[3]~input_o\)) # (!\BTPM_S1~input_o\ & ((\L_33|I0\(3))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \v2[3]~input_o\,
	datac => \BTPM_S1~input_o\,
	datad => \L_33|I0\(3),
	combout => \TM2|Yout[3]~36_combout\);

-- Location: LCCOMB_X69_Y10_N24
\TM3|I1[3]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM3|I1\(3) = (GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM3|I1\(3))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM2|Yout[3]~36_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM3|I1\(3),
	datac => \TM2|Yout[3]~36_combout\,
	datad => \TTS~inputclkctrl_outclk\,
	combout => \TM3|I1\(3));

-- Location: LCCOMB_X69_Y10_N20
\TM4|I0[3]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM4|I0\(3) = (GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & ((\TM3|I1\(3)))) # (!GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & (\TM4|I0\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM4|I0\(3),
	datac => \BTPD_S2~inputclkctrl_outclk\,
	datad => \TM3|I1\(3),
	combout => \TM4|I0\(3));

-- Location: LCCOMB_X70_Y10_N18
\L_27|Yout[3]~3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_27|Yout[3]~3_combout\ = (\M3S1~input_o\ & ((\L_3|I0\(3)) # ((\TM4|I0\(3))))) # (!\M3S1~input_o\ & (((\L_3|I2\(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M3S1~input_o\,
	datab => \L_3|I0\(3),
	datac => \L_3|I2\(3),
	datad => \TM4|I0\(3),
	combout => \L_27|Yout[3]~3_combout\);

-- Location: LCCOMB_X73_Y11_N20
\L_33|I0[2]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_33|I0\(2) = (GLOBAL(\M3S3~inputclkctrl_outclk\) & ((\L_31|Mult0|auto_generated|mac_out2~DATAOUT2\))) # (!GLOBAL(\M3S3~inputclkctrl_outclk\) & (\L_33|I0\(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_33|I0\(2),
	datac => \L_31|Mult0|auto_generated|mac_out2~DATAOUT2\,
	datad => \M3S3~inputclkctrl_outclk\,
	combout => \L_33|I0\(2));

-- Location: LCCOMB_X73_Y11_N12
\TM6|Yout[2]~70\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[2]~70_combout\ = (\YMS1[0]~input_o\ & ((\YMS1[1]~input_o\) # ((\L_33|I1\(2))))) # (!\YMS1[0]~input_o\ & (!\YMS1[1]~input_o\ & (\L_54|I1\(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101010011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YMS1[0]~input_o\,
	datab => \YMS1[1]~input_o\,
	datac => \L_54|I1\(2),
	datad => \L_33|I1\(2),
	combout => \TM6|Yout[2]~70_combout\);

-- Location: LCCOMB_X73_Y11_N10
\TM6|Yout[2]~71\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[2]~71_combout\ = (\YMS1[1]~input_o\ & ((\TM6|Yout[2]~70_combout\ & (\v3[2]~input_o\)) # (!\TM6|Yout[2]~70_combout\ & ((\L_33|I0\(2)))))) # (!\YMS1[1]~input_o\ & (((\TM6|Yout[2]~70_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YMS1[1]~input_o\,
	datab => \v3[2]~input_o\,
	datac => \L_33|I0\(2),
	datad => \TM6|Yout[2]~70_combout\,
	combout => \TM6|Yout[2]~71_combout\);

-- Location: LCCOMB_X73_Y11_N0
\TM7|I0[2]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM7|I0\(2) = (GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM6|Yout[2]~71_combout\))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM7|I0\(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TTS~inputclkctrl_outclk\,
	datac => \TM7|I0\(2),
	datad => \TM6|Yout[2]~71_combout\,
	combout => \TM7|I0\(2));

-- Location: LCCOMB_X77_Y7_N26
\L_6|I2[2]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I2\(2) = (GLOBAL(\L_6|Equal0~1clkctrl_outclk\) & ((\TM7|I0\(2)))) # (!GLOBAL(\L_6|Equal0~1clkctrl_outclk\) & (\L_6|I2\(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_6|I2\(2),
	datac => \TM7|I0\(2),
	datad => \L_6|Equal0~1clkctrl_outclk\,
	combout => \L_6|I2\(2));

-- Location: LCCOMB_X77_Y7_N10
\L_50|Yout[2]~4\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_50|Yout[2]~4_combout\ = (\L_6|I2\(2)) # ((\TM8|Equal3~0_combout\ & \TM7|I1\(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM8|Equal3~0_combout\,
	datac => \L_6|I2\(2),
	datad => \TM7|I1\(2),
	combout => \L_50|Yout[2]~4_combout\);

-- Location: LCCOMB_X77_Y7_N28
\L_48|Yout[2]~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_48|Yout[2]~2_combout\ = (\A2S1~input_o\ & (\L_12|I1\(2))) # (!\A2S1~input_o\ & ((\L_50|Yout[2]~4_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \A2S1~input_o\,
	datac => \L_12|I1\(2),
	datad => \L_50|Yout[2]~4_combout\,
	combout => \L_48|Yout[2]~2_combout\);

-- Location: LCCOMB_X73_Y5_N20
\L_54|I0[2]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_54|I0\(2) = (GLOBAL(\A2S3~inputclkctrl_outclk\) & ((\L_52|O[2]~4_combout\))) # (!GLOBAL(\A2S3~inputclkctrl_outclk\) & (\L_54|I0\(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_54|I0\(2),
	datac => \A2S3~inputclkctrl_outclk\,
	datad => \L_52|O[2]~4_combout\,
	combout => \L_54|I0\(2));

-- Location: LCCOMB_X73_Y5_N8
\L_26|I1[2]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_26|I1\(2) = (GLOBAL(\M2S3~inputclkctrl_outclk\) & (\L_26|I1\(2))) # (!GLOBAL(\M2S3~inputclkctrl_outclk\) & ((\L_24|Mult0|auto_generated|mac_out2~DATAOUT2\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_26|I1\(2),
	datac => \L_24|Mult0|auto_generated|mac_out2~DATAOUT2\,
	datad => \M2S3~inputclkctrl_outclk\,
	combout => \L_26|I1\(2));

-- Location: LCCOMB_X73_Y5_N10
\L_26|I0[2]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_26|I0\(2) = (GLOBAL(\M2S3~inputclkctrl_outclk\) & (\L_24|Mult0|auto_generated|mac_out2~DATAOUT2\)) # (!GLOBAL(\M2S3~inputclkctrl_outclk\) & ((\L_26|I0\(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \M2S3~inputclkctrl_outclk\,
	datac => \L_24|Mult0|auto_generated|mac_out2~DATAOUT2\,
	datad => \L_26|I0\(2),
	combout => \L_26|I0\(2));

-- Location: LCCOMB_X73_Y5_N12
\L_10|Yout[2]~4\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_10|Yout[2]~4_combout\ = (\GMS1[0]~input_o\ & (\GMS1[1]~input_o\)) # (!\GMS1[0]~input_o\ & ((\GMS1[1]~input_o\ & ((\L_26|I0\(2)))) # (!\GMS1[1]~input_o\ & (\L_26|I1\(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110010011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \GMS1[0]~input_o\,
	datab => \GMS1[1]~input_o\,
	datac => \L_26|I1\(2),
	datad => \L_26|I0\(2),
	combout => \L_10|Yout[2]~4_combout\);

-- Location: LCCOMB_X73_Y5_N14
\L_10|Yout[2]~5\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_10|Yout[2]~5_combout\ = (\GMS1[0]~input_o\ & ((\L_10|Yout[2]~4_combout\ & (\v1[2]~input_o\)) # (!\L_10|Yout[2]~4_combout\ & ((\L_54|I0\(2)))))) # (!\GMS1[0]~input_o\ & (((\L_10|Yout[2]~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \GMS1[0]~input_o\,
	datab => \v1[2]~input_o\,
	datac => \L_54|I0\(2),
	datad => \L_10|Yout[2]~4_combout\,
	combout => \L_10|Yout[2]~5_combout\);

-- Location: LCCOMB_X75_Y6_N18
\L_12|I0[2]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I0\(2) = (GLOBAL(\L_12|I0[15]~0clkctrl_outclk\) & ((\L_12|I0\(2)))) # (!GLOBAL(\L_12|I0[15]~0clkctrl_outclk\) & (\L_10|Yout[2]~5_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_10|Yout[2]~5_combout\,
	datac => \L_12|I0[15]~0clkctrl_outclk\,
	datad => \L_12|I0\(2),
	combout => \L_12|I0\(2));

-- Location: LCCOMB_X73_Y5_N6
\L_12|I2[2]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I2\(2) = (GLOBAL(\L_12|Equal0~2clkctrl_outclk\) & ((\L_10|Yout[2]~5_combout\))) # (!GLOBAL(\L_12|Equal0~2clkctrl_outclk\) & (\L_12|I2\(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_12|I2\(2),
	datab => \L_10|Yout[2]~5_combout\,
	datad => \L_12|Equal0~2clkctrl_outclk\,
	combout => \L_12|I2\(2));

-- Location: LCCOMB_X75_Y6_N12
\L_20|Yout[2]~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_20|Yout[2]~2_combout\ = (\M2S1~input_o\ & (\L_12|I0\(2))) # (!\M2S1~input_o\ & ((\L_12|I2\(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_12|I0\(2),
	datac => \M2S1~input_o\,
	datad => \L_12|I2\(2),
	combout => \L_20|Yout[2]~2_combout\);

-- Location: LCCOMB_X78_Y8_N18
\L_26|I0[1]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_26|I0\(1) = (GLOBAL(\M2S3~inputclkctrl_outclk\) & ((\L_24|Mult0|auto_generated|mac_out2~DATAOUT1\))) # (!GLOBAL(\M2S3~inputclkctrl_outclk\) & (\L_26|I0\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_26|I0\(1),
	datac => \M2S3~inputclkctrl_outclk\,
	datad => \L_24|Mult0|auto_generated|mac_out2~DATAOUT1\,
	combout => \L_26|I0\(1));

-- Location: LCCOMB_X78_Y8_N24
\L_54|I0[1]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_54|I0\(1) = (GLOBAL(\A2S3~inputclkctrl_outclk\) & (\L_52|O[1]~2_combout\)) # (!GLOBAL(\A2S3~inputclkctrl_outclk\) & ((\L_54|I0\(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_52|O[1]~2_combout\,
	datab => \L_54|I0\(1),
	datad => \A2S3~inputclkctrl_outclk\,
	combout => \L_54|I0\(1));

-- Location: LCCOMB_X78_Y8_N4
\L_10|Yout[1]~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_10|Yout[1]~2_combout\ = (\GMS1[1]~input_o\ & (((\GMS1[0]~input_o\)))) # (!\GMS1[1]~input_o\ & ((\GMS1[0]~input_o\ & ((\L_54|I0\(1)))) # (!\GMS1[0]~input_o\ & (\L_26|I1\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_26|I1\(1),
	datab => \L_54|I0\(1),
	datac => \GMS1[1]~input_o\,
	datad => \GMS1[0]~input_o\,
	combout => \L_10|Yout[1]~2_combout\);

-- Location: LCCOMB_X78_Y8_N14
\L_10|Yout[1]~3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_10|Yout[1]~3_combout\ = (\GMS1[1]~input_o\ & ((\L_10|Yout[1]~2_combout\ & (\v1[1]~input_o\)) # (!\L_10|Yout[1]~2_combout\ & ((\L_26|I0\(1)))))) # (!\GMS1[1]~input_o\ & (((\L_10|Yout[1]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v1[1]~input_o\,
	datab => \L_26|I0\(1),
	datac => \GMS1[1]~input_o\,
	datad => \L_10|Yout[1]~2_combout\,
	combout => \L_10|Yout[1]~3_combout\);

-- Location: LCCOMB_X77_Y6_N26
\L_12|I2[1]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I2\(1) = (GLOBAL(\L_12|Equal0~2clkctrl_outclk\) & ((\L_10|Yout[1]~3_combout\))) # (!GLOBAL(\L_12|Equal0~2clkctrl_outclk\) & (\L_12|I2\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_12|I2\(1),
	datac => \L_10|Yout[1]~3_combout\,
	datad => \L_12|Equal0~2clkctrl_outclk\,
	combout => \L_12|I2\(1));

-- Location: LCCOMB_X77_Y6_N20
\L_20|Yout[1]~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_20|Yout[1]~1_combout\ = (\M2S1~input_o\ & ((\L_12|I0\(1)))) # (!\M2S1~input_o\ & (\L_12|I2\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M2S1~input_o\,
	datac => \L_12|I2\(1),
	datad => \L_12|I0\(1),
	combout => \L_20|Yout[1]~1_combout\);

-- Location: LCCOMB_X72_Y8_N22
\L_26|I0[0]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_26|I0\(0) = (GLOBAL(\M2S3~inputclkctrl_outclk\) & ((\L_24|Mult0|auto_generated|mac_out2~dataout\))) # (!GLOBAL(\M2S3~inputclkctrl_outclk\) & (\L_26|I0\(0)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_26|I0\(0),
	datac => \L_24|Mult0|auto_generated|mac_out2~dataout\,
	datad => \M2S3~inputclkctrl_outclk\,
	combout => \L_26|I0\(0));

-- Location: LCCOMB_X72_Y8_N8
\L_10|Yout[0]~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_10|Yout[0]~0_combout\ = (\GMS1[0]~input_o\ & (((\GMS1[1]~input_o\)))) # (!\GMS1[0]~input_o\ & ((\GMS1[1]~input_o\ & ((\L_26|I0\(0)))) # (!\GMS1[1]~input_o\ & (\L_26|I1\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_26|I1\(0),
	datab => \GMS1[0]~input_o\,
	datac => \L_26|I0\(0),
	datad => \GMS1[1]~input_o\,
	combout => \L_10|Yout[0]~0_combout\);

-- Location: IOIBUF_X68_Y0_N15
\v1[0]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_v1(0),
	o => \v1[0]~input_o\);

-- Location: LCCOMB_X72_Y8_N6
\L_10|Yout[0]~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_10|Yout[0]~1_combout\ = (\GMS1[0]~input_o\ & ((\L_10|Yout[0]~0_combout\ & ((\v1[0]~input_o\))) # (!\L_10|Yout[0]~0_combout\ & (\L_54|I0\(0))))) # (!\GMS1[0]~input_o\ & (((\L_10|Yout[0]~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100001011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \GMS1[0]~input_o\,
	datab => \L_54|I0\(0),
	datac => \L_10|Yout[0]~0_combout\,
	datad => \v1[0]~input_o\,
	combout => \L_10|Yout[0]~1_combout\);

-- Location: LCCOMB_X71_Y7_N14
\L_12|I1[0]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_12|I1\(0) = (GLOBAL(\L_12|Equal0~1clkctrl_outclk\) & (\L_10|Yout[0]~1_combout\)) # (!GLOBAL(\L_12|Equal0~1clkctrl_outclk\) & ((\L_12|I1\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_10|Yout[0]~1_combout\,
	datac => \L_12|I1\(0),
	datad => \L_12|Equal0~1clkctrl_outclk\,
	combout => \L_12|I1\(0));

-- Location: LCCOMB_X71_Y7_N0
\L_6|I2[0]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I2\(0) = (GLOBAL(\L_6|Equal0~1clkctrl_outclk\) & (\TM7|I0\(0))) # (!GLOBAL(\L_6|Equal0~1clkctrl_outclk\) & ((\L_6|I2\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM7|I0\(0),
	datac => \L_6|Equal0~1clkctrl_outclk\,
	datad => \L_6|I2\(0),
	combout => \L_6|I2\(0));

-- Location: LCCOMB_X71_Y7_N10
\L_50|Yout[0]~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_50|Yout[0]~0_combout\ = (\L_6|I2\(0)) # ((\TM8|Equal3~0_combout\ & \TM7|I1\(0)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM8|Equal3~0_combout\,
	datac => \TM7|I1\(0),
	datad => \L_6|I2\(0),
	combout => \L_50|Yout[0]~0_combout\);

-- Location: LCCOMB_X71_Y7_N28
\L_48|Yout[0]~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_48|Yout[0]~0_combout\ = (\A2S1~input_o\ & (\L_12|I1\(0))) # (!\A2S1~input_o\ & ((\L_50|Yout[0]~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \A2S1~input_o\,
	datac => \L_12|I1\(0),
	datad => \L_50|Yout[0]~0_combout\,
	combout => \L_48|Yout[0]~0_combout\);

-- Location: LCCOMB_X72_Y9_N4
\L_54|I1[0]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_54|I1\(0) = (GLOBAL(\A2S3~inputclkctrl_outclk\) & ((\L_54|I1\(0)))) # (!GLOBAL(\A2S3~inputclkctrl_outclk\) & (\L_52|O[0]~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_52|O[0]~0_combout\,
	datac => \L_54|I1\(0),
	datad => \A2S3~inputclkctrl_outclk\,
	combout => \L_54|I1\(0));

-- Location: LCCOMB_X73_Y12_N16
\TM6|Yout[0]~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[0]~1_combout\ = (!\YTPM_S1[1]~input_o\ & ((\L_40|I0\(0)) # (!\YTPM_S1[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \YTPM_S1[1]~input_o\,
	datac => \YTPM_S1[0]~input_o\,
	datad => \L_40|I0\(0),
	combout => \TM6|Yout[0]~1_combout\);

-- Location: LCCOMB_X72_Y9_N24
\TM6|Yout[0]~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[0]~2_combout\ = (\TM6|Yout[0]~0_combout\ & ((\TM6|Yout[0]~1_combout\ & (\v3[0]~input_o\)) # (!\TM6|Yout[0]~1_combout\ & ((\L_61|I0\(0)))))) # (!\TM6|Yout[0]~0_combout\ & (((\TM6|Yout[0]~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v3[0]~input_o\,
	datab => \TM6|Yout[0]~0_combout\,
	datac => \L_61|I0\(0),
	datad => \TM6|Yout[0]~1_combout\,
	combout => \TM6|Yout[0]~2_combout\);

-- Location: LCCOMB_X72_Y9_N10
\TM6|Yout[0]~3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[0]~3_combout\ = (\YTPM_S1[1]~input_o\ & ((\YTPM_S1[0]~input_o\ & (\L_33|I1\(0))) # (!\YTPM_S1[0]~input_o\ & ((\TM6|Yout[0]~2_combout\))))) # (!\YTPM_S1[1]~input_o\ & (((\TM6|Yout[0]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101111110000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPM_S1[1]~input_o\,
	datab => \L_33|I1\(0),
	datac => \YTPM_S1[0]~input_o\,
	datad => \TM6|Yout[0]~2_combout\,
	combout => \TM6|Yout[0]~3_combout\);

-- Location: LCCOMB_X72_Y9_N20
\TM6|Yout[0]~4\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[0]~4_combout\ = (\YTPM_S1[2]~input_o\ & (\L_54|I1\(0))) # (!\YTPM_S1[2]~input_o\ & ((\TM6|Yout[0]~3_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \YTPM_S1[2]~input_o\,
	datac => \L_54|I1\(0),
	datad => \TM6|Yout[0]~3_combout\,
	combout => \TM6|Yout[0]~4_combout\);

-- Location: LCCOMB_X72_Y9_N28
\TM7|I1[0]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM7|I1\(0) = (GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM7|I1\(0))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM6|Yout[0]~4_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM7|I1\(0),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM6|Yout[0]~4_combout\,
	combout => \TM7|I1\(0));

-- Location: LCCOMB_X76_Y16_N30
\L_36|Yout[0]~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_36|Yout[0]~0_combout\ = (\L_6|I0\(0)) # ((\TM8|Equal0~0_combout\ & \TM7|I1\(0)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM8|Equal0~0_combout\,
	datac => \L_6|I0\(0),
	datad => \TM7|I1\(0),
	combout => \L_36|Yout[0]~0_combout\);

-- Location: LCCOMB_X76_Y16_N28
\L_34|Yout[0]~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_34|Yout[0]~1_combout\ = (\M4S1~input_o\ & ((\L_36|Yout[0]~0_combout\) # ((\L_34|Yout[0]~0_combout\ & \L_7|Mux15~5_combout\)))) # (!\M4S1~input_o\ & (\L_34|Yout[0]~0_combout\ & ((\L_7|Mux15~5_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M4S1~input_o\,
	datab => \L_34|Yout[0]~0_combout\,
	datac => \L_36|Yout[0]~0_combout\,
	datad => \L_7|Mux15~5_combout\,
	combout => \L_34|Yout[0]~1_combout\);

-- Location: LCCOMB_X77_Y11_N24
\L_40|I0[1]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_40|I0\(1) = (GLOBAL(\M4S3~inputclkctrl_outclk\) & ((\L_38|Mult0|auto_generated|mac_out2~DATAOUT1\))) # (!GLOBAL(\M4S3~inputclkctrl_outclk\) & (\L_40|I0\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_40|I0\(1),
	datac => \M4S3~inputclkctrl_outclk\,
	datad => \L_38|Mult0|auto_generated|mac_out2~DATAOUT1\,
	combout => \L_40|I0\(1));

-- Location: LCCOMB_X77_Y11_N4
\TM2|Yout[1]~4\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[1]~4_combout\ = (\TM2|Yout[9]~2_combout\ & ((\TM2|Yout[1]~3_combout\ & ((\L_40|I0\(1)))) # (!\TM2|Yout[1]~3_combout\ & (\L_61|I0\(1))))) # (!\TM2|Yout[9]~2_combout\ & (\TM2|Yout[1]~3_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110001100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM2|Yout[9]~2_combout\,
	datab => \TM2|Yout[1]~3_combout\,
	datac => \L_61|I0\(1),
	datad => \L_40|I0\(1),
	combout => \TM2|Yout[1]~4_combout\);

-- Location: LCCOMB_X77_Y11_N12
\TM3|I0[1]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM3|I0\(1) = (GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM2|Yout[1]~4_combout\))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM3|I0\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM3|I0\(1),
	datac => \TM2|Yout[1]~4_combout\,
	datad => \TTS~inputclkctrl_outclk\,
	combout => \TM3|I0\(1));

-- Location: LCCOMB_X71_Y10_N14
\L_3|I2[1]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_3|I2\(1) = (GLOBAL(\L_3|Equal0~1clkctrl_outclk\) & (\TM3|I0\(1))) # (!GLOBAL(\L_3|Equal0~1clkctrl_outclk\) & ((\L_3|I2\(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM3|I0\(1),
	datac => \L_3|I2\(1),
	datad => \L_3|Equal0~1clkctrl_outclk\,
	combout => \L_3|I2\(1));

-- Location: LCCOMB_X71_Y10_N2
\L_27|Yout[1]~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_27|Yout[1]~1_combout\ = (\M3S1~input_o\ & ((\L_3|I0\(1)) # ((\TM4|I0\(1))))) # (!\M3S1~input_o\ & (((\L_3|I2\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M3S1~input_o\,
	datab => \L_3|I0\(1),
	datac => \L_3|I2\(1),
	datad => \TM4|I0\(1),
	combout => \L_27|Yout[1]~1_combout\);

-- Location: LCCOMB_X72_Y9_N14
\L_33|I0[0]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_33|I0\(0) = (GLOBAL(\M3S3~inputclkctrl_outclk\) & ((\L_31|Mult0|auto_generated|mac_out2~dataout\))) # (!GLOBAL(\M3S3~inputclkctrl_outclk\) & (\L_33|I0\(0)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_33|I0\(0),
	datac => \M3S3~inputclkctrl_outclk\,
	datad => \L_31|Mult0|auto_generated|mac_out2~dataout\,
	combout => \L_33|I0\(0));

-- Location: LCCOMB_X72_Y9_N6
\TM2|Yout[0]~33\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM2|Yout[0]~33_combout\ = (\BTPM_S1~input_o\ & ((\v2[0]~input_o\))) # (!\BTPM_S1~input_o\ & (\L_33|I0\(0)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \BTPM_S1~input_o\,
	datac => \L_33|I0\(0),
	datad => \v2[0]~input_o\,
	combout => \TM2|Yout[0]~33_combout\);

-- Location: LCCOMB_X72_Y9_N0
\TM3|I1[0]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM3|I1\(0) = (GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM3|I1\(0))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM2|Yout[0]~33_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM3|I1\(0),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM2|Yout[0]~33_combout\,
	combout => \TM3|I1\(0));

-- Location: LCCOMB_X72_Y10_N12
\TM4|I0[0]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM4|I0\(0) = (GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & ((\TM3|I1\(0)))) # (!GLOBAL(\BTPD_S2~inputclkctrl_outclk\) & (\TM4|I0\(0)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM4|I0\(0),
	datac => \BTPD_S2~inputclkctrl_outclk\,
	datad => \TM3|I1\(0),
	combout => \TM4|I0\(0));

-- Location: LCCOMB_X71_Y10_N0
\L_27|Yout[0]~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_27|Yout[0]~0_combout\ = (\M3S1~input_o\ & ((\TM4|I0\(0)) # ((\L_3|I0\(0))))) # (!\M3S1~input_o\ & (((\L_3|I2\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \M3S1~input_o\,
	datab => \TM4|I0\(0),
	datac => \L_3|I2\(0),
	datad => \L_3|I0\(0),
	combout => \L_27|Yout[0]~0_combout\);

-- Location: LCCOMB_X78_Y10_N0
\L_33|I1[1]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_33|I1\(1) = (GLOBAL(\M3S3~inputclkctrl_outclk\) & (\L_33|I1\(1))) # (!GLOBAL(\M3S3~inputclkctrl_outclk\) & ((\L_31|Mult0|auto_generated|mac_out2~DATAOUT1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_33|I1\(1),
	datac => \L_31|Mult0|auto_generated|mac_out2~DATAOUT1\,
	datad => \M3S3~inputclkctrl_outclk\,
	combout => \L_33|I1\(1));

-- Location: LCCOMB_X77_Y11_N8
\TM6|Yout[1]~6\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[1]~6_combout\ = (\YTPM_S1[1]~input_o\ & (((\L_61|I0\(1))))) # (!\YTPM_S1[1]~input_o\ & (((\L_40|I0\(1))) # (!\YTPM_S1[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111010001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPM_S1[0]~input_o\,
	datab => \YTPM_S1[1]~input_o\,
	datac => \L_61|I0\(1),
	datad => \L_40|I0\(1),
	combout => \TM6|Yout[1]~6_combout\);

-- Location: LCCOMB_X77_Y11_N10
\TM6|Yout[1]~7\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[1]~7_combout\ = (\TM6|Yout[0]~5_combout\ & (((\TM6|Yout[1]~6_combout\)))) # (!\TM6|Yout[0]~5_combout\ & ((\TM6|Yout[1]~6_combout\ & (\v3[1]~input_o\)) # (!\TM6|Yout[1]~6_combout\ & ((\L_33|I0\(1))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110010111100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM6|Yout[0]~5_combout\,
	datab => \v3[1]~input_o\,
	datac => \TM6|Yout[1]~6_combout\,
	datad => \L_33|I0\(1),
	combout => \TM6|Yout[1]~7_combout\);

-- Location: LCCOMB_X77_Y11_N28
\TM6|Yout[1]~8\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[1]~8_combout\ = (\YTPM_S1[0]~input_o\ & ((\YTPM_S1[1]~input_o\ & (\L_33|I1\(1))) # (!\YTPM_S1[1]~input_o\ & ((\TM6|Yout[1]~7_combout\))))) # (!\YTPM_S1[0]~input_o\ & (((\TM6|Yout[1]~7_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111011110000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPM_S1[0]~input_o\,
	datab => \YTPM_S1[1]~input_o\,
	datac => \L_33|I1\(1),
	datad => \TM6|Yout[1]~7_combout\,
	combout => \TM6|Yout[1]~8_combout\);

-- Location: LCCOMB_X77_Y11_N18
\TM6|Yout[1]~9\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[1]~9_combout\ = (\YTPM_S1[2]~input_o\ & (\L_54|I1\(1))) # (!\YTPM_S1[2]~input_o\ & ((\TM6|Yout[1]~8_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_54|I1\(1),
	datac => \YTPM_S1[2]~input_o\,
	datad => \TM6|Yout[1]~8_combout\,
	combout => \TM6|Yout[1]~9_combout\);

-- Location: LCCOMB_X77_Y11_N2
\TM7|I1[1]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM7|I1\(1) = (GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM7|I1\(1))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM6|Yout[1]~9_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TTS~inputclkctrl_outclk\,
	datac => \TM7|I1\(1),
	datad => \TM6|Yout[1]~9_combout\,
	combout => \TM7|I1\(1));

-- Location: LCCOMB_X77_Y12_N8
\L_57|Yout[1]~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_57|Yout[1]~2_combout\ = (\L_3|I1\(1) & ((\TTS~input_o\) # ((\L_55|Yout[0]~0_combout\ & \TM7|I1\(1))))) # (!\L_3|I1\(1) & (((\L_55|Yout[0]~0_combout\ & \TM7|I1\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_3|I1\(1),
	datab => \TTS~input_o\,
	datac => \L_55|Yout[0]~0_combout\,
	datad => \TM7|I1\(1),
	combout => \L_57|Yout[1]~2_combout\);

-- Location: LCCOMB_X77_Y12_N18
\L_55|Yout[1]~3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_55|Yout[1]~3_combout\ = (\L_55|Yout[15]~1_combout\ & ((\L_7|Mux14~3_combout\) # ((\A3S1~input_o\ & \L_57|Yout[1]~2_combout\)))) # (!\L_55|Yout[15]~1_combout\ & (\A3S1~input_o\ & (\L_57|Yout[1]~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_55|Yout[15]~1_combout\,
	datab => \A3S1~input_o\,
	datac => \L_57|Yout[1]~2_combout\,
	datad => \L_7|Mux14~3_combout\,
	combout => \L_55|Yout[1]~3_combout\);

-- Location: LCCOMB_X78_Y16_N18
\L_61|I1[1]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_61|I1\(1) = (GLOBAL(\A3S3~inputclkctrl_outclk\) & (\L_61|I1\(1))) # (!GLOBAL(\A3S3~inputclkctrl_outclk\) & ((\L_59|O[1]~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_61|I1\(1),
	datac => \L_59|O[1]~2_combout\,
	datad => \A3S3~inputclkctrl_outclk\,
	combout => \L_61|I1\(1));

-- Location: LCCOMB_X78_Y16_N26
\L_19|I1[1]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_19|I1\(1) = (GLOBAL(\M1S3~inputclkctrl_outclk\) & (\L_19|I1\(1))) # (!GLOBAL(\M1S3~inputclkctrl_outclk\) & ((\L_17|Mult0|auto_generated|mac_out2~DATAOUT1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_19|I1\(1),
	datac => \M1S3~inputclkctrl_outclk\,
	datad => \L_17|Mult0|auto_generated|mac_out2~DATAOUT1\,
	combout => \L_19|I1\(1));

-- Location: LCCOMB_X78_Y16_N28
\L_47|I0[1]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_47|I0\(1) = (GLOBAL(\A1S3~inputclkctrl_outclk\) & ((\L_45|O[1]~2_combout\))) # (!GLOBAL(\A1S3~inputclkctrl_outclk\) & (\L_47|I0\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_47|I0\(1),
	datac => \L_45|O[1]~2_combout\,
	datad => \A1S3~inputclkctrl_outclk\,
	combout => \L_47|I0\(1));

-- Location: LCCOMB_X78_Y16_N20
\L_7|Mux14~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux14~0_combout\ = (\RMS1[1]~input_o\ & (((\RMS1[0]~input_o\) # (\L_47|I0\(1))))) # (!\RMS1[1]~input_o\ & (\v0[1]~input_o\ & (!\RMS1[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111011000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v0[1]~input_o\,
	datab => \RMS1[1]~input_o\,
	datac => \RMS1[0]~input_o\,
	datad => \L_47|I0\(1),
	combout => \L_7|Mux14~0_combout\);

-- Location: LCCOMB_X78_Y16_N30
\L_7|Mux14~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux14~1_combout\ = (\RMS1[0]~input_o\ & ((\L_7|Mux14~0_combout\ & ((\L_19|I1\(1)))) # (!\L_7|Mux14~0_combout\ & (\L_19|I0\(1))))) # (!\RMS1[0]~input_o\ & (((\L_7|Mux14~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_19|I0\(1),
	datab => \RMS1[0]~input_o\,
	datac => \L_19|I1\(1),
	datad => \L_7|Mux14~0_combout\,
	combout => \L_7|Mux14~1_combout\);

-- Location: LCCOMB_X78_Y16_N8
\L_47|I1[1]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_47|I1\(1) = (GLOBAL(\A1S3~inputclkctrl_outclk\) & ((\L_47|I1\(1)))) # (!GLOBAL(\A1S3~inputclkctrl_outclk\) & (\L_45|O[1]~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_45|O[1]~2_combout\,
	datac => \L_47|I1\(1),
	datad => \A1S3~inputclkctrl_outclk\,
	combout => \L_47|I1\(1));

-- Location: LCCOMB_X75_Y16_N10
\L_40|I1[1]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_40|I1\(1) = (GLOBAL(\M4S3~inputclkctrl_outclk\) & (\L_40|I1\(1))) # (!GLOBAL(\M4S3~inputclkctrl_outclk\) & ((\L_38|Mult0|auto_generated|mac_out2~DATAOUT1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_40|I1\(1),
	datac => \M4S3~inputclkctrl_outclk\,
	datad => \L_38|Mult0|auto_generated|mac_out2~DATAOUT1\,
	combout => \L_40|I1\(1));

-- Location: LCCOMB_X78_Y16_N12
\L_7|Mux14~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux14~2_combout\ = (\L_7|Mux15~3_combout\ & (\L_7|Mux15~0_combout\)) # (!\L_7|Mux15~3_combout\ & ((\L_7|Mux15~0_combout\ & ((\L_40|I1\(1)))) # (!\L_7|Mux15~0_combout\ & (\L_47|I1\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110010011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_7|Mux15~3_combout\,
	datab => \L_7|Mux15~0_combout\,
	datac => \L_47|I1\(1),
	datad => \L_40|I1\(1),
	combout => \L_7|Mux14~2_combout\);

-- Location: LCCOMB_X78_Y16_N2
\L_7|Mux14~3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux14~3_combout\ = (\L_7|Mux15~3_combout\ & ((\L_7|Mux14~2_combout\ & (\L_61|I1\(1))) # (!\L_7|Mux14~2_combout\ & ((\L_7|Mux14~1_combout\))))) # (!\L_7|Mux15~3_combout\ & (((\L_7|Mux14~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_7|Mux15~3_combout\,
	datab => \L_61|I1\(1),
	datac => \L_7|Mux14~1_combout\,
	datad => \L_7|Mux14~2_combout\,
	combout => \L_7|Mux14~3_combout\);

-- Location: LCCOMB_X78_Y16_N0
\L_13|Yout[1]~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_13|Yout[1]~2_combout\ = (\L_13|Yout[15]~0_combout\ & \L_7|Mux14~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \L_13|Yout[15]~0_combout\,
	datad => \L_7|Mux14~3_combout\,
	combout => \L_13|Yout[1]~2_combout\);

-- Location: LCCOMB_X79_Y16_N24
\L_19|I0[0]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_19|I0\(0) = (GLOBAL(\M1S3~inputclkctrl_outclk\) & ((\L_17|Mult0|auto_generated|mac_out2~dataout\))) # (!GLOBAL(\M1S3~inputclkctrl_outclk\) & (\L_19|I0\(0)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_19|I0\(0),
	datac => \M1S3~inputclkctrl_outclk\,
	datad => \L_17|Mult0|auto_generated|mac_out2~dataout\,
	combout => \L_19|I0\(0));

-- Location: LCCOMB_X79_Y16_N8
\L_7|Mux15~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux15~1_combout\ = (\RMS1[0]~input_o\ & (((\RMS1[1]~input_o\) # (\L_19|I0\(0))))) # (!\RMS1[0]~input_o\ & (\v0[0]~input_o\ & (!\RMS1[1]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111011000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v0[0]~input_o\,
	datab => \RMS1[0]~input_o\,
	datac => \RMS1[1]~input_o\,
	datad => \L_19|I0\(0),
	combout => \L_7|Mux15~1_combout\);

-- Location: LCCOMB_X79_Y16_N18
\L_19|I1[0]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_19|I1\(0) = (GLOBAL(\M1S3~inputclkctrl_outclk\) & (\L_19|I1\(0))) # (!GLOBAL(\M1S3~inputclkctrl_outclk\) & ((\L_17|Mult0|auto_generated|mac_out2~dataout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_19|I1\(0),
	datac => \M1S3~inputclkctrl_outclk\,
	datad => \L_17|Mult0|auto_generated|mac_out2~dataout\,
	combout => \L_19|I1\(0));

-- Location: LCCOMB_X79_Y16_N26
\L_7|Mux15~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux15~2_combout\ = (\RMS1[1]~input_o\ & ((\L_7|Mux15~1_combout\ & ((\L_19|I1\(0)))) # (!\L_7|Mux15~1_combout\ & (\L_47|I0\(0))))) # (!\RMS1[1]~input_o\ & (((\L_7|Mux15~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100001011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \RMS1[1]~input_o\,
	datab => \L_47|I0\(0),
	datac => \L_7|Mux15~1_combout\,
	datad => \L_19|I1\(0),
	combout => \L_7|Mux15~2_combout\);

-- Location: LCCOMB_X79_Y16_N20
\L_47|I1[0]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_47|I1\(0) = (GLOBAL(\A1S3~inputclkctrl_outclk\) & ((\L_47|I1\(0)))) # (!GLOBAL(\A1S3~inputclkctrl_outclk\) & (\L_45|O[0]~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_45|O[0]~0_combout\,
	datac => \L_47|I1\(0),
	datad => \A1S3~inputclkctrl_outclk\,
	combout => \L_47|I1\(0));

-- Location: LCCOMB_X79_Y16_N16
\L_7|Mux15~4\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux15~4_combout\ = (\L_7|Mux15~0_combout\ & (\L_7|Mux15~3_combout\)) # (!\L_7|Mux15~0_combout\ & ((\L_7|Mux15~3_combout\ & (\L_7|Mux15~2_combout\)) # (!\L_7|Mux15~3_combout\ & ((\L_47|I1\(0))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101100111001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_7|Mux15~0_combout\,
	datab => \L_7|Mux15~3_combout\,
	datac => \L_7|Mux15~2_combout\,
	datad => \L_47|I1\(0),
	combout => \L_7|Mux15~4_combout\);

-- Location: LCCOMB_X76_Y16_N24
\L_7|Mux15~5\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_7|Mux15~5_combout\ = (\L_7|Mux15~0_combout\ & ((\L_7|Mux15~4_combout\ & ((\L_61|I1\(0)))) # (!\L_7|Mux15~4_combout\ & (\L_40|I1\(0))))) # (!\L_7|Mux15~0_combout\ & (((\L_7|Mux15~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_40|I1\(0),
	datab => \L_7|Mux15~0_combout\,
	datac => \L_61|I1\(0),
	datad => \L_7|Mux15~4_combout\,
	combout => \L_7|Mux15~5_combout\);

-- Location: LCCOMB_X80_Y15_N4
\L_9|I6[0]~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_9|I6[0]~0_combout\ = (\L_7|Mux15~5_combout\ & (\RDS2[1]~input_o\ & (\RDS2[2]~input_o\ & !\RDS2[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_7|Mux15~5_combout\,
	datab => \RDS2[1]~input_o\,
	datac => \RDS2[2]~input_o\,
	datad => \RDS2[0]~input_o\,
	combout => \L_9|I6[0]~0_combout\);

-- Location: LCCOMB_X80_Y15_N2
\L_9|I6[1]~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_9|I6[1]~1_combout\ = (\RDS2[2]~input_o\ & (\L_7|Mux14~3_combout\ & (\RDS2[1]~input_o\ & !\RDS2[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \RDS2[2]~input_o\,
	datab => \L_7|Mux14~3_combout\,
	datac => \RDS2[1]~input_o\,
	datad => \RDS2[0]~input_o\,
	combout => \L_9|I6[1]~1_combout\);

-- Location: LCCOMB_X80_Y15_N0
\L_9|I6[2]~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_9|I6[2]~2_combout\ = (\L_7|Mux13~3_combout\ & (\RDS2[1]~input_o\ & (\RDS2[2]~input_o\ & !\RDS2[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_7|Mux13~3_combout\,
	datab => \RDS2[1]~input_o\,
	datac => \RDS2[2]~input_o\,
	datad => \RDS2[0]~input_o\,
	combout => \L_9|I6[2]~2_combout\);

-- Location: LCCOMB_X80_Y15_N10
\L_9|I6[3]~3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_9|I6[3]~3_combout\ = (\RDS2[2]~input_o\ & (!\RDS2[0]~input_o\ & (\RDS2[1]~input_o\ & \L_7|Mux12~3_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \RDS2[2]~input_o\,
	datab => \RDS2[0]~input_o\,
	datac => \RDS2[1]~input_o\,
	datad => \L_7|Mux12~3_combout\,
	combout => \L_9|I6[3]~3_combout\);

-- Location: LCCOMB_X80_Y15_N28
\L_9|I6[4]~4\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_9|I6[4]~4_combout\ = (\L_7|Mux11~3_combout\ & (\RDS2[1]~input_o\ & (\RDS2[2]~input_o\ & !\RDS2[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_7|Mux11~3_combout\,
	datab => \RDS2[1]~input_o\,
	datac => \RDS2[2]~input_o\,
	datad => \RDS2[0]~input_o\,
	combout => \L_9|I6[4]~4_combout\);

-- Location: LCCOMB_X80_Y15_N14
\L_9|I6[5]~5\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_9|I6[5]~5_combout\ = (\RDS2[2]~input_o\ & (\L_7|Mux10~3_combout\ & (\RDS2[1]~input_o\ & !\RDS2[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \RDS2[2]~input_o\,
	datab => \L_7|Mux10~3_combout\,
	datac => \RDS2[1]~input_o\,
	datad => \RDS2[0]~input_o\,
	combout => \L_9|I6[5]~5_combout\);

-- Location: LCCOMB_X80_Y15_N8
\L_9|I6[6]~6\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_9|I6[6]~6_combout\ = (\L_7|Mux9~3_combout\ & (\RDS2[1]~input_o\ & (\RDS2[2]~input_o\ & !\RDS2[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_7|Mux9~3_combout\,
	datab => \RDS2[1]~input_o\,
	datac => \RDS2[2]~input_o\,
	datad => \RDS2[0]~input_o\,
	combout => \L_9|I6[6]~6_combout\);

-- Location: LCCOMB_X76_Y13_N28
\L_9|I6[7]~7\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_9|I6[7]~7_combout\ = (\RDS2[2]~input_o\ & (\RDS2[1]~input_o\ & (\L_7|Mux8~3_combout\ & !\RDS2[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \RDS2[2]~input_o\,
	datab => \RDS2[1]~input_o\,
	datac => \L_7|Mux8~3_combout\,
	datad => \RDS2[0]~input_o\,
	combout => \L_9|I6[7]~7_combout\);

-- Location: LCCOMB_X80_Y15_N18
\L_9|I6[8]~8\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_9|I6[8]~8_combout\ = (\L_7|Mux7~3_combout\ & (\RDS2[1]~input_o\ & (\RDS2[2]~input_o\ & !\RDS2[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_7|Mux7~3_combout\,
	datab => \RDS2[1]~input_o\,
	datac => \RDS2[2]~input_o\,
	datad => \RDS2[0]~input_o\,
	combout => \L_9|I6[8]~8_combout\);

-- Location: LCCOMB_X80_Y15_N24
\L_9|I6[9]~9\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_9|I6[9]~9_combout\ = (\L_7|Mux6~3_combout\ & (\RDS2[1]~input_o\ & (\RDS2[2]~input_o\ & !\RDS2[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_7|Mux6~3_combout\,
	datab => \RDS2[1]~input_o\,
	datac => \RDS2[2]~input_o\,
	datad => \RDS2[0]~input_o\,
	combout => \L_9|I6[9]~9_combout\);

-- Location: LCCOMB_X80_Y15_N26
\L_9|I6[10]~10\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_9|I6[10]~10_combout\ = (\L_7|Mux5~3_combout\ & (\RDS2[1]~input_o\ & (\RDS2[2]~input_o\ & !\RDS2[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_7|Mux5~3_combout\,
	datab => \RDS2[1]~input_o\,
	datac => \RDS2[2]~input_o\,
	datad => \RDS2[0]~input_o\,
	combout => \L_9|I6[10]~10_combout\);

-- Location: LCCOMB_X80_Y15_N20
\L_9|I6[11]~11\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_9|I6[11]~11_combout\ = (\RDS2[2]~input_o\ & (\RDS2[1]~input_o\ & (\L_7|Mux4~3_combout\ & !\RDS2[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \RDS2[2]~input_o\,
	datab => \RDS2[1]~input_o\,
	datac => \L_7|Mux4~3_combout\,
	datad => \RDS2[0]~input_o\,
	combout => \L_9|I6[11]~11_combout\);

-- Location: LCCOMB_X78_Y16_N16
\L_9|I6[12]~12\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_9|I6[12]~12_combout\ = (\L_7|Mux3~3_combout\ & (\RDS2[1]~input_o\ & (\RDS2[2]~input_o\ & !\RDS2[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_7|Mux3~3_combout\,
	datab => \RDS2[1]~input_o\,
	datac => \RDS2[2]~input_o\,
	datad => \RDS2[0]~input_o\,
	combout => \L_9|I6[12]~12_combout\);

-- Location: LCCOMB_X80_Y15_N6
\L_9|I6[13]~13\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_9|I6[13]~13_combout\ = (\RDS2[2]~input_o\ & (\L_7|Mux2~3_combout\ & (\RDS2[1]~input_o\ & !\RDS2[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \RDS2[2]~input_o\,
	datab => \L_7|Mux2~3_combout\,
	datac => \RDS2[1]~input_o\,
	datad => \RDS2[0]~input_o\,
	combout => \L_9|I6[13]~13_combout\);

-- Location: LCCOMB_X80_Y15_N16
\L_9|I6[14]~14\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_9|I6[14]~14_combout\ = (\L_7|Mux1~3_combout\ & (\RDS2[1]~input_o\ & (\RDS2[2]~input_o\ & !\RDS2[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_7|Mux1~3_combout\,
	datab => \RDS2[1]~input_o\,
	datac => \RDS2[2]~input_o\,
	datad => \RDS2[0]~input_o\,
	combout => \L_9|I6[14]~14_combout\);

-- Location: LCCOMB_X80_Y15_N22
\L_9|I6[15]~15\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_9|I6[15]~15_combout\ = (\L_7|Mux0~3_combout\ & (\RDS2[1]~input_o\ & (\RDS2[2]~input_o\ & !\RDS2[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_7|Mux0~3_combout\,
	datab => \RDS2[1]~input_o\,
	datac => \RDS2[2]~input_o\,
	datad => \RDS2[0]~input_o\,
	combout => \L_9|I6[15]~15_combout\);

-- Location: LCCOMB_X1_Y45_N10
\L_6|Equal0~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|Equal0~0_combout\ = (\YDS2[1]~input_o\) # (\YDS2[0]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \YDS2[1]~input_o\,
	datad => \YDS2[0]~input_o\,
	combout => \L_6|Equal0~0_combout\);

-- Location: CLKCTRL_G4
\L_6|Equal0~0clkctrl\ : cycloneiv_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \L_6|Equal0~0clkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \L_6|Equal0~0clkctrl_outclk\);

-- Location: LCCOMB_X71_Y11_N20
\L_6|I3[0]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I3\(0) = (GLOBAL(\L_6|Equal0~0clkctrl_outclk\) & (\L_6|I3\(0))) # (!GLOBAL(\L_6|Equal0~0clkctrl_outclk\) & ((\TM7|I0\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_6|I3\(0),
	datac => \TM7|I0\(0),
	datad => \L_6|Equal0~0clkctrl_outclk\,
	combout => \L_6|I3\(0));

-- Location: LCCOMB_X78_Y7_N6
\L_6|I3[1]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I3\(1) = (GLOBAL(\L_6|Equal0~0clkctrl_outclk\) & (\L_6|I3\(1))) # (!GLOBAL(\L_6|Equal0~0clkctrl_outclk\) & ((\TM7|I0\(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_6|I3\(1),
	datac => \TM7|I0\(1),
	datad => \L_6|Equal0~0clkctrl_outclk\,
	combout => \L_6|I3\(1));

-- Location: LCCOMB_X73_Y6_N20
\L_6|I3[2]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I3\(2) = (GLOBAL(\L_6|Equal0~0clkctrl_outclk\) & (\L_6|I3\(2))) # (!GLOBAL(\L_6|Equal0~0clkctrl_outclk\) & ((\TM7|I0\(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_6|I3\(2),
	datac => \TM7|I0\(2),
	datad => \L_6|Equal0~0clkctrl_outclk\,
	combout => \L_6|I3\(2));

-- Location: LCCOMB_X76_Y15_N8
\L_6|I3[3]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I3\(3) = (GLOBAL(\L_6|Equal0~0clkctrl_outclk\) & ((\L_6|I3\(3)))) # (!GLOBAL(\L_6|Equal0~0clkctrl_outclk\) & (\TM7|I0\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM7|I0\(3),
	datac => \L_6|I3\(3),
	datad => \L_6|Equal0~0clkctrl_outclk\,
	combout => \L_6|I3\(3));

-- Location: LCCOMB_X70_Y7_N8
\L_6|I3[4]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I3\(4) = (GLOBAL(\L_6|Equal0~0clkctrl_outclk\) & ((\L_6|I3\(4)))) # (!GLOBAL(\L_6|Equal0~0clkctrl_outclk\) & (\TM7|I0\(4)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM7|I0\(4),
	datac => \L_6|I3\(4),
	datad => \L_6|Equal0~0clkctrl_outclk\,
	combout => \L_6|I3\(4));

-- Location: LCCOMB_X79_Y15_N30
\L_6|I3[5]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I3\(5) = (GLOBAL(\L_6|Equal0~0clkctrl_outclk\) & (\L_6|I3\(5))) # (!GLOBAL(\L_6|Equal0~0clkctrl_outclk\) & ((\TM7|I0\(5))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_6|I3\(5),
	datac => \TM7|I0\(5),
	datad => \L_6|Equal0~0clkctrl_outclk\,
	combout => \L_6|I3\(5));

-- Location: LCCOMB_X73_Y6_N26
\L_6|I3[6]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I3\(6) = (GLOBAL(\L_6|Equal0~0clkctrl_outclk\) & (\L_6|I3\(6))) # (!GLOBAL(\L_6|Equal0~0clkctrl_outclk\) & ((\TM7|I0\(6))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_6|I3\(6),
	datac => \TM7|I0\(6),
	datad => \L_6|Equal0~0clkctrl_outclk\,
	combout => \L_6|I3\(6));

-- Location: LCCOMB_X78_Y9_N10
\TM6|Yout[7]~80\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[7]~80_combout\ = (\YMS1[0]~input_o\ & (\YMS1[1]~input_o\)) # (!\YMS1[0]~input_o\ & ((\YMS1[1]~input_o\ & ((\L_33|I0\(7)))) # (!\YMS1[1]~input_o\ & (\L_54|I1\(7)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110010011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YMS1[0]~input_o\,
	datab => \YMS1[1]~input_o\,
	datac => \L_54|I1\(7),
	datad => \L_33|I0\(7),
	combout => \TM6|Yout[7]~80_combout\);

-- Location: LCCOMB_X78_Y9_N12
\TM6|Yout[7]~81\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM6|Yout[7]~81_combout\ = (\YMS1[0]~input_o\ & ((\TM6|Yout[7]~80_combout\ & (\v3[7]~input_o\)) # (!\TM6|Yout[7]~80_combout\ & ((\L_33|I1\(7)))))) # (!\YMS1[0]~input_o\ & (((\TM6|Yout[7]~80_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \v3[7]~input_o\,
	datab => \YMS1[0]~input_o\,
	datac => \L_33|I1\(7),
	datad => \TM6|Yout[7]~80_combout\,
	combout => \TM6|Yout[7]~81_combout\);

-- Location: LCCOMB_X78_Y9_N30
\TM7|I0[7]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM7|I0\(7) = (GLOBAL(\TTS~inputclkctrl_outclk\) & ((\TM6|Yout[7]~81_combout\))) # (!GLOBAL(\TTS~inputclkctrl_outclk\) & (\TM7|I0\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM7|I0\(7),
	datac => \TTS~inputclkctrl_outclk\,
	datad => \TM6|Yout[7]~81_combout\,
	combout => \TM7|I0\(7));

-- Location: LCCOMB_X78_Y7_N8
\L_6|I3[7]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I3\(7) = (GLOBAL(\L_6|Equal0~0clkctrl_outclk\) & ((\L_6|I3\(7)))) # (!GLOBAL(\L_6|Equal0~0clkctrl_outclk\) & (\TM7|I0\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM7|I0\(7),
	datac => \L_6|I3\(7),
	datad => \L_6|Equal0~0clkctrl_outclk\,
	combout => \L_6|I3\(7));

-- Location: LCCOMB_X75_Y7_N26
\L_6|I3[8]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I3\(8) = (GLOBAL(\L_6|Equal0~0clkctrl_outclk\) & ((\L_6|I3\(8)))) # (!GLOBAL(\L_6|Equal0~0clkctrl_outclk\) & (\TM7|I0\(8)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM7|I0\(8),
	datac => \L_6|I3\(8),
	datad => \L_6|Equal0~0clkctrl_outclk\,
	combout => \L_6|I3\(8));

-- Location: LCCOMB_X79_Y7_N16
\L_6|I3[9]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I3\(9) = (GLOBAL(\L_6|Equal0~0clkctrl_outclk\) & (\L_6|I3\(9))) # (!GLOBAL(\L_6|Equal0~0clkctrl_outclk\) & ((\TM7|I0\(9))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \L_6|I3\(9),
	datac => \TM7|I0\(9),
	datad => \L_6|Equal0~0clkctrl_outclk\,
	combout => \L_6|I3\(9));

-- Location: LCCOMB_X76_Y6_N30
\L_6|I3[10]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I3\(10) = (GLOBAL(\L_6|Equal0~0clkctrl_outclk\) & (\L_6|I3\(10))) # (!GLOBAL(\L_6|Equal0~0clkctrl_outclk\) & ((\TM7|I0\(10))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_6|I3\(10),
	datac => \TM7|I0\(10),
	datad => \L_6|Equal0~0clkctrl_outclk\,
	combout => \L_6|I3\(10));

-- Location: LCCOMB_X71_Y11_N22
\L_6|I3[11]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I3\(11) = (GLOBAL(\L_6|Equal0~0clkctrl_outclk\) & ((\L_6|I3\(11)))) # (!GLOBAL(\L_6|Equal0~0clkctrl_outclk\) & (\TM7|I0\(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM7|I0\(11),
	datac => \L_6|I3\(11),
	datad => \L_6|Equal0~0clkctrl_outclk\,
	combout => \L_6|I3\(11));

-- Location: LCCOMB_X78_Y7_N22
\L_6|I3[12]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I3\(12) = (GLOBAL(\L_6|Equal0~0clkctrl_outclk\) & (\L_6|I3\(12))) # (!GLOBAL(\L_6|Equal0~0clkctrl_outclk\) & ((\TM7|I0\(12))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_6|I3\(12),
	datac => \TM7|I0\(12),
	datad => \L_6|Equal0~0clkctrl_outclk\,
	combout => \L_6|I3\(12));

-- Location: LCCOMB_X76_Y6_N16
\L_6|I3[13]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I3\(13) = (GLOBAL(\L_6|Equal0~0clkctrl_outclk\) & (\L_6|I3\(13))) # (!GLOBAL(\L_6|Equal0~0clkctrl_outclk\) & ((\TM7|I0\(13))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_6|Equal0~0clkctrl_outclk\,
	datac => \L_6|I3\(13),
	datad => \TM7|I0\(13),
	combout => \L_6|I3\(13));

-- Location: LCCOMB_X76_Y15_N26
\L_6|I3[14]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I3\(14) = (GLOBAL(\L_6|Equal0~0clkctrl_outclk\) & (\L_6|I3\(14))) # (!GLOBAL(\L_6|Equal0~0clkctrl_outclk\) & ((\TM7|I0\(14))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \L_6|I3\(14),
	datac => \TM7|I0\(14),
	datad => \L_6|Equal0~0clkctrl_outclk\,
	combout => \L_6|I3\(14));

-- Location: LCCOMB_X76_Y6_N26
\L_6|I3[15]\ : cycloneiv_lcell_comb
-- Equation(s):
-- \L_6|I3\(15) = (GLOBAL(\L_6|Equal0~0clkctrl_outclk\) & ((\L_6|I3\(15)))) # (!GLOBAL(\L_6|Equal0~0clkctrl_outclk\) & (\TM7|I0\(15)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \TM7|I0\(15),
	datac => \L_6|I3\(15),
	datad => \L_6|Equal0~0clkctrl_outclk\,
	combout => \L_6|I3\(15));

-- Location: LCCOMB_X71_Y7_N24
\TM8|I4[0]~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM8|I4[0]~0_combout\ = (!\YTPD_S2[1]~input_o\ & (\YTPD_S2[2]~input_o\ & (\TM7|I1\(0) & !\YTPD_S2[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPD_S2[1]~input_o\,
	datab => \YTPD_S2[2]~input_o\,
	datac => \TM7|I1\(0),
	datad => \YTPD_S2[0]~input_o\,
	combout => \TM8|I4[0]~0_combout\);

-- Location: LCCOMB_X76_Y4_N24
\TM8|I4[1]~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM8|I4[1]~1_combout\ = (\YTPD_S2[2]~input_o\ & (!\YTPD_S2[0]~input_o\ & (!\YTPD_S2[1]~input_o\ & \TM7|I1\(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPD_S2[2]~input_o\,
	datab => \YTPD_S2[0]~input_o\,
	datac => \YTPD_S2[1]~input_o\,
	datad => \TM7|I1\(1),
	combout => \TM8|I4[1]~1_combout\);

-- Location: LCCOMB_X76_Y4_N22
\TM8|I4[2]~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM8|I4[2]~2_combout\ = (\YTPD_S2[2]~input_o\ & (!\YTPD_S2[0]~input_o\ & (\TM7|I1\(2) & !\YTPD_S2[1]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPD_S2[2]~input_o\,
	datab => \YTPD_S2[0]~input_o\,
	datac => \TM7|I1\(2),
	datad => \YTPD_S2[1]~input_o\,
	combout => \TM8|I4[2]~2_combout\);

-- Location: LCCOMB_X71_Y7_N22
\TM8|I4[3]~3\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM8|I4[3]~3_combout\ = (\TM7|I1\(3) & (\YTPD_S2[2]~input_o\ & (!\YTPD_S2[1]~input_o\ & !\YTPD_S2[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM7|I1\(3),
	datab => \YTPD_S2[2]~input_o\,
	datac => \YTPD_S2[1]~input_o\,
	datad => \YTPD_S2[0]~input_o\,
	combout => \TM8|I4[3]~3_combout\);

-- Location: LCCOMB_X71_Y7_N20
\TM8|I4[4]~4\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM8|I4[4]~4_combout\ = (\TM7|I1\(4) & (\YTPD_S2[2]~input_o\ & (!\YTPD_S2[1]~input_o\ & !\YTPD_S2[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM7|I1\(4),
	datab => \YTPD_S2[2]~input_o\,
	datac => \YTPD_S2[1]~input_o\,
	datad => \YTPD_S2[0]~input_o\,
	combout => \TM8|I4[4]~4_combout\);

-- Location: LCCOMB_X71_Y7_N6
\TM8|I4[5]~5\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM8|I4[5]~5_combout\ = (\TM7|I1\(5) & (\YTPD_S2[2]~input_o\ & (!\YTPD_S2[1]~input_o\ & !\YTPD_S2[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM7|I1\(5),
	datab => \YTPD_S2[2]~input_o\,
	datac => \YTPD_S2[1]~input_o\,
	datad => \YTPD_S2[0]~input_o\,
	combout => \TM8|I4[5]~5_combout\);

-- Location: LCCOMB_X71_Y7_N12
\TM8|I4[6]~6\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM8|I4[6]~6_combout\ = (\TM7|I1\(6) & (\YTPD_S2[2]~input_o\ & (!\YTPD_S2[1]~input_o\ & !\YTPD_S2[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM7|I1\(6),
	datab => \YTPD_S2[2]~input_o\,
	datac => \YTPD_S2[1]~input_o\,
	datad => \YTPD_S2[0]~input_o\,
	combout => \TM8|I4[6]~6_combout\);

-- Location: LCCOMB_X71_Y7_N18
\TM8|I4[7]~7\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM8|I4[7]~7_combout\ = (\TM7|I1\(7) & (\YTPD_S2[2]~input_o\ & (!\YTPD_S2[1]~input_o\ & !\YTPD_S2[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM7|I1\(7),
	datab => \YTPD_S2[2]~input_o\,
	datac => \YTPD_S2[1]~input_o\,
	datad => \YTPD_S2[0]~input_o\,
	combout => \TM8|I4[7]~7_combout\);

-- Location: LCCOMB_X73_Y14_N8
\TM8|I4[8]~8\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM8|I4[8]~8_combout\ = (\YTPD_S2[2]~input_o\ & (!\YTPD_S2[0]~input_o\ & (\TM7|I1\(8) & !\YTPD_S2[1]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPD_S2[2]~input_o\,
	datab => \YTPD_S2[0]~input_o\,
	datac => \TM7|I1\(8),
	datad => \YTPD_S2[1]~input_o\,
	combout => \TM8|I4[8]~8_combout\);

-- Location: LCCOMB_X76_Y4_N16
\TM8|I4[9]~9\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM8|I4[9]~9_combout\ = (\YTPD_S2[2]~input_o\ & (!\YTPD_S2[0]~input_o\ & (\TM7|I1\(9) & !\YTPD_S2[1]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPD_S2[2]~input_o\,
	datab => \YTPD_S2[0]~input_o\,
	datac => \TM7|I1\(9),
	datad => \YTPD_S2[1]~input_o\,
	combout => \TM8|I4[9]~9_combout\);

-- Location: LCCOMB_X76_Y4_N14
\TM8|I4[10]~10\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM8|I4[10]~10_combout\ = (\YTPD_S2[2]~input_o\ & (!\YTPD_S2[0]~input_o\ & (!\YTPD_S2[1]~input_o\ & \TM7|I1\(10))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPD_S2[2]~input_o\,
	datab => \YTPD_S2[0]~input_o\,
	datac => \YTPD_S2[1]~input_o\,
	datad => \TM7|I1\(10),
	combout => \TM8|I4[10]~10_combout\);

-- Location: LCCOMB_X71_Y7_N8
\TM8|I4[11]~11\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM8|I4[11]~11_combout\ = (\TM7|I1\(11) & (\YTPD_S2[2]~input_o\ & (!\YTPD_S2[1]~input_o\ & !\YTPD_S2[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM7|I1\(11),
	datab => \YTPD_S2[2]~input_o\,
	datac => \YTPD_S2[1]~input_o\,
	datad => \YTPD_S2[0]~input_o\,
	combout => \TM8|I4[11]~11_combout\);

-- Location: LCCOMB_X71_Y7_N30
\TM8|I4[12]~12\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM8|I4[12]~12_combout\ = (\TM7|I1\(12) & (\YTPD_S2[2]~input_o\ & (!\YTPD_S2[1]~input_o\ & !\YTPD_S2[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM7|I1\(12),
	datab => \YTPD_S2[2]~input_o\,
	datac => \YTPD_S2[1]~input_o\,
	datad => \YTPD_S2[0]~input_o\,
	combout => \TM8|I4[12]~12_combout\);

-- Location: LCCOMB_X76_Y4_N28
\TM8|I4[13]~13\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM8|I4[13]~13_combout\ = (\YTPD_S2[2]~input_o\ & (!\YTPD_S2[0]~input_o\ & (\TM7|I1\(13) & !\YTPD_S2[1]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPD_S2[2]~input_o\,
	datab => \YTPD_S2[0]~input_o\,
	datac => \TM7|I1\(13),
	datad => \YTPD_S2[1]~input_o\,
	combout => \TM8|I4[13]~13_combout\);

-- Location: LCCOMB_X73_Y14_N30
\TM8|I4[14]~14\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM8|I4[14]~14_combout\ = (\TM7|I1\(14) & (!\YTPD_S2[0]~input_o\ & (\YTPD_S2[2]~input_o\ & !\YTPD_S2[1]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \TM7|I1\(14),
	datab => \YTPD_S2[0]~input_o\,
	datac => \YTPD_S2[2]~input_o\,
	datad => \YTPD_S2[1]~input_o\,
	combout => \TM8|I4[14]~14_combout\);

-- Location: LCCOMB_X76_Y4_N6
\TM8|I4[15]~15\ : cycloneiv_lcell_comb
-- Equation(s):
-- \TM8|I4[15]~15_combout\ = (\YTPD_S2[2]~input_o\ & (!\YTPD_S2[0]~input_o\ & (\TM7|I1\(15) & !\YTPD_S2[1]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \YTPD_S2[2]~input_o\,
	datab => \YTPD_S2[0]~input_o\,
	datac => \TM7|I1\(15),
	datad => \YTPD_S2[1]~input_o\,
	combout => \TM8|I4[15]~15_combout\);

ww_Op1(0) <= \Op1[0]~output_o\;

ww_Op1(1) <= \Op1[1]~output_o\;

ww_Op1(2) <= \Op1[2]~output_o\;

ww_Op1(3) <= \Op1[3]~output_o\;

ww_Op1(4) <= \Op1[4]~output_o\;

ww_Op1(5) <= \Op1[5]~output_o\;

ww_Op1(6) <= \Op1[6]~output_o\;

ww_Op1(7) <= \Op1[7]~output_o\;

ww_Op1(8) <= \Op1[8]~output_o\;

ww_Op1(9) <= \Op1[9]~output_o\;

ww_Op1(10) <= \Op1[10]~output_o\;

ww_Op1(11) <= \Op1[11]~output_o\;

ww_Op1(12) <= \Op1[12]~output_o\;

ww_Op1(13) <= \Op1[13]~output_o\;

ww_Op1(14) <= \Op1[14]~output_o\;

ww_Op1(15) <= \Op1[15]~output_o\;

ww_Op2_1(0) <= \Op2_1[0]~output_o\;

ww_Op2_1(1) <= \Op2_1[1]~output_o\;

ww_Op2_1(2) <= \Op2_1[2]~output_o\;

ww_Op2_1(3) <= \Op2_1[3]~output_o\;

ww_Op2_1(4) <= \Op2_1[4]~output_o\;

ww_Op2_1(5) <= \Op2_1[5]~output_o\;

ww_Op2_1(6) <= \Op2_1[6]~output_o\;

ww_Op2_1(7) <= \Op2_1[7]~output_o\;

ww_Op2_1(8) <= \Op2_1[8]~output_o\;

ww_Op2_1(9) <= \Op2_1[9]~output_o\;

ww_Op2_1(10) <= \Op2_1[10]~output_o\;

ww_Op2_1(11) <= \Op2_1[11]~output_o\;

ww_Op2_1(12) <= \Op2_1[12]~output_o\;

ww_Op2_1(13) <= \Op2_1[13]~output_o\;

ww_Op2_1(14) <= \Op2_1[14]~output_o\;

ww_Op2_1(15) <= \Op2_1[15]~output_o\;

ww_Op2_2(0) <= \Op2_2[0]~output_o\;

ww_Op2_2(1) <= \Op2_2[1]~output_o\;

ww_Op2_2(2) <= \Op2_2[2]~output_o\;

ww_Op2_2(3) <= \Op2_2[3]~output_o\;

ww_Op2_2(4) <= \Op2_2[4]~output_o\;

ww_Op2_2(5) <= \Op2_2[5]~output_o\;

ww_Op2_2(6) <= \Op2_2[6]~output_o\;

ww_Op2_2(7) <= \Op2_2[7]~output_o\;

ww_Op2_2(8) <= \Op2_2[8]~output_o\;

ww_Op2_2(9) <= \Op2_2[9]~output_o\;

ww_Op2_2(10) <= \Op2_2[10]~output_o\;

ww_Op2_2(11) <= \Op2_2[11]~output_o\;

ww_Op2_2(12) <= \Op2_2[12]~output_o\;

ww_Op2_2(13) <= \Op2_2[13]~output_o\;

ww_Op2_2(14) <= \Op2_2[14]~output_o\;

ww_Op2_2(15) <= \Op2_2[15]~output_o\;
END structure;


