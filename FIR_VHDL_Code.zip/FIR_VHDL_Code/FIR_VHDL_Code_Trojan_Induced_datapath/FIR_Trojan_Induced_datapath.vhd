Library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;

entity FIR_Trojan_Induced_datapath is
Port (K0,K1,K2,K3,K4,K5,K6,K7,K8,K9,K10,K11,K12,K13,K14,K15,K16,K17,K18,K19,K20 : in std_logic_vector(15 downto 0);--primary inputs
		RMS,RDS : IN STD_logic_vector(3 downto 0);--selection lines for 16x1/1x16 demux of red register
		GMS,GDS,BMS,BDS,BRMS,BRDS : in std_logic_vector(1 downto 0);--selection lines for 4x1/1x4 mux/demux of green,blue,brownn registers
		LBMS,LBDS,TMS,TDS,SMS,SDS : in std_logic;--selection lines for 2x1/1x2 mux/demux of light-blue,tan,silver registers
		RR,GR,BR,BRR,LBR,TR,SR,PR,VR,KR,LGR,GOR,GRR,AR,OLR,BLR,ORR,BER,IR,MR,LOR : in std_logic;--register enable pin for all registers
		RTMS,RTDS : in std_logic_vector(3 downto 0);--selection line for trojan path 16x1/1x16 mux/demux of red register
		TTMS,TTDS,KTMS,KTDS : in std_logic_vector(1 downto 0);--selection line for trojan path 4x1/1x4 mux/demux of tan and khanki registers
		BTMS,BTDS,PTMS,PTDS : std_logic;--selection line for trojan path 2x1/1x2 mux/demux of blue and pink registers
		TTS : in std_logic;--selection line for trojan triggered 2x1/1x2 mux/demux
		L1,L2,L3,L4,L5,L6,L7,L8,L9 : in std_logic;--latch enable pin
		A1S1,A1S2,A1S3 : in std_logic_vector(3 downto 0);--selection line(muLiplexer) for 16x1/1x16 mux/demux of A1 adders
		M1S1,M1S2,M1S3,M2S1,M2S2,M2S3 : in std_logic_vector(2 downto 0);--selection line(multiplexer) for 8x1/1x8 mux/demux of M1,M2 multipliers		
		OP1_1,OP1_2 : out std_logic_vector(15 downto 0));--final output
end FIR_Trojan_Induced_datapath;

architecture Structural of FIR_Trojan_Induced_datapath is

component Adder is
Port (A,B : in std_logic_vector(15 downto 0);
		O : out std_logic_vector (15 downto 0));
end component;

component Multiplier is
Port (A,B : in std_logic_vector(15 downto 0);
		O : out std_logic_vector (15 downto 0));
end component;

component MUX_2x1 is
Port (I0,I1 : in std_logic_vector(15 downto 0);
	   S : in std_logic;
		Yout : out std_logic_vector(15 downto 0));
end component;

component MUX_4x1 is
Port(I0,I1,I2,I3 : in std_logic_vector(15 downto 0);
	  S : in std_logic_vector(1 downto 0);
	  Yout : out std_logic_vector(15 downto 0));
end component;

component MUX_8x1 is
Port(I0,I1,I2,I3,I4,I5,I6,I7 : in std_logic_vector(15 downto 0);
	  S : in std_logic_vector(2 downto 0);
	  Yout : out std_logic_vector(15 downto 0));
end component;

component MUX_16x1 is
Port(I0,I1,I2,I3,I4,I5,I6,I7,I8,I9,I10,I11,I12,I13,I14,I15 : in std_logic_vector(15 downto 0);
	  S : in std_logic_vector(3 downto 0);
	  Yout : out std_logic_vector(15 downto 0));
end component;

component DEMUX_1x2 is
Port(Yin : in std_logic_vector(15 downto 0);
	  S : in std_logic;
	  I0,I1: out std_logic_vector(15 downto 0));
end component;

component DEMUX_1x4 is
Port (Yin: in std_logic_vector(15 downto 0);
		S : in std_logic_vector(1 downto 0);
		I0,I1,I2,I3 : out std_logic_vector(15 downto 0));
end component;

component DEMUX_1x8 is
Port (Yin : in std_logic_vector(15 downto 0);
		S : in std_logic_vector(2 downto 0);
		I0,I1,I2,I3,I4,I5,I6,I7 : out std_logic_vector(15 downto 0));
end component;

component DEMUX_1x16 is
Port (Yin : in std_logic_vector(15 downto 0);
		S : in std_logic_vector(3 downto 0);
		I0,I1,I2,I3,I4,I5,I6,I7,I8,I9,I10,I11,I12,I13,I14,I15 : out std_logic_vector(15 downto 0));
end component;

component Register_bh is
port (Rin : in std_logic_vector(15 downto 0);
		Ren : in std_logic;
		Ro : out std_logic_vector(15 downto 0));
end component;

component Latch_bh is
port (Lin : in std_logic_vector(15 downto 0);
		Len : in std_logic;
		Lo : out std_logic_vector(15 downto 0));
end component;

Signal s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12,s13,s14,s15,s16,s17,s18,s19,s20,s21,s22,s23,s24,s25,s26,s27,s28,s29,s30,s31,s32,s33,s34,s35,s36,s37,s38,s39,s40,s41,s42,s43,s44,s45,s46,s47,s48,s49,s50,s51,s52,s53,s54,s55,s56,s57,s58,s59,s60,s61,s62,s63,s64,s65,s66,s67,s68,s69,s70,s71,s72,s73,s74,s75,s76,s77,s78,s79,s80,s81,s82,s83,s84,s85,s86,s87,s88,s89,s90,s91,s92,s93,s94,s95,s96,s97,s98,s99,s100,s101,s102,s103,s104,s105,s106,s107,s108,s109,s110,s111,s112,s113,s114,s115,s116,s117,s118,s119,s120 : std_logic_vector(15 downto 0);
Signal s18_1,s18_2,s22_1,s22_2,s23_1,s23_2,s24_1,s24_2,s25_1,s25_2,s26_1,s26_2,s27_1,s27_2,s28_1,s28_2,s44_1,s44_2,s46_1,s46_2,s66_1,s66_2,s67_1,s67_2,s77_1,s77_2,s84_1,s84_2 : std_logic_vector(15 downto 0);
Signal f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13,f14,f15,f16,f17,f18,f19,f20,f21,f22,f23,f24,f25,f26,f27,f28,f29,f30,f31,f32,f33,f34,f35,f36,f37,f38,f39,f40,f41,f42,f43,f44,f45,f46,f47,f48,f49,f50,f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61,f62,f63,f64,f65,f66,f67,f68 : std_logic_vector(15 downto 0);--free signal pins

begin

s18 <= s18_1 or s18_2;
s22 <= s22_1 or s22_2;
s23 <= s23_1 or s23_2;
s24 <= s24_1 or s24_2;
s25 <= s25_1 or s25_2;
s26 <= s26_1 or s26_2;
s27 <= s27_1 or s27_2;
s28 <= s28_1 or s28_2;
s44 <= s44_1 or s44_2;
s46 <= s46_1 or s46_2;
s66 <= s66_1 or s66_2;
s67 <= s67_1 or s67_2;
s77 <= s77_1 or s77_2;
s84 <= s84_1 or s84_2;

-------------Red register-------------
L_1:MUX_16x1 port map(I0=>K0,I1=>s1,I2=>s2,I3=>s3,I4=>s4,I5=>s5,I6=>s6,I7=>s7,I8=>s8,I9=>s9,I10=>s10,I11=>s11,I12=>f1,I13=>f2,I14=>f3,I15=>f4,S=>RMS,Yout=>s12);
L_2:MUX_16x1 port map(I0=>K0,I1=>s4,I2=>s5,I3=>s6,I4=>s7,I5=>s8,I6=>s9,I7=>s10,I8=>s11,I9=>f5,I10=>f6,I11=>f7,I12=>f8,I13=>f9,I14=>f10,I15=>f11,S=>RTMS,Yout=>s13);--Trojan path mux
L_3:MUX_2x1 port map(I0=>s12,I1=>s13,S=>TTS,Yout=>s14);--Trojan triggered mux
L_4:Register_bh port map(Rin=>s14,Ren=>RR,Ro=>s15);
L_5:DEMUX_1x2 port map(Yin=>s15,S=>TTS,I0=>s16,I1=>s17);--Trojan triggered demux
L_6:DEMUX_1x16 port map(Yin=>s16,S=>RDS,I0=>s18_1,I1=>s19,I2=>s20,I3=>s21,I4=>s22_1,I5=>s23_1,I6=>s24_1,I7=>s25_1,I8=>s26_1,I9=>s27_1,I10=>s28_1,I11=>OP1_1,I12=>f12,I13=>f13,I14=>f14,I15=>f15);
L_7:DEMUX_1x16 port map(Yin=>s17,S=>RTDS,I0=>s18_2,I1=>s22_2,I2=>s23_2,I3=>s24_2,I4=>s25_2,I5=>s26_2,I6=>s27_2,I7=>s28_2,I8=>OP1_2,I9=>f16,I10=>f17,I11=>f18,I12=>f19,I13=>f20,I14=>f21,I15=>f22);--Trojan path demux
-------------Green register-------------
L_8:MUX_4x1 port map(I0=>K1,I1=>s29,I2=>s30,I3=>f23,S=>GMS,Yout=>s31);
L_9:Register_bh port map(Rin=>s31,Ren=>GR,Ro=>s32);
L_10:DEMUX_1x4 port map(Yin=>s32,S=>GDS,I0=>s33,I1=>s34,I2=>s35,I3=>f24);
-------------Blue register-------------
L_11:MUX_4x1 port map(I0=>K2,I1=>s36,I2=>s37,I3=>f25,S=>BMS,Yout=>s38);
L_12:MUX_2x1 port map(I0=>K2,I1=>s37,S=>BTMS,Yout=>s39);--Trojan path mux
L_13:MUX_2x1 port map(I0=>s38,I1=>s39,S=>TTS,Yout=>s40);--Trojan triggered mux
L_14:Register_bh port map(Rin=>s40,Ren=>BR,Ro=>s41);
L_15:DEMUX_1x2 port map(Yin=>s41,S=>TTS,I0=>s42,I1=>s43);--Trojan triggered demux
L_16:DEMUX_1x4 port map(Yin=>s42,S=>BDS,I0=>s44_1,I1=>s45,I2=>s46_1,I3=>f26);
L_17:DEMUX_1x2 port map(Yin=>s43,S=>BTDS,I0=>s44_2,I1=>s46_2);--Trojan path demux
-------------Brown register-------------
L_18:MUX_4x1 port map(I0=>K3,I1=>s47,I2=>s48,I3=>f27,S=>BRMS,Yout=>s49);
L_19:Register_bh port map(Rin=>s49,Ren=>BRR,Ro=>s50);
L_20:DEMUX_1x4 port map(Yin=>s50,S=>BRDS,I0=>s51,I1=>s52,I2=>s53,I3=>f28);
-------------Light-blue register-------------
L_21:MUX_2x1 port map(I0=>K4,I1=>s54,S=>LBMS,Yout=>s55);
L_22:Register_bh port map(Rin=>s55,Ren=>LBR,Ro=>s56);
L_23:DEMUX_1x2 port map(Yin=>s56,S=>LBDS,I0=>s57,I1=>s58);
-------------Tan register-------------
L_24:MUX_2x1 port map(I0=>K5,I1=>s59,S=>TMS,Yout=>s60);
L_25:MUX_4x1 port map(I0=>K5,I1=>s36,I2=>s59,I3=>f29,S=>TTMS,Yout=>s61);--Trojan path mux
L_26:MUX_2x1 port map(I0=>s60,I1=>s61,S=>TTS,Yout=>s62);--Trojan triggered mux
L_27:Register_bh port map(Rin=>s62,Ren=>TR,Ro=>s63);
L_28:DEMUX_1x2 port map(Yin=>s63,S=>TTS,I0=>s64,I1=>s65);--Trojan triggered demux
L_29:DEMUX_1x2 port map(Yin=>s64,S=>TDS,I0=>s66_1,I1=>s67_1);
L_30:DEMUX_1x4 port map(Yin=>s65,S=>TTDS,I0=>s66_2,I1=>s68,I2=>s67_2,I3=>f30);--Trojan path demux
-------------Silver register-------------
L_31:MUX_2x1 port map(I0=>K6,I1=>s69,S=>SMS,Yout=>s70);
L_32:Register_bh port map(Rin=>s70,Ren=>SR,Ro=>s71);
L_33:DEMUX_1x2 port map(Yin=>s71,S=>SDS,I0=>s72,I1=>s73);
-------------Pink register-------------
L_34:MUX_2x1 port map(I0=>K7,I1=>s19,S=>PTMS,Yout=>s74);--Trojan path mux
L_35:MUX_2x1 port map(I0=>K7,I1=>s74,S=>TTS,Yout=>s75);--Trojan triggered mux
L_36:Register_bh port map(Rin=>s75,Ren=>PR,Ro=>s76);
L_37:DEMUX_1x2 port map(Yin=>s76,S=>TTS,I0=>s77_1,I1=>s78);--Trojan triggered demux
L_38:DEMUX_1x2 port map(Yin=>s78,S=>PTDS,I0=>s77_2,I1=>s79);--Trojan path demux
-------------Violet register-------------
L_39:Register_bh port map(Rin=>K8,Ren=>VR,Ro=>s80);
-------------Khaki register-------------
L_40:MUX_4x1 port map(I0=>K9,I1=>s20,I2=>s21,I3=>f31,S=>KTMS,Yout=>s81);--Trojan path mux
L_41:MUX_2x1 port map(I0=>K9,I1=>s81,S=>TTS,Yout=>s82);--Trojan triggered mux
L_42:Register_bh port map(Rin=>s82,Ren=>KR,Ro=>s83);
L_43:DEMUX_1x2 port map(Yin=>s83,S=>TTS,I0=>s84_1,I1=>s85);--Trojan triggered demux
L_44:DEMUX_1x4 port map(Yin=>s85,S=>KTDS,I0=>s84_2,I1=>s86,I2=>s87,I3=>f32);--Trojan path demux
-------------Light-green register-------------
L_45:Register_bh port map(Rin=>K10,Ren=>LGR,Ro=>s88);
-------------Golden register-------------
L_46:Register_bh port map(Rin=>K11,Ren=>GOR,Ro=>s89);
-------------Grey register-------------
L_47:Register_bh port map(Rin=>K12,Ren=>GRR,Ro=>s90);
-------------Aqua register-------------
L_48:Register_bh port map(Rin=>K13,Ren=>AR,Ro=>s91);
-------------Olive register-------------
L_49:Register_bh port map(Rin=>K14,Ren=>OLR,Ro=>s92);
-------------Black register-------------
L_50:Register_bh port map(Rin=>K15,Ren=>BLR,Ro=>s93);
-------------Orange register-------------
L_51:Register_bh port map(Rin=>K16,Ren=>ORR,Ro=>s94);
-------------Beige register-------------
L_52:Register_bh port map(Rin=>K17,Ren=>BER,Ro=>s95);
-------------Indigo register-------------
L_53:Register_bh port map(Rin=>K18,Ren=>IR,Ro=>s96);
-------------Magenta register-------------
L_54:Register_bh port map(Rin=>K19,Ren=>MR,Ro=>s97);
-------------Light-orange register-------------
L_55:Register_bh port map(Rin=>K20,Ren=>LOR,Ro=>s98);
-------------Lower Level Trojan Mux-------------
L_56:MUX_2x1 port map(I0=>s19,I1=>s79,S=>TTS,Yout=>s99);--Trojan path mux/demux
L_57:MUX_2x1 port map(I0=>s20,I1=>s86,S=>TTS,Yout=>s100);--Trojan path mux/demux
L_58:MUX_2x1 port map(I0=>s21,I1=>s87,S=>TTS,Yout=>s101);--Trojan path mux/demux
L_59:MUX_2x1 port map(I0=>s45,I1=>s68,S=>TTS,Yout=>s102);--Trojan path mux/demux
-------------Adder(A1)-------------
L_60:MUX_16x1 port map(I0=>s33,I1=>s100,I2=>s101,I3=>s22,I4=>s23,I5=>s24,I6=>s25,I7=>s26,I8=>s27,I9=>s28,I10=>f33,I11=>f34,I12=>f35,I13=>f36,I14=>f37,I15=>f38,S=>A1S1,Yout=>s103);	
L_61:Latch_bh Port Map(Lin=>s103,Len=>L1,Lo=>s104); 
L_62:MUX_16x1 port map(I0=>s99,I1=>s102,I2=>s34,I3=>s52,I4=>s46,I5=>s58,I6=>s35,I7=>s67,I8=>s53,I9=>s73,I10=>f39,I11=>f40,I12=>f41,I13=>f42,I14=>f43,I15=>f44,S=>A1S2,Yout=>s105);
L_63:Latch_bh Port Map(Lin=>s105,Len=>L2,Lo=>s106); 
L_64:Adder Port Map(A=>s104,B=>s106,O=>s107);	
L_65:Latch_bh Port Map(Lin=>s107,Len=>L3,Lo=>s108); 
L_66:DEMUX_1x16 port map(Yin=>s108,S=>A1S3,I0=>s2,I1=>s3,I2=>s4,I3=>s5,I4=>s6,I5=>s7,I6=>s8,I7=>s9,I8=>s10,I9=>s11,I10=>f45,I11=>f46,I12=>f47,I13=>f48,I14=>f49,I15=>f50);
-------------Multiplier(M1)-------------
L_67:MUX_8x1 Port Map(I0=>s18,I1=>s57,I2=>s80,I3=>s90,I4=>s94,I5=>f51,I6=>f52,I7=>f53,S=>M1S1,Yout=>s109);	
L_68:Latch_bh Port Map(Lin=>s109,Len=>L4,Lo=>s110); 
L_69:MUX_8x1 Port Map(I0=>s51,I1=>s77,I2=>s89,I3=>s93,I4=>s97,I5=>f54,I6=>f55,I7=>f56,S=>M1S2,Yout=>s111);
L_70:Latch_bh Port Map(Lin=>s111,Len=>L5,Lo=>s112); 
L_71:Multiplier Port Map(A=>s110,B=>s112,O=>s113);	
L_72:Latch_bh Port Map(Lin=>s113,Len=>L6,Lo=>s114); 
L_73:DEMUX_1x8 Port Map(Yin=>s114,S=>M1S3,I0=>s1,I1=>s29,I2=>s37,I3=>s30,I4=>s48,I5=>f57,I6=>f58,I7=>f59);
-------------Multiplier(M2)-------------
L_74:MUX_8x1 Port Map(I0=>s44,I1=>s72,I2=>s88,I3=>s92,I4=>s96,I5=>f60,I6=>f61,I7=>f62,S=>M2S1,Yout=>s115);	
L_75:Latch_bh Port Map(Lin=>s115,Len=>L7,Lo=>s116); 
L_76:MUX_8x1 Port Map(I0=>s66,I1=>s84,I2=>s91,I3=>s95,I4=>s98,I5=>f63,I6=>f64,I7=>f65,S=>M2S2,Yout=>s117);
L_77:Latch_bh Port Map(Lin=>s117,Len=>L8,Lo=>s118); 
L_78:Multiplier Port Map(A=>s116,B=>s118,O=>s119);	
L_79:Latch_bh Port Map(Lin=>s119,Len=>L9,Lo=>s120); 
L_80:DEMUX_1x8 Port Map(Yin=>s120,S=>M2S3,I0=>s36,I1=>s47,I2=>s54,I3=>s59,I4=>s69,I5=>f66,I6=>f67,I7=>f68);
end Structural;