library ieee;
use ieee.std_logic_1164.all;

entity MUX_16x1 is
Port (I0,I1,I2,I3,I4,I5,I6,I7,I8,I9,I10,I11,I12,I13,I14,I15 : in std_logic_vector(15 downto 0);
		S : in std_logic_vector(3 downto 0);
		Yout : out std_logic_vector(15 downto 0));
end MUX_16x1;

architecture behavioral of MUX_16x1 is
begin
process(I0,I1,I2,I3,I4,I5,I6,I7,I8,I9,I10,I11,I12,I13,I14,I15,S)
begin
	if(S = "0000") then
		Yout <= I0;
	elsif(S = "0001") then
		Yout <= I1;
	elsif(S = "0010") then
		Yout <= I2;	
	elsif(S = "0011") then
		Yout <= I3;
	elsif(S = "0100") then
		Yout <= I4;
	elsif(S = "0101") then
		Yout <= I5;
	elsif(S = "0110") then
		Yout <= I6;
	elsif(S <= "0111")then
		Yout <= I7;
	elsif(S = "1000") then
		Yout <= I8;
	elsif(S = "1001") then
		Yout <= I9;
	elsif(S = "1010") then
		Yout <= I10;	
	elsif(S = "1011") then
		Yout <= I11;
	elsif(S = "1100") then
		Yout <= I12;
	elsif(S = "1101") then
		Yout <= I13;
	elsif(S = "1110") then
		Yout <= I14;
	else
		Yout <= I15;
	end if;
end process;
end behavioral;