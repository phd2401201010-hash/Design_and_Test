library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;

entity Multiplier is
Port (A : in std_logic_vector(15 downto 0);
		B : in std_logic_vector(15 downto 0);
		O : out std_logic_vector(15 downto 0));
end Multiplier;

architecture behavioral of Multiplier is
signal r1,r2 : std_logic_vector(15 downto 0) := (others =>'0') ;
signal temp : std_logic_vector(31 downto 0);

begin
r1 <= A;
r2 <= B;
process(A,B) is
begin
temp <= r1 * r2;
O <= temp(15 downto 0);
end process;

end behavioral;