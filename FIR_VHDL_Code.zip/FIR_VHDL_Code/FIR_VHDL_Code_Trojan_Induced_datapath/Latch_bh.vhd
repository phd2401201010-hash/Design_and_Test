library ieee;
use ieee.std_logic_1164.all;

entity Latch_bh is
Port (Lin : in std_logic_vector(15 downto 0);
		Len : in std_logic;
		Lo : out std_logic_vector(15 downto 0));
end Latch_bh;

architecture behavioral of Latch_bh is
begin
process(Lin,Len)
begin
if(Len = '0') then
Lo <= Lin;
end if;
end process;
end behavioral;