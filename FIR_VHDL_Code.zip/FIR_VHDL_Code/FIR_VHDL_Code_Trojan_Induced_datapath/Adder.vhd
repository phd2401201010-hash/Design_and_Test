library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;

entity Adder is
Port (A : in STD_LOGIC_VECTOR(15 downto 0);
		B : in STD_LOGIC_VECTOR(15 downto 0);
		O : out STD_LOGIC_VECTOR(15 downto 0));
end Adder;

architecture dataflow of Adder is
begin
O <= A + B;
end dataflow;
