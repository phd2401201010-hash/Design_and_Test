library ieee;
use ieee.std_logic_1164.all;

entity DEMUX_1x16 is
Port (Yin : in std_logic_vector(15 downto 0);
		S : in std_logic_vector(3 downto 0);
		I0,I1,I2,I3,I4,I5,I6,I7,I8,I9,I10,I11,I12,I13,I14,I15 : out std_logic_vector(15 downto 0));
end DEMUX_1x16;

architecture behavioral of DEMUX_1x16 is
begin
process(Yin,S)
begin
	if(S = "0000")then
		I0 <= Yin;
	elsif(S = "0001")then
		I1 <= Yin;
	elsif(S = "0010")then
		I2 <= Yin;	
	elsif(S = "0011")then
		I3 <= Yin;
	elsif(S = "0100")then
		I4 <= Yin;
	elsif(S = "0101")then
		I5 <= Yin;
	elsif(S = "0110")then
		I6 <= Yin;		
	elsif(S = "0111")then
		I7 <= Yin;
	elsif(S = "1000")then
		I8 <= Yin;
	elsif(S = "1001")then
		I9 <= Yin;	
	elsif(S = "1010")then
		I10 <= Yin;	
	elsif(S = "1011")then
		I11 <= Yin;
	elsif(S = "1100")then
		I12 <= Yin;
	elsif(S = "1101")then
		I13 <= Yin;
	elsif(S = "1110")then
		I14 <= Yin;		
	else
		I15 <= Yin;
	end if;
end process;
end behavioral;